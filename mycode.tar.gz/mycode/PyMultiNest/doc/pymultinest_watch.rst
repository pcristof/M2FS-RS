Watching the progress
=======================================

This module is not necessary for most users.

.. automodule:: pymultinest.watch
      :members:
