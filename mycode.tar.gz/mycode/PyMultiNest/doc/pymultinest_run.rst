Running the sampler
===========================

.. automodule:: pymultinest.run
    :members: run

.. automodule:: pymultinest.solve
    :members: solve, Solver

