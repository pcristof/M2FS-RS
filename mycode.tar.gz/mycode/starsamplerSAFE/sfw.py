import numpy as np
import scipy.special as ss


def sfw_fprob(X, V, model_param, DM_param, context):

        r, = X
        vr, vt = V
        #theta, = A #no angle in this model

        #note: rhos = 4Pi*G*rhos = ((21/.465)(1/rs))^2 = 4229.2 (km/s)^2 (1/kpc^2)
        a,d,e, Ec, rlim, b0, b1, alp, q, Jb, = model_param
        rhos, rs, alpha, beta, gamma, = DM_param   ############this P0 or P0 above?
        P0, Plim = context

	#by constrution alp needs to be positive when b1>b0, otherwise negative.	
	if b1>b0:
		alp = abs(alp)
	else:
		alp = -1*abs(alp)

        G = 4.302*10**-6 # (kpc/m_sun) (km/s)^2

        Ps = rhos * rs**2   #unit (km/s)**2  #Vmax=0.465*sqrt(Ps)
        Pr = genphi0(r, rhos, rs, alpha, beta, gamma) - P0
                                #Ps * ( 1 - (np.log(1+x))/x )
        J  = abs(r * vt)           #J = v * r*sin(theta)
        E  = (vt*vt + vr*vr)/2.0 + Pr # v*v/2 + Pr

        Ec   = Ec * Ps
        xlim = rlim / rs #turn rlim in unit of rs
        #Plim = genphi(xlim, alpha, beta, gamma, rhos, rs) 
        Jb   = Jb * rs * (Ps**0.5) #*0.086

	'''
        if b <= 0:
                gJ = 1.0/(1 + (J/Jb)**-b)
        else:
                gJ = 1 + (J/Jb)**b
	'''
	gJ = ( (J/Jb)**(b0/alp) + (J/Jb)**(b1/alp) )**alp


        N  = 1.0*10**3

        try:
                if (len(E)>0):
                        E = E * (E<Plim) * (E>0)
                        hE = N*(E**a) * ((E**q + Ec**q)**(d/q)) * ((Plim - E)**e)
        except:
                if E < Plim and E >= 0:
                        hE = N*(E**a) * ((E**q + Ec**q)**(d/q)) * ((Plim - E)**e)
                else:
                        hE = 0.0

        return hE * gJ * r*r*vt/(rs*rs)


def sampler_input(model_param, DM_param):
	rhos, rs, alpha, beta, gamma = DM_param

        rlim = [0, model_param[4]]

        P0   = genphi0(1e-10, rhos, rs, alpha, beta, gamma)
        Plim = genphi0(rlim[1], rhos, rs, alpha, beta, gamma) - P0
	vmax = (2 * abs(Plim))**0.5

	nX = 1
	nV = 2
        context = [P0, Plim]
        vlim = [0, vmax]

	return nX, nV, context, rlim, vlim


#conditional probability at a given surface radius R, model='sfw_R'
def sfw_fRprob(X,V, model_param, DM_param, context):
        z, = X
        R, P0, Plim = context

        r2 = (z*z+R*R)
        prob = sfw_fprob([r2**.5], V, model_param, DM_param, [P0,Plim])
        prob = R*prob/r2 #if r2>0 else 0 
        return prob


def sampler_input_R(model_param, DM_param, R):
	rhos, rs, alpha, beta, gamma = DM_param

	rlim = [0, model_param[4]]

	P0   = genphi0(1e-10, rhos, rs, alpha, beta, gamma)
	PR   = genphi0(R,     rhos, rs, alpha, beta, gamma) - P0
	Plim = genphi0(rlim[1], rhos, rs, alpha, beta, gamma) - P0                
	vmax = (2 * abs(Plim - PR))**0.5

	nX = 1
	nV = 2
	context = [R, P0, Plim]
	vlim = (2 * abs(Plim - Pr0))**0.5

        return nV, context, rlim, vlim


##----------------------------------------------------
#define the general potential
def genphi0(r, rhos, rs, alpha, beta, gamma):

        if (alpha==beta and beta == gamma and gamma==99):
                return burkert_phi(r, rhos, rs)

        x = r/rs #+ 1e-10
        Ps = rhos * rs**2

        x0 = 10**-15
        alpha = alpha*1.0 #in case alpha is int 
        beta  = beta *1.0
        gamma = gamma*1.0

        #p1a = ss.hyp2f1((3.-gamma)/alpha, (beta*1.-gamma)/alpha, (3.+alpha-gamma)/alpha, -x0**alpha)
        p1b = ss.hyp2f1((3.-gamma)/alpha, (beta-gamma)/alpha, (3+alpha-gamma)/alpha,  -x**alpha)
        #I1  = ( x0**(3-gamma) * p1a - x**(3-gamma) * p1b ) / (x * (gamma - 3.))
        I1 = (0 - x**(3-gamma) * p1b ) / (x * (gamma - 3)) #to save time ignore p1a..

        p2  = ss.hyp2f1( (-2.+beta)/alpha,(beta-gamma*1.)/alpha,(-2.+alpha+beta)/alpha, -x**(-alpha))
        I2  = x**(2.-beta) * p2 / (beta -2.)
        ans1 = Ps * ( 1 - (I1 + I2) )

        return ans1

def burkert_phi(r, rhos, rb):
        x = r/rb
        Ps = rhos * rb**2
        P = (1-1./x) * (np.log(x*x+1)/4.) + (1+1./x)*0.5*(np.arctan(x) - np.log(x+1))
        #rmax = 3.245*rb
        #Vmax = 0.602*Ps**.5
        return Ps*P



def OMgenphi(r, rlim, rhos, rs, alpha, beta, gamma):
	x0 = 10**-12
        alpha = alpha*1.0 #in case alpha is int 
        beta  = beta *1.0
        gamma = gamma*1.0

	r = r-x0 #in case r=rlim.. which is not allowed by mathematica..	
	x = r/rs #+ 1e-10
        Ps = rhos * rs**2

	#p1a = ss.hyp2f1((3.-gamma)/alpha, (beta*1.-gamma)/alpha, (3.+alpha-gamma)/alpha, -x0**alpha)
	p1b = ss.hyp2f1((3.-gamma)/alpha, (beta-gamma)/alpha, (3+alpha-gamma)/alpha,  -x**alpha)
	#I1  = ( x0**(3-gamma) * p1a - x**(3-gamma) * p1b ) / (x * (gamma - 3.))
	I1 = (0 - x**(3-gamma) * p1b ) / (x * (gamma - 3)) #to save time ignore p1a..(for gamma<3 or so)

	xlim = rlim/rs
	p2a = ss.hyp2f1( (2.-gamma)/alpha,(beta-gamma*1.)/alpha,(2.+alpha-gamma)/alpha, -x**(alpha) )
	p2b = ss.hyp2f1( (2.-gamma)/alpha,(beta-gamma*1.)/alpha,(2.+alpha-gamma)/alpha, -xlim**(alpha) )
	I2  = (x**(2-gamma) * p2a - xlim**(2-gamma) * p2b) / (gamma - 2)

	ans = Ps * ( 1 - (I1 + I2) ) #why 1- ?

	return ans



