import matplotlib.pyplot as plt
import numpy as np
import star_sampler as ssp
import king as k


sigma = 10
ratio0 = 9
psi0  = (sigma**2) * ratio0

model_param = [psi0, ratio0]


#SAMPLE mock data ------------------------------------------------------------
Nstars = 1e4

#1. construct the sampler, choose your model and input parameters
ssam = ssp.Sampler(myDF = k.king_fprob, sampler_input = k.sampler_input,
                        model_param=model_param)

#2. sample the model using rejection sampling, specify filename[string] will save the output to the file
#   @params: r_vr_vt=False, r_v=False, z_vr_vt=False; setting one of them to True will activate
#   corresponding transformation to [x,y,z,vx,vy,vz] coordinates.
x1,y1,z1,vx1,vy1,vz1 = ssam.sample(sample_method='rejection', N=Nstars, filename=None, 
		r_vr_vt=False, r_v=True, z_vr_vt=False)

#3  sample the model using importance sampling, requires additional @param steps and @param rfactor.
x2,y2,z2,vx2,vy2,vz2 = ssam.sample(sample_method='impt', N = Nstars, steps = 20, rfactor = 3,
		filename=None, r_vr_vt=False, r_v=True, z_vr_vt=False)

print np.std(x1), np.std(x2)

