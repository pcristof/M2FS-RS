import matplotlib.pyplot as plt
import numpy as np

import star_sampler as ssp
import my_model as mm


#specify parameters that's needed in my_model.py
model_param = [1,-2,0]	# [a,u1,u2]
DM_param = [2,10] 	# [s1,s2]
Nstars = 5000 # number of sample points


#start with rejection sampling, specify filename will save the output to the file
#to use importance sampling, use 'impt' sample method.


#1. construct the sampler, choose your model and input parameters
ssam = ssp.Sampler(myDF=mm.my_fprob, sampler_input = mm.sampler_input,
                        model_param=model_param, DM_param=DM_param)


#2. lets start with rejection sampling, specify filename will save the output to the file
#   @params: r_vr_vt=False, r_v=False, z_vr_vt=False; setting one of them to True will activate
#   corresponding transformation to [x,y,z,vx,vy,vz] coordinates.
rej_output = ssam.sample(sample_method='rejection', N=Nstars, filename=None, r_vr_vt=False, r_v=False, z_vr_vt=False)


#3, importance sampling requires additional @param steps and @param rfactor.
impt_output = ssam.sample(sample_method='impt', N=Nstars, steps=20, rfactor=3, filename=None, r_vr_vt=False, r_v=False, z_vr_vt=False)




#plot the first sampled coordinates
plt.hist(rej_output[:,1], bins=30)
plt.hist(impt_output[:,1], bins=30)
#plt.yscale('log')
plt.show()

