from scipy.stats import gamma


# X: it's a list that should contain your position coordinate i.e. just [r] in spherical case
# V: it's a list that should contain your velocity coordinates i.e.  [vx,vy,vz] or [vr,vt]
# context: additional input that will go to your density function (my_fprob) in my_model.py 
# model_param and DM_parameter: that's
def my_fprob(X, V, model_param, DM_param, context):

	r, = X
	v1,v2 = V
	
	a,u1,u2 = model_param
	s1,s2   = DM_param

	z1 = (v1-u1)/s1
	z2 = (v2-u2)/s2


	p1 = gamma.pdf(r,a)

	return p1


# Please specify (or add lines to calculate) the following variables:
#   nV: the number of velocity coordinates in your DF defined above
#   rlim: [rmin, rmax]: the radius sample limits (where your DF goes to zero)
#   vlim: [vmin, vmax]: velocity sample limits, typically the escape velocity
#   context: if needed one can pre-compute certain quantities and put them in the @list 'context'; 
#            the list will be passed to @function my_fprob, which you can use to calculate 
#	     the probability.
def sampler_input(model_param, DM_param):

	a,u1,u2 = model_param
	s1,s2 = DM_param

	nX = 1
        nV = 2 #since we have 2 velocity coordinates v1,v2
        context = [] #can be empty
        rlim = [0, 100]
        vlim = [u1-s1*5 , u1+s1*5]

        return nX, nV, context, rlim, vlim



