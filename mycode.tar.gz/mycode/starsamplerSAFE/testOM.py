import numpy as np
import star_sampler as ssp
import osipkov_merritt as om

#DM_param = [3460*400/64., 1.0, 1., 3., 1.]
#model_param = [.25, .25, 2.,5., .1]
# rhos, rs, alpha, beta, gamma, = DM_param
# ra, rs_s, al_s, be_s, ga_s, = model_param

DM_param = [3460*40/64., 5., 1, 3.5, 1]
model_param = [1.0, 1., 2.,5., .1]

#DM_param = [3460*400/64., 1.0, 1., 3., 1.]  #.064
#model_param = [.25, .25, 2.,5., .1]

Nstars= 1e4




#1. construct the sampler, choose your model and input parameters
ssam = ssp.Sampler(myDF=om.OM_fprob, sampler_input = om.sampler_input,
                        model_param=model_param, DM_param=DM_param)

#2. lets start with rejection sampling, specify filename will save the output to the file
#   @params: r_vr_vt=False, r_v=False, z_vr_vt=False; setting one of them to True will activate
#   corresponding transformation to [x,y,z,vx,vy,vz] coordinates.
rej_output = ssam.sample(sample_method='rejection', N=Nstars, filename='out1', r_vr_vt=False, r_v=False, z_vr_vt=False)


#3, importance sampling requires additional @param steps and @param rfactor.
impt_output = ssam.sample(sample_method='impt', N=Nstars, steps=20, rfactor=3, filename='out2', r_vr_vt=True, r_v=False, z_vr_vt=False)


print rej_output
print '\n'
print impt_output
print np.shape(rej_output), np.shape(impt_output)
# sample the model using importance sampling
#x1,y1,z1,vx1,vy1,vz1 = sam1.sample(sample_method='impt', N = Nstars, steps = 20, rfactor = 3)




