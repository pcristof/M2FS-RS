import numpy as np
#import matplotlib.pyplot as plt
import random as rand
import scipy.special as ss
#import genfun2 as gfun
import time
import scipy.optimize
from scipy import integrate
import warnings
#import matplotlib as mpl
#mpl.use('Agg')


#from scipy.interpolate import interp1d
#from scipy.interpolate import InterpolatedUnivariateSpline #UnivariateSpline
#from scipy.interpolate import LSQUnivariateSpline
#from scipy.interpolate import UnivariateSpline
from scipy.interpolate import PchipInterpolator



def OM_fprob(X, V, model_param, DM_param, context):
        r, = X
        vr, vt = V
        rhos, rs, alpha, beta, gamma, = DM_param
	ra, rs_s, al_s, be_s, ga_s, = model_param
	#dfGQ, Plim, rarr, Parr = context
	#Qarr1, dfGQarr1, rarr, Parr = context
	Qarr1, dfGQarr1, Plim0, rtrunc = context	

	#Plim = gfun.genphi0(rlim, rhos, rs, alpha, beta, gamma)
	Pr = -(OMgenphi(r, rtrunc, rhos, rs, alpha, beta, gamma) )
	
	#Pr = -(gfun.genphi0(r, rhos, rs, alpha, beta, gamma) - Plim0)

        #dr = rarr[5] - rarr[4]
	#Pindex = r/dr
	#Pr = Parr[Pindex.astype(int)]

	Q  = Pr - ( vr*vr + (1+r*r/(ra*ra))*vt*vt )*0.5

	#h = 1.e-9
	#p = (dfGQ(Q+h*.5)-dfGQ(Q-h*.5))/h	
	#p = dfGQarr1(Q)
		
	try:
                if (len(Q)>0):
			Qup = Q>np.max(Qarr1)
			Qlo = Q<np.min(Qarr1)
			#Q[Qup] = Qarr1[0] # to be set to 0
			#Q[Qlo] = Qarr1[0] # to be set to 0
			#Qindex = Q/(Qarr1[1]-Qarr1[0])
			#p = dfGQarr1[Qindex.astype(int)]
			p = dfGQarr1(Q)
			p[Qup] = 0
			p[Qlo] = 0
                        p = p * (Q>0) # so that probability is zero when Q<=0
		
			#print "this p<0 - r, vr, vt, Q: ", p[p<0][0:2],  \
			#		r[p<0][0:2], vr[p<0][0:2], vt[p<0][0:2], Q[p<0][0:2]
			#print 'Q[p<0]: ', Q[p<0]
			#p[p<0] = 0
        except:
		if ( Q > np.min(Qarr1) and Q < np.max(Qarr1) ):
			#Qindex = Q/(Qarr1[1]-Qarr1[0])
               		#p = dfGQarr1[int(Qindex)]
			p = dfGQarr1(Q)
		else:
			p = 0
		#p = 0 if Q <= 0 else p
		
	#p = p * Q>np.max(Qarr1) * Q<np.min(Qarr1)

		if p< 0:
			print "this p<0 - r, vr, vt: ", p, r, vr, vt, Q
			#p = 0
	return p * r*r*vt 

def sampler_input(model_param, DM_param):
	rhos, rs, alpha, beta, gamma, = DM_param

	#num_rsteps = 1e5 should be enough of a table to approximate drho(r)/dPhi(r) 
	#num_Qsteps = 1000 should be enough to create G(Q) table to approximate f(Q)
	Qarr, dfG, Plim0, rtrunc = GQ(model_param, DM_param, num_rsteps = 1e5, num_Qsteps = 1000)
        r200 = getR200(DM_param) 

	#for truncating rho at rmax.
	Pr0 = OMgenphi(1e-8, rtrunc, rhos, rs, alpha, beta, gamma)
        Plim0 = OMgenphi(r200, rtrunc, rhos, rs, alpha, beta, gamma) * 0 #or should it be zero??

	
	#for setting potential to zero at rlim.
	#Pr0 = gfun.genphi0(1e-10, rhos, rs, alpha, beta, gamma)

	vmax = (2 * abs(Plim0 - Pr0))**0.5

	nX = 1
        nV = 2
        context = [Qarr, dfG, Plim0, rtrunc]
        rlim = [0, r200]
        vlim = [0, vmax]
	print 'r200: ', r200, rtrunc, rlim, vlim
        return nX, nV, context, rlim, vlim


def OM_fRprob(X,V,model_param, DM_param, context):
        z, = X
	#R, Qarr1, dfGQarr1, rarr, Parr = context
	R, Qarr1, dfGQarr1, Plim0 = context

        r2 = (z*z+R*R)
        prob = OM_fprob([r2**.5], V, model_param, DM_param, [Qarr1, dfGQarr1, Plim0])
        prob = R*prob/r2 #if r2>0 else 0 
        return prob


def sampler_input_R(model_param, DM_param,R):
        rhos, rs, alpha, beta, gamma, = DM_param
        #Qarr, dfG, Plim0 = GQ(model_param, DM_param)
        #context = [Qarr, dfG, Plim0]

	#num_rsteps = 1e5 should be enough of a table to approximate drho(r)/dPhi(r) 
        #num_Qsteps = 1000 should be enough to create G(Q) table to approximate f(Q)
        Qarr, dfG, Plim0, rtrunc = GQ(model_param, DM_param, num_rsteps = 1e5, num_Qsteps = 1000)
        r200 = getR200(DM_param)

        #for truncating rho at rtrunc.
	PR0  = OMgenphi(R, rtrunc, rhos, rs, alpha, beta, gamma)
        Plim0 = 0 #OMgenphi(r200, rtrunc, rhos, rs, alpha, beta, gamma)
        vmax = (2 * abs(Plim0 - PR0))**0.5

	nX = 1
        nV = 2
        rlim = [0, r200]
        vlim = [0, vmax]

        return nX, nV, context, rlim, vlim


def OMgenphi(r, rlim, rhos, rs, alpha, beta, gamma):
	#if (alpha==1 and beta == 3 and gamma==1):
	#	x = r/rs
	#	Ps = rhos * rs**2
	#        return Ps * ( 1 - (np.log(1+x))/x )

        x0 = 10**-12
        xlim = (rlim + 0) / rs
        alpha = alpha*1.0 #in case alpha is int 
        beta  = beta *1.0
        gamma = gamma*1.0

        x = r/rs #+ 1e-10
        Ps = rhos * rs**2

	x2 = x
	#change x>xlim t0 xlim
	#x_gt_xlim_indx = x>xlim
	try:
	    #if len(x2)>1:
	    x2[x2>xlim] = xlim	
	except:
	    x2 = x2 if x2<xlim else xlim

        p2a = ss.hyp2f1( (2.-gamma)/alpha,(beta-gamma*1.)/alpha, (2.+alpha-gamma)/alpha, -x2**(alpha) )
        p2b = ss.hyp2f1( (2.-gamma)/alpha,(beta-gamma*1.)/alpha, (2.+alpha-gamma)/alpha, -xlim**(alpha) )
       	I2  = (x2**(2-gamma) * p2a - xlim**(2-gamma) * p2b) / (gamma - 2)

        p1a = ss.hyp2f1((3.-gamma)/alpha, (beta*1.-gamma)/alpha, (3.+alpha-gamma)/alpha, -x0**alpha)
        p1b = ss.hyp2f1((3.-gamma)/alpha, (beta-gamma)/alpha, (3+alpha-gamma)/alpha,  -x2**alpha)
        I1  = ( x0**(3-gamma) * p1a - x2**(3-gamma) * p1b ) / ((r/rs) * (gamma - 3.))
        #I1 = (0 - x**(3-gamma) * p1b ) / (x * (gamma - 3)) #to save time ignore p1a..(for gamma<3 or so)

        ans = Ps * ( 0 - (I1 + I2) ) #why 1- ?

        return ans

def getPtrunc(rtrunc, rhos, rs, alpha, beta, gamma):
	x0 = 10**-12
        xtrunc = (rtrunc + 0) / rs
        alpha = alpha*1.0 #in case alpha is int 
        beta  = beta *1.0
        gamma = gamma*1.0
	Ps = rhos * rs**2

	p1a = ss.hyp2f1((3.-gamma)/alpha, (beta*1.-gamma)/alpha, (3.+alpha-gamma)/alpha, -x0**alpha)
        p1b = ss.hyp2f1((3.-gamma)/alpha, (beta-gamma)/alpha, (3+alpha-gamma)/alpha,  -xtrunc**alpha)
        I1  = ( x0**(3-gamma) * p1a - xtrunc**(3-gamma) * p1b ) / (xtrunc * (gamma - 3.))

	return Ps * ( 0 - I1 )



def OM_fprob1(X, V, A, model_param, DM_param, context):
        r, = X
        vr, vt = V
        rhos, rs, alpha, beta, gamma, = DM_param
        rlim, ra, rs_s, al_s, be_s, ga_s, = model_param
	Qarr, Garr, Plim = context

        Pr = -(gfun.genphi0(r, rhos, rs, alpha, beta, gamma) - Plim)
        Q  = Pr - ( vr*vr + (1+r*r/(ra*ra))*vt*vt )*0.5

	#Qm = np.matrix(Q).T

	if ( isinstance(Q, np.ndarray) ):
		ind = np.digitize(Q, bins = Qarr)
		#ind = np.sum(Qarr<Qm, axis=1)
		#ind = np.array(ind.T)[0]
	
		#for i in ind:
		#	if i==0:
		#		print min(Qarr), Q[i]

		ind[ind==len(Qarr)] = ind[ind==len(Qarr)] - 1
		ind[ind==0] = ind[ind==0] + 1
		upindex = ind
		loindex = ind-1
	else: 
		upindex = sum(Qarr<Q) if np.max(Qarr)>=Q else len(Qarr)-1 
		loindex = upindex - 1 if upindex>0 else 0
		upindex = loindex + 1

	p = (Garr[upindex] - Garr[loindex]) / (Qarr[upindex] - Qarr[loindex])
        p = p * (Q>0)

        return p * r*r*vt


#---
def OM_fprob2(X, V, A, model_param, DM_param, context):
        r, = X
        vr, vt = V
        rhos, rs, alpha, beta, gamma, = DM_param
        rlim, ra, rs_s, al_s, be_s, ga_s, = model_param
        Qarr, Garr, Plim = context

        Pr = -(gfun.genphi0(r, rhos, rs, alpha, beta, gamma) - Plim)
        Q  = Pr - ( vr*vr + (1+r*r/(ra*ra))*vt*vt )*0.5

	Qm = np.matrix(Q).T

        try:
                if (len(Q)>0):
			ind = np.sum(Qarr<Qm, axis=1)
			ind = np.array(ind.T)[0]
                        ind[ind==len(Qarr)] = ind[ind==len(Qarr)] - 1
			ind[ind==0] = ind[ind==0] + 1
			upindex = ind
                        loindex = ind-1

        except:
                upindex = sum(Qarr<Q) if np.max(Qarr)>=Q else len(Qarr)-1
                loindex = upindex - 1 if upindex>0 else 0
                upindex = loindex + 1

        p = (Garr[upindex] - Garr[loindex]) / (Qarr[upindex] - Qarr[loindex])
        p = p * (Q>0)

        return p * r*r*vt
#---

def rhoQ(rarr, rmax, ra, al_s, be_s, ga_s):
	rhos_s = 1.0
	rhoQ1 = ( (1+rarr*rarr/(ra*ra))
                  * rhos_s * ((rarr/rs_s)**-ga_s) * (1+(rarr/rs_s)**al_s)**((ga_s-be_s)/al_s) )
	return rhoQ1

#lmsx  #-------FAILURE------it's because...
def GQ(model_param, DM_param, num_rsteps = 1e5, num_Qsteps = 1000, Rs=np.array([])):
        rhos, rs, alpha, beta, gamma, = DM_param
        ra, rs_s, al_s, be_s, ga_s, = model_param
        rhos_s = 1.0

	#Parr_sorted0, frhoQ0, dfrhoQ0, GQ0, fQ0, Plim0 = GQ_1(model_param, DM_param, 
	#					num_rsteps = 1e5, num_Qsteps = 1000, Rs=Rs)


        al_s = al_s*1.0
        be_s = be_s*1.0
        ga_s = ga_s*1.0

        nsteps = 1e5

	r200   = getR200(DM_param)
        rmax   = r200*1000000
	rtrunc = r200*10 #rho cut off point..
        Plim = 0 #OMgenphi(r200, r200, rhos, rs, alpha, beta, gamma)*0 
        #Plim0 = OMgenphi(r200*100, r200*100, rhos, rs, alpha, beta, gamma)
	#Ptrunc = getPtrunc(r200, rhos, rs, alpha, beta, gamma) * 0

	#---------------we want drho/dP over large range of rarr, so use rmax----------------
        t0 = time.time()
        #   TODO###############rarr, Parr = getPhi(r200, DM_param, nsteps*1)
	rarr0 = np.linspace(1e-8, rmax*1, num_rsteps*.5)
        #rarr1 = np.linspace(1e-7, r200*.01, num_rsteps*.1)
        rarr1 = np.logspace(-4, np.log10(rmax)-0, num_rsteps*.5)
	rarr2 = np.logspace(-8, np.log10(rmax)-6, num_rsteps*.5)
        rarr = np.hstack((rarr0, rarr1, rarr2))
        rarr = np.unique(rarr)
        rarr = rarr[np.argsort(rarr)]

        Parr  = -1*(OMgenphi(rarr , rtrunc, rhos, rs, alpha, beta, gamma) ) #- PlimX + Ptrunc)
	#################
        print 'getphi time: ', time.time()-t0, r200 #, Ptrunc, Plim

        rhoQ = ( (1+rarr*rarr/(ra*ra))
                  * rhos_s * ((rarr/rs_s)**-ga_s) * (1+(rarr/rs_s)**al_s)**((ga_s-be_s)/al_s) )


        # -------- interpolate between rhoQ(r) and Phi(r) -------------------------
	rhoQ_sorted = rhoQ[np.argsort(Parr)]
        Parr_sorted = Parr[np.argsort(Parr)]
        Parr_sorted, Pindx = np.unique(Parr_sorted, return_index=True)
        rhoQ_sorted = rhoQ_sorted[Pindx]

        t0 = time.time()
        frhoQ  = PchipInterpolator(Parr_sorted, rhoQ_sorted, extrapolate=False)
        dfrhoQ = frhoQ.derivative()
        print "interpolate time:  ",  time.time()-t0

	minP = min(Parr_sorted)
	maxP = max(Parr_sorted)
	minP0 = min(Parr_sorted)
        maxP0 = max(Parr_sorted)
	print "Phi ranges: ", [minP, maxP], [minP0, maxP0]
	plot=0	

	if plot:
		plt.plot(Parr_sorted, rhoQ_sorted, label = 'rhosQ vs Phi')	
		plt.plot(Parr_sorted, dfrhoQ(Parr_sorted), label='dRhoQ/dPhi')	
		#plt.plot(Parr_sorted0, dfrhoQ0(Parr_sorted0), label='from GQ_1')
		#plt.plot(Parr_sorted0, dfrhoQ0(Parr_sorted0-Plim0), label='from GQ_1 P-Plim0')
		plt.yscale('log')
		plt.legend(loc="lower right")
		plt.show()
	

	#  TODO
        #rarr1 = np.linspace(1e-9, r200*1-1e-10, 1000) #np.hstack((range3,range2,range1))
	#rarr1 = np.logspace(1e-7, np.log10(rmax), 1000)
        #Qarr  = -1*( OMgenphi(rarr1, rtrunc, rhos, rs, alpha, beta, gamma) ) #- Plim + Ptrunc)

        #Qarr = Qarr[np.argsort(Qarr)]
	#Qarr = np.linspace(1e-9, max(Parr_sorted), 1000)

	#-------- calculate G(Q) -------------------------------------------------------
	#Qarr = np.linspace(0, maxP, 10000)
        def G_integrand(u, Q):
	    #if u<maxP and u>minP:
            phi = Q-u*u
            return -2 * dfrhoQ(phi) 
	    #else:
	    #	return 0

	#print 'min max Q and P: ', min(Qarr), max(Qarr), minP, maxP

        t0 = time.time()
	'''
	Gi_old = 0  #to make negative probability (ie. dG/dQ < 0) == 0.
        Garr = []
        i=0
        for Q in Qarr:
                Gi = integrate.quad(G_integrand, Q**.5, 0, args=(Q,))[0]
		#Gi = integrate.romberg(G_integrand, Q**.5, 0, args=(Q,), vec_func=True)
                Gi = Gi if Gi>= Gi_old else Gi_old
                #print i, "doing Q Gi: ", Q, Gi
                Garr.append(Gi)
                Gi_old = Gi
                i=i+1
	'''
	Qmax = Plim - OMgenphi(Rs, rtrunc, rhos, rs, alpha, beta, gamma) #gfun.genphi0(Rs, rhos, rs, alpha, beta, gamma)
	rarrZ = np.logspace(-5, np.log10(r200)+5, int(num_Qsteps*.35))
        QarrZ  = -1*(OMgenphi(rarrZ , rtrunc, rhos, rs, alpha, beta, gamma) - Plim )
	Qarr0 = Qmax
	Qarr1 = np.linspace(0, max(Parr_sorted)*1, int(num_Qsteps*.65))
        Qarr = np.hstack((Qarr1, Qarr0, QarrZ))
        Qarr = np.unique(Qarr)
        Qarr = Qarr[np.argsort(Qarr)]


	Garr = [integrate.quad(G_integrand, Q**.5, 0, args=(Q,), full_output=1)[0]
                for Q in Qarr]

        Garr = np.nan_to_num( np.array(Garr) )
        print '------integrate time: ', time.time()-t0

        #------------ interpolate Qarr and Garr to get f(Q) ----------------------
        GQ = PchipInterpolator(Qarr, Garr, extrapolate=False)
	print "GQ200: ", GQ(200), 'Qmin max: ', [min(Qarr)]
	
        fQ = GQ.derivative()
	fQarr = fQ(Qarr)

	#--------------------------check if unphysical-------------------
	numQ = 20000
        Qtest = np.linspace(0, max(Qarr)*1, numQ)
        fQtest = fQ(Qtest)
        num_neg_fQ = sum(fQtest<0)
        neg_Q_fraction = num_neg_fQ / (numQ*1.)
        if neg_Q_fraction > 0.0001: #len(neg_fQ) > len(Qarr)*.01:
                print 'This model could be unphysical! please double check'
                print 'model_param = ', model_param
                print 'DM_param = ', DM_param, '\n'
                #return Qarr, fGQ, -99  #means this model is unphysical
                #rmax = -99
	#--------------------end check ----------------------------------

	plot=0
        if plot:
	  #plt.plot(Parr_sorted, dfrhoQ(Parr_sorted), marker='+', label='dRhoQ/dPhi')	
          plt.plot(Qarr, Garr, marker = '.', label='G(Q)')
          plt.plot(Qarr, GQ(Qarr))
	  #plt.plot(Qarr, GQ0(Qarr), label='G0(Q)')

          plt.plot(Qarr, fQ(Qarr), marker='.', label='f(Q)')
	  #plt.plot(Qarr, fQ0(Qarr), marker='.', label='f0(Q)')
	  #plt.plot(Qarr, fQ0(Qarr-Plim0), marker='.', label='f0(Q+Plim0)')
          #plt.xscale('log')
          plt.xlabel('Q')
          #plt.ylabel('f(Q)')
	  plt.legend(loc='lower right')
          plt.yscale('log')
          plt.show()

        #return Qarr, GQ, rmax #Qarr, dfGQ, Plim, rmax #Qarr1, dfGQ, Plim, rmax
	return Qarr, fQ, Plim, rtrunc


#lmsx #make sure OM_fprob and sample_input have appropriate genphi0 
def GQ_1(model_param, DM_param, num_rsteps = 1e5, num_Qsteps = 1000, Rs=np.array([])):
	rhos, rs, alpha, beta, gamma, = DM_param
	ra, rs_s, al_s, be_s, ga_s, = model_param
	rhos_s = 1.0
	
	al_s = al_s*1.0
	be_s = be_s*1.0
	ga_s = ga_s*1.0

	
	#Plim = gfun.genphi0(rlim, rhos, rs, alpha, beta, gamma)
	r200 = getR200(DM_param)*100 # essentially rlim
	Plim = gfun.genphi0(r200, rhos, rs, alpha, beta, gamma)
	P0 = gfun.genphi0(1e-8, rhos, rs, alpha, beta, gamma)
	Ptrunc = getPtrunc(r200, rhos, rs, alpha, beta, gamma) *0

	print 'P0-Plim_1: ', [P0,Plim]
	t0 = time.time()

	rarr0 = np.linspace(1e-8, r200*1, num_rsteps*.5)	
	#rarr1 = np.linspace(1e-7, r200*.01, num_rsteps*.1)
	rarr1 = np.logspace(-8, np.log10(r200)-0, num_rsteps*.5)
	#rarr2 = np.logspace(-8, np.log10(r200)-4, num_rsteps*.5)
	rarr = np.hstack((rarr0, rarr1))
	rarr = np.unique(rarr)
	rarr = rarr[np.argsort(rarr)]

	#rarr = np.logspace(1e-8, np.log10(r200)+1, nsteps) #Will give incorrect sampling
	Parr  = -1*( gfun.genphi0(rarr, rhos, rs, alpha, beta, gamma) - Plim)
	'''
	Parr1 = -1*( gfun.genphi0(rarr1, rhos, rs, alpha, beta, gamma) - Plim)
	plt.plot(rarr, Parr)
	plt.plot(rarr1,Parr1, marker='.')	
	plt.yscale('log')
	plt.show()
	'''
	#print 'getphi time: ', time.time()-t0, Plim


	rhoQ = ( (1+rarr*rarr/(ra*ra)) 
		  * rhos_s * ((rarr/rs_s)**-ga_s) * (1+(rarr/rs_s)**al_s)**((ga_s-be_s)/al_s) )
	#rhoQ[rarr>r200] = 0 #chopping off is bad if rarr_max > r200...	
	
	#frP = PchipInterpolator(Parr[::-1], rarr[::-1], extrapolate=True)
	def rhoP(P):
		r = frP(P)
		rhoQP = ( (1+r*r/(ra*ra))
                  * rhos_s * ((r/rs_s)**-ga_s) * (1+(r/rs_s)**al_s)**((ga_s-be_s)/al_s) )
		return rhoQP

	#Parr1 = ( Parr[1:len(Parr)-1] + Parr[0:len(Parr)-2] ) * 0.5
	#drho_dP = (rhoQ[1:len(rhoQ)-1]-rhoQ[0:len(rhoQ)-2]) / (Parr[1:len(Parr)-1]-Parr[0:len(Parr)-2])

	#for interpolator use only
	#Parr_sorted = Parr[::-1]
	#rhoQ_sorted = rhoQ[::-1]
	rhoQ_sorted = rhoQ[np.argsort(Parr)]
	Parr_sorted = Parr[np.argsort(Parr)]	
	Parr_sorted, Pindx = np.unique(Parr_sorted, return_index=True)
        rhoQ_sorted = rhoQ_sorted[Pindx]

	#-------------------------------------
	t0 = time.time()
	frhoQ = PchipInterpolator(Parr_sorted, rhoQ_sorted, extrapolate=False)
	dfrhoQ = frhoQ.derivative()
	#print "rhoQ0, interpolate time:  ", frhoQ(0), min(Parr_sorted), time.time()-t0
	plot=0
        if plot:
                plt.plot(Parr_sorted, rhoQ_sorted, label = 'rhosQ vs Phi')
                plt.plot(Parr_sorted, dfrhoQ(Parr_sorted), label='dRhoQ/dPhi')
                plt.yscale('log')
                plt.legend(loc="lower right")
                plt.show()


	dr = rarr[11] - rarr[10]

	#Doing that will cause uneven distribution of Q to calculate G(Q), cause resolution problem
	#but sometimes better than linear?
	#r1arr = np.linspace(1e-9, r200*1-1e-10, nG) 
	#Qarr  = -1*(gfun.genphi0(r1arr, rhos, rs, alpha, beta, gamma) - Plim ) #lms
	#Qarr = Qarr[np.argsort(Qarr)]

	#rr = Rs*Rs
	#RR = Rs*Rs
	Qmax = Plim - gfun.genphi0(Rs, rhos, rs, alpha, beta, gamma)
	#g_rR = ra*ra/((ra*ra+rr)*(ra*ra+rr-RR))**.5
	#Phir = Phir[np.argsort(Phir)] #- 0.5*(rara+rr)*vzi*vzi/(rara+rr-RR)
	#Qmax = Phir[-50:]
	#print Qmax

	# this put more points at high Q values [corresponds to small r]
	rarrZ = np.logspace(-7, np.log10(r200)-0, int(num_Qsteps*.35))
	QarrZ  = -1*(gfun.genphi0(rarrZ, rhos, rs, alpha, beta, gamma) - Plim )

	Qarr0 = Qmax
	Qarr1 = np.linspace(0, max(Parr_sorted)*1, int(num_Qsteps*.65))
	#Qarr2 = np.linspace(max(Parr_sorted)*.9801, max(Parr_sorted), int(num_Qsteps*.35))
	Qarr = np.hstack((Qarr1, Qarr0, QarrZ))
	Qarr = np.unique(Qarr)
	Qarr = Qarr[np.argsort(Qarr)]
	
	##TEST
	#Qarr  = -1*(OMgenphi(r1arr, r200, rhos, rs, alpha, beta, gamma))	


	#Qarr1 = np.linspace(min(Qarr), max(Qarr), nsteps*1)
	#uarr = (Qarr - 0)**.5

	#ss.seterr(other='ignore')
	#print 'ranges: ', min(Qarr), max(Qarr), min(Qarr1), max(Qarr1)
	def G_integrand(u, Q):
		phi = Q-u*u
		#h = .001
		#result = ( rhoP(phi+h) - rhoP(phi-h) ) / (2.0*h)
		#phi_upindex = sum(Parr<phi)
		#phi_upindex = 1 if phi_upindex==0 else phi_upindex
		#phi_upindex = len(Parr)-1 if phi_upindex==len(Parr) else phi_upindex
		return -2 * dfrhoQ(phi) #drho_dP[phi_upindex-1] #dfrhoQ(phi)

	#to supress the integration warning.
	warnings.filterwarnings('ignore', category=integrate.IntegrationWarning)


	#QarrA = Qarr[:int(len(Qarr)*.5)]
	QarrB = Qarr #[int(len(Qarr)*.5):]
	Gi_old = 0
	t0 = time.time()
	Garr_trapz = []
	#Garr_trapz = []
        i=0
        #for Q in Qarr:
	#	Gx = np.linspace(Q**.5, 0, 1000)
	#	Gy = G_integrand(Gx, Q)
	#	Gi = integrate.trapz(Gy, Gx)
	#	Garr_trapz.append(Gi)
	#	print Gi

	'''
	for Q in QarrB:
                Gi = integrate.quad(G_integrand, Q**.5, 0, args=(Q,), full_output=1)[0]
                #print i, "doing Q Gi: ", Q, Gi
                #Gi = Gi if Gi>= Gi_old else Gi_old
                Garr.append(Gi)
                #Gi_old = Gi
                #i=i+1
	'''

	Garr = [integrate.quad(G_integrand, Q**.5, 0, args=(Q,), full_output=1)[0] 
		for Q in Qarr]

        Garr = np.nan_to_num( np.array(Garr) )

	#print '------integrate time: ', time.time()-t0

	fGQ = PchipInterpolator(Qarr, Garr, extrapolate=False)
	#fGQ_trapz = PchipInterpolator(Qarr, Garr_trapz, extrapolate=False)
        dfGQ = fGQ.derivative()
	fQarr = dfGQ(Qarr)

	#neg_fQ_indx = len(fQarr[fQarr>0]) - 1
	#neg_Qmax = Qarr[neg_fQ_indx]
	#neg_Q_fraction = (max(Qarr) - neg_Qmax) / max(Qarr)
	#print 'NEG Qmax: ', neg_Qmax, max(Qarr), neg_Q_fraction

	fQ_neg_indx = np.argwhere(fQarr<0)
	if len(fQ_neg_indx)>2:
            Q_neg_min = Qarr[min(fQ_neg_indx)]
            Q_neg_max = Qarr[max(fQ_neg_indx)]
            gap_neg_frac = (Q_neg_max - Q_neg_min) / max(Qarr)
	    if gap_neg_frac > 0.01: #len(neg_fQ) > len(Qarr)*.01:
		print 'This model could be unphysical!'
		print 'model_param = ', model_param
                print 'DM_param = ', DM_param, '\n'
		#return Qarr, fGQ, -99  #means this model is unphysical
		r200 = -99

		fdir = '/physics2/maoshenl/multinest_runs/om_LLcalk/gaia_4k_LLcalk_core_plum+rs_001negGap2_test/'
		fig = mpl.pyplot.figure()
		ax = fig.add_subplot(111)
		ax.plot(Qarr, Garr, marker='.')
                ax.plot(Qarr, dfGQ(Qarr), marker='.')
                ax.set_yscale('log')
                ax.set_xlabel('Q')  
                ax.set_ylabel('f(Q)')	
		fig.savefig(fdir + 'unphys_plot/ra%d_rss%d_rhos%d_rs%d_al%d_be%d_ga%d.png'
                        %(ra*1000, rs_s*1000, np.log10(rhos)*1000, rs*1000, 
                        alpha*1000, beta*1000, gamma*1000))

		'''
		mpl.pyplot.plot(Qarr, Garr, marker='.')
		mpl.pyplot.plot(Qarr, dfGQ(Qarr), marker='.')
		mpl.pyplot.yscale('log')
		mpl.pyplot.xlabel('Q')	
		mpl.pyplot.ylabel('f(Q)')
		#rhos, rs, alpha, beta, gamma, = DM_param
        	#ra, rs_s, al_s, be_s, ga_s, = model_param
		mpl.pyplot.savefig("./unphys_plot/ra%d_rss%d_rhos%d_rs%d_al%d_be%d_ga%d.png"
			%(ra*1000, rs_s*1000, np.log10(rhos)*1000, rs*1000, 
			alpha*1000, beta*1000, gamma*1000))
		mpl.pyplot.close()
		'''

        #Qarr1 = np.linspace(min(Qarr), max(Qarr), nsteps)
        #dfGQarr1 = dfGQ(Qarr1)

	#rhoU = frhoQ(Qarr) #-2 * ( frhoQ(0) - frhoQ(uarr) )
	#frhoU = PchipInterpolator(uarr, rhoU, extrapolate=True)
	#rhoU_Q = -2*( frhoU(0) - frhoU(Qarr**.5) ) #/ (2. * Qarr**.5)
	#frhoU_Q = PchipInterpolator(Qarr, rhoU_Q, extrapolate=True)
	#dfrhoU_Q = frhoU_Q.derivative()
	
	#tile at the Q=0 for f(Q) can be resolved by defining potential=0 at larger r, 
	#note that num_rsteps also needs to be increased to keep the right resolution
	plot=1
	if plot:
	  plt.plot(Qarr, Garr, marker='.')
	  #plt.plot(Qarr, Garr_trapz, marker='x', color='y')
	  plt.plot(Qarr, dfGQ(Qarr), marker='.')	
	  plt.yscale('log')
	  #plt.xscale('log')
	  plt.xlabel('Q')
	  plt.ylabel('f(Q)')
	  
	  #plt.plot(Qarr1, dfGQ(Qarr1), marker='.')
	  #plt.plot(Qarr2, dfGQ(Qarr2), marker='*')
	  #plt.plot(QarrZ, dfGQ(QarrZ), marker='o', color='g')
	  
	  plt.show()
	
	#return Qarr, fGQ, r200 #dfGQ, Plim, r200
	return Parr_sorted, frhoQ, dfrhoQ, fGQ, dfGQ, Plim



def getPhi(rlim, DM_param, steps = 500):

	rlim = rlim*1
	rhos, rs, alpha, beta, gamma, = DM_param

	r0 = 1e-13
	rarr = np.linspace(r0, rlim, steps*1)
	#rarr2= np.linspace(r0, rlim*10, steps*5)

	#r200 = getR200(DM_param)
        Plim = OMgenphi(rlim, rlim, rhos, rs, alpha, beta, gamma)*1
	Ptrunc = getPtrunc(rlim, rhos, rs, alpha, beta, gamma) * (+0)
	Parr  = -1*(OMgenphi(rarr , rlim, rhos, rs, alpha, beta, gamma)	- Plim*1 + Ptrunc)
	#Parr2 = -1*(OMgenphi(rarr2, rlim, rhos, rs, alpha, beta, gamma) - Plim*1 + Ptrunc)

	#Plim2 = gfun.genphi0(rlim, rhos, rs, alpha, beta, gamma)
        #Parr2 = -1*(gfun.genphi0(rarr, rhos, rs, alpha, beta, gamma)   - 1*Plim2)
	#print "Plim1,2: ", Plim, Plim2
	#Pr = interp1d(rarr, Parr, kind='cubic')
	#rP = interp1d(Parr, rarr, kind='cubic')

	#rarr2 = np.linspace(.0001, rlim, 200)
	#Parr2 = -1*(gfun.genphi0(rarr2, rhos, rs, alpha, beta, gamma)     - Plim)
	#plt.plot(rarr2, Pr(rarr2)-Parr2)

	#plt.plot(rarr2, Parr2)
	#plt.plot(rarr, Parr, 'r')
	#plt.show()

	return rarr, Parr

def SigR(R, model_param, DM_param):
	ra, rs_s, al_s, be_s, ga_s, = model_param
	rhos_s = 1
	
	r200 = getR200(DM_param)
	rlim = 1000000*r200

	if R>rlim:
		rlim = np.inf
		print 'SigR, R > rlim = r200*10, set rlim=np.inf', R, rlim

	def SigR_integrand(r):
		if r<=R: 
			return 0

		s = r/rs_s  
		rhoL = rhos_s*(s**-ga_s) * (1+s**al_s)**((ga_s-be_s)/al_s)
		aux = r/(r*r-R*R)**.5
		return rhoL*aux
	
	ans = 2 * integrate.quad(SigR_integrand, R, rlim*1, points=[R,])[0]
	'''
	if ans<0:
		return 0
		#ans = integrate.romberg(SigR_integrand, R, rlim, show=False)
		#x = np.linspace(R,rlim, 10000)
		#y = SigR_integrand(x)
		#y_int = integrate.trapz(y, x)
		#ans = y_int
	'''
	return ans, rlim


def SigR3(R, model_param, DM_param, trapz = False, trapzN=1000, rlim=1):
        ra, rs_s, al_s, be_s, ga_s, = model_param
        rhos_s = 1  #also setting rhos_s in VP3 to be zero

        r200 = getR200(DM_param)
        #rlim = 10*r200

        if R>rlim:
                #rlim = 10*R
                print 'SigR, R > rlim = lim, set rlim=10*R', R, rlim
		return 0

        def SigR_integrand(u):
		rr = u*u + R*R
		r  = rr**.5 

		if not trapz:
                    if r<R: # not singular, don't need it anymore?
                        return 0

                s = r/rs_s
		ww = u*u/(rs_s*rs_s)
		XX = R*R/(rs_s*rs_s)		

                rhoL = rhos_s*((ww+XX)**(-ga_s/2.)) * (1+(ww+XX)**(al_s/2.))**((ga_s-be_s)/al_s)
                #aux = r/(r*r-R*R)**.5
                return rhoL #*aux

	ans=1
	ulim = ((rlim*rlim-R*R)**.5)*1
	if not trapz:
	        ans = 2 * integrate.quad(SigR_integrand, 0, ulim*1)[0]

	if ans<0 or trapz:
                #x = np.linspace(0,ulim, 100000)
		x = np.logspace(-10,np.log10(ulim), trapzN)
                y = SigR_integrand(x)
                ans = 2 * integrate.trapz(y, x)
		#ans = 2 * integrate.simps(y, x)
        return ans, ulim


def SigR_trapz(R, model_param, DM_param, trapzN=1000, rlim=1):
	return SigR3(R, model_param, DM_param, trapz = True, trapzN=trapzN, rlim=rlim)


#r = R/cos(theta) substituion, seems to work worse
def SigR2(R, model_param, DM_param):
        ra, rs_s, al_s, be_s, ga_s, = model_param
        rhos_s = 1

        def SigR_integrand(theta):
	
		r = R/np.cos(theta)
                if r<R:
                        return 0
                #r = r+1e-8 #lms
                s = r/rs_s
                rhoL = rhos_s*(s**-ga_s) * (1+s**al_s)**((ga_s-be_s)/al_s)
                aux = R/(np.cos(theta))**2 #r/(r*r-R*R)**.5
                return rhoL*aux

	t1 = 0
	t2 = np.pi/2. #np.arccos(R/rlim)  #or pi/2 (rlim=inf)?
        ans = 2 * integrate.quad(SigR_integrand,t1,t2)[0]
        return ans




def OMVP_fprob(X, V, A, model_param, DM_param, context):
        R, = X
        vz, = V
        rhos, rs, alpha, beta, gamma, = DM_param
        ra, rs_s, al_s, be_s, ga_s, = model_param
        fGQ, = context

	return VP(R,vz, model_param, DM_param, fGQ)


def VP(R,vz, model_param, DM_param, fGQ):
	if R<0:
		print "R<0", R
		return 0.0
	rhos, rs, alpha, beta, gamma, = DM_param
        ra, rs_s, al_s, be_s, ga_s, = model_param

	#Plim = gfun.genphi0(rlim, rhos, rs, alpha, beta, gamma)
	r200 = getR200(DM_param)
	rlim = r200*10
        Plim = gfun.genphi0(r200*10, rhos, rs, alpha, beta, gamma)

	#There shouldn't be any stars that has R>rlim for this set of model
	if R>rlim:
		return 0.0
		print "R-rlim: ", R, rlim

	RR  = R*R 
	rara= ra*ra

	def VP_integrand(r):
		if r<R: 
			return 0
		rr  = r*r + 0e-1 #lms
		Phir = Plim - gfun.genphi0(r, rhos, rs, alpha, beta, gamma)
		g_rR = rara/((rara+rr)*(rara+rr-RR))**.5
		Qmax = Phir - 0.5*(rara+rr)*vz*vz/(rara+rr-RR)
		if Qmax < 00:
			return 0
		GQmax = fGQ(Qmax)
		if GQmax < 0:
                        return 0
		integrand = r*g_rR*GQmax/(rr-RR)**.5
		return integrand

	sigR, rlimR = SigR(R, model_param, DM_param)
	if sigR>0:
		vp_int = integrate.quad(VP_integrand,R, rlimR*1)[0]
		#print 'sigR vpint: ', sigR, vp_int
		if vp_int<0:
			vp_int = integrate.quad(VP_integrand,R, np.inf)[0]
			print 'REDO vp_int..', vp_int
		ans = (2**.5/(np.pi*sigR)) * vp_int #integrate.quad(VP_integrand,R,rlim)[0]
		#ans = integrate.quad(VP_integrand,R,rlim)[0]
	else:
		print 'sigR < 0', R, sigR
		print 'model_param = ', model_param
                print 'DM_param = ', DM_param, '\n'
		return 0

	if ans>1:
		print '>1: Ri, vzi, sigR, VP = ', [R, vz, sigR, ans] #sigR
		print 'model_param = ', model_param
		print 'DM_param = ', DM_param, '\n'
		return 0
	if ans<0:
                print 'NEG: Ri, vzi, sigR, VP = ', [R, vz, sigR, ans] #sigR
                print 'model_param = ', model_param 
		print 'DM_param = ', DM_param, '\n'
                return 0	

        return ans 

#transformation got rid of singularity, but integration still not very good...
def VP3(R,vz, model_param, DM_param, fGQ):
        if R<0:
                print "R<0", R
                return 0.0
        rhos, rs, alpha, beta, gamma, = DM_param
        ra, rs_s, al_s, be_s, ga_s, = model_param

        #Plim = gfun.genphi0(rlim, rhos, rs, alpha, beta, gamma)
        r200 = getR200(DM_param)
        rlim = r200*10
        Plim = gfun.genphi0(r200*10, rhos, rs, alpha, beta, gamma)

        #There shouldn't be any stars that has R>rlim for this set of model
        if R>rlim:
                return 0.0
                print "R-rlim: ", R, rlim

        RR  = R*R
        rara= ra*ra

        def VP_integrand(u):
		rr = (u*u+R*R)
                r  = rr**.5 

                Phir = Plim - gfun.genphi0(r, rhos, rs, alpha, beta, gamma)
                #g_rR = rara/((rara+rr)*(rara+rr-RR))**.5
                #Qmax = Phir - 0.5*(rara+rr)*vz*vz/(rara+rr-RR)
		g_rR = rara/((rara+u*u+RR)*(rara+u*u))**.5
		Qmax = Phir - 0.5*(rara+u*u+RR)*vz*vz/(rara+u*u)

		try:
		    if len(u)>1:
			Qmax_lt_0 = Qmax<0
			Qmax[Qmax_lt_0] = 0
	
	                GQmax = fGQ(Qmax)
			GQmax_lt_0 = GQmax < 0
			GQmax[GQmax_lt_0] = 0
			
			integrand = g_rR * GQmax
                	return integrand

		except:
			if Qmax < 0:
                        	return 0
                        GQmax = fGQ(Qmax)
                        if GQmax < 0:
                        	return 0
                        integrand = g_rR * GQmax
                        return integrand
		'''	
		if Qmax < 0:
                       return 0
                GQmax = fGQ(Qmax)
                if GQmax < 0:
                       return 0
                integrand = g_rR * GQmax
                return integrand
		'''
	
	#ulimR = (rlim*rlim-R*R)**.5
	#sigR = 1
        sigR, ulimR = SigR3(R, model_param, DM_param)
        if sigR>0:
                vp_int = integrate.quad(VP_integrand,0, ulimR*1)[0]
		#print '3R vpint: ', sigR, vp_int
                if vp_int<0:
			sigR, ulimR = SigR3(R, model_param, DM_param, trapz=True)
                        #vp_int = integrate.quad(VP_integrand,R, np.inf, points=[R])[0]
			x = np.logspace(-10,np.log10(ulimR), 1000)
                	y = VP_integrand(x)
        	        vp_int = integrate.trapz(y, x)
                        print 'trapz vp_int..', sigR, vp_int
                ans = (2**.5/(np.pi*sigR)) * vp_int #integrate.quad(VP_integrand,R,rlim)[0]
                #ans = integrate.quad(VP_integrand,R,rlim)[0]
        else:
                print 'sigR < 0', R, sigR
                print 'model_param = ', model_param
                print 'DM_param = ', DM_param, '\n'
                return 0

        if ans>1:
                print '>1: Ri, vzi, sigR, VP = ', [R, vz, sigR, ans] #sigR
                print 'model_param = ', model_param
                print 'DM_param = ', DM_param, '\n'
                return 0
        if ans<0:
                print 'NEG: Ri, vzi, sigR, VP = ', [R, vz, sigR, ans] #sigR
                print 'model_param = ', model_param
                print 'DM_param = ', DM_param, '\n'
                return 0

        return ans

#very fast, simple trapz rule..
def VP_trapz(R,vz, model_param, DM_param, fGQ, trapzN = 1000, rlim=1):
        if R<0 or R>rlim:
		#print 'Model unphysical: ', rlim
                #print "R<0 or R>rlim: ", R, model_param, DM_param
                return 0.0

        rhos, rs, alpha, beta, gamma, = DM_param
        ra, rs_s, al_s, be_s, ga_s, = model_param

        #Plim = gfun.genphi0(rlim, rhos, rs, alpha, beta, gamma)
        r200 = getR200(DM_param)
        #rlim = r200*10
        Plim = gfun.genphi0(rlim, rhos, rs, alpha, beta, gamma)


        RR  = R*R
        rara= ra*ra

	def VP_integrand(u):
                rr = (u*u+R*R)
                r  = rr**.5

                Phir = Plim - gfun.genphi0(r, rhos, rs, alpha, beta, gamma)
                g_rR = rara/((rara+u*u+RR)*(rara+u*u))**.5
                Qmax = Phir - 0.5*(rara+u*u+RR)*vz*vz/(rara+u*u)

		#if True:
                Qmax_lt_0 = Qmax<0  # integrant should return zero if so
                Qmax[Qmax_lt_0] = 0

                GQmax = fGQ(Qmax)
                GQmax_lt_0 = GQmax < 0
                GQmax[GQmax_lt_0] = 0 #set it to zero if negative
		GQmax[Qmax_lt_0]  = 0 #Qmax lt zero, so it has to be zero
			
                integrand = g_rR * GQmax
                return integrand

	sigR, ulimR = SigR_trapz(R, model_param, DM_param, trapzN=trapzN, rlim=rlim)
        x = np.logspace(-10,np.log10(ulimR), trapzN)
        y = VP_integrand(x)
        vp_int = integrate.trapz(y, x)
	#vp_int = integrate.simps(y, x)
        #print 'trapz sigR vp_int..', sigR, vp_int
        ans = (2**.5/(np.pi*sigR)) * vp_int

	if sigR < 0:
                print 'sigR < 0', R, sigR
                print 'model_param = ', model_param
                print 'DM_param = ', DM_param, '\n'
                return 0

	if ans>1:
                print '>1: Ri, vzi, sigR, VP = ', [R, vz, sigR, ans] #sigR
                print 'model_param = ', model_param
                print 'DM_param = ', DM_param, '\n'
                return 0
        if ans<0:
                print 'NEG: Ri, vzi, sigR, VP = ', [R, vz, sigR, ans] #sigR
                print 'model_param = ', model_param
                print 'DM_param = ', DM_param, '\n'
                return 0

	return ans

def losvdisp(R, model_param, DM_param):
	ra, rs_s, al_s, be_s, ga_s, = model_param
	rhos, rs, al, be, ga, = DM_param
        rhos_s = 1
	G = 4.302*10**-6 #kpc/M_sun * (km/s)^2
	al = al*1.0

	r200 = getR200(DM_param) * 10
	norm = SigR(R, model_param, DM_param)
	if norm<=0:
		return 0

	def los_integrand(r):
		u = r/R
		ua = ra/R

		uaua = ua*ua
		uu = u*u
		Ku = ( (uaua+0.5)/(1+uaua)**1.5 * (uu+uaua)/u * np.arctan2((uu-1)**.5,(uaua+1)**.5) 
			- 1.0 * 0.5*(1-1.0/uu)**.5/(uaua+1) )

		s = r/rs_s
		rhoL = rhos_s*(s**-ga_s) * (1+s**al_s)**((ga_s-be_s)/al_s) 

		x0 = 1e-13
		auxx = r/rs
		p1_a = ss.hyp2f1((3.-ga)/al, (be-ga)/al, (3+al-ga)/al, -x0**al)
       		p1_b = ss.hyp2f1((3.-ga)/al,(be-ga)/al,(3.+al-ga)/al, -auxx**al)
		#note: rhos = 4Pi*G*rhos = ((21/.465)(1/rs))^2 = 4229.2 (km/s)^2 (1/kpc^2)
		Mr = rhos * ( x0**(3.-ga) * p1_a - auxx**(3.-ga) * p1_b ) / ((ga - 3.))

		return Ku * rhoL * Mr / r

	norm0, rlim = norm
	ans = 2 * integrate.quad(los_integrand,R,rlim)[0] / norm0
	ans = ans * (ans>0)
	return ans**.5

def getR200(DM_param):
	rhos, rs, al, be, ga, = DM_param

	G = 4.302*10**-6 #kpc/M_sun * (km/s)^2
	H = .072 #km/s / kpc
	rho_c = 3*H*H/(8*np.pi*G)

	def F(r):
		M200 = (4*np.pi/3.0) * r**3 * rho_c * 200.

		x0 = 1e-10
        	auxx = r/rs
        	p1_a = ss.hyp2f1((3.-ga)/al, (be-ga)/al, (3+al-ga)/al, -x0**al)
       		p1_b = ss.hyp2f1((3.-ga)/al,(be-ga)/al,(3.+al-ga)/al, -auxx**al)
        	#note: rhos = 4Pi*G*rhos = ((21/.465)(1/rs))^2 = 4229.2 (km/s)^2 (1/kpc^2)
        	Mr = (rhos/G) * ( x0**(3.-ga) * p1_a - auxx**(3.-ga) * p1_b ) / ((ga - 3.))

		return Mr-M200

	r200 = scipy.optimize.broyden1(F, [100.], f_tol=1e-1)[0]
	#r200 = scipy.optimize.excitingmixing(F, [1.], f_tol=1e-0)[0]

	#print F(r200), (4*np.pi/3.0) * r200**3 * rho_c

	return r200 * 1

def ommax(model_param, DM_param, context):

	#to find max of the function
        def aux_fprob(x1,x2,x3):
		result = OM_fprob([x1], [x2,x3], [], model_param, DM_param, context)
                return result
	
	optvar = scipy.optimize.fmin(lambda (x1,x2,x3): -aux_fprob(x1,x2,x3), (0.1,0.1,0.1))

        fmax = 1.05 * OM_fprob(optvar[0:1], optvar[1:3], [], model_param, DM_param, context)

	return fmax


def OM_sample(DM_param, model_param, samplesize, steps = 1000):
	rhos, rs, alpha, beta, gamma, = DM_param
	ra, rs_s, al_s, be_s, ga_s, = model_param

	r200 = getR200(DM_param)
	rlim = r200 #lms
	Plim = gfun.genphi0(r200, rhos, rs, alpha, beta, gamma)
	P0 = gfun.genphi0(1e-8, rhos, rs, alpha, beta, gamma)

	t0 = time.time()

	#Sample Q
        #build step function
        Qarr1, dfGQarr1, rarr, Parr = GQ(model_param, DM_param)
        Qarr0 = np.linspace(min(Qarr1),Plim-P0, steps)
	#Pri = Qarr0[-2] #Plim-P0 #2730 #Qarr0[-1]-8 ##out
	#Qmax_index = sum(Qarr0<Pri) ##out
        #Qarr0 = Qarr0[:(Qmax_index+1)] ##out
	#Qarr0[-1] = Pri
        Qprob_arr0 = dfGQarr1(Qarr0) #* (2*(Pri-Qarr0)*(1))**.5 #Careful! need to take ( )**.5 out
	#Qprob_arr0 = np.nan_to_num(Qprob_arr0)
        dQ = Qarr0[1]-Qarr0[0]
	
	'''
        Qprob_proposal = []
        for i in xrange(len(Qarr0)-1):
                Qprob_proposal.append( max(Qprob_arr0[i], Qprob_arr0[i+1]) )
	Q_max, fQ_max = Qprob_max(dfGQarr1, Pri)
	Qmax_index = sum(Qarr0<Q_max)
        Qprob_proposal = np.array(Qprob_proposal)
	Qprob_proposal[Qmax_index-1] = fQ_max * 1.05 #if fQ_max<10*Qprob_proposal[Qmax_index-1] else Qprob_proposal[Qmax_index-1]
	print "Pri Q_max: ",Pri, Q_max, fQ_max 

	norm_Qprob_proposal = Qprob_proposal/np.sum(Qprob_proposal)
	Qarr2 = np.linspace(1e-10,Pri, 10000)
	#print "Qprob_proposal: ", Qprob_proposal	
	plt.plot(Qarr0[:-1], Qprob_proposal)
	plt.plot(Qarr2, dfGQarr1(Qarr2) * np.nan_to_num((2*(Pri-Qarr2))**.5) )
	plt.yscale('log')
	plt.show()
	'''

	#sample r
        #build step function
	rarr = np.linspace(1e-10,rlim, steps)
	rprob_arr = rprobability(model_param, rarr)
	dr = rarr[1]-rarr[0]
        rprob_proposal = []
        for i in xrange(len(rarr)-1):
                rprob_proposal.append( max(rprob_arr[i], rprob_arr[i+1]) )

	r_max, fr_max = rprob_max(model_param)
	rmax_index = sum(rarr<r_max)
	print 'max_index: ', rmax_index, r_max, fr_max, max(rprob_proposal)
        rprob_proposal = np.array(rprob_proposal)
	rprob_proposal[rmax_index-1] = fr_max * 1.05
	norm_rprob_proposal = rprob_proposal/np.sum(rprob_proposal)

	#rarr2 = np.linspace(1e-10,rlim, 10000)
	#rprob_arr2 = rprobability(model_param, rarr2)
	#plt.plot(rarr2, rprob_arr2)
	#plt.plot(rarr[:-1], rprob_proposal)
	#plt.yscale('log')
        #plt.show()

	r200 = getR200(DM_param)
	vmax = (2 * (max(Parr)-min(Parr)))**0.5

	N = 0
	r_list  = []
	vr_list = []
	vt_list = []
	if (True): 
	    j=0
	    computeN = 0
	    acceptN = 0
	    r_accept=[]
	    num  = samplesize
            auxN = samplesize
            eff = 1.0	
	    while(True):
			anxN = int(auxN/eff)
			if (auxN > 1e7):
	                        auxN = 1e7
			#sampling from proposal
	        	rindex = np.random.choice(np.arange(len(rprob_proposal)), 
						  size=auxN,p=norm_rprob_proposal)
	        	ux = rarr[rindex] + np.random.rand(auxN)*dr
			fproposal = rprob_proposal[rindex]
		
			uf = rprobability(model_param, ux)
			u = np.random.rand(auxN)
			accept_index = ( (uf/fproposal)>u )
			r_accept.append( ux[accept_index] )
	
			acceptN += np.sum(accept_index)
	                computeN += auxN
	                eff = acceptN/(computeN*1.0)
	                eff = eff if eff>0 else .01		
			#print 'sample r', j, computeN, acceptN
			j = j+1
			if (acceptN >= samplesize):
	                        break
	                auxN = samplesize - acceptN

	    rsamples = np.hstack(r_accept)[0:samplesize]
	    #print "rsample <1e-3??  -- ", rsamples[rsamples<1e-3]
            #samplearr = np.vstack((rsamples,rsamples,rsamples))
	    #samplearr = np.swapaxes(samplearr,0,1)
            #return gfun.r_vr_vt_complete(samplearr)	
	
	    j =0
	    null_count = 0 
	    vr_samples = []
	    vt_samples = []
	    r_samples = []
	    for ri in rsamples:
		Pri = -(gfun.genphi0(ri, rhos, rs, alpha, beta, gamma) - Plim)
		Qmax = Pri
		accept = False
		num_guess=1
		if (True):
			##Sample Q
        		#Qarr = np.linspace(min(Qarr1),Qmax, steps) #out
			#Qprob_arr = dfGQarr1(Qarr) * (2*(Pri-Qarr))**.5 #out
			Qmax_index = sum(Qarr0<Qmax)
			Qarr = Qarr0[:(Qmax_index+1)]
        		Qprob_arr = Qprob_arr0[:(Qmax_index+1)] * (2*(Pri-Qarr))**.5 #lms
			#print "Q with negative prob: ", Qarr[Qprob_arr<0], max(Qarr1), Qmax
        		#dQ = Qarr[1]-Qarr[0]
        		Qprob_proposal = []
        		for i in xrange(len(Qarr)-1):
                		Qprob_proposal.append( max(Qprob_arr[i], Qprob_arr[i+1]) )
        		Qprob_proposal = np.array(Qprob_proposal)

			Q_max, fQ_max = Qprob_max(dfGQarr1, Pri)
			if Q_max < 100:
				print j, "Qmax<100"
        		Qmax_index = sum(Qarr<Q_max) 
			#ONLY if Q_max is within the limit of Qarr
			if (Qmax_index>0 and (Qmax_index-1 < len(Qprob_proposal)) 
			    and fQ_max>Qprob_proposal[0] and fQ_max>Qprob_proposal[-1]):
	        		Qprob_proposal[Qmax_index-1] = fQ_max * 1.05

			norm_Qprob_proposal = Qprob_proposal/np.sum(Qprob_proposal)
			
		while(not accept):
	                #sampling from proposal
			num_guess = num_guess*2 if num_guess<1e6 else 1e6
			#print "ri-num_guess: ", ri, num_guess, i
	                Qindex = np.random.choice(np.arange(len(Qprob_proposal)),
	                                          size=num_guess,p=norm_Qprob_proposal)
	                ux = Qarr[Qindex] + np.random.rand(num_guess)*dQ
	                fproposal = Qprob_proposal[Qindex]
	
	                uf = dfGQarr1(ux) * (2*(Pri-ux)*(Pri>ux))**.5 #lms
	                u = np.random.rand(num_guess)
	                accept_ux =  ux[((uf/fproposal)>u)] # == np.ones(num_guess)]
			#print "this is u, uf, fproposal: ", u, uf, fproposal, accept_index
	                #Q_accept.append( ux[accept_index] )
			if len(accept_ux)>0:
		   	    for uxi in accept_ux:
				Qi = uxi #[indx]

				#vtmax = (2*(Pri-Qi)/(1+ri*ri/(ra*ra)))**.5
				#vti = rand.random() * vtmax #vmax
				#T2 = (1+ri*ri/(ra*ra)) * vti*vti

				vrmax = (2*max(Pri-Qi,0))**.5
				vri = rand.random() * vrmax				
				T2 = vri*vri

		                T1 = (Pri-Qi)*2
				if T1>T2 :
					#vri = (T1-T2)**.5
					vti =( (T1 - T2)/(1+ri*ri/(ra*ra)) )**.5
					vr_samples.append(vri)
					vt_samples.append(vti)
					r_samples.append(ri)
					accept = True
					j = j+1
					#if ri<1e-3:
					print "samples accepted: ",j, num_guess #,ri,Pri,num_guess,max(fproposal)
					break
				else:
					null_count = null_count+ 1					
					#print "T1<T2!!!!!!!!!!!!!!!!1", j, Pri-Qi

		#calculate see if it's valid
		#Q  = Pr - ( vr*vr + (1+r*r/(ra*ra))*vt*vt )*0.5

	samplearr = np.vstack((r_samples,vr_samples,vt_samples))
        samplearr = np.swapaxes(samplearr,0,1)
	print 'OM3C sample time: ', time.time()-t0, null_count
	return gfun.r_vr_vt_complete(samplearr)
	

def rprobability(model_param, r):
	rhos_s = 1
	ra, rs_s, al_s, be_s, ga_s, = model_param
	rprob = (r*r)*rhos_s * ((r/rs_s)**-ga_s) * (1+(r/rs_s)**al_s)**((ga_s-be_s)/al_s) 	
	return rprob


def rprob_max(model_param):
	rhos_s = 1
        ra, rs_s, al_s, be_s, ga_s, = model_param

	def rfun(r):
		rprob = (r*r)*rhos_s * ((r/rs_s)**-ga_s) * (1+(r/rs_s)**al_s)**((ga_s-be_s)/al_s)
        	return rprob 

	optvar = scipy.optimize.fmin(lambda (r1): -rfun(r1), (0.1))
        fmax = rfun(optvar) 
        return optvar, fmax


def Qprob_max(dfGQarr1, Pri):
	def Qfun(Q):
		if Q>Pri:
			return 0
		else:
			result = dfGQarr1(Q) * (2*(Pri-Q))**.5 
			return -result
	x1 = 0
	x2 = Pri
	optvar = scipy.optimize.fmin(lambda (Q1): Qfun(Q1), (Pri*.9), disp=False)
	#optvar = scipy.optimize.fminbound(Qfun, x1,x2, disp=False)
	fmax = -Qfun(optvar)
	return optvar, fmax


	





