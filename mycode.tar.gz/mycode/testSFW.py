import matplotlib.pyplot as plt
import numpy as np
import star_sampler as ssp
import sfw

# "rhos" "rs" 
#"amr" "dmr" "emr" "Esmr" "normmr" "rtmr" "bmr" "qmr" "Jbetamr" 
#"amp" "dmp" "emp" "Esmp" "normmp" "rtmp" "bmp" "qmp" "Jbetamp"
#DM_param = [7.259377, -0.5460245, 99,99,99 ]

#MR
#model_param=[2.863079,-2.488383, 7.097298, 1.327396, 2.260476,-4.235693, 9.42695, 0.3120146] 

#MP
#model_param=[2.615965, -6.551869, 1.229456, 2.308727, 3.684815, 5.55633, 8.613895, 2.736394]

b0 = 0
b1 = -9.0
alp = 1
param = [2.0, -5.3, 2.5, 0.16, 1.5, b0,b1,alp, 6.9, 0.086, 4229.2, 0.694444, 1., 3., 1.]
a,d,e, Ec, rlim, b0,b1, alp, q, Jb, rhos, rs, alpha, beta, gamma = param
model_param = [a, d,  e, Ec, rlim, b0,b1,alp, q, Jb]
DM_param    = [rhos, rs, alpha, beta, gamma]


#SAMPLE mock data ------------------------------------------------------------
Nstars = 1e4

#1. construct the sampler, choose your model and input parameters
ssam = ssp.Sampler(myDF = sfw.sfw_fprob, sampler_input = sfw.sampler_input,
                        model_param=model_param, DM_param=DM_param)

#2. sample the model using rejection sampling, specify filename[string] will save the output to the file
#   @params: r_vr_vt=False, r_v=False, z_vr_vt=False; setting one of them to True will activate
#   corresponding transformation to [x,y,z,vx,vy,vz] coordinates.
x1,y1,z1,vx1,vy1,vz1 = ssam.sample(sample_method='rejection', N=Nstars, filename='sfw1.dat', 
		r_vr_vt=True, r_v=False, z_vr_vt=False)

#3  sample the model using importance sampling, requires additional @param steps and @param rfactor.
x2,y2,z2,vx2,vy2,vz2 = ssam.sample(sample_method='impt', N = Nstars, steps = 20, rfactor = 3,
		filename=None, r_vr_vt=True, r_v=False, z_vr_vt=False)


print np.std(x1), np.std(x2)

