import matplotlib
import numpy as np
matplotlib.use('TkAgg')
from matplotlib import pyplot as plt

fig,ax=plt.subplots()
ax.plot(np.random.rand(10))
coords=[]
key=[]

def onclick(event):
    print('you pressed',event.button,event.xdata,event.ydata)
    global coords
    coords.append((event.xdata,event.ydata))
def onkey(event):
    global key
    print('you pressed',event.key)
    key.append(event.key)
#cid=fig.canvas.mpl_connect('button_press_event',onclick)
cid=fig.canvas.mpl_connect('key_press_event',onkey)
plt.show()

