from astropy import units as u
from astropy.coordinates import SkyCoord
import numpy as np

def etaxiarr(rarad,decrad,racenter,deccenter):
    xi=np.cos(decrad)*np.sin(rarad-racenter)/(np.sin(deccenter)*np.sin(decrad)+np.cos(deccenter)*np.cos(decrad)*np.cos(rarad-racenter))*180.*60./np.pi
    eta=(np.cos(deccenter)*np.sin(decrad)-np.sin(deccenter)*np.cos(decrad)*np.cos(rarad-racenter))/(np.sin(deccenter)*np.sin(decrad)+np.cos(deccenter)*np.cos(decrad)*np.cos(rarad-racenter))*180.*60./np.pi
    return xi,eta

class hst_aperture:
    def __init__(self,detector=None,chip=None,filter=None,chip1_corners=None,chip2_corners=None,chip3_corners=None,chip4_corners=None,exptime=None):
        self.detector=detector
        self.filter=filter
        self.chip=chip
        self.chip1_corners=chip1_corners
        self.chip2_corners=chip2_corners
        self.chip3_corners=chip3_corners
        self.chip4_corners=chip4_corners
        self.exptime=exptime

def get_hst_aperture_wfc3(fitsdata,center):
    exptime=fitsdata[0].header['EXPTIME']
    corners_xi=[]
    corners_eta=[]
    if fitsdata[0].header['INSTRUME']=='WFC3':
        for j in [1,4]:
#            ra_aper=np.real(fitsdata[j].header['RA_APER'])
#            dec_aper=np.real(fitsdata[j].header['DEC_APER'])
            ra_aper=np.real(fitsdata[j].header['CRVAL1'])
            dec_aper=np.real(fitsdata[j].header['CRVAL2'])
            pos=SkyCoord(ra=ra_aper*u.deg,dec=dec_aper*u.deg)
            orientat=np.real(fitsdata[j].header['ORIENTAT'])
            pa_aper=np.real(fitsdata[j].header['PA_APER'])
            reference_pixel_x=fitsdata[j].header['CRPIX1']
            reference_pixel_y=fitsdata[j].header['CRPIX2']
            field_position_v2=0.#30.6556
            field_position_v3=0.#25.2168
#            print(fitsdata[0].header['aperture'])
            if fitsdata[0].header['APERTURE']=='UVIS-CENTER':
                x_scale=0.039750#0.039637
                y_scale=0.039591#0.039365
                beta_x=-41.4701#-41.2625
                beta_y=44.7597#44.8312
            if fitsdata[0].header['APERTURE']=='UVIS':
                x_scale=0.039721#0.039637
                y_scale=0.039548#0.039365
                beta_x=-41.3870#-41.2625
                beta_y=44.8315#44.8312
            if fitsdata[0].header['APERTURE']=='UVIS1':
                x_scale=0.039637#0.039637
                y_scale=0.039365#0.039365
                beta_x=-41.2625#-41.2625
                beta_y=44.8312#44.8312
            if fitsdata[0].header['APERTURE']=='UVIS2':
                x_scale=0.039858#0.039637
                y_scale=0.039837#0.039365
                beta_x=-41.6335#-41.2625
                beta_y=44.7671#44.8312
            if fitsdata[0].header['APERTURE']=='UVIS1-FIX':
                x_scale=0.039637#0.039637
                y_scale=0.039365#0.039365
                beta_x=-41.2625#-41.2625
                beta_y=44.8312#44.8312
            if fitsdata[0].header['APERTURE']=='UVIS2-FIX':
                x_scale=0.039858#0.039637
                y_scale=0.039837#0.039365
                beta_x=-41.6335#-41.2625
                beta_y=44.7671#44.8312
            if fitsdata[0].header['APERTURE']=='IR-FIX':
                x_scale=0.135437#0.039637
                y_scale=0.120944#0.039365
                beta_x=-45.1585#-41.2625
                beta_y=44.6677#44.8312
            theta=orientat-beta_y
            corner_pix_x=np.array([0,np.float(fitsdata[j].header['SIZAXIS1']),np.float(fitsdata[j].header['SIZAXIS1']),0])#identify corner pixels
            corner_pix_y=np.array([0,0,np.float(fitsdata[j].header['SIZAXIS2']),np.float(fitsdata[j].header['SIZAXIS2'])])#identify corner pixels
            v2=field_position_v2+x_scale*np.sin(beta_x*np.pi/180.)*(corner_pix_x-reference_pixel_x)+y_scale*np.sin(beta_y*np.pi/180.)*(corner_pix_y-reference_pixel_y)
            v3=field_position_v3+x_scale*np.cos(beta_x*np.pi/180.)*(corner_pix_x-reference_pixel_x)+y_scale*np.cos(beta_y*np.pi/180.)*(corner_pix_y-reference_pixel_y)
            v2prime=v2*np.cos(theta*np.pi/180)+v3*np.sin(theta*np.pi/180)
            v3prime=v3*np.cos(theta*np.pi/180)-v2*np.sin(theta*np.pi/180)
            xi_pos,eta_pos=etaxiarr(pos.ra.radian,pos.dec.radian,center.ra.radian,center.dec.radian)
            corners_xi=xi_pos+v2prime/60.
            corners_eta=eta_pos+v3prime/60.
#            if fitsdata[j].header['CCDCHIP']==1:
            if j==1:
#                chip1_corners=np.array([[corners_xi[0],corners_eta[0]],[corners_xi[1],corners_eta[1]],[corners_xi[2],corners_eta[2]],[corners_xi[3],corners_eta[3]]])
                chip1_corners=np.array([(corners_xi[0],corners_eta[0]),(corners_xi[1],corners_eta[1]),(corners_xi[2],corners_eta[2]),(corners_xi[3],corners_eta[3])])
#            if fitsdata[j].header['CCDCHIP']==2:
            if j==4:
#                chip2_corners=np.array([[corners_xi[0],corners_eta[0]],[corners_xi[1],corners_eta[1]],[corners_xi[2],corners_eta[2]],[corners_xi[3],corners_eta[3]]])
                chip2_corners=np.array([(corners_xi[0],corners_eta[0]),(corners_xi[1],corners_eta[1]),(corners_xi[2],corners_eta[2]),(corners_xi[3],corners_eta[3])])
        return hst_aperture(detector=fitsdata[0].header['DETECTOR'],filter=fitsdata[0].header['FILTER'],chip=fitsdata[j].header['CCDCHIP'],chip1_corners=chip1_corners,chip2_corners=chip2_corners,exptime=exptime)
    

def get_hst_aperture_acs(fitsdata,center):
    corners_xi=[]
    corners_eta=[]
    exptime=fitsdata[0].header['EXPTIME']
    if fitsdata[0].header['INSTRUME']=='ACS':
        for j in [1,4]:
#            ra_aper=np.real(fitsdata[j].header['RA_APER'])
#            dec_aper=np.real(fitsdata[j].header['DEC_APER'])
            ra_aper=np.real(fitsdata[j].header['CRVAL1'])
            dec_aper=np.real(fitsdata[j].header['CRVAL2'])
            pos=SkyCoord(ra=ra_aper*u.deg,dec=dec_aper*u.deg)
            orientat=np.real(fitsdata[j].header['ORIENTAT'])
            pa_aper=np.real(fitsdata[j].header['PA_APER'])
            reference_pixel_x=fitsdata[j].header['CRPIX1']
            reference_pixel_y=fitsdata[j].header['CRPIX2']
            field_position_v2=0.#264.21
            field_position_v3=0.#198.55
#            print(fitsdata[0].header['aperture'])
            if fitsdata[0].header['APERTURE']=='WFC':
                x_scale=0.049
                y_scale=0.049
                beta_x=92.163
                beta_y=177.552
            if fitsdata[0].header['APERTURE']=='WFCENTER':
                x_scale=0.049
                y_scale=0.049
                beta_x=92.056
                beta_y=177.527
            if fitsdata[0].header['APERTURE']=='WFC1':
                x_scale=0.049
                y_scale=0.049
                beta_x=92.459
                beta_y=177.352
            if fitsdata[0].header['APERTURE']=='WFC-FIX':
                x_scale=0.049
                y_scale=0.049
                beta_x=92.178
                beta_y=177.532
                
            theta=orientat-beta_y
            corner_pix_x=np.array([0,np.float(fitsdata[j].header['SIZAXIS1']),np.float(fitsdata[j].header['SIZAXIS1']),0])#identify corner pixels
            corner_pix_y=np.array([0,0,np.float(fitsdata[j].header['SIZAXIS2']),np.float(fitsdata[j].header['SIZAXIS2'])])#identify corner pixels
            v2=field_position_v2+x_scale*np.sin(beta_x*np.pi/180.)*(corner_pix_x-reference_pixel_x)+y_scale*np.sin(beta_y*np.pi/180.)*(corner_pix_y-reference_pixel_y)
            v3=field_position_v3+x_scale*np.cos(beta_x*np.pi/180.)*(corner_pix_x-reference_pixel_x)+y_scale*np.cos(beta_y*np.pi/180.)*(corner_pix_y-reference_pixel_y)
            v2prime=v2*np.cos(theta*np.pi/180)+v3*np.sin(theta*np.pi/180)
            v3prime=v3*np.cos(theta*np.pi/180)-v2*np.sin(theta*np.pi/180)
            xi_pos,eta_pos=etaxiarr(pos.ra.radian,pos.dec.radian,center.ra.radian,center.dec.radian)
            corners_xi=xi_pos+v2prime/60.
            corners_eta=eta_pos+v3prime/60.
#            if fitsdata[j].header['CCDCHIP']==1:
            if j==1:
#                chip1_corners=np.array([[corners_xi[0],corners_eta[0]],[corners_xi[1],corners_eta[1]],[corners_xi[2],corners_eta[2]],[corners_xi[3],corners_eta[3]]])
                chip1_corners=np.array([(corners_xi[0],corners_eta[0]),(corners_xi[1],corners_eta[1]),(corners_xi[2],corners_eta[2]),(corners_xi[3],corners_eta[3])])
#            if fitsdata[j].header['CCDCHIP']==2:
            if j==4:
#                chip2_corners=np.array([[corners_xi[0],corners_eta[0]],[corners_xi[1],corners_eta[1]],[corners_xi[2],corners_eta[2]],[corners_xi[3],corners_eta[3]]])
                chip2_corners=np.array([(corners_xi[0],corners_eta[0]),(corners_xi[1],corners_eta[1]),(corners_xi[2],corners_eta[2]),(corners_xi[3],corners_eta[3])])
            if 'CLEAR' in fitsdata[0].header['FILTER1']:
                filter0=fitsdata[0].header['FILTER2']
            if 'CLEAR' in fitsdata[0].header['FILTER2']:
                filter0=fitsdata[0].header['FILTER1']
        return hst_aperture(detector=fitsdata[0].header['DETECTOR'],filter=filter0,chip=fitsdata[j].header['CCDCHIP'],chip1_corners=chip1_corners,chip2_corners=chip2_corners,exptime=exptime)


def get_hst_aperture_wfpc2(fitsdata,center,fitsdata2):
    corners_xi=[]
    corners_eta=[]
    exptime=fitsdata[0].header['EXPTIME']
    if fitsdata[0].header['INSTRUME']=='WFPC2':
        for j in [1,2,3,4]:
            ra_aper=np.real(fitsdata[j].header['CRVAL1'])
            dec_aper=np.real(fitsdata[j].header['CRVAL2'])
            pos=SkyCoord(ra=ra_aper*u.deg,dec=dec_aper*u.deg)
            orientat=np.real(fitsdata[j].header['ORIENTAT'])
            reference_pixel_x=fitsdata[j].header['CRPIX1']
            reference_pixel_y=fitsdata[j].header['CRPIX2']
            field_position_v2=0.#30.6556
            field_position_v3=0.#25.2168
            if fitsdata2[0].header['APER_1']=='WFALL':
                x_scale=0.099573#0.039637
                y_scale=0.099480#0.039365
                beta_x=314.69801#-41.2625
                beta_y=44.6980#44.8312
            elif fitsdata2[0].header['APER_1']=='WFALL-FIX':
                x_scale=0.099573#0.039637
                y_scale=0.099480#0.039365
                beta_x=314.69801#-41.2625
                beta_y=44.6980#44.8312
            elif fitsdata2[0].header['APER_1']=='PC1':
                x_scale=0.099573#0.0455283#0.039637
                y_scale=0.099480#0.045507#0.039365
                beta_x=314.69801#134.90801#-41.2625
                beta_y=44.6980#224.9080#44.8312
            elif fitsdata2[0].header['APER_1']=='PC1-FIX':
                x_scale=0.099573#0.0455283#0.039637
                y_scale=0.099480#0.045507#0.039365
                beta_x=314.6980#134.90801#-41.2625
                beta_y=44.6980#224.9080#44.8312
            elif fitsdata2[0].header['APER_1']=='WF3':
                x_scale=0.099573#0.039637
                y_scale=0.099480#0.039365
                beta_x=314.6980#-41.2625
                beta_y=44.6980#44.8312
            elif fitsdata2[0].header['APER_1']=='WF3-FIX':
                x_scale=0.099573#0.039637
                y_scale=0.099480#0.039365
                beta_x=314.6980#-41.2625
                beta_y=44.6980#44.8312
            else:
                print(fitsdata2[0].header['APER_1'],' bbbb')
                np.pause()
            if j==1:
                x_scale=x_scale/2.#planetary camera high resolution
                y_scale=y_scale/2.#planetary camera high resolution
            theta=orientat-beta_y
            size1=800#np.size(fitsdata[j].data)
            size2=800#np.size(fitsdata[j].data[0])
            corner_pix_x=np.array([0,size1,size1,0])#identify corner pixels
            corner_pix_y=np.array([0,0,size2,size2])#identify corner pixels
            v2=field_position_v2+x_scale*np.sin(beta_x*np.pi/180.)*(corner_pix_x-reference_pixel_x)+y_scale*np.sin(beta_y*np.pi/180.)*(corner_pix_y-reference_pixel_y)
            v3=field_position_v3+x_scale*np.cos(beta_x*np.pi/180.)*(corner_pix_x-reference_pixel_x)+y_scale*np.cos(beta_y*np.pi/180.)*(corner_pix_y-reference_pixel_y)
            v2prime=v2*np.cos(theta*np.pi/180)+v3*np.sin(theta*np.pi/180)
            v3prime=v3*np.cos(theta*np.pi/180)-v2*np.sin(theta*np.pi/180)
            xi_pos,eta_pos=etaxiarr(pos.ra.radian,pos.dec.radian,center.ra.radian,center.dec.radian)
            corners_xi=xi_pos+v2prime/60.
            corners_eta=eta_pos+v3prime/60.
            if fitsdata[j].header['DETECTOR']==1:
#                chip1_corners=np.array([[corners_xi[0],corners_eta[0]],[corners_xi[1],corners_eta[1]],[corners_xi[2],corners_eta[2]],[corners_xi[3],corners_eta[3]]])
                chip1_corners=np.array([(corners_xi[0],corners_eta[0]),(corners_xi[1],corners_eta[1]),(corners_xi[2],corners_eta[2]),(corners_xi[3],corners_eta[3])])
            if fitsdata[j].header['DETECTOR']==2:
#                chip2_corners=np.array([[corners_xi[0],corners_eta[0]],[corners_xi[1],corners_eta[1]],[corners_xi[2],corners_eta[2]],[corners_xi[3],corners_eta[3]]])
                chip2_corners=np.array([(corners_xi[0],corners_eta[0]),(corners_xi[1],corners_eta[1]),(corners_xi[2],corners_eta[2]),(corners_xi[3],corners_eta[3])])
            if fitsdata[j].header['DETECTOR']==3:
#                chip3_corners=np.array([[corners_xi[0],corners_eta[0]],[corners_xi[1],corners_eta[1]],[corners_xi[2],corners_eta[2]],[corners_xi[3],corners_eta[3]]])
                chip3_corners=np.array([(corners_xi[0],corners_eta[0]),(corners_xi[1],corners_eta[1]),(corners_xi[2],corners_eta[2]),(corners_xi[3],corners_eta[3])])
            if fitsdata[j].header['DETECTOR']==4:
#                chip4_corners=np.array([[corners_xi[0],corners_eta[0]],[corners_xi[1],corners_eta[1]],[corners_xi[2],corners_eta[2]],[corners_xi[3],corners_eta[3]]])
                chip4_corners=np.array([(corners_xi[0],corners_eta[0]),(corners_xi[1],corners_eta[1]),(corners_xi[2],corners_eta[2]),(corners_xi[3],corners_eta[3])])
        return hst_aperture(detector=fitsdata[0].header['INSTRUME'],filter=fitsdata[0].header['filtnam1'],chip=fitsdata[1].header['DETECTOR'],chip1_corners=chip1_corners,chip2_corners=chip2_corners,chip3_corners=chip3_corners,chip4_corners=chip4_corners,exptime=exptime)


class separation2:
    def __init__(self,s=None,xy1=None,xy2=None,v1=None,v2=None,i1=None,i2=None):
        self.s=s
        self.xy1=xy1
        self.xy2=xy2
        self.v1=v1
        self.v2=v2
        self.i1=i1
        self.i2=i2
