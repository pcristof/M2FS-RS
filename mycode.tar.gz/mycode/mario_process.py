def m2fshires_multinest(fit_directory,root,targets):
    import numpy as np
    from scipy.stats import skew,kurtosis
    from astropy.io import fits

    class multinest_result:
        def __init__(self,posterior_1000=None,moments=None,bestfit_wav=None,bestfit_fit=None):
            self.posterior_1000=posterior_1000
            self.moments=moments
            self.bestfit_wav=bestfit_wav
            self.bestfit_fit=bestfit_fit

    posterior_1000=[]
    moments=[]
    bestfit_wav=[]
    bestfit_fit=[]
    for j in targets:
        multinest_in=fit_directory+root[j]+'post_equal_weights.dat'
        bestfit_in=fit_directory+root[j]+'_bestfit.dat'

        with open(multinest_in) as f:
            data=f.readlines()
        posterior0=[]
        for line in data:
            p=line.split()
            posterior0.append([float(p[0]),float(p[1]),float(p[2]),float(p[3]),float(p[4]),float(p[5]),float(p[6]),float(p[7]),float(p[8]),float(p[9]),float(p[10]),float(p[11]),float(p[12]),float(p[13]),float(p[14]),float(p[15])])
        posterior0=np.array(posterior0)

        posterior0_1000=posterior0[np.random.randint(low=0,high=len(posterior0),size=1000)]
#        moments0=[[np.mean(posterior0[:,i]),np.std(posterior0[:,i]),skew(posterior0[:,i]),kurtosis(posterior0[:,i])] for i in range(0,len(p))]
        moments0=[[np.mean(posterior0[:,i]) for i in range(0,len(p))],[np.std(posterior0[:,i]) for i in range(0,len(p))],[skew(posterior0[:,i]) for i in range(0,len(p))],[kurtosis(posterior0[:,i]) for i in range(0,len(p))]]

        posterior_1000.append(posterior0_1000)
        moments.append(moments0)

        with open(bestfit_in) as f:
            data=f.readlines()
        bestfit_wav0=[]
        bestfit_fit0=[]
        bestfit_counts0=[]
        bestfit_varcounts0=[]
        for line in data:
            p=line.split()
            bestfit_wav0.append(float(p[0]))
            bestfit_fit0.append(float(p[1]))
            bestfit_counts0.append(float(p[2]))
            bestfit_varcounts0.append(float(p[3]))
        bestfit_wav0=np.array(bestfit_wav0)
        bestfit_fit0=np.array(bestfit_fit0)
        bestfit_counts0=np.array(bestfit_counts0)
        bestfit_varcounts0=np.array(bestfit_varcounts0)

        bestfit_wav.append(bestfit_wav0)
        bestfit_fit.append(bestfit_fit0)

    posterior_1000=np.array(posterior_1000)
    moments=np.array(moments)
    bestfit_wav=np.array(bestfit_wav)
    bestfit_fit=np.array(bestfit_fit)

    if  len(bestfit_fit)!=len(targets):
        print('ERROR: number of targets does not equal number of posterior files!!!!')
        np.pause()

    return multinest_result(posterior_1000=posterior_1000,moments=moments,bestfit_wav=bestfit_wav,bestfit_fit=bestfit_fit)

def mario_getfromfits(hdul):
    import numpy as np
    from astropy import time, coordinates as coord, units as u
    from astropy.time import Time
    from astropy.coordinates import SkyCoord, EarthLocation
    import astropy.units as u
    from astropy.io import fits

    class fitsobject:
        def __init__(self,radeg=None,decdeg=None,wav=None,spec=None,var=None,mask=None,obj=None,icode=None,hjd=None,snratio=None,vheliocorr=None,header=None,channel=None,aperture=None,resolution=None,filt=None,channelcassfib=None):
            self.radeg=radeg
            self.decdeg=decdeg
            self.wav=wav
            self.spec=spec
            self.var=var
            self.mask=mask
            self.obj=obj
            self.icode=icode
            self.hjd=hjd
            self.snratio=snratio
            self.vheliocorr=vheliocorr
            self.header=header
            self.channel=channel
            self.aperture=aperture
            self.resolution=resolution
            self.filt=filt
            self.channelcassfib=channelcassfib

#    nddata=astropy.nddata.CCDData.read(fitsfile[i],unit=u.electron)
#    hdul=fits.open(fitsfile)
#for new CfA pipeline, HDUs are as follows (via email from Nelson on Apr 3, 2019:
#hdu0: wavelength(angs)
#hdu1: sky-subtracted, variance-weighted coadded spectra (total counts) OR flux-calibrated averaged spectra
#hdu2: inverse variance (counts)
#hdu3: AND bad pixel mask, requires pixel to be masked in all co-added frames
#hdu4: OR bad pixel mask, requires pixel to be masked in any co-added frames
#hdu5: plugmap structure (fiber info)
#hdu6: combined sky spectra, absent if flux calibration was set
#hdu7: summed (unweighted) spectra, absent if flux calibration was set
    wav=hdul[0].data
    mario_skysub=hdul[1].data
    ivar=hdul[2].data
    mask_and=hdul[3].data
    mask_or=hdul[4].data
    mask=mask_or#use the AND mask
    var=1./ivar
    masked=np.where(mask_or==1)[0]

    snratio=[]
    for j in range(0,len(mario_skysub)):
        keep=np.where((mario_skysub[j]==mario_skysub[j])&(var[j]==var[j])&(var[j]>0.))[0]
        snratio.append(np.median(mario_skysub[j][keep]/np.sqrt(var[j][keep])))
    snratio=np.array(snratio)

    fiber=hdul[5].data
    obj=fiber['OBJTYPE']
    icode=fiber['ICODE']

    hjd=[]
    vheliocorr=[]
    radeg=[]
    decdeg=[]
    channel=[]
    aperture=[]
    resolution=[]
    filt=[]
    channelcassfib=[]
    keep_aps=[]

    for j in range(0,len(obj)):
        if obj[j]=='TARGET' or obj[j]=='SKY':
            ra,dec=fiber[j]['RA'],fiber[j]['DEC']
            radeg.append(ra)
            decdeg.append(dec)
            coords=coord.SkyCoord(ra,dec,unit=(u.deg,u.deg),frame='icrs')
            lco=coord.EarthLocation.of_site('lco')
#            times=time.Time(hdul[0].header['DATE-OBS']+'T'+hdul[0].header['UT-TIME'],location=lco,precision=6)
            times=time.Time(hdul[0].header['DATE-OBS'],location=lco,precision=6)
            time0=hdul[0].header['DATE-OBS']+'T'+hdul[0].header['UT-TIME']
            light_travel_time_helio=times.light_travel_time(coords,'heliocentric')
            crap=(Time(times)).jd+light_travel_time_helio.value
#            print(Time(time0,location=lco).jd+light_travel_time_helio.value)
#            hjd.append((Time(hdul[0].header['DATE-OBS']+'T'+hdul[0].header['UT-TIME']).jd+light_travel_time_helio).value)
            hjd.append(crap)
            vheliocorr.append((coords.radial_velocity_correction('heliocentric',obstime=times).to(u.km/u.s)).value)
            bad=np.where(mask_or[j]==1)[0]
            var[j][bad]=1.e+30
            channel.append(fiber[j]['CHANNEL'])
            aperture.append(fiber[j]['APERTURE'])
            resolution.append(fiber[j]['RESOLUTION'])
            filt.append(fiber[j]['FILTER'])
            channelcassfib.append(fiber[j]['CHANNEL_CASSETTE_FIBER'])
            keep_aps.append(fiber[j]['APERTURE'])

    radeg=np.array(radeg)
    decdeg=np.array(decdeg)
    hjd=np.array(hjd)
    vheliocorr=np.array(vheliocorr)
    header=hdul[0].header
    channel=np.array(channel)
    aperture=np.array(aperture)
    resolution=np.array(resolution)
    filt=np.array(filt)
    channelcassfib=np.array(channelcassfib)
    keep_aps=np.array(keep_aps,dtype='int')-1

    return fitsobject(radeg=radeg,decdeg=decdeg,wav=wav[keep_aps],spec=mario_skysub[keep_aps],var=var[keep_aps],mask=mask[keep_aps],obj=obj,icode=icode,hjd=hjd,snratio=snratio[keep_aps],vheliocorr=vheliocorr,header=header,channel=channel,aperture=aperture,resolution=resolution,filt=filt,channelcassfib=channelcassfib)

def getwav_dc2(hdul):#for older hecto frames, interprets iraf headers to get wavelength solutions for each aperture
    import numpy as np
    import re

    class wavobject:
        def __init__(self,wav=None,wavcal=None):
            self.wav=wav
            self.wavcal=wavcal

    skysub=hdul[0].data
    pixels=len(skysub[0])
    header=hdul[0].header
    combined=''
    for line in header:
        if 'WAT2' in line:
            if len(header[line])==67:
                combined=combined+header[line]+' '#had to add this by hand because last space is getting dropped from string if blank space
            else:
                combined=combined+header[line]
    combined2=combined.split('spec')
    del combined2[0:2]#remove first two items, which do not correspond to apertures

    print(combined2)

    apwav=[]
    apwavcal=[]
    for ap in range(0,len(combined2)):
        removequote=re.sub('\"','',combined2[ap])
        linefields=removequote.split()
        del linefields[1]#remove '=' to match what we get for linefields in old IDL code
        coefficients=len(linefields)-12   
        order0=np.long(linefields[13])
        aperture=np.long(linefields[0])
        coeff=np.zeros(coefficients)
        for k in range(0,coefficients):
            coeff[k]=np.float(linefields[k+12])
        func=np.long(coeff[0])
        order=np.long(coeff[1])
        xmin=coeff[2]
        xmax=coeff[3]
        wav=[]
        wavcal=[]
        x=np.arange(pixels,dtype='float')+1.

        for jj in range(0,len(x)):
            if x[jj] > xmin and x[jj] < xmax:
                n=(2.*x[jj]-(xmax+xmin))/(xmax-xmin) # defined by IRAF
                s=(x[jj]-xmin)/(xmax-xmin)*np.float(order) # defined by IRAF
                j=np.long(s)                                # defined by IRAF
                a=np.float(j+1)-s                          # defined by IRAF
                b=s-np.float(j)                            # defined by IRAF

                if coeff[0]==3:
                    z=np.zeros(4)
                    z[0]=a**3.        # defined by IRAF
                    z[1]=1.+3.*a*(1.+a*b) # defined by IRAF
                    z[2]=1.+3.*b*(1.+a*b) # defined by IRAF
                    z[3]=b**3.             # defined by IRAF
                    summ=0.
                    for ii in range(0,4):
                        summ=summ+coeff[ii+j+4]*z[ii]

                if coeff[0]==2:
                    z=np.zeros(order)
                    z[0]=1.*coeff[4]
                    z[1]=n*coeff[5]
                    for ii in range(2,order):
                        z[ii]=coeff[ii+4]*((2.*np.float(ii+1)-3.)*n*z[ii-1]-np.float(ii+1-2)*z[ii-2])/(np.float(ii+1-1))
                    summ=np.sum(z)
                    print(x[jj],n,summ)

                if coeff[0]==1:
                    z[0]=1.
                    z[1]=n
                    z[2]=2.*n*z[1]-1.*z[0]
                    z[3]=2.*n*z[2]-1.*z[1]
                    summ=1.*coeff[4]*z[0]+1.*coeff[5]*z[1]+1.*coeff[6]*z[2]+1.*coeff[7]*z[3]
                wav.append(summ)
                wavcal.append(1)
            if x[jj] <= xmin or x[jj] >= xmax:
                wav.append(0.)
                wavcal.append(0)
        wav=np.array(wav)
        wavcal=np.array(wavcal)
        apwav.append(wav)
        apwavcal.append(wavcal)
    apwav=np.array(apwav)
    apwavcal=np.array(apwavcal)

    return wavobject(wav=apwav,wavcal=apwavcal)

def mario_getwav(hdul):#for older hecto frames, interprets iraf headers to get wavelength solutions for each aperture
    import numpy as np
    import re

    class wavobject:
        def __init__(self,wav=None,wavcal=None):
            self.wav=wav
            self.wavcal=wavcal

    skysub=hdul[0].data
    pixels=len(skysub[0])
    header=hdul[0].header
    apwav=[]
    apwavcal=[]
    crval1=header['crval1']
    cdelt1=header['cdelt1']
    for ap in range(0,len(skysub)):
        wav=[]
        wavcal=[]
        x=np.arange(pixels,dtype='float')+1.
        for jj in range(0,len(x)):
            wav.append(crval1+jj*cdelt1)
            wavcal.append(1)
        wav=np.array(wav)
        wavcal=np.array(wavcal)
        apwav.append(wav)
        apwavcal.append(wavcal)
    apwav=np.array(apwav)
    apwavcal=np.array(apwavcal)

    return wavobject(wav=apwav,wavcal=apwavcal)

def mario_getplugmap(hdul,fibermap):#for older hecto frames, interprets iraf headers to get wavelength solutions for each aperture
    from astropy.io import fits
    import numpy as np
    import re
    from astropy import time, coordinates as coord, units as u
    from astropy.coordinates import SkyCoord, EarthLocation

    header=hdul[0].header

    channel0=header['shoe']
    resolution0=header['slide']
    filter0=header['filter']

    aperture=[]
    radeg=[]
    decdeg=[]
    objtype=[]
    expid=[]
    icode=[]
    rcode=[]
    xfocal=[]
    yfocal=[]
    channel=[]
    resolution=[]
    filt=[]
    channelcassfib=[]

    for i in range(0,len(hdul[0].data)):
        ap=i+1
        if channel0=='B':
            if ((ap>=1)&(ap<=16)):
                cass='8'
                fib=str(ap).zfill(2)
            if ((ap>=17)&(ap<=32)):
                cass='7'
                fib=str(ap-16).zfill(2)
            if ((ap>=33)&(ap<=48)):
                cass='6'
                fib=str(ap-32).zfill(2)
            if ((ap>=49)&(ap<=64)):
                cass='5'
                fib=str(ap-48).zfill(2)
            if ((ap>=65)&(ap<=80)):
                cass='4'
                fib=str(ap-64).zfill(2)
            if ((ap>=81)&(ap<=96)):
                cass='3'
                fib=str(ap-80).zfill(2)
            if ((ap>=97)&(ap<=112)):
                cass='2'
                fib=str(ap-96).zfill(2)
            if ((ap>=113)&(ap<=128)):
                cass='1'
                fib=str(ap-112).zfill(2)
        if channel0=='R':
            if ((ap>=1)&(ap<=16)):
                cass='1'
                fib=str(ap).zfill(2)
            if ((ap>=17)&(ap<=32)):
                cass='2'
                fib=str(ap-16).zfill(2)
            if ((ap>=33)&(ap<=48)):
                cass='3'
                fib=str(ap-32).zfill(2)
            if ((ap>=49)&(ap<=64)):
                cass='4'
                fib=str(ap-48).zfill(2)
            if ((ap>=65)&(ap<=80)):
                cass='5'
                fib=str(ap-64).zfill(2)
            if ((ap>=81)&(ap<=96)):
                cass='6'
                fib=str(ap-80).zfill(2)
            if ((ap>=97)&(ap<=112)):
                cass='7'
                fib=str(ap-96).zfill(2)
            if ((ap>=113)&(ap<=128)):
                cass='8'
                fib=str(ap-112).zfill(2)

        channel_cass_fib=channel0+cass+'-'+fib
        fibermap_item0=[q for q in fibermap if channel_cass_fib in q][0]
        fibermap_item=fibermap_item0.split()
        coords_string=fibermap_item[2]+' '+fibermap_item[3]
#        coords_string=header[cassfib].replace('_',' ')
        
        t=-999#for consistency with hecto fits format
        r=-999#for consistency with hecto fits format
        x=-999#for consistency with hecto fits format
        y=-999#for consistency with hecto fits format
        obj=coords_string
        if fibermap_item[5]=='T':
#        if ':' in coords_string:
            c=SkyCoord(coords_string,unit=(u.hourangle,u.deg))
            aperture.append(np.long(ap))
            radeg.append(c.ra.degree)
            decdeg.append(c.dec.degree)
            expid.append(obj)
            rcode.append(r)
            xfocal.append(x)
            yfocal.append(y)
            objtype0='TARGET'
#            if 'sky' in obj: objtype0='SKY'
#            if 'unused' in obj: objtype0='UNUSED'
#            if 'reject' in obj: objtype0='REJECTED'
#            if 'SKY' in obj: objtype0='SKY'
#            if 'UNUSED' in obj: objtype0='UNUSED'
#            if 'REJECT' in obj: objtype0='REJECTED'
#            if objtype0=='SKY': 
#                icode.append(-1)
#            if objtype0=='TARGET': 
            icode.append(1)
#            if objtype0=='UNUSED':
#                icode.append(0)
            objtype.append(objtype0)
            channel.append(channel0)
            resolution.append(resolution0)
            filt.append(filter0)
            channelcassfib.append(channel_cass_fib)

        if fibermap_item[5]=='S':
#        if (('sky' in coords_string)|('Sky' in coords_string)):
            c=SkyCoord(coords_string,unit=(u.hourangle,u.deg))
            aperture.append(np.long(ap))
            radeg.append(c.ra.degree)
            decdeg.append(c.dec.degree)
            expid.append(obj)
            rcode.append(r)
            xfocal.append(x)
            yfocal.append(y)
            objtype0='SKY'
#            if 'sky' in obj: objtype0='SKY'
#            if 'unused' in obj: objtype0='UNUSED'
#            if 'reject' in obj: objtype0='REJECTED'
#            if 'SKY' in obj: objtype0='SKY'
#            if 'UNUSED' in obj: objtype0='UNUSED'
#            if 'REJECT' in obj: objtype0='REJECTED'
#            if objtype0=='SKY': 
            icode.append(-1)
#            if objtype0=='TARGET': 
#            icode.append(1)
#            if objtype0=='UNUSED':
#                icode.append(0)
            objtype.append(objtype0)
            channel.append(channel0)
            resolution.append(resolution0)
            filt.append(filter0)
            channelcassfib.append(channel_cass_fib)

    icode=np.array(icode,dtype='int')
    objtype=np.array(objtype)
    expid=np.array(expid)
    radeg=np.array(radeg)
    decdeg=np.array(decdeg)
    aperture=np.array(aperture)
    rcode=np.array(rcode)
    xfocal=np.array(xfocal)
    yfocal=np.array(yfocal)
    channel=np.array(channel)
    resolution=np.array(resolution)
    filt=np.array(filt)

    bcode=objtype#redundancy seems to be built in at CfA for some reason
    rmag=np.zeros(len(aperture))
    rapmag=np.zeros(len(aperture))
    frames=np.zeros(len(aperture),dtype='int')
    mag=np.zeros((len(aperture),5))

    cols=fits.ColDefs([fits.Column(name='EXPID',format='A100',array=expid),fits.Column(name='OBJTYPE',format='A6',array=objtype),fits.Column(name='RA',format='D',array=radeg),fits.Column(name='DEC',format='D',array=decdeg),fits.Column(name='APERTURE',format='I',array=aperture),fits.Column(name='RMAG',format='D',array=rmag),fits.Column(name='RAPMAG',format='D',array=rapmag),fits.Column(name='ICODE',format='D',array=icode),fits.Column(name='RCODE',format='D',array=rcode),fits.Column(name='BCODE',format='A6',array=bcode),fits.Column(name='MAG',format='5D',array=mag),fits.Column(name='XFOCAL',format='D',array=xfocal),fits.Column(name='YFOCAL',format='D',array=yfocal),fits.Column(name='FRAMES',format='B',array=frames),fits.Column(name='CHANNEL',format='A100',array=channel),fits.Column(name='RESOLUTION',format='A100',array=resolution),fits.Column(name='FILTER',format='A100',array=filt),fits.Column(name='CHANNEL_CASSETTE_FIBER',format='A100',array=channelcassfib)])

    plugmap_table_hdu=fits.FITS_rec.from_columns(cols)
    return plugmap_table_hdu
