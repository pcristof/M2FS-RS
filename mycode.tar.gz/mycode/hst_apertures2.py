from astropy import units as u
from astropy.coordinates import SkyCoord
import numpy as np
import mycode

class hst_aperture2:
    def __init__(self,detector=None,filter=None,corners=None):
        self.detector=detector
        self.filter=filter
        self.corners=corners

def get_hst_aperture2(fitsdata,center):
    ra_v1=np.real(fitsdata[0].header['RA_V1'])
    dec_v1=np.real(fitsdata[0].header['DEC_V1'])
    pa_v3=np.real(fitsdata[0].header['PA_V3'])
    pos=SkyCoord(ra=ra_v1*u.deg,dec=dec_v1*u.deg)
    x_scale=np.real(fitsdata[0].header['HOSD1'])
    y_scale=np.real(fitsdata[0].header['HOSD2'])
    v2=np.array([np.real(fitsdata[0].header['APVER1V2']),np.real(fitsdata[0].header['APVER2V2']),np.real(fitsdata[0].header['APVER3V2']),np.real(fitsdata[0].header['APVER4V2'])])
    v3=np.array([np.real(fitsdata[0].header['APVER1V3']),np.real(fitsdata[0].header['APVER2V3']),np.real(fitsdata[0].header['APVER3V3']),np.real(fitsdata[0].header['APVER4V3'])])
    theta=pa_v3
    v2prime=v2*np.cos(theta*np.pi/180)+v3*np.sin(theta*np.pi/180)
    v3prime=v3*np.cos(theta*np.pi/180)-v2*np.sin(theta*np.pi/180)
    xi_pos,eta_pos=mycode.etaxiarr(pos.ra.radian,pos.dec.radian,center.ra.radian,center.dec.radian)
    corners_xi=xi_pos+v2prime/60.
    corners_eta=eta_pos+v3prime/60.
    corners=np.array([[corners_xi[0],corners_eta[0]],[corners_xi[1],corners_eta[1]],[corners_xi[2],corners_eta[2]],[corners_xi[3],corners_eta[3]]])
    return hst_aperture2(detector=fitsdata[0].header['CONFIG'],filter=fitsdata[0].header['SPEC_1'],corners=corners)
    
class separation2:
    def __init__(self,s=None,xy1=None,xy2=None,v1=None,v2=None,i1=None,i2=None):
        self.s=s
        self.xy1=xy1
        self.xy2=xy2
        self.v1=v1
        self.v2=v2
        self.i1=i1
        self.i2=i2
