def sspphecto_multinest(fit_directory,root,targets,npix):
    import numpy as np
    from scipy.stats import skew,kurtosis
    from astropy.io import fits
    from os import path

    class multinest_result:
        def __init__(self,posterior_1000=None,moments=None,bestfit_wav=None,bestfit_fit=None,bestfit_counts=None,bestfit_varcounts=None,evidence=None):
            self.posterior_1000=posterior_1000
            self.moments=moments
            self.bestfit_wav=bestfit_wav
            self.bestfit_fit=bestfit_fit
            self.bestfit_counts=bestfit_counts
            self.bestfit_varcounts=bestfit_varcounts
            self.evidence=evidence

    posterior_1000=[]
    moments=[]
    bestfit_wav=[]
    bestfit_fit=[]
    bestfit_counts=[]
    bestfit_varcounts=[]
    evidence=[]

    for j in range(0,len(root)):
#    for j in targets:
        multinest_in=fit_directory+root[j]+'post_equal_weights.dat'
        bestfit_in=fit_directory+root[j]+'_bestfit.dat'
        stats_in=fit_directory+root[j]+'stats.dat'

        bestfit_wav0=np.zeros(npix)
        bestfit_fit0=np.zeros(npix)
        bestfit_counts0=np.zeros(npix)
        bestfit_varcounts0=np.zeros(npix)

        posterior0_1000=[]
        for n in range(0,1000):
            posterior0_1000.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
#        posterior0_1000=posterior0[np.random.randint(low=0,high=len(posterior0),size=1000)]
        moments0=[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]]
        evidence0=[0]

        if ((path.exists(multinest_in))&(path.exists(bestfit_in))&(path.exists(stats_in))):
            with open(multinest_in) as f:
                data=f.readlines()
            posterior0=[]
            for line in data:
                p=line.split()
                posterior0.append([float(p[0]),float(p[1]),float(p[2]),float(p[3]),float(p[4]),float(p[5]),float(p[6]),float(p[7]),float(p[8]),float(p[9]),float(p[10]),float(p[11]),float(p[12]),float(p[13]),float(p[14]),float(p[15])])
            posterior0=np.array(posterior0)
            posterior0_1000=posterior0[np.random.randint(low=0,high=len(posterior0),size=1000)]
#        moments0=[[np.mean(posterior0[:,i]),np.std(posterior0[:,i]),skew(posterior0[:,i]),kurtosis(posterior0[:,i])] for i in range(0,len(p))]
            moments0=[[np.mean(posterior0[:,i]) for i in range(0,len(p))],[np.std(posterior0[:,i]) for i in range(0,len(p))],[skew(posterior0[:,i]) for i in range(0,len(p))],[kurtosis(posterior0[:,i]) for i in range(0,len(p))]]

            with open(stats_in) as f:
                data=f.readlines()[0]
            evidence0=np.float(data.split()[2])

            with open(bestfit_in) as f:
                data=f.readlines()
            bestfit_wav0=[]
            bestfit_fit0=[]
            bestfit_counts0=[]
            bestfit_varcounts0=[]
            for line in data:
                p=line.split()
                bestfit_wav0.append(float(p[0]))
                bestfit_fit0.append(float(p[1]))
                bestfit_counts0.append(float(p[2]))
                bestfit_varcounts0.append(float(p[3]))
            bestfit_wav0=np.array(bestfit_wav0)
            bestfit_fit0=np.array(bestfit_fit0)
            bestfit_counts0=np.array(bestfit_counts0)
            bestfit_varcounts0=np.array(bestfit_varcounts0)

        bestfit_wav.append(bestfit_wav0)
        bestfit_fit.append(bestfit_fit0)
        bestfit_counts.append(bestfit_counts0)
        bestfit_varcounts.append(bestfit_varcounts0)

        posterior_1000.append(posterior0_1000)
        moments.append(moments0)
        evidence.append(evidence0)

    posterior_1000=np.array(posterior_1000)
    moments=np.array(moments)
    bestfit_wav=np.array(bestfit_wav)
    bestfit_fit=np.array(bestfit_fit)
    bestfit_counts=np.array(bestfit_counts)
    bestfit_varcounts=np.array(bestfit_varcounts)
    evidence=np.array(evidence)

#    if  len(bestfit_fit)!=len(targets):
#        print('ERROR: number of targets does not equal number of posterior files!!!!')
#        np.pause()

    return multinest_result(posterior_1000=posterior_1000,moments=moments,bestfit_wav=bestfit_wav,bestfit_fit=bestfit_fit,bestfit_counts=bestfit_counts,bestfit_varcounts=bestfit_varcounts,evidence=evidence)

def ianhecto_multinest(fit_directory,root,targets,npix,teffpriorstuff):
    import numpy as np
    from scipy.stats import skew,kurtosis
    from astropy.io import fits
    from os import path

    class multinest_result:
        def __init__(self,posterior_1000=None,moments=None,teffprior_posterior_1000=None,teffprior_moments=None,bestfit_wav=None,bestfit_fit=None,bestfit_counts=None,bestfit_varcounts=None,evidence=None,teffprior_survey=None):
            self.posterior_1000=posterior_1000
            self.moments=moments
            self.teffprior_posterior_1000=teffprior_posterior_1000
            self.teffprior_moments=teffprior_moments
            self.bestfit_wav=bestfit_wav
            self.bestfit_fit=bestfit_fit
            self.bestfit_counts=bestfit_counts
            self.bestfit_varcounts=bestfit_varcounts
            self.evidence=evidence
            self.teffprior_survey=teffprior_survey

    posterior_1000=[]
    moments=[]
    teffprior_posterior_1000=[]
    teffprior_moments=[]
    bestfit_wav=[]
    bestfit_fit=[]
    bestfit_counts=[]
    bestfit_varcounts=[]
    evidence=[]
    teffprior_survey=[]

    for j in range(0,len(root)):
#    for j in targets:
        multinest_in=fit_directory+root[j]+'post_equal_weights.dat'
        bestfit_in=fit_directory+root[j]+'_bestfit.dat'
        stats_in=fit_directory+root[j]+'stats.dat'

        bestfit_wav0=np.zeros(npix)
        bestfit_fit0=np.zeros(npix)
        bestfit_counts0=np.zeros(npix)
        bestfit_varcounts0=np.zeros(npix)

        posterior0_1000=[]
        teffprior_posterior0_1000=[]
        for n in range(0,1000):
            posterior0_1000.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
            teffprior_posterior0_1000.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
#        posterior0_1000=posterior0[np.random.randint(low=0,high=len(posterior0),size=1000)]
        moments0=[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]]
        teffprior_moments0=[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]]
        evidence0=[0]

        if ((path.exists(multinest_in))&(path.exists(bestfit_in))&(path.exists(stats_in))):

            survey='none'
            if ((teffpriorstuff.des_teffprior[1][j]==teffpriorstuff.des_teffprior[1][j])&(teffpriorstuff.des_teffprior[2][j]==teffpriorstuff.des_teffprior[2][j])&(teffpriorstuff.des_teffprior[3][j]==teffpriorstuff.des_teffprior[3][j])&(np.abs(teffpriorstuff.des_teffprior[1][j])<100.)&(np.abs(teffpriorstuff.des_teffprior[2][j])<100.)&(np.abs(teffpriorstuff.des_teffprior[3][j])<100.)):#
                teffprior50=teffpriorstuff.des_teffprior[0][0]
                teffprior16=teffpriorstuff.des_teffprior[0][1]
                teffprior84=teffpriorstuff.des_teffprior[0][2]
                mag1=teffpriorstuff.des_teffprior[1][j]
                mag2=teffpriorstuff.des_teffprior[2][j]
                mag3=teffpriorstuff.des_teffprior[3][j]
                color1=mag1-mag2
                color2=mag2-mag3
                survey='des'
            elif ((teffpriorstuff.decals_teffprior[1][j]==teffpriorstuff.decals_teffprior[1][j])&(teffpriorstuff.decals_teffprior[2][j]==teffpriorstuff.decals_teffprior[2][j])&(teffpriorstuff.decals_teffprior[3][j]==teffpriorstuff.decals_teffprior[3][j])&(np.abs(teffpriorstuff.decals_teffprior[1][j])<100.)&(np.abs(teffpriorstuff.decals_teffprior[2][j])<100.)&(np.abs(teffpriorstuff.decals_teffprior[3][j])<100.)):#
                teffprior50=teffpriorstuff.decals_teffprior[0][0]
                teffprior16=teffpriorstuff.decals_teffprior[0][1]
                teffprior84=teffpriorstuff.decals_teffprior[0][2]
                mag1=teffpriorstuff.decals_teffprior[1][j]
                mag2=teffpriorstuff.decals_teffprior[2][j]
                mag3=teffpriorstuff.decals_teffprior[3][j]
                color1=mag1-mag2
                color2=mag2-mag3
                survey='decals'
            elif ((teffpriorstuff.sdss_teffprior[1][j]==teffpriorstuff.sdss_teffprior[1][j])&(teffpriorstuff.sdss_teffprior[2][j]==teffpriorstuff.sdss_teffprior[2][j])&(teffpriorstuff.sdss_teffprior[3][j]==teffpriorstuff.sdss_teffprior[3][j])&(np.abs(teffpriorstuff.sdss_teffprior[1][j])<100.)&(np.abs(teffpriorstuff.sdss_teffprior[2][j])<100.)&(np.abs(teffpriorstuff.sdss_teffprior[3][j])<100.)):#
                teffprior50=teffpriorstuff.sdss_teffprior[0][0]
                teffprior16=teffpriorstuff.sdss_teffprior[0][1]
                teffprior84=teffpriorstuff.sdss_teffprior[0][2]
                mag1=teffpriorstuff.sdss_teffprior[1][j]
                mag2=teffpriorstuff.sdss_teffprior[2][j]
                mag3=teffpriorstuff.sdss_teffprior[3][j]
                color1=mag1-mag2
                color2=mag2-mag3
                survey='sdss'
            elif ((teffpriorstuff.gaia_teffprior[1][j]==teffpriorstuff.gaia_teffprior[1][j])&(teffpriorstuff.gaia_teffprior[2][j]==teffpriorstuff.gaia_teffprior[2][j])&(teffpriorstuff.gaia_teffprior[3][j]==teffpriorstuff.gaia_teffprior[3][j])&(np.abs(teffpriorstuff.gaia_teffprior[1][j])<100.)&(np.abs(teffpriorstuff.gaia_teffprior[2][j])<100.)&(np.abs(teffpriorstuff.gaia_teffprior[3][j])<100.)):#
                teffprior50=teffpriorstuff.gaia_teffprior[0][0]
                teffprior16=teffpriorstuff.gaia_teffprior[0][1]
                teffprior84=teffpriorstuff.gaia_teffprior[0][2]
                mag1=teffpriorstuff.gaia_teffprior[1][j]
                mag2=teffpriorstuff.gaia_teffprior[2][j]
                mag3=teffpriorstuff.gaia_teffprior[3][j]
                color1=mag2-mag3
                survey='gaia'
            elif ((teffpriorstuff.ps1_teffprior[1][j]==teffpriorstuff.ps1_teffprior[1][j])&(teffpriorstuff.ps1_teffprior[2][j]==teffpriorstuff.ps1_teffprior[2][j])&(teffpriorstuff.ps1_teffprior[3][j]==teffpriorstuff.ps1_teffprior[3][j])&(np.abs(teffpriorstuff.ps1_teffprior[1][j])<100.)&(np.abs(teffpriorstuff.ps1_teffprior[2][j])<100.)&(np.abs(teffpriorstuff.ps1_teffprior[3][j])<100.)):#
                teffprior50=teffpriorstuff.ps1_teffprior[0][0]
                teffprior16=teffpriorstuff.ps1_teffprior[0][1]
                teffprior84=teffpriorstuff.ps1_teffprior[0][2]
                mag1=teffpriorstuff.ps1_teffprior[1][j]
                mag2=teffpriorstuff.ps1_teffprior[2][j]
                mag3=teffpriorstuff.ps1_teffprior[3][j]
                color1=mag1-mag2
                color2=mag2-mag3
                survey='ps1'
            teffprior_survey.append(survey)

            with open(multinest_in) as f:
                data=f.readlines()
            posterior0=[]
            for line in data:
                p=line.split()
                posterior0.append([float(p[0]),float(p[1]),float(p[2]),float(p[3]),float(p[4]),float(p[5]),float(p[6]),float(p[7]),float(p[8]),float(p[9]),float(p[10]),float(p[11]),float(p[12]),float(p[13]),float(p[14]),float(p[15]),float(p[16])])
            posterior0=np.array(posterior0)

            #sample importance re-sample
            teff=posterior0.T[1]
            feh=posterior0.T[3]
            if survey=='gaia':
                mmm=10.**teffprior50.predict(np.column_stack((np.zeros(len(feh))+color1,feh)))
                lll=10.**teffprior16.predict(np.column_stack((np.zeros(len(feh))+color1,feh)))
                hhh=10.**teffprior84.predict(np.column_stack((np.zeros(len(feh))+color1,feh)))
                sss=0.5*(hhh-lll)
                ppp=1./np.sqrt(2.*np.pi*sss**2)*np.exp(-0.5*(teff-mmm)**2/sss**2)
            elif survey !='none':
                mmm=10.**teffprior50.predict(np.column_stack((np.zeros(len(feh))+color1,np.zeros(len(feh))+color2,feh)))
                lll=10.**teffprior16.predict(np.column_stack((np.zeros(len(feh))+color1,np.zeros(len(feh))+color2,feh)))
                hhh=10.**teffprior84.predict(np.column_stack((np.zeros(len(feh))+color1,np.zeros(len(feh))+color2,feh)))
                sss=0.5*(hhh-lll)
                ppp=1./np.sqrt(2.*np.pi*sss**2)*np.exp(-0.5*(teff-mmm)**2/sss**2)
            elif survey=='none':
                ppp=np.zeros(len(feh))+1.

            resample=np.random.choice(np.arange(len(posterior0)),size=len(posterior0),replace=True,p=ppp/np.sum(ppp))
            teffprior_posterior0=posterior0[resample]

            posterior0_1000=posterior0[np.random.randint(low=0,high=len(posterior0),size=1000)]
            teffprior_posterior0_1000=teffprior_posterior0[np.random.randint(low=0,high=len(teffprior_posterior0),size=1000)]
#        moments0=[[np.mean(posterior0[:,i]),np.std(posterior0[:,i]),skew(posterior0[:,i]),kurtosis(posterior0[:,i])] for i in range(0,len(p))]
            moments0=[[np.mean(posterior0[:,i]) for i in range(0,len(p))],[np.std(posterior0[:,i]) for i in range(0,len(p))],[skew(posterior0[:,i]) for i in range(0,len(p))],[kurtosis(posterior0[:,i]) for i in range(0,len(p))]]
            teffprior_moments0=[[np.mean(teffprior_posterior0[:,i]) for i in range(0,len(p))],[np.std(teffprior_posterior0[:,i]) for i in range(0,len(p))],[skew(teffprior_posterior0[:,i]) for i in range(0,len(p))],[kurtosis(teffprior_posterior0[:,i]) for i in range(0,len(p))]]

            with open(stats_in) as f:
                data=f.readlines()[0]
            evidence0=np.float(data.split()[2])

            with open(bestfit_in) as f:
                data=f.readlines()
            bestfit_wav0=[]
            bestfit_fit0=[]
            bestfit_counts0=[]
            bestfit_varcounts0=[]
            for line in data:
                p=line.split()
                bestfit_wav0.append(float(p[0]))
                bestfit_fit0.append(float(p[1]))
                bestfit_counts0.append(float(p[2]))
                bestfit_varcounts0.append(float(p[3]))
            bestfit_wav0=np.array(bestfit_wav0)
            bestfit_fit0=np.array(bestfit_fit0)
            bestfit_counts0=np.array(bestfit_counts0)
            bestfit_varcounts0=np.array(bestfit_varcounts0)

        bestfit_wav.append(bestfit_wav0)
        bestfit_fit.append(bestfit_fit0)
        bestfit_counts.append(bestfit_counts0)
        bestfit_varcounts.append(bestfit_varcounts0)

        posterior_1000.append(posterior0_1000)
        moments.append(moments0)
        teffprior_posterior_1000.append(teffprior_posterior0_1000)
        teffprior_moments.append(teffprior_moments0)
        evidence.append(evidence0)

    posterior_1000=np.array(posterior_1000)
    moments=np.array(moments)
    teffprior_posterior_1000=np.array(teffprior_posterior_1000)
    teffprior_moments=np.array(teffprior_moments)
    bestfit_wav=np.array(bestfit_wav)
    bestfit_fit=np.array(bestfit_fit)
    bestfit_counts=np.array(bestfit_counts)
    bestfit_varcounts=np.array(bestfit_varcounts)
    evidence=np.array(evidence)

#    if  len(bestfit_fit)!=len(targets):
#        print('ERROR: number of targets does not equal number of posterior files!!!!')
#        np.pause()

    return multinest_result(posterior_1000=posterior_1000,moments=moments,teffprior_posterior_1000=teffprior_posterior_1000,teffprior_moments=teffprior_moments,bestfit_wav=bestfit_wav,bestfit_fit=bestfit_fit,evidence=evidence,teffprior_survey=teffprior_survey)

def ian4hecto_multinest(fit_directory,root,targets,npix,teffpriorstuff):
    import numpy as np
    from scipy.stats import skew,kurtosis
    from astropy.io import fits
    from os import path

    class multinest_result:
        def __init__(self,posterior_1000=None,moments=None,teffprior_posterior_1000=None,teffprior_moments=None,bestfit_wav=None,bestfit_fit=None,bestfit_counts=None,bestfit_varcounts=None,evidence=None,teffprior_survey=None):
            self.posterior_1000=posterior_1000
            self.moments=moments
            self.teffprior_posterior_1000=teffprior_posterior_1000
            self.teffprior_moments=teffprior_moments
            self.bestfit_wav=bestfit_wav
            self.bestfit_fit=bestfit_fit
            self.bestfit_counts=bestfit_counts
            self.bestfit_varcounts=bestfit_varcounts
            self.evidence=evidence
            self.teffprior_survey=teffprior_survey

    posterior_1000=[]
    moments=[]
    teffprior_posterior_1000=[]
    teffprior_moments=[]
    bestfit_wav=[]
    bestfit_fit=[]
    bestfit_counts=[]
    bestfit_varcounts=[]
    evidence=[]
    teffprior_survey=[]

    for j in range(0,len(root)):
#    for j in targets:
        multinest_in=fit_directory+root[j]+'post_equal_weights.dat'
        bestfit_in=fit_directory+root[j]+'_bestfit.dat'
        stats_in=fit_directory+root[j]+'stats.dat'

        bestfit_wav0=np.zeros(npix)
        bestfit_fit0=np.zeros(npix)
        bestfit_counts0=np.zeros(npix)
        bestfit_varcounts0=np.zeros(npix)

        posterior0_1000=[]
        teffprior_posterior0_1000=[]
        for n in range(0,1000):
            posterior0_1000.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
            teffprior_posterior0_1000.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
#        posterior0_1000=posterior0[np.random.randint(low=0,high=len(posterior0),size=1000)]
        moments0=[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]]
        teffprior_moments0=[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]]
        evidence0=[0]

        if ((path.exists(multinest_in))&(path.exists(bestfit_in))&(path.exists(stats_in))):

            survey='none'
            if ((teffpriorstuff.des_teffprior[1][j]==teffpriorstuff.des_teffprior[1][j])&(teffpriorstuff.des_teffprior[2][j]==teffpriorstuff.des_teffprior[2][j])&(teffpriorstuff.des_teffprior[3][j]==teffpriorstuff.des_teffprior[3][j])&(np.abs(teffpriorstuff.des_teffprior[1][j])<100.)&(np.abs(teffpriorstuff.des_teffprior[2][j])<100.)&(np.abs(teffpriorstuff.des_teffprior[3][j])<100.)):#
                teffprior50=teffpriorstuff.des_teffprior[0][0]
                teffprior16=teffpriorstuff.des_teffprior[0][1]
                teffprior84=teffpriorstuff.des_teffprior[0][2]
                mag1=teffpriorstuff.des_teffprior[1][j]
                mag2=teffpriorstuff.des_teffprior[2][j]
                mag3=teffpriorstuff.des_teffprior[3][j]
                color1=mag1-mag2
                color2=mag2-mag3
                survey='des'
            elif ((teffpriorstuff.decals_teffprior[1][j]==teffpriorstuff.decals_teffprior[1][j])&(teffpriorstuff.decals_teffprior[2][j]==teffpriorstuff.decals_teffprior[2][j])&(teffpriorstuff.decals_teffprior[3][j]==teffpriorstuff.decals_teffprior[3][j])&(np.abs(teffpriorstuff.decals_teffprior[1][j])<100.)&(np.abs(teffpriorstuff.decals_teffprior[2][j])<100.)&(np.abs(teffpriorstuff.decals_teffprior[3][j])<100.)):#
                teffprior50=teffpriorstuff.decals_teffprior[0][0]
                teffprior16=teffpriorstuff.decals_teffprior[0][1]
                teffprior84=teffpriorstuff.decals_teffprior[0][2]
                mag1=teffpriorstuff.decals_teffprior[1][j]
                mag2=teffpriorstuff.decals_teffprior[2][j]
                mag3=teffpriorstuff.decals_teffprior[3][j]
                color1=mag1-mag2
                color2=mag2-mag3
                survey='decals'
            elif ((teffpriorstuff.sdss_teffprior[1][j]==teffpriorstuff.sdss_teffprior[1][j])&(teffpriorstuff.sdss_teffprior[2][j]==teffpriorstuff.sdss_teffprior[2][j])&(teffpriorstuff.sdss_teffprior[3][j]==teffpriorstuff.sdss_teffprior[3][j])&(np.abs(teffpriorstuff.sdss_teffprior[1][j])<100.)&(np.abs(teffpriorstuff.sdss_teffprior[2][j])<100.)&(np.abs(teffpriorstuff.sdss_teffprior[3][j])<100.)):#
                teffprior50=teffpriorstuff.sdss_teffprior[0][0]
                teffprior16=teffpriorstuff.sdss_teffprior[0][1]
                teffprior84=teffpriorstuff.sdss_teffprior[0][2]
                mag1=teffpriorstuff.sdss_teffprior[1][j]
                mag2=teffpriorstuff.sdss_teffprior[2][j]
                mag3=teffpriorstuff.sdss_teffprior[3][j]
                color1=mag1-mag2
                color2=mag2-mag3
                survey='sdss'
            elif ((teffpriorstuff.gaia_teffprior[1][j]==teffpriorstuff.gaia_teffprior[1][j])&(teffpriorstuff.gaia_teffprior[2][j]==teffpriorstuff.gaia_teffprior[2][j])&(teffpriorstuff.gaia_teffprior[3][j]==teffpriorstuff.gaia_teffprior[3][j])&(np.abs(teffpriorstuff.gaia_teffprior[1][j])<100.)&(np.abs(teffpriorstuff.gaia_teffprior[2][j])<100.)&(np.abs(teffpriorstuff.gaia_teffprior[3][j])<100.)):#
                teffprior50=teffpriorstuff.gaia_teffprior[0][0]
                teffprior16=teffpriorstuff.gaia_teffprior[0][1]
                teffprior84=teffpriorstuff.gaia_teffprior[0][2]
                mag1=teffpriorstuff.gaia_teffprior[1][j]
                mag2=teffpriorstuff.gaia_teffprior[2][j]
                mag3=teffpriorstuff.gaia_teffprior[3][j]
                color1=mag2-mag3
                survey='gaia'
            elif ((teffpriorstuff.ps1_teffprior[1][j]==teffpriorstuff.ps1_teffprior[1][j])&(teffpriorstuff.ps1_teffprior[2][j]==teffpriorstuff.ps1_teffprior[2][j])&(teffpriorstuff.ps1_teffprior[3][j]==teffpriorstuff.ps1_teffprior[3][j])&(np.abs(teffpriorstuff.ps1_teffprior[1][j])<100.)&(np.abs(teffpriorstuff.ps1_teffprior[2][j])<100.)&(np.abs(teffpriorstuff.ps1_teffprior[3][j])<100.)):#
                teffprior50=teffpriorstuff.ps1_teffprior[0][0]
                teffprior16=teffpriorstuff.ps1_teffprior[0][1]
                teffprior84=teffpriorstuff.ps1_teffprior[0][2]
                mag1=teffpriorstuff.ps1_teffprior[1][j]
                mag2=teffpriorstuff.ps1_teffprior[2][j]
                mag3=teffpriorstuff.ps1_teffprior[3][j]
                color1=mag1-mag2
                color2=mag2-mag3
                survey='ps1'
            teffprior_survey.append(survey)

            with open(multinest_in) as f:
                data=f.readlines()
            posterior0=[]
            for line in data:
                p=line.split()
                posterior0.append([float(p[0]),float(p[1]),float(p[2]),float(p[3]),float(p[4]),float(p[5]),float(p[6]),float(p[7]),float(p[8]),float(p[9]),float(p[10]),float(p[11]),float(p[12]),float(p[13]),float(p[14]),float(p[15])])
            posterior0=np.array(posterior0)

            #sample importance re-sample
            teff=posterior0.T[1]
            feh=posterior0.T[3]
            if survey=='gaia':
                mmm=10.**teffprior50.predict(np.column_stack((np.zeros(len(feh))+color1,feh)))
                lll=10.**teffprior16.predict(np.column_stack((np.zeros(len(feh))+color1,feh)))
                hhh=10.**teffprior84.predict(np.column_stack((np.zeros(len(feh))+color1,feh)))
                sss=0.5*(hhh-lll)
                ppp=1./np.sqrt(2.*np.pi*sss**2)*np.exp(-0.5*(teff-mmm)**2/sss**2)
            elif survey !='none':
                mmm=10.**teffprior50.predict(np.column_stack((np.zeros(len(feh))+color1,np.zeros(len(feh))+color2,feh)))
                lll=10.**teffprior16.predict(np.column_stack((np.zeros(len(feh))+color1,np.zeros(len(feh))+color2,feh)))
                hhh=10.**teffprior84.predict(np.column_stack((np.zeros(len(feh))+color1,np.zeros(len(feh))+color2,feh)))
                sss=0.5*(hhh-lll)
                ppp=1./np.sqrt(2.*np.pi*sss**2)*np.exp(-0.5*(teff-mmm)**2/sss**2)
            elif survey=='none':
                ppp=np.zeros(len(feh))+1.

            resample=np.random.choice(np.arange(len(posterior0)),size=len(posterior0),replace=True,p=ppp/np.sum(ppp))
            teffprior_posterior0=posterior0[resample]

            posterior0_1000=posterior0[np.random.randint(low=0,high=len(posterior0),size=1000)]
            teffprior_posterior0_1000=teffprior_posterior0[np.random.randint(low=0,high=len(teffprior_posterior0),size=1000)]
#        moments0=[[np.mean(posterior0[:,i]),np.std(posterior0[:,i]),skew(posterior0[:,i]),kurtosis(posterior0[:,i])] for i in range(0,len(p))]
            moments0=[[np.mean(posterior0[:,i]) for i in range(0,len(p))],[np.std(posterior0[:,i]) for i in range(0,len(p))],[skew(posterior0[:,i]) for i in range(0,len(p))],[kurtosis(posterior0[:,i]) for i in range(0,len(p))]]
            teffprior_moments0=[[np.mean(teffprior_posterior0[:,i]) for i in range(0,len(p))],[np.std(teffprior_posterior0[:,i]) for i in range(0,len(p))],[skew(teffprior_posterior0[:,i]) for i in range(0,len(p))],[kurtosis(teffprior_posterior0[:,i]) for i in range(0,len(p))]]

            with open(stats_in) as f:
                data=f.readlines()[0]
            evidence0=np.float(data.split()[2])

            with open(bestfit_in) as f:
                data=f.readlines()
            bestfit_wav0=[]
            bestfit_fit0=[]
            bestfit_counts0=[]
            bestfit_varcounts0=[]
            for line in data:
                p=line.split()
                bestfit_wav0.append(float(p[0]))
                bestfit_fit0.append(float(p[1]))
                bestfit_counts0.append(float(p[2]))
                bestfit_varcounts0.append(float(p[3]))
            bestfit_wav0=np.array(bestfit_wav0)
            bestfit_fit0=np.array(bestfit_fit0)
            bestfit_counts0=np.array(bestfit_counts0)
            bestfit_varcounts0=np.array(bestfit_varcounts0)

        bestfit_wav.append(bestfit_wav0)
        bestfit_fit.append(bestfit_fit0)
        bestfit_counts.append(bestfit_counts0)
        bestfit_varcounts.append(bestfit_varcounts0)

        posterior_1000.append(posterior0_1000)
        moments.append(moments0)
        teffprior_posterior_1000.append(teffprior_posterior0_1000)
        teffprior_moments.append(teffprior_moments0)
        evidence.append(evidence0)

    posterior_1000=np.array(posterior_1000)
    moments=np.array(moments)
    teffprior_posterior_1000=np.array(teffprior_posterior_1000)
    teffprior_moments=np.array(teffprior_moments)
    bestfit_wav=np.array(bestfit_wav)
    bestfit_fit=np.array(bestfit_fit)
    bestfit_counts=np.array(bestfit_counts)
    bestfit_varcounts=np.array(bestfit_varcounts)
    evidence=np.array(evidence)

    return multinest_result(posterior_1000=posterior_1000,moments=moments,teffprior_posterior_1000=teffprior_posterior_1000,teffprior_moments=teffprior_moments,bestfit_wav=bestfit_wav,bestfit_fit=bestfit_fit,evidence=evidence,teffprior_survey=teffprior_survey)

def sspphecto_multinest(fit_directory,root,targets,npix):
    import numpy as np
    from scipy.stats import skew,kurtosis
    from astropy.io import fits
    from os import path

    class multinest_result:
        def __init__(self,posterior_1000=None,moments=None,bestfit_wav=None,bestfit_fit=None,bestfit_counts=None,bestfit_varcounts=None,evidence=None):
            self.posterior_1000=posterior_1000
            self.moments=moments
            self.bestfit_wav=bestfit_wav
            self.bestfit_fit=bestfit_fit
            self.bestfit_counts=bestfit_counts
            self.bestfit_varcounts=bestfit_varcounts
            self.evidence=evidence

    posterior_1000=[]
    moments=[]
    bestfit_wav=[]
    bestfit_fit=[]
    bestfit_counts=[]
    bestfit_varcounts=[]
    evidence=[]

    for j in range(0,len(root)):
#    for j in targets:
        multinest_in=fit_directory+root[j]+'post_equal_weights.dat'
        bestfit_in=fit_directory+root[j]+'_bestfit.dat'
        stats_in=fit_directory+root[j]+'stats.dat'

        bestfit_wav0=np.zeros(npix)
        bestfit_fit0=np.zeros(npix)
        bestfit_counts0=np.zeros(npix)
        bestfit_varcounts0=np.zeros(npix)

        posterior0_1000=[]
        for n in range(0,1000):
            posterior0_1000.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
#        posterior0_1000=posterior0[np.random.randint(low=0,high=len(posterior0),size=1000)]
        moments0=[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]]
        evidence0=[0]

        if ((path.exists(multinest_in))&(path.exists(bestfit_in))&(path.exists(stats_in))):
            with open(multinest_in) as f:
                data=f.readlines()
            posterior0=[]
            for line in data:
                p=line.split()
                posterior0.append([float(p[0]),float(p[1]),float(p[2]),float(p[3]),float(p[4]),float(p[5]),float(p[6]),float(p[7]),float(p[8]),float(p[9]),float(p[10]),float(p[11]),float(p[12]),float(p[13]),float(p[14]),float(p[15])])
            posterior0=np.array(posterior0)
            posterior0_1000=posterior0[np.random.randint(low=0,high=len(posterior0),size=1000)]
#        moments0=[[np.mean(posterior0[:,i]),np.std(posterior0[:,i]),skew(posterior0[:,i]),kurtosis(posterior0[:,i])] for i in range(0,len(p))]
            moments0=[[np.mean(posterior0[:,i]) for i in range(0,len(p))],[np.std(posterior0[:,i]) for i in range(0,len(p))],[skew(posterior0[:,i]) for i in range(0,len(p))],[kurtosis(posterior0[:,i]) for i in range(0,len(p))]]

            with open(stats_in) as f:
                data=f.readlines()[0]
            evidence0=np.float(data.split()[2])

            with open(bestfit_in) as f:
                data=f.readlines()
            bestfit_wav0=[]
            bestfit_fit0=[]
            bestfit_counts0=[]
            bestfit_varcounts0=[]
            for line in data:
                p=line.split()
                bestfit_wav0.append(float(p[0]))
                bestfit_fit0.append(float(p[1]))
                bestfit_counts0.append(float(p[2]))
                bestfit_varcounts0.append(float(p[3]))
            bestfit_wav0=np.array(bestfit_wav0)
            bestfit_fit0=np.array(bestfit_fit0)
            bestfit_counts0=np.array(bestfit_counts0)
            bestfit_varcounts0=np.array(bestfit_varcounts0)

        bestfit_wav.append(bestfit_wav0)
        bestfit_fit.append(bestfit_fit0)
        bestfit_counts.append(bestfit_counts0)
        bestfit_varcounts.append(bestfit_varcounts0)

        posterior_1000.append(posterior0_1000)
        moments.append(moments0)
        evidence.append(evidence0)

    posterior_1000=np.array(posterior_1000)
    moments=np.array(moments)
    bestfit_wav=np.array(bestfit_wav)
    bestfit_fit=np.array(bestfit_fit)
    bestfit_counts=np.array(bestfit_counts)
    bestfit_varcounts=np.array(bestfit_varcounts)
    evidence=np.array(evidence)

#    if  len(bestfit_fit)!=len(targets):
#        print('ERROR: number of targets does not equal number of posterior files!!!!')
#        np.pause()

    return multinest_result(posterior_1000=posterior_1000,moments=moments,bestfit_wav=bestfit_wav,bestfit_fit=bestfit_fit,bestfit_counts=bestfit_counts,bestfit_varcounts=bestfit_varcounts,evidence=evidence)

def nelson_getfromfits(hdul):
    import numpy as np
    from astropy import time, coordinates as coord, units as u
    from astropy.time import Time
    from astropy.coordinates import SkyCoord, EarthLocation
    import astropy.units as u
    from astropy.io import fits

    class fitsobject:
        def __init__(self,radeg=None,decdeg=None,wav=None,spec=None,var=None,mask=None,sky_spec=None,obj=None,icode=None,hjd=None,snratio=None,vheliocorr=None,header=None):
            self.radeg=radeg
            self.decdeg=decdeg
            self.wav=wav
            self.spec=spec
            self.var=var
            self.mask=mask
            self.sky_spec=sky_spec
            self.obj=obj
            self.icode=icode
            self.hjd=hjd
            self.snratio=snratio
            self.vheliocorr=vheliocorr
            self.header=header

#    nddata=astropy.nddata.CCDData.read(fitsfile[i],unit=u.electron)
#    hdul=fits.open(fitsfile)
#for new CfA pipeline, HDUs are as follows (via email from Nelson on Apr 3, 2019:
#hdu0: wavelength(angs)
#hdu1: sky-subtracted, variance-weighted coadded spectra (total counts) OR flux-calibrated averaged spectra
#hdu2: inverse variance (counts)
#hdu3: AND bad pixel mask, requires pixel to be masked in all co-added frames
#hdu4: OR bad pixel mask, requires pixel to be masked in any co-added frames
#hdu5: plugmap structure (fiber info)
#hdu6: combined sky spectra, absent if flux calibration was set
#hdu7: summed (unweighted) spectra, absent if flux calibration was set
    wav=hdul[0].data
    cfa_skysub=hdul[1].data
    ivar=hdul[2].data
    mask_and=hdul[3].data
    mask_or=hdul[4].data
    mask=mask_or#use the AND mask
    sky_spec=hdul[6].data
    var=1./ivar
    masked=np.where(mask_or==1)[0]

    snratio=[]
    for j in range(0,len(cfa_skysub)):
        keep=np.where((cfa_skysub[j]==cfa_skysub[j])&(var[j]==var[j])&(var[j]>0.)&(mask[j]==False))[0]
        snratio.append(np.median(cfa_skysub[j][keep]/np.sqrt(var[j][keep])))
    snratio=np.array(snratio)

    fiber=hdul[5].data
    obj=fiber['OBJTYPE']
    icode=fiber['ICODE']

    hjd=[]
    vheliocorr=[]
    radeg=[]
    decdeg=[]
    for j in range(0,len(obj)):
        ra,dec=fiber[j]['RA'],fiber[j]['DEC']
        radeg.append(ra)
        decdeg.append(dec)
        coords=coord.SkyCoord(ra,dec,unit=(u.deg,u.deg),frame='icrs')
        mmt=coord.EarthLocation.of_site('mmt')
        times=time.Time(hdul[0].header['DATE-OBS'],location=mmt)
        light_travel_time_helio=times.light_travel_time(coords,'heliocentric')
        hjd.append((Time(hdul[0].header['DATE-OBS']).jd+light_travel_time_helio).value)
        vheliocorr.append((coords.radial_velocity_correction('heliocentric',obstime=times).to(u.km/u.s)).value)
        bad=np.where(mask_or[j]==1)[0]
        var[j][bad]=1.e+30
    radeg=np.array(radeg)
    decdeg=np.array(decdeg)
    hjd=np.array(hjd)
    vheliocorr=np.array(vheliocorr)
    header=hdul[0].header

    return fitsobject(radeg=radeg,decdeg=decdeg,wav=wav,spec=cfa_skysub,var=var,mask=mask,sky_spec=sky_spec,obj=obj,icode=icode,hjd=hjd,snratio=snratio,vheliocorr=vheliocorr,header=header)

def nelson_oldformat_getwav(hdul):#for older hecto frames, interprets iraf headers to get wavelength solutions for each aperture
    import numpy as np
    import re

    class wavobject:
        def __init__(self,wav=None,wavcal=None):
            self.wav=wav
            self.wavcal=wavcal

    skysub=hdul[0].data
    pixels=len(skysub[0])
    header=hdul[0].header
    combined=''
    for line in header:
        if 'WAT2' in line:
            if len(header[line])==67:
                combined=combined+header[line]+' '#had to add this by hand because last space is getting dropped from string if blank space
            else:
                combined=combined+header[line]
    combined2=combined.split('spec')
    del combined2[0:2]#remove first two items, which do not correspond to apertures
    apwav=[]
    apwavcal=[]
    for ap in range(0,len(combined2)):
        removequote=re.sub('\"','',combined2[ap])
        linefields=removequote.split()
        del linefields[1]#remove '=' to match what we get for linefields in old IDL code
        coefficients=len(linefields)-12   
        order0=np.long(linefields[13])
        aperture=np.long(linefields[0])
        coeff=np.zeros(coefficients)
        for k in range(0,coefficients):
            coeff[k]=np.float(linefields[k+12])
        func=np.long(coeff[0])
        order=np.long(coeff[1])
        xmin=coeff[2]
        xmax=coeff[3]
        wav=[]
        wavcal=[]
        x=np.arange(pixels,dtype='float')+1.
        for jj in range(0,len(x)):
            if x[jj] > xmin and x[jj] < xmax:
                n=(2.*x[jj]-(xmax+xmin))/(xmax-xmin) # defined by IRAF
                s=(x[jj]-xmin)/(xmax-xmin)*np.float(order) # defined by IRAF
                j=np.long(s)                                # defined by IRAF
                a=np.float(j+1)-s                          # defined by IRAF
                b=s-np.float(j)                            # defined by IRAF
                z=np.zeros(4)
                if coeff[0]==3:
                    z[0]=a**3.        # defined by IRAF
                    z[1]=1.+3.*a*(1.+a*b) # defined by IRAF
                    z[2]=1.+3.*b*(1.+a*b) # defined by IRAF
                    z[3]=b**3.             # defined by IRAF
                    summ=0.
                    for ii in range(0,4):
                        summ=summ+coeff[ii+j+4]*z[ii]
                if coeff[0]==1:
                    z[0]=1.
                    z[1]=n
                    z[2]=2.*n*z[1]-1.*z[0]
                    z[3]=2.*n*z[2]-1.*z[1]
                    summ=1.*coeff[4]*z[0]+1.*coeff[5]*z[1]+1.*coeff[6]*z[2]+1.*coeff[7]*z[3]
                wav.append(summ)
                wavcal.append(1)
            if x[jj] <= xmin or x[jj] >= xmax:
                wav.append(0.)
                wavcal.append(0)
        wav=np.array(wav)
        wavcal=np.array(wavcal)
        apwav.append(wav)
        apwavcal.append(wavcal)
    apwav=np.array(apwav)
    apwavcal=np.array(apwavcal)

    return wavobject(wav=apwav,wavcal=apwavcal)

def nelson_oldformat_getplugmap(hdul):#for older hecto frames, interprets iraf headers to get wavelength solutions for each aperture
    from astropy.io import fits
    import numpy as np
    import re
    from astropy import time, coordinates as coord, units as u
    from astropy.coordinates import SkyCoord, EarthLocation

    header=hdul[0].header
    aperture=[]
    radeg=[]
    decdeg=[]
    objtype=[]
    expid=[]
    icode=[]
    rcode=[]
    xfocal=[]
    yfocal=[]
    for line in header:
        if 'APID' in line:
            aperture.append(np.long(line.split('APID')[1]))
            apinfo=header[line].split()
            obj,ra,dec,t,r,x,y=apinfo
            c=SkyCoord(ra+dec,unit=(u.hourangle,u.deg))
            radeg.append(c.ra.degree)
            decdeg.append(c.dec.degree)
            expid.append(obj)
            rcode.append(r)
            xfocal.append(x)
            yfocal.append(y)
            objtype0='TARGET'
            if 'sky' in obj: objtype0='SKY'
            if 'unused' in obj: objtype0='UNUSED'
            if 'reject' in obj: objtype0='REJECTED'
            if 'SKY' in obj: objtype0='SKY'
            if 'UNUSED' in obj: objtype0='UNUSED'
            if 'REJECT' in obj: objtype0='REJECTED'
            if objtype0=='SKY': 
                icode.append(-1)
            if objtype0=='TARGET': 
                icode.append(1)
            if objtype0=='UNUSED':
                icode.append(0)
            objtype.append(objtype0)

    icode=np.array(icode,dtype='int')
    objtype=np.array(objtype)
    expid=np.array(expid)
    radeg=np.array(radeg)
    decdeg=np.array(decdeg)
    aperture=np.array(aperture)
    rcode=np.array(rcode)
    xfocal=np.array(xfocal)
    yfocal=np.array(yfocal)

    bcode=objtype#redundancy seems to be built in at CfA for some reason
    rmag=np.zeros(len(aperture))
    rapmag=np.zeros(len(aperture))
    frames=np.zeros(len(aperture),dtype='int')
    mag=np.zeros((len(aperture),5))

    cols=fits.ColDefs([fits.Column(name='EXPID',format='A100',array=expid),fits.Column(name='OBJTYPE',format='A6',array=objtype),fits.Column(name='RA',format='D',array=radeg),fits.Column(name='DEC',format='D',array=decdeg),fits.Column(name='FIBERID',format='D',array=aperture),fits.Column(name='RMAG',format='D',array=rmag),fits.Column(name='RAPMAG',format='D',array=rapmag),fits.Column(name='ICODE',format='D',array=icode),fits.Column(name='RCODE',format='D',array=rcode),fits.Column(name='BCODE',format='A6',array=bcode),fits.Column(name='MAG',format='5D',array=mag),fits.Column(name='XFOCAL',format='D',array=xfocal),fits.Column(name='YFOCAL',format='D',array=yfocal),fits.Column(name='FRAMES',format='B',array=frames)])

    plugmap_table_hdu=fits.FITS_rec.from_columns(cols)
    return plugmap_table_hdu

def get_meansky(throughputcorr_array,wavcal_array,err,mask,plugmap):
    import numpy as np
    import scipy
    import astropy.units as u
    from specutils import Spectrum1D
    from astropy.modeling import models,fitting
    import matplotlib.pyplot as plt
    from astropy.nddata import StdDevUncertainty

    wav_min=[]
    wav_max=[]
    npix=[]
    use=[]
    for i in range(0,len(throughputcorr_array)):
#        pix=throughputcorr_array[i].spec1d_pixel
        pix=np.arange(len(throughputcorr_array[i]))
        wav=np.array(wavcal_array.wav[i])
        if len(wav)>0:
            keep=np.where(mask==0)[0]
            wav_min.append(np.min(wav[mask[i]==0]))
            wav_max.append(np.max(wav[mask[i]==0]))
            npix.append(len(np.where(mask[i]==0)[0]))
            use.append(1)
        else:
            wav_min.append(1.e+10)
            wav_max.append(-1.e+10)
            npix.append(0)
            use.append(0)
    wav_min=np.array(wav_min)
    wav_max=np.array(wav_max)
    npix=np.array(npix)
    use=np.array(use)

    meansky=Spectrum1D(spectral_axis=np.array([0.])*u.AA,flux=np.array([0.])*u.electron,uncertainty=StdDevUncertainty(np.array([np.inf])),mask=np.array([True]))

    if len(throughputcorr_array)>0:
        if len(wav_min[use==1])>0:
            wav0=np.linspace(np.min(wav_min[use==1]),np.max(wav_max[use==1]),np.long(np.median(npix[use==1])*10))[::-1]
    
#            id_nlines=np.array([len(np.where(id_lines_array[q].wav>0.)[0]) for q in range(0,len(id_lines_array))],dtype='int')
            skies=np.where((plugmap['objtype']=='SKY')&(len([wavcal_array.wav[q] for q in range(0,len(wavcal_array.wav))])>0))[0]

            sky_flux_array=[]
            sky_err_array=[]
            sky_mask_array=[]

            for i in range(0,len(skies)):
#            use=np.where(throughputcorr_array[skies[i]].spec1d_mask==False)[0]
                wav=wavcal_array.wav[skies[i]]
                if len(wav)>0:
                    sky_flux_array.append(np.interp(wav0[::-1],wav[wavcal_array.wavcal[skies[i]]==1][::-1],throughputcorr_array[skies[i]][wavcal_array.wavcal[skies[i]]==1][::-1])[::-1])
                    sky_err_array.append(np.interp(wav0[::-1],wav[wavcal_array.wavcal[skies[i]]==1][::-1],err[skies[i]][wavcal_array.wavcal[skies[i]]==1][::-1])[::-1])
                    sky_mask_array.append(np.interp(wav0[::-1],wav[wavcal_array.wavcal[skies[i]]==1][::-1],mask[skies[i]][wavcal_array.wavcal[skies[i]]==1][::-1])[::-1])
#                    sky_flux_array.append(np.interp(wav0[::-1],wav[::-1],throughputcorr_array[skies[i]][::-1]))
#                    sky_err_array.append(np.interp(wav0[::-1],wav[::-1],err[skies[i]][::-1]))
#                    sky_mask_array.append(np.interp(wav0[::-1],wav[::-1],mask[skies[i]][::-1]))
#                    sky_mask_array.append(np.full(len(wav0),False))
            sky_flux_array=np.array(sky_flux_array)
            sky_err_array=np.array(sky_err_array)
            sky_mask_array=np.array(sky_mask_array)

            sky0_flux=[]
            sky0_err=[]
            sky0_mask=[]
            nnn=[]
            for i in range(0,len(wav0)):
                vec=np.array([sky_flux_array[q][i] for q in range(0,len(sky_flux_array))],dtype='float')
                vec_mask=np.array([sky_mask_array[q][i] for q in range(0,len(sky_flux_array))],dtype='bool')
                for j in range(0,len(vec)):
                    if wav_min[skies[j]]>wav0[i]:
                        vec_mask[j]=True
                    if wav_max[skies[j]]<=wav0[i]:
                        vec_mask[j]=True
                med=np.median(vec[vec_mask==False])
                mad=np.median(np.abs(vec[vec_mask==False]-med))*1.4826*np.sqrt(np.pi/2.)/np.sqrt(np.float(len(np.where(vec_mask==False)[0])))
                    
                sky0_flux.append(med)
                sky0_err.append(mad)
                nnn.append(len(vec[vec_mask==False]))
                if med!=med:
                    sky0_mask.append(True)
                else:
                    sky0_mask.append(False)
            sky0_flux=np.array(sky0_flux)
            sky0_err=np.array(sky0_err)
            sky0_mask=np.array(sky0_mask)
            nnn=np.array(nnn)
 #           plt.plot(nnn)
 #           plt.show()
 #           plt.close()
 #           np.pause()
        else:
            wav0=[0.]
            sky0_flux=np.array([0.])
            sky0_err=np.array([0.])
            sky0_mask=np.array([True])

        meansky=Spectrum1D(spectral_axis=wav0*u.AA,flux=sky0_flux*u.electron,uncertainty=StdDevUncertainty(sky0_err),mask=sky0_mask)
    return meansky

def get_skysubtract(meansky,i,throughputcorr_array,err,mask,wavcal_array):
    import numpy as np
    import scipy
    import astropy.units as u
    from specutils import Spectrum1D
    from astropy.modeling import models,fitting
    import matplotlib.pyplot as plt
    from astropy.nddata import StdDevUncertainty
    from copy import deepcopy
#        sky=Spectrum1D(spectral_axis=np.arange(len(sky0_flux))*u.AA,flux=sky0_flux*u.electron,uncertainty=StdDevUncertainty(sky0_err),mask=sky0_mask),True))

    spec1d0=Spectrum1D(spectral_axis=np.arange(len(throughputcorr_array[i]))*u.AA,flux=throughputcorr_array[i]*u.electron,uncertainty=StdDevUncertainty(err[i]),mask=mask[i])
    sky0=Spectrum1D(spectral_axis=np.arange(len(throughputcorr_array[i]))*u.AA,flux=np.zeros(len(throughputcorr_array[i]))*u.electron,uncertainty=StdDevUncertainty(np.full(len(throughputcorr_array[i]),np.inf)),mask=np.full(len(throughputcorr_array[i]),True))
    wav0=meansky.spectral_axis.value
    wav=wavcal_array.wav[i]
    skysubtract0=deepcopy(spec1d0)
    skysubtract0.mask=np.full(len(skysubtract0.flux),True,dtype=bool)

    if len(wav)>0:
        sky_flux=np.interp(wav[::-1],wav0[::-1],meansky.flux[::-1])[::-1]
        sky_err=np.interp(wav[::-1],wav0[::-1],meansky.uncertainty.quantity.value[::-1])[::-1]
        sky_mask=np.interp(wav[::-1],wav0[::-1],meansky.mask[::-1])[::-1]
        sky0=Spectrum1D(spectral_axis=np.arange(len(throughputcorr_array[i]))*u.AA,flux=sky_flux*u.electron,uncertainty=StdDevUncertainty(sky_err),mask=sky_mask)
        skysubtract=spec1d0.subtract(sky0)
    sky=sky0.flux

    mask=np.zeros(len(skysubtract.mask),dtype=int)
    for j in range(0,len(mask)):
        if skysubtract.mask[j]:
            mask[j]=1
    skysubtract.mask=mask
#    skysubtract=Spectrum1D(spectral_axis=wav*u.AA,flux=throughputcorr_array[i]*u.electron,uncertainty=StdDevUncertainty(err[i]),mask=mask[i])
#    sky=extract1d(throughputcorr_array[i].aperture,spec1d_pixel=throughputcorr_array[i].spec1d_pixel,spec1d_flux=sky0.flux,spec1d_uncertainty=sky0.uncertainty,spec1d_mask=sky0.mask)
#    skysubtract=extract1d(throughputcorr_array[i].aperture,spec1d_pixel=throughputcorr_array[i].spec1d_pixel,spec1d_flux=skysubtract0.flux,spec1d_uncertainty=skysubtract0.uncertainty,spec1d_mask=skysubtract0.mask)
    return sky,skysubtract
