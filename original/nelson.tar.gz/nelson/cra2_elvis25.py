import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
from scipy.stats import kde
import random
import scipy.optimize as optimize
from galpy.potential import MWPotential2014
from galpy.potential import NFWPotential
from galpy.orbit import Orbit
from galpy.potential import vesc
from astropy import units
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.8)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='10')
plt.rc('ytick',labelsize='10')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

with open('cra2_elvis2_kauket_cra2.dat') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()
kauket_scatter2=[]
kauket_ncra2=[]
kauket_ncra2lo=[]
kauket_ncra2hi=[]
kauket_cra2tide=[]
kauket_cra2tidelo=[]
kauket_cra2tidehi=[]
for line in data: # fill arrays
    p=line.split()
    kauket_scatter2.append(float(p[0]))
    kauket_ncra2.append(float(p[1]))
    kauket_ncra2lo.append(float(p[2]))
    kauket_ncra2hi.append(float(p[3]))
    kauket_cra2tide.append(float(p[4]))
    kauket_cra2tidelo.append(float(p[5]))
    kauket_cra2tidehi.append(float(p[6]))
kauket_scatter2=np.array(kauket_scatter2)
kauket_ncra2=np.array(kauket_ncra2)
kauket_ncra2lo=np.array(kauket_ncra2lo)
kauket_ncra2hi=np.array(kauket_ncra2hi)
kauket_cra2tide=np.array(kauket_cra2tide)
kauket_cra2tidelo=np.array(kauket_cra2tidelo)
kauket_cra2tidehi=np.array(kauket_cra2tidehi)

with open('cra2_elvis2_kauket_gal5.dat') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()
kauket_scatter=[]
kauket_ngal5=[]
kauket_ngal5lo=[]
kauket_ngal5hi=[]
kauket_gal5tide=[]
kauket_gal5tidelo=[]
kauket_gal5tidehi=[]
for line in data: # fill arrays
    p=line.split()
    kauket_scatter.append(float(p[0]))
    kauket_ngal5.append(float(p[1]))
    kauket_ngal5lo.append(float(p[2]))
    kauket_ngal5hi.append(float(p[3]))
    kauket_gal5tide.append(float(p[4]))
    kauket_gal5tidelo.append(float(p[5]))
    kauket_gal5tidehi.append(float(p[6]))
kauket_scatter=np.array(kauket_scatter)
kauket_ngal5=np.array(kauket_ngal5)
kauket_ngal5lo=np.array(kauket_ngal5lo)
kauket_ngal5hi=np.array(kauket_ngal5hi)
kauket_gal5tide=np.array(kauket_gal5tide)
kauket_gal5tidelo=np.array(kauket_gal5tidelo)
kauket_gal5tidehi=np.array(kauket_gal5tidehi)

with open('cra2_elvis2_scylla_cra2.dat') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()
scylla_scatter2=[]
scylla_ncra2=[]
scylla_ncra2lo=[]
scylla_ncra2hi=[]
scylla_cra2tide=[]
scylla_cra2tidelo=[]
scylla_cra2tidehi=[]
for line in data: # fill arrays
    p=line.split()
    scylla_scatter2.append(float(p[0]))
    scylla_ncra2.append(float(p[1]))
    scylla_ncra2lo.append(float(p[2]))
    scylla_ncra2hi.append(float(p[3]))
    scylla_cra2tide.append(float(p[4]))
    scylla_cra2tidelo.append(float(p[5]))
    scylla_cra2tidehi.append(float(p[6]))
scylla_scatter2=np.array(scylla_scatter2)
scylla_ncra2=np.array(scylla_ncra2)
scylla_ncra2lo=np.array(scylla_ncra2lo)
scylla_ncra2hi=np.array(scylla_ncra2hi)
scylla_cra2tide=np.array(scylla_cra2tide)
scylla_cra2tidelo=np.array(scylla_cra2tidelo)
scylla_cra2tidehi=np.array(scylla_cra2tidehi)

with open('cra2_elvis2_scylla_gal5.dat') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()
scylla_scatter=[]
scylla_ngal5=[]
scylla_ngal5lo=[]
scylla_ngal5hi=[]
scylla_gal5tide=[]
scylla_gal5tidelo=[]
scylla_gal5tidehi=[]
for line in data: # fill arrays
    p=line.split()
    scylla_scatter.append(float(p[0]))
    scylla_ngal5.append(float(p[1]))
    scylla_ngal5lo.append(float(p[2]))
    scylla_ngal5hi.append(float(p[3]))
    scylla_gal5tide.append(float(p[4]))
    scylla_gal5tidelo.append(float(p[5]))
    scylla_gal5tidehi.append(float(p[6]))
scylla_scatter=np.array(scylla_scatter)
scylla_ngal5=np.array(scylla_ngal5)
scylla_ngal5lo=np.array(scylla_ngal5lo)
scylla_ngal5hi=np.array(scylla_ngal5hi)
scylla_gal5tide=np.array(scylla_gal5tide)
scylla_gal5tidelo=np.array(scylla_gal5tidelo)
scylla_gal5tidehi=np.array(scylla_gal5tidehi)

with open('cra2_elvis2_hall_cra2.dat') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()
hall_scatter2=[]
hall_ncra2=[]
hall_ncra2lo=[]
hall_ncra2hi=[]
hall_cra2tide=[]
hall_cra2tidelo=[]
hall_cra2tidehi=[]
for line in data: # fill arrays
    p=line.split()
    hall_scatter2.append(float(p[0]))
    hall_ncra2.append(float(p[1]))
    hall_ncra2lo.append(float(p[2]))
    hall_ncra2hi.append(float(p[3]))
    hall_cra2tide.append(float(p[4]))
    hall_cra2tidelo.append(float(p[5]))
    hall_cra2tidehi.append(float(p[6]))
hall_scatter2=np.array(hall_scatter2)
hall_ncra2=np.array(hall_ncra2)
hall_ncra2lo=np.array(hall_ncra2lo)
hall_ncra2hi=np.array(hall_ncra2hi)
hall_cra2tide=np.array(hall_cra2tide)
hall_cra2tidelo=np.array(hall_cra2tidelo)
hall_cra2tidehi=np.array(hall_cra2tidehi)

with open('cra2_elvis2_hall_gal5.dat') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()
hall_scatter=[]
hall_ngal5=[]
hall_ngal5lo=[]
hall_ngal5hi=[]
hall_gal5tide=[]
hall_gal5tidelo=[]
hall_gal5tidehi=[]
for line in data: # fill arrays
    p=line.split()
    hall_scatter.append(float(p[0]))
    hall_ngal5.append(float(p[1]))
    hall_ngal5lo.append(float(p[2]))
    hall_ngal5hi.append(float(p[3]))
    hall_gal5tide.append(float(p[4]))
    hall_gal5tidelo.append(float(p[5]))
    hall_gal5tidehi.append(float(p[6]))
hall_scatter=np.array(hall_scatter)
hall_ngal5=np.array(hall_ngal5)
hall_ngal5lo=np.array(hall_ngal5lo)
hall_ngal5hi=np.array(hall_ngal5hi)
hall_gal5tide=np.array(hall_gal5tide)
hall_gal5tidelo=np.array(hall_gal5tidelo)
hall_gal5tidehi=np.array(hall_gal5tidehi)


gs=plt.GridSpec(12,12) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
axelvis=fig.add_subplot(gs[0:3,0:5])
axtide=fig.add_subplot(gs[3:6,0:5])
axorbit=fig.add_subplot(gs[8:12,0:4])
axgal=fig.add_subplot(gs[8:12,7:12])

axtide.set_xlim([0.2,2.])
axtide.set_ylim([-3,-0.1])
axtide.set_xticks([0.5,1.,1.5,2])
axtide.set_xticklabels([0.5,1.,1.5,2])
axtide.set_xlabel(r'scatter in SMHM [dex]')
axtide.set_ylabel(r'$\log_{10}[M_{\rm vir}/M_{\rm peak}]$')
axtide.plot(kauket_scatter,kauket_gal5tide,color='r',linestyle='--')
axtide.fill_between(kauket_scatter2,kauket_cra2tidelo,kauket_cra2tidehi,color='r',alpha=0.1)
axtide.plot(kauket_scatter2,kauket_cra2tide,color='r')
axtide.plot(scylla_scatter,scylla_gal5tide,color='b',linestyle='--')
axtide.fill_between(scylla_scatter2,scylla_cra2tidelo,scylla_cra2tidehi,color='b',alpha=0.1)
axtide.plot(scylla_scatter2,scylla_cra2tide,color='b')
axtide.plot(hall_scatter,hall_gal5tide,color='green',linestyle='--')
axtide.fill_between(hall_scatter2,hall_cra2tidelo,hall_cra2tidehi,color='green',alpha=0.1)
axtide.plot(hall_scatter2,hall_cra2tide,color='green')
axtide.plot([1,1.3],[-12.5,-12.5],color='k',linestyle='--',label=r'$M_*>10^5M_{\odot}$')
axtide.plot([1,1.3],[-12,-12],color='k',label=r'$M_*>10^5M_{\odot},M_{\rm halo}<10^7M_{\odot}$')
#axtide.legend(loc=4,fontsize=4,handlelength=4.5,scatterpoints=1,borderaxespad=0)

axgal.set_xlim([0.2,2.])
axgal.set_ylim([-3,-0.1])
axgal.set_xticks([0.5,1.,1.5,2])
axgal.set_xticklabels([0.5,1.,1.5,2])
axgal.set_xlabel(r'scatter in SMHM [dex]')
axgal.set_ylabel(r'$\log_{10}[M_{\rm vir}/M_{\rm peak}]$')
axgal.plot(kauket_scatter,kauket_gal5tide,color='r',linestyle='--')
axgal.fill_between(kauket_scatter2,kauket_cra2tidelo,kauket_cra2tidehi,color='r',alpha=0.1)
axgal.plot(kauket_scatter2,kauket_cra2tide,color='r',lw=2)
axgal.plot(scylla_scatter,scylla_gal5tide,color='b',linestyle='--')
axgal.fill_between(scylla_scatter2,scylla_cra2tidelo,scylla_cra2tidehi,color='b',alpha=0.1)
axgal.plot(scylla_scatter2,scylla_cra2tide,color='b')
axgal.plot(hall_scatter,hall_gal5tide,color='green',linestyle='--')
axgal.fill_between(hall_scatter2,hall_cra2tidelo,hall_cra2tidehi,color='green',alpha=0.1)
axgal.plot(hall_scatter2,hall_cra2tide,color='green')
axgal.plot([1,1.3],[-12.5,-12.5],color='k',linestyle='--',label=r'$M_*>10^5M_{\odot}$')
axgal.plot([1,1.3],[-12,-12],color='k',label=r'$M_*>10^5M_{\odot},M_{\rm halo}<10^7M_{\odot}$')
axgal.plot([1,1.3],[-12.5,-12.5],color='k',linestyle='--',label=r'$M_*>10^5M_{\odot}$')
axgal.plot([1,1.3],[-12,-12],color='k',label=r'$M_*>10^5M_{\odot},M_{\rm halo}<10^7M_{\odot}$')
axgal.legend(loc=4,fontsize=4,handlelength=4.5,scatterpoints=1,borderaxespad=0)

#axtide.plot(scylla_tide_x,scylla_tide,color='b')
#axtide.plot(hall_tide_x,hall_tide,color='c')
#axtide.plot(kauket_tide_x,kauket_tide2,color='r',linestyle='--')
#axtide.plot(scylla_tide_x,scylla_tide2,color='b',linestyle='--')
#axtide.plot(hall_tide_x,hall_tide2,color='c',linestyle='--')
#axtide.plot(tide_x,scylla_tide,color='b')
#axtide.plot(tide_x,hall_tide,color='c')

axelvis.set_xlim([0.2,2.])
axelvis.set_ylim([0.5,9000])
axelvis.set_xscale(u'linear')
axelvis.set_yscale(u'log')
axelvis.xaxis.set_major_formatter(plt.NullFormatter())
#axelvis.set_xlabel(r'scatter in SMHM [dex]')
axelvis.set_ylabel(r'$N_{\rm satellites}$')
#axelvis.plot(scylla_x,scylla_y0,color='b',alpha=1,label=r'$M_{\rm host}=1.6\times 10^{12}M_{\odot}$',zorder=5)
#axelvis.plot(hall_x,hall_y0,color='c',alpha=1,label=r'$M_{\rm host}=1.7\times 10^{12}M_{\odot}$',zorder=5)
axelvis.plot(kauket_scatter,kauket_ngal5,color='r',alpha=1,linestyle='--',lw=1.4)
axelvis.fill_between(kauket_scatter2,kauket_ncra2lo,kauket_ncra2hi,color='r',alpha=0.1)
axelvis.plot(kauket_scatter2,kauket_ncra2,color='r',alpha=1,lw=2)
axelvis.plot(scylla_scatter,scylla_ngal5,color='b',alpha=1,linestyle='--')
axelvis.fill_between(scylla_scatter2,scylla_ncra2lo,scylla_ncra2hi,color='b',alpha=0.1)
axelvis.plot(scylla_scatter2,scylla_ncra2,color='b',alpha=1)
axelvis.plot(hall_scatter,hall_ngal5,color='green',alpha=1,linestyle='--')
axelvis.fill_between(hall_scatter2,hall_ncra2lo,hall_ncra2hi,color='green',alpha=0.1)
axelvis.plot(hall_scatter2,hall_ncra2,color='green',alpha=1)
axelvis.plot([1,2],[10000,10000],color='r',label=r'$M_{\rm host}=1.0\times 10^{12}M_{\odot}$')
axelvis.plot([1,2],[10000,10000],color='b',label=r'$M_{\rm host}=1.6\times 10^{12}M_{\odot}$')
axelvis.plot([1,2],[10000,10000],color='green',label=r'$M_{\rm host}=1.7\times 10^{12}M_{\odot}$')
axelvis.plot([1,1.3],[-12.5,-12.5],color='k',linestyle='--',label=r'$M_*>10^5M_{\odot}$')
axelvis.plot([1,1.3],[-12,-12],color='k',label=r'$M_*>10^5M_{\odot},M_{\rm halo}<10^7M_{\odot}$')
#axelvis.plot(scylla_x,scylla_y02,color='b',alpha=1,label=r'$M_{\rm host}=1.6\times 10^{12}M_{\odot}$',zorder=5,linestyle='--')
#axelvis.plot(hall_x,hall_y02,color='c',alpha=1,label=r'$M_{\rm host}=1.7\times 10^{12}M_{\odot}$',zorder=5,linestyle='--')
#axelvis.plot(kauket_x,kauket_y02,color='r',alpha=1,label=r'$M_{\rm host}=1.0\times 10^{12}M_{\odot}$',zorder=10,linestyle='--')
#axelvis.legend(loc=2,fontsize=5,scatterpoints=1,borderaxespad=0)
axelvis.legend(loc=1,fontsize=4,handlelength=4.5,scatterpoints=1,borderaxespad=0)

plotfilename='cra2_elvis25.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
