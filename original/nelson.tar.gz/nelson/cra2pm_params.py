import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
from scipy.stats import gaussian_kde
#import randomp
import mycode2
from matplotlib.patches import Rectangle
np.set_printoptions(threshold='nan')
#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')

plt.rc('legend',frameon='False')
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='6')
plt.rc('ytick',labelsize='6')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

rahcenter=11
ramcenter=49
rascenter=14.4
chardecdcenter='-18'
decmcenter=24
decscenter=46.8
racenter0,deccenter0=mycode2.radecradians(rahcenter,ramcenter,rascenter,chardecdcenter,decmcenter,decscenter)
            
data1='/physics2/mgwalker/chains/cra2pm.pop'
out1='cra2pm_newcommands.tex'
g1=open(out1,'w')

cra2_dmodulus=20.3
maxsigv=10.

with open(data1) as f: # read data file
    data=f.readlines()[1:]
cra2_ra=[]
cra2_dec=[]
cra2_xi=[]
cra2_eta=[]
cra2_r=[]
cra2_theta=[]
cra2_hjd=[]
cra2_v=[]
cra2_sigv=[]
cra2_skewv=[]
cra2_kurtv=[]
cra2_teff=[]
cra2_sigteff=[]
cra2_skewteff=[]
cra2_kurtteff=[]
cra2_logg=[]
cra2_siglogg=[]
cra2_skewlogg=[]
cra2_kurtlogg=[]
cra2_z=[]
cra2_sigz=[]
cra2_skewz=[]
cra2_kurtz=[]
cra2_snratio=[]
cra2_gmag=[]
cra2_siggmag=[]
cra2_rmag=[]
cra2_sigrmag=[]
cra2_imag=[]
cra2_sigimag=[]
cra2_pmem=[]
cra2_pmemlo1=[]
cra2_pmemhi1=[]
cra2_pmemlo2=[]
cra2_pmemhi2=[]
cra2_pnon=[]
cra2_pnonlo1=[]
cra2_pnonhi1=[]
cra2_pnonlo2=[]
cra2_pnonhi2=[]

for line in data: # fill arrays
    p=line.split()
    cra2_ra.append(float(p[0]))
    cra2_dec.append(float(p[1]))
    cra2_xi.append(float(p[2]))
    cra2_eta.append(float(p[3]))
    cra2_r.append(float(p[4]))
    cra2_theta.append(float(p[5]))
    cra2_hjd.append(float(p[6]))
    cra2_v.append(float(p[7]))
    cra2_sigv.append(float(p[8]))
    cra2_skewv.append(float(p[9]))
    cra2_kurtv.append(float(p[10]))
    cra2_teff.append(float(p[11]))
    cra2_sigteff.append(float(p[12]))
    cra2_skewteff.append(float(p[13]))
    cra2_kurtteff.append(float(p[14]))
    cra2_logg.append(float(p[15]))
    cra2_siglogg.append(float(p[16]))
    cra2_skewlogg.append(float(p[17]))
    cra2_kurtlogg.append(float(p[18]))
    cra2_z.append(float(p[19]))
    cra2_sigz.append(float(p[20]))
    cra2_skewz.append(float(p[21]))
    cra2_kurtz.append(float(p[22]))
    cra2_snratio.append(float(p[24]))
    cra2_gmag.append(float(p[25]))
    cra2_siggmag.append(float(p[26]))
    cra2_rmag.append(float(p[27]))
    cra2_sigrmag.append(float(p[28]))
    cra2_imag.append(float(p[29]))
    cra2_sigimag.append(float(p[30]))
    cra2_pmem.append(float(p[31]))
    cra2_pmemlo1.append(float(p[32]))
    cra2_pmemhi1.append(float(p[33]))
    cra2_pmemlo2.append(float(p[34]))
    cra2_pmemhi2.append(float(p[35]))
    cra2_pnon.append(float(p[36]))
    cra2_pnonlo1.append(float(p[37]))
    cra2_pnonhi1.append(float(p[38]))
    cra2_pnonlo2.append(float(p[39]))
    cra2_pnonhi2.append(float(p[40]))

cra2_ra=np.array(cra2_ra)
cra2_dec=np.array(cra2_dec)
cra2_xi=np.array(cra2_xi)
cra2_eta=np.array(cra2_eta)
cra2_r=np.array(cra2_r)
cra2_theta=np.array(cra2_theta)
cra2_hjd=np.array(cra2_hjd)
cra2_v=np.array(cra2_v)
cra2_sigv=np.array(cra2_sigv)
cra2_skewv=np.array(cra2_skewv)
cra2_kurtv=np.array(cra2_kurtv)
cra2_teff=np.array(cra2_teff)
cra2_sigteff=np.array(cra2_sigteff)
cra2_skewteff=np.array(cra2_skewteff)
cra2_kurtteff=np.array(cra2_kurtteff)
cra2_logg=np.array(cra2_logg)
cra2_siglogg=np.array(cra2_siglogg)
cra2_skewlogg=np.array(cra2_skewlogg)
cra2_kurtlogg=np.array(cra2_kurtlogg)
cra2_z=np.array(cra2_z)
cra2_sigz=np.array(cra2_sigz)
cra2_skewz=np.array(cra2_skewz)
cra2_kurtz=np.array(cra2_kurtz)
cra2_pmem=np.array(cra2_pmem)
cra2_snratio=np.array(cra2_snratio)
cra2_gmag=np.array(cra2_gmag)
cra2_siggmag=np.array(cra2_siggmag)
cra2_rmag=np.array(cra2_rmag)
cra2_sigrmag=np.array(cra2_sigrmag)
cra2_imag=np.array(cra2_imag)
cra2_sigimag=np.array(cra2_sigimag)
cra2_pmem=np.array(cra2_pmem)
cra2_pmemlo1=np.array(cra2_pmemlo1)
cra2_pmemhi1=np.array(cra2_pmemhi1)
cra2_pmemlo2=np.array(cra2_pmemlo2)
cra2_pmemhi2=np.array(cra2_pmemhi2)
cra2_pnon=np.array(cra2_pnon)
cra2_pnonlo1=np.array(cra2_pnonlo1)
cra2_pnonhi1=np.array(cra2_pnonhi1)
cra2_pnonlo2=np.array(cra2_pnonlo2)
cra2_pnonhi2=np.array(cra2_pnonhi2)
    
cra2_mag=cra2_gmag
cra2_col=cra2_gmag-cra2_imag
cra2_sigr=cra2_r-cra2_r+0.000001

cra2_vmem=[70.,110.]
cra2_loggmem=[0.5,3.2]
cra2_zmem=[-4.,-0.5]
cra2_teffmem=[4000,7500]
cra2_rmem=[0.,90.]
cra2_magmem=[21.5,18]
cra2_colmem=[0.4,0.75]

#cra2_keep=np.where((cra2_sigv < maxsigv) & (cra2_skewv >= -1.) & (cra2_skewv <= 1.) & (cra2_kurtv >= -1) & (cra2_kurtv <= 1))
cra2_keep=np.where((cra2_sigv < maxsigv) & (cra2_skewv >= -1.) & (cra2_skewv <= 1.) & (cra2_kurtv >= -1) & (cra2_kurtv <= 1))
cra2_mem=np.where((cra2_pmem >= 0.5) & (cra2_sigv < maxsigv) & (np.abs(cra2_skewv) >= -1.) & (np.abs(cra2_skewv) <= 1.) & (np.abs(cra2_kurtv) >= -1.) & (np.abs(cra2_kurtv) <= 1.))
#cra2_mem=np.where((cra2_sigv < maxsigv) & (cra2_skewv > -1.) & (cra2_skewv < 1.) & (cra2_kurtv > -1.) & (cra2_kurtv < 1.) & (cra2_pmem > 0.9))
cra2_nonmem=np.where((cra2_pmem < 0.5) & (cra2_sigv < maxsigv) & (np.abs(cra2_skewv) >= -1.) & (np.abs(cra2_skewv) <= 1.) & (np.abs(cra2_kurtv) >= -1.) & (np.abs(cra2_kurtv) <= 1.))

data4='age12fehm170.iso'
with open(data4) as g: # read data file
    iso_data=g.readlines()[9:]

iso170_g=[]
iso170_r=[]
iso170_i=[]
iso170_logg=[]
iso170_teff=[]

for line in iso_data: # fill arrays
    p=line.split()
    iso170_teff.append(float(p[2]))
    iso170_logg.append(float(p[3]))
    iso170_g.append(float(p[6]))
    iso170_r.append(float(p[7]))
    iso170_i.append(float(p[8]))

iso170_g=np.array(iso170_g)
iso170_r=np.array(iso170_r)
iso170_i=np.array(iso170_i)
iso170_logg=np.array(iso170_logg)
iso170_teff=np.array(iso170_teff)
iso170_teff=10.**iso170_teff

data3='age12fehm250.iso'
with open(data3) as g: # read data file
    iso_data=g.readlines()[9:]

iso250_g=[]
iso250_r=[]
iso250_i=[]
iso250_logg=[]
iso250_teff=[]

for line in iso_data: # fill arrays
    p=line.split()
    iso250_teff.append(float(p[2]))
    iso250_logg.append(float(p[3]))
    iso250_g.append(float(p[6]))
    iso250_r.append(float(p[7]))
    iso250_i.append(float(p[8]))

iso250_g=np.array(iso250_g)
iso250_r=np.array(iso250_r)
iso250_i=np.array(iso250_i)
iso250_logg=np.array(iso250_logg)
iso250_teff=np.array(iso250_teff)
iso250_teff=10.**iso250_teff



data3='age12fehm200.iso'
with open(data3) as g: # read data file
    iso_data=g.readlines()[9:]

iso200_g=[]
iso200_r=[]
iso200_i=[]
iso200_logg=[]
iso200_teff=[]

for line in iso_data: # fill arrays
    p=line.split()
    iso200_teff.append(float(p[2]))
    iso200_logg.append(float(p[3]))
    iso200_g.append(float(p[6]))
    iso200_r.append(float(p[7]))
    iso200_i.append(float(p[8]))

iso200_g=np.array(iso200_g)
iso200_r=np.array(iso200_r)
iso200_i=np.array(iso200_i)
iso200_logg=np.array(iso200_logg)
iso200_teff=np.array(iso200_teff)
iso200_teff=10.**iso200_teff



data3='age12fehm100.iso'
with open(data3) as g: # read data file
    iso_data=g.readlines()[9:]

iso100_g=[]
iso100_r=[]
iso100_i=[]
iso100_logg=[]
iso100_teff=[]

for line in iso_data: # fill arrays
    p=line.split()
    iso100_teff.append(float(p[2]))
    iso100_logg.append(float(p[3]))
    iso100_g.append(float(p[6]))
    iso100_r.append(float(p[7]))
    iso100_i.append(float(p[8]))

iso100_g=np.array(iso100_g)
iso100_r=np.array(iso100_r)
iso100_i=np.array(iso100_i)
iso100_logg=np.array(iso100_logg)
iso100_teff=np.array(iso100_teff)
iso100_teff=10.**iso100_teff


data3='age12fehm150.iso'
with open(data3) as g: # read data file
    iso_data=g.readlines()[9:]

iso150_g=[]
iso150_r=[]
iso150_i=[]
iso150_logg=[]
iso150_teff=[]

for line in iso_data: # fill arrays
    p=line.split()
    iso150_teff.append(float(p[2]))
    iso150_logg.append(float(p[3]))
    iso150_g.append(float(p[6]))
    iso150_r.append(float(p[7]))
    iso150_i.append(float(p[8]))

iso150_g=np.array(iso150_g)
iso150_r=np.array(iso150_r)
iso150_i=np.array(iso150_i)
iso150_logg=np.array(iso150_logg)
iso150_teff=np.array(iso150_teff)
iso150_teff=10.**iso150_teff


data3='age12fehm150.iso'
with open(data3) as g: # read data file
    iso_data=g.readlines()[9:]

iso150_g=[]
iso150_r=[]
iso150_i=[]
iso150_logg=[]
iso150_teff=[]

for line in iso_data: # fill arrays
    p=line.split()
    iso150_teff.append(float(p[2]))
    iso150_logg.append(float(p[3]))
    iso150_g.append(float(p[6]))
    iso150_r.append(float(p[7]))
    iso150_i.append(float(p[8]))

iso150_g=np.array(iso150_g)
iso150_r=np.array(iso150_r)
iso150_i=np.array(iso150_i)
iso150_logg=np.array(iso150_logg)
iso150_teff=np.array(iso150_teff)
iso150_teff=10.**iso150_teff



data3='age12fehm100.iso'
with open(data3) as g: # read data file
    iso_data=g.readlines()[9:]

iso100_g=[]
iso100_r=[]
iso100_i=[]
iso100_logg=[]
iso100_teff=[]

for line in iso_data: # fill arrays
    p=line.split()
    iso100_teff.append(float(p[2]))
    iso100_logg.append(float(p[3]))
    iso100_g.append(float(p[6]))
    iso100_r.append(float(p[7]))
    iso100_i.append(float(p[8]))

iso100_g=np.array(iso100_g)
iso100_r=np.array(iso100_r)
iso100_i=np.array(iso100_i)
iso100_logg=np.array(iso100_logg)
iso100_teff=np.array(iso100_teff)
iso100_teff=10.**iso100_teff



data3='age12fehm050.iso'
with open(data3) as g: # read data file
    iso_data=g.readlines()[9:]

iso050_g=[]
iso050_r=[]
iso050_i=[]
iso050_logg=[]
iso050_teff=[]

for line in iso_data: # fill arrays
    p=line.split()
    iso050_teff.append(float(p[2]))
    iso050_logg.append(float(p[3]))
    iso050_g.append(float(p[6]))
    iso050_r.append(float(p[7]))
    iso050_i.append(float(p[8]))

iso050_g=np.array(iso050_g)
iso050_r=np.array(iso050_r)
iso050_i=np.array(iso050_i)
iso050_logg=np.array(iso050_logg)
iso050_teff=np.array(iso050_teff)
iso050_teff=10.**iso050_teff



data3='age12fehm000.iso'
with open(data3) as g: # read data file
    iso_data=g.readlines()[9:]

iso000_g=[]
iso000_r=[]
iso000_i=[]
iso000_logg=[]
iso000_teff=[]

for line in iso_data: # fill arrays
    p=line.split()
    iso000_teff.append(float(p[2]))
    iso000_logg.append(float(p[3]))
    iso000_g.append(float(p[6]))
    iso000_r.append(float(p[7]))
    iso000_i.append(float(p[8]))

iso000_g=np.array(iso000_g)
iso000_r=np.array(iso000_r)
iso000_i=np.array(iso000_i)
iso000_logg=np.array(iso000_logg)
iso000_teff=np.array(iso000_teff)
iso000_teff=10.**iso000_teff

gs=plt.GridSpec(7,5) # define multi-panel plot
gs2=plt.GridSpec(15,15) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
gs2.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
#fig.set_

ax10_10=fig.add_subplot(gs2[12:15,12:15])
ax10_9=fig.add_subplot(gs2[12:15,9:12])
ax9_10=fig.add_subplot(gs2[9:12,12:15])

#ax4_4=fig.add_subplot(gs2[3:,3:])

ax6_0=fig.add_subplot(gs[6,0])
ax5_0=fig.add_subplot(gs[5,0])
ax4_0=fig.add_subplot(gs[4,0])
ax3_0=fig.add_subplot(gs[3,0])

ax5_1=fig.add_subplot(gs[5,1])
ax4_1=fig.add_subplot(gs[4,1])
ax3_1=fig.add_subplot(gs[3,1])

ax4_2=fig.add_subplot(gs[4,2])
ax3_2=fig.add_subplot(gs[3,2])

ax3_3=fig.add_subplot(gs[3,3])

ax3_4=fig.add_subplot(gs[3,4])


ax2_0=fig.add_subplot(gs[2,0])
ax2_1=fig.add_subplot(gs[2,1])
ax2_2=fig.add_subplot(gs[2,2])
ax2_3=fig.add_subplot(gs[2,3])

vlim=[-100,300]
tefflim=[4001.,7999.] 
revtefflim=[7999.,4001.] 
logglim=[0.001,4.99]
revlogglim=[4.99,0.001]
zlim=[-4.99,0.99]
rlim=[0.,90.]
collim=[0.25,1]
maglim=[16.5,21.5]
revmaglim=[21.5,16.5]

vlabel=[r'$v_{\rm los}$ [km/s]']
tefflabel=[r'$T_{\rm eff}$ [K]']
logglabel=[r'$\log_{10}[g/(\mathrm{cm/s}^2)]$']
zlabel=[r'$[\mathrm{Fe/H}]$']
rlabel=[r'$R$ [arcmin]']
collabel=[r'g-r [mag]']
maglabel=[r'r [mag]']

histticks=[25,50,75,100]
histlim=[0,100]
rhistlim=[0,35]
rhistticks=[10,20,30]
vticks=[-100,0,100,200,300]
vticklabels=['-100','0','100','200','300']
loggticks=[1,2,3,4]
revloggticks=[4,3,2,1]
logglabels=['1','2','3','4']
revlogglabels=['4','3','2','1']
zticks=[-4,-3,-2,-1,0]
zlabels=['-4','-3','-2','-1','0']
teffticks=[5000,6000,7000]
revteffticks=[7000,6000,5000]
teffticklabels=['5000','6000','7000']
revteffticklabels=['7000','6000','5000']
colmap=plt.get_cmap("Greys")
rticks=[20,40,60,80]
rticklabels=['20','40','60','80']
colticks=[0.5,0.75]
colticklabels=colticks
magticks=[17,18,19,20]
revmagticks=[20,19,18,17]
magticklabels=magticks
revmagticklabels=revmagticks

cra2_vteffx=[cra2_vmem[0],cra2_vmem[1],cra2_vmem[1],cra2_vmem[0],cra2_vmem[0]]
cra2_vteffy=[cra2_teffmem[0],cra2_teffmem[0],cra2_teffmem[1],cra2_teffmem[1],cra2_teffmem[0]]
cra2_vloggx=[cra2_vmem[0],cra2_vmem[1],cra2_vmem[1],cra2_vmem[0],cra2_vmem[0]]
cra2_vloggy=[cra2_loggmem[0],cra2_loggmem[0],cra2_loggmem[1],cra2_loggmem[1],cra2_loggmem[0]]
cra2_vzx=[cra2_vmem[0],cra2_vmem[1],cra2_vmem[1],cra2_vmem[0],cra2_vmem[0]]
cra2_vzy=[cra2_zmem[0],cra2_zmem[0],cra2_zmem[1],cra2_zmem[1],cra2_zmem[0]]
cra2_vrx=[cra2_vmem[0],cra2_vmem[1],cra2_vmem[1],cra2_vmem[0],cra2_vmem[0]]
cra2_vry=[cra2_rmem[0],cra2_rmem[0],cra2_rmem[1],cra2_rmem[1],cra2_rmem[0]]
cra2_vcolx=[cra2_vmem[0],cra2_vmem[1],cra2_vmem[1],cra2_vmem[0],cra2_vmem[0]]
cra2_vcoly=[cra2_colmem[0],cra2_colmem[0],cra2_colmem[1],cra2_colmem[1],cra2_colmem[0]]
cra2_vmagx=[cra2_vmem[0],cra2_vmem[1],cra2_vmem[1],cra2_vmem[0],cra2_vmem[0]]
cra2_vmagy=[cra2_magmem[0],cra2_magmem[0],cra2_magmem[1],cra2_magmem[1],cra2_magmem[0]]

cra2_teffloggx=[cra2_teffmem[0],cra2_teffmem[1],cra2_teffmem[1],cra2_teffmem[0],cra2_teffmem[0]]
cra2_teffloggy=[cra2_loggmem[0],cra2_loggmem[0],cra2_loggmem[1],cra2_loggmem[1],cra2_loggmem[0]]
cra2_teffzx=[cra2_teffmem[0],cra2_teffmem[1],cra2_teffmem[1],cra2_teffmem[0],cra2_teffmem[0]]
cra2_teffzy=[cra2_zmem[0],cra2_zmem[0],cra2_zmem[1],cra2_zmem[1],cra2_zmem[0]]
cra2_teffrx=[cra2_teffmem[0],cra2_teffmem[1],cra2_teffmem[1],cra2_teffmem[0],cra2_teffmem[0]]
cra2_teffry=[cra2_rmem[0],cra2_rmem[0],cra2_rmem[1],cra2_rmem[1],cra2_rmem[0]]
cra2_teffcolx=[cra2_teffmem[0],cra2_teffmem[1],cra2_teffmem[1],cra2_teffmem[0],cra2_teffmem[0]]
cra2_teffcoly=[cra2_colmem[0],cra2_colmem[0],cra2_colmem[1],cra2_colmem[1],cra2_colmem[0]]
cra2_teffmagx=[cra2_teffmem[0],cra2_teffmem[1],cra2_teffmem[1],cra2_teffmem[0],cra2_teffmem[0]]
cra2_teffmagy=[cra2_magmem[0],cra2_magmem[0],cra2_magmem[1],cra2_magmem[1],cra2_magmem[0]]

cra2_loggzx=[cra2_loggmem[0],cra2_loggmem[1],cra2_loggmem[1],cra2_loggmem[0],cra2_loggmem[0]]
cra2_loggzy=[cra2_zmem[0],cra2_zmem[0],cra2_zmem[1],cra2_zmem[1],cra2_zmem[0]]
cra2_loggrx=[cra2_loggmem[0],cra2_loggmem[1],cra2_loggmem[1],cra2_loggmem[0],cra2_loggmem[0]]
cra2_loggry=[cra2_rmem[0],cra2_rmem[0],cra2_rmem[1],cra2_rmem[1],cra2_rmem[0]]
cra2_loggcolx=[cra2_loggmem[0],cra2_loggmem[1],cra2_loggmem[1],cra2_loggmem[0],cra2_loggmem[0]]
cra2_loggcoly=[cra2_colmem[0],cra2_colmem[0],cra2_colmem[1],cra2_colmem[1],cra2_colmem[0]]
cra2_loggmagx=[cra2_loggmem[0],cra2_loggmem[1],cra2_loggmem[1],cra2_loggmem[0],cra2_loggmem[0]]
cra2_loggmagy=[cra2_magmem[0],cra2_magmem[0],cra2_magmem[1],cra2_magmem[1],cra2_magmem[0]]

cra2_zrx=[cra2_zmem[0],cra2_zmem[1],cra2_zmem[1],cra2_zmem[0],cra2_zmem[0]]
cra2_zry=[cra2_rmem[0],cra2_rmem[0],cra2_rmem[1],cra2_rmem[1],cra2_rmem[0]]
cra2_zcolx=[cra2_zmem[0],cra2_zmem[1],cra2_zmem[1],cra2_zmem[0],cra2_zmem[0]]
cra2_zcoly=[cra2_colmem[0],cra2_colmem[0],cra2_colmem[1],cra2_colmem[1],cra2_colmem[0]]
cra2_zmagx=[cra2_zmem[0],cra2_zmem[1],cra2_zmem[1],cra2_zmem[0],cra2_zmem[0]]
cra2_zmagy=[cra2_magmem[0],cra2_magmem[0],cra2_magmem[1],cra2_magmem[1],cra2_magmem[0]]

ax6_0.set_xlabel(vlabel[0],fontsize=8,rotation=0)
ax6_0.set_ylabel(tefflabel[0],fontsize=8,rotation=90,labelpad=5)
ax6_0.set_xlim(vlim)
ax6_0.set_ylim(revtefflim)
ax6_0.set_xscale(u'linear')
ax6_0.set_yscale(u'linear')
ax6_0.set_xticks(vticks)
ax6_0.set_xticklabels(vticklabels,rotation=0)
ax6_0.set_yticks([8000]+revteffticks)
ax6_0.set_yticklabels([8000]+revteffticks,rotation=0)
ax6_0.errorbar(cra2_v[cra2_keep],cra2_teff[cra2_keep],xerr=cra2_sigv[cra2_keep],yerr=cra2_sigteff[cra2_keep],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True)
ax6_0.errorbar(cra2_v[cra2_mem],cra2_teff[cra2_mem],xerr=cra2_sigv[cra2_mem],yerr=cra2_sigteff[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True)
##ax6_0.add_patch(Rectangle((cra2_vmem[0],cra2_teffmem[0]),cra2_vmem[1]-cra2_vmem[0],cra2_teffmem[1]-cra2_teffmem[0],facecolor='r',alpha=0.2,edgecolor='None'))

ax5_0.set_ylabel(logglabel[0],fontsize=8,rotation=90,labelpad=5)
ax5_0.set_xlim(vlim)
ax5_0.set_ylim(revlogglim)
ax5_0.set_xscale(u'linear')
ax5_0.set_yscale(u'linear')
ax5_0.set_xticks(vticks)
ax5_0.set_yticks(revloggticks)
ax5_0.set_yticklabels(revloggticks,rotation=0)
ax5_0.xaxis.set_major_formatter(plt.NullFormatter())
#ax5_0.add_patch(Rectangle((cra2_vmem[0],cra2_loggmem[0]),cra2_vmem[1]-cra2_vmem[0],cra2_loggmem[1]-cra2_loggmem[0],facecolor='r',alpha=0.2,edgecolor='None'))
ax5_0.errorbar(cra2_v[cra2_keep],cra2_logg[cra2_keep],xerr=cra2_sigv[cra2_keep],yerr=cra2_siglogg[cra2_keep],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True)
ax5_0.errorbar(cra2_v[cra2_mem],cra2_logg[cra2_mem],xerr=cra2_sigv[cra2_mem],yerr=cra2_siglogg[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True)
#ax5_0.plot(cra2_vloggx,cra2_vloggy,color='r',linewidth=0.25)

ax4_0.set_ylabel(zlabel[0],fontsize=8,rotation=90,labelpad=5)
ax4_0.set_xlim(vlim)
ax4_0.set_ylim(zlim)
ax4_0.set_xscale(u'linear')
ax4_0.set_yscale(u'linear')
ax4_0.set_xticks(vticks)
ax4_0.set_yticks(zticks)
ax4_0.set_yticklabels(zticks,rotation=0)
ax4_0.xaxis.set_major_formatter(plt.NullFormatter())
#ax4_0.add_patch(Rectangle((cra2_vmem[0],cra2_zmem[0]),cra2_vmem[1]-cra2_vmem[0],cra2_zmem[1]-cra2_zmem[0],facecolor='r',alpha=0.2,edgecolor='None'))
ax4_0.errorbar(cra2_v[cra2_keep],cra2_z[cra2_keep],xerr=cra2_sigv[cra2_keep],yerr=cra2_sigz[cra2_keep],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True)
ax4_0.errorbar(cra2_v[cra2_mem],cra2_z[cra2_mem],xerr=cra2_sigv[cra2_mem],yerr=cra2_sigz[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True)
#ax4_0.plot(cra2_vzx,cra2_vzy,color='r',linewidth=0.25)

ax3_0.set_ylabel(rlabel[0],fontsize=8,rotation=90,labelpad=5)
ax3_0.set_xlim(vlim)
ax3_0.set_ylim(rlim)
ax3_0.set_xscale(u'linear')
ax3_0.set_yscale(u'linear')
ax3_0.set_xticks(vticks)
ax3_0.set_yticks(rticks)
ax3_0.set_yticklabels(rticks,rotation=0)
ax3_0.xaxis.set_major_formatter(plt.NullFormatter())
#ax3_0.add_patch(Rectangle((cra2_vmem[0],cra2_rmem[0]),cra2_vmem[1]-cra2_vmem[0],cra2_rmem[1]-cra2_rmem[0],facecolor='r',alpha=0.2,edgecolor='None'))
ax3_0.errorbar(cra2_v[cra2_keep],cra2_r[cra2_keep],xerr=cra2_sigv[cra2_keep],yerr=cra2_sigr[cra2_keep],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True,label='MW foreground')
ax3_0.errorbar(cra2_v[cra2_mem],cra2_r[cra2_mem],xerr=cra2_sigv[cra2_mem],yerr=cra2_sigr[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True,label='member')
#ax3_0.plot(cra2_vrx,cra2_vry,color='r',linewidth=0.25)

ax2_0.set_ylabel('N',fontsize=8,rotation=90,labelpad=5)
ax2_0.xaxis.set_major_formatter(plt.NullFormatter())
ax2_0.set_xlim(vlim)
ax2_0.set_ylim(histlim)
ax2_0.set_xticks(vticks)
ax2_0.set_yticks(histticks)
ax2_0.hist(cra2_v[cra2_mem],bins=30,range=vlim,normed=False,histtype='stepfilled',align='mid',rwidth=0,orientation='vertical',color='r',linewidth=0.25,alpha=0.5,label='Cra 2')
ax2_0.hist(cra2_v[cra2_keep],bins=30,range=vlim,normed=False,histtype='step',align='mid',rwidth=0,orientation='vertical',color='k',linewidth=0.25,label='MW foreground')
#ax2_0.legend(loc=2,fontsize=6,handlelength=0.5,numpoints=1,scatterpoints=1,shadow=False,borderpad=0)
#ax2_0.text(-80,75,'Cra 2',fontsize=8)
ax2_0.legend(loc=2,fontsize=5,handlelength=1,numpoints=1,scatterpoints=1,shadow=False)

ax5_1.set_xlabel(tefflabel[0],fontsize=8,rotation=0)
ax5_1.set_xlim(revtefflim)
ax5_1.set_ylim(revlogglim)
ax5_1.set_xscale(u'linear')
ax5_1.set_yscale(u'linear')
ax5_1.set_xticks([4000]+revteffticks)
ax5_1.set_xticklabels([4000]+revteffticks,rotation=0)
ax5_1.set_yticks(revloggticks)
ax5_1.yaxis.set_major_formatter(plt.NullFormatter())
#ax5_1.add_patch(Rectangle((cra2_teffmem[0],cra2_loggmem[0]),cra2_teffmem[1]-cra2_teffmem[0],cra2_loggmem[1]-cra2_loggmem[0],facecolor='r',alpha=0.2,edgecolor='None'))
ax5_1.errorbar(cra2_teff[cra2_keep],cra2_logg[cra2_keep],xerr=cra2_sigteff[cra2_keep],yerr=cra2_siglogg[cra2_keep],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True)
ax5_1.errorbar(cra2_teff[cra2_mem],cra2_logg[cra2_mem],xerr=cra2_sigteff[cra2_mem],yerr=cra2_siglogg[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True)

ax4_1.set_xlim(revtefflim)
ax4_1.set_ylim(zlim)
ax4_1.set_xscale(u'linear')
ax4_1.set_yscale(u'linear')
ax4_1.set_xticks(revteffticks)
ax4_1.set_yticks(zticks)
ax4_1.xaxis.set_major_formatter(plt.NullFormatter())
ax4_1.yaxis.set_major_formatter(plt.NullFormatter())
#ax4_1.add_patch(Rectangle((cra2_teffmem[0],cra2_zmem[0]),cra2_teffmem[1]-cra2_teffmem[0],cra2_zmem[1]-cra2_zmem[0],facecolor='r',alpha=0.2,edgecolor='None'))
ax4_1.errorbar(cra2_teff[cra2_keep],cra2_z[cra2_keep],xerr=cra2_sigteff[cra2_keep],yerr=cra2_sigz[cra2_keep],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True)
ax4_1.errorbar(cra2_teff[cra2_mem],cra2_z[cra2_mem],xerr=cra2_sigteff[cra2_mem],yerr=cra2_sigz[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True)

ax3_1.set_xlim(revtefflim)
ax3_1.set_ylim(rlim)
ax3_1.set_xscale(u'linear')
ax3_1.set_yscale(u'linear')
ax3_1.set_xticks(revteffticks)
ax3_1.set_yticks(rticks)
ax3_1.xaxis.set_major_formatter(plt.NullFormatter())
ax3_1.yaxis.set_major_formatter(plt.NullFormatter())
#ax3_1.add_patch(Rectangle((cra2_teffmem[0],cra2_rmem[0]),cra2_teffmem[1]-cra2_teffmem[0],cra2_rmem[1]-cra2_rmem[0],facecolor='r',alpha=0.2,edgecolor='None'))
ax3_1.errorbar(cra2_teff[cra2_keep],cra2_r[cra2_keep],xerr=cra2_sigteff[cra2_keep],yerr=cra2_sigr[cra2_keep],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True)
ax3_1.errorbar(cra2_teff[cra2_mem],cra2_r[cra2_mem],xerr=cra2_sigteff[cra2_mem],yerr=cra2_sigr[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True)

#ax2_1.set_ylabel('N',fontsize=8,rotation=90,labelpad=5)
ax2_1.xaxis.set_major_formatter(plt.NullFormatter())
ax2_1.yaxis.set_major_formatter(plt.NullFormatter())
ax2_1.set_xlim(revtefflim)
ax2_1.set_ylim(histlim)
ax2_1.set_xticks(revteffticks)
ax2_1.set_yticks(histticks)
ax2_1.hist(cra2_teff[cra2_keep],bins=30,range=tefflim,normed=False,histtype='step',align='mid',rwidth=0,orientation='vertical',color='k',linewidth=0.25)
ax2_1.hist(cra2_teff[cra2_mem],bins=30,range=tefflim,normed=False,histtype='stepfilled',align='mid',rwidth=0,orientation='vertical',color='r',linewidth=0.25,alpha=0.5)

ax4_2.set_xlabel(logglabel[0],fontsize=8,rotation=0)
ax4_2.set_xlim(revlogglim)
ax4_2.set_ylim(zlim)
ax4_2.set_xscale(u'linear')
ax4_2.set_yscale(u'linear')
ax4_2.set_xticks([0]+revloggticks)
ax4_2.set_xticklabels([0]+revloggticks,rotation=0)
ax4_2.set_yticks(zticks)
ax4_2.yaxis.set_major_formatter(plt.NullFormatter())
#ax4_2.add_patch(Rectangle((cra2_loggmem[0],cra2_zmem[0]),cra2_loggmem[1]-cra2_loggmem[0],cra2_zmem[1]-cra2_zmem[0],facecolor='r',alpha=0.2,edgecolor='None'))
ax4_2.errorbar(cra2_logg[cra2_keep],cra2_z[cra2_keep],xerr=cra2_siglogg[cra2_keep],yerr=cra2_sigz[cra2_keep],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True)
ax4_2.errorbar(cra2_logg[cra2_mem],cra2_z[cra2_mem],xerr=cra2_siglogg[cra2_mem],yerr=cra2_sigz[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True)
#ax4_2.plot(cra2_loggzx,cra2_loggzy,color='r',linewidth=0.25)

ax3_2.set_xlim(revlogglim)
ax3_2.set_ylim(rlim)
ax3_2.set_xscale(u'linear')
ax3_2.set_yscale(u'linear')
ax3_2.set_xticks(revloggticks)
ax3_2.set_yticks(rticks)
ax3_2.xaxis.set_major_formatter(plt.NullFormatter())
ax3_2.yaxis.set_major_formatter(plt.NullFormatter())

#ax3_2.add_patch(Rectangle((cra2_loggmem[0],cra2_rmem[0]),cra2_loggmem[1]-cra2_loggmem[0],cra2_rmem[1]-cra2_rmem[0],facecolor='r',alpha=0.2,edgecolor='None'))
ax3_2.errorbar(cra2_logg[cra2_keep],cra2_r[cra2_keep],xerr=cra2_siglogg[cra2_keep],yerr=cra2_sigr[cra2_keep],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True)
ax3_2.errorbar(cra2_logg[cra2_mem],cra2_r[cra2_mem],xerr=cra2_siglogg[cra2_mem],yerr=cra2_sigr[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True)
#ax3_2.plot(cra2_loggrx,cra2_loggry,color='r',linewidth=0.25)

#ax2_2.set_ylabel('N',fontsize=8,rotation=90,labelpad=5)
ax2_2.xaxis.set_major_formatter(plt.NullFormatter())
ax2_2.yaxis.set_major_formatter(plt.NullFormatter())
ax2_2.set_xlim(revlogglim)
ax2_2.set_ylim(histlim)
ax2_2.set_xticks(revloggticks)
ax2_2.set_yticks(histticks)
ax2_2.hist(cra2_logg[cra2_keep],bins=30,range=logglim,normed=False,histtype='step',align='mid',rwidth=0,orientation='vertical',color='k',linewidth=0.25)
ax2_2.hist(cra2_logg[cra2_mem],bins=30,range=logglim,normed=False,histtype='stepfilled',align='mid',rwidth=0,orientation='vertical',color='r',linewidth=0.25,alpha=0.5)


ax3_3.set_xlabel(zlabel[0],fontsize=8,rotation=0)
ax3_3.set_xlim(zlim)
ax3_3.set_ylim(rlim)
ax3_3.set_xscale(u'linear')
ax3_3.set_yscale(u'linear')
ax3_3.set_xticks(zticks)
ax3_3.set_xticklabels(zticks,rotation=0)
ax3_3.set_yticks(rticks)
ax3_3.yaxis.set_major_formatter(plt.NullFormatter())
#ax3_3.add_patch(Rectangle((cra2_zmem[0],cra2_rmem[0]),cra2_zmem[1]-cra2_zmem[0],cra2_rmem[1]-cra2_rmem[0],facecolor='r',alpha=0.2,edgecolor='None'))
ax3_3.errorbar(cra2_z[cra2_keep],cra2_r[cra2_keep],xerr=cra2_sigz[cra2_keep],yerr=cra2_sigr[cra2_keep],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True)
ax3_3.errorbar(cra2_z[cra2_mem],cra2_r[cra2_mem],xerr=cra2_sigz[cra2_mem],yerr=cra2_sigr[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True)
#ax3_3.plot(cra2_zrx,cra2_zry,color='r',linewidth=0.25)

#ax2_3.set_ylabel('N',fontsize=8,rotation=90,labelpad=5)
ax2_3.xaxis.set_major_formatter(plt.NullFormatter())
ax2_3.yaxis.set_major_formatter(plt.NullFormatter())
ax2_3.set_ylim(histlim)
ax2_3.set_xticks(zticks)
ax2_3.set_yticks(histticks)
ax2_3.hist(cra2_z[cra2_keep],bins=30,range=zlim,normed=False,histtype='step',align='mid',rwidth=0,orientation='vertical',color='k',linewidth=0.25)
ax2_3.hist(cra2_z[cra2_mem],bins=30,range=zlim,normed=False,histtype='stepfilled',align='mid',rwidth=0,orientation='vertical',color='r',linewidth=0.25,alpha=0.5)


#ax3_4.set_xlabel('N',fontsize=8,rotation=0,labelpad=5)
#ax3_4.xaxis.set_major_formatter(plt.NullFormatter())
ax3_4.yaxis.set_major_formatter(plt.NullFormatter())
ax3_4.set_xlim(rhistlim)
ax3_4.set_yticks(rticks)
ax3_4.set_xticks(rhistticks)
ax3_4.hist(cra2_r[cra2_keep],bins=30,range=rlim,normed=False,histtype='step',align='mid',rwidth=0,orientation='horizontal',color='k',linewidth=0.25)
ax3_4.hist(cra2_r[cra2_mem],bins=30,range=rlim,normed=False,histtype='stepfilled',align='mid',rwidth=0,orientation='horizontal',color='r',linewidth=0.25,alpha=0.5)


ax10_10.set_xlabel(r'$T_{\rm eff}$ [K]',fontsize=8,rotation=0,labelpad=5)
ax10_10.set_ylabel(r'$\log g$',fontsize=8,rotation=90,labelpad=5)
ax10_10.set_xlim([8000,4000])
ax10_10.set_ylim([5,0.01])
ax10_10.yaxis.set_label_position('right')
ax10_10.yaxis.tick_right()
ax10_10.set_xscale(u'linear')
ax10_10.set_yscale(u'linear')
ax10_10.set_yticks([5,4,3,2,1])
#ax10_10.set_xticklabels(vticks,rotation=0)
ax10_10.set_xticks([7000,6000,5000,4000])
ax10_10.plot(iso170_teff,iso170_logg,lw=1,color='k',ls=':')
ax10_10.plot(iso200_teff,iso200_logg,lw=1,color='k',ls='-')
ax10_10.plot(iso100_teff,iso100_logg,lw=1,color='k',ls='--')
#ax10_10.plot(iso000_teff,iso000_logg,lw=1,color='g')
ax10_10.errorbar(cra2_teff[cra2_mem],cra2_logg[cra2_mem],xerr=cra2_sigteff[cra2_mem],yerr=cra2_siglogg[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True,label='Cra 2 member')
ax10_10.scatter(cra2_teff[cra2_keep],cra2_logg[cra2_keep],marker='.',s=1,alpha=0.65,color='k',rasterized=True,label='MW foreground')
ax10_10.scatter(cra2_teff[cra2_mem],cra2_logg[cra2_mem],marker='.',s=1,alpha=0.65,color='r',rasterized=True)
#ax10_10.legend(loc=2,fontsize=8,handlelength=0,shadow=False)
#ax2_0.text(-0.4,16.5,'Crater',fontsize=10)
ax10_10.legend(loc=2,fontsize=4,handlelength=0,numpoints=1,scatterpoints=1,shadow=False)


#ax9_10.set_xlabel(r'$T_{\rm eff}$ [K]',fontsize=12,rotation=0,labelpad=5)
ax9_10.set_ylabel(r'$r-(m-M)$',fontsize=7,rotation=90,labelpad=5)
ax9_10.set_xlim([8000,4000])
ax9_10.yaxis.set_label_position('right')
ax9_10.yaxis.tick_right()
ax9_10.set_ylim([2.49,-3.9])
ax9_10.set_xscale(u'linear')
ax9_10.set_yscale(u'linear')
ax9_10.set_yticks([2,1,0,-1,-2,-3])
ax9_10.set_xticks([8000,7000,6000,5000,4000])
ax9_10.xaxis.set_major_formatter(plt.NullFormatter())
ax9_10.plot(iso170_teff,iso170_r,lw=1,color='k',label=r"[Fe/H]=$-1.7$",ls=':')
ax9_10.plot(iso200_teff,iso200_r,lw=1,color='k',label=r"[Fe/H]=$-2.0$",ls='-')
ax9_10.plot(iso100_teff,iso100_r,lw=1,color='k',label=r"[Fe/H]=$-1.0$",ls='--')
#ax9_10.plot(iso000_teff,iso000_r+dmodulus,lw=1,color='g',label=r"[Fe/H]=$0$")
#ax9_10.errorbar(teff,rmag,xerr=sigteff,yerr=siglogg-siglogg,elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True)
ax9_10.errorbar(cra2_teff[cra2_mem],cra2_mag[cra2_mem]-cra2_dmodulus,xerr=cra2_sigteff[cra2_mem],yerr=cra2_siglogg[cra2_mem]-cra2_siglogg[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True)
ax9_10.legend(loc=2,fontsize=4,handlelength=4,shadow=False)
#ax9_10.text(-0.4,16.5,'Crater',fontsize=10)
#ax9_10.text(7500,16.5,'Cra 2',fontsize=12)

ax10_9.set_xlabel(r'$r-(m-M)$',fontsize=8,rotation=0,labelpad=5)
#ax10_9.set_ylabel(r'$\log g$',fontsize=8,rotation=90,labelpad=5)
ax10_9.set_xlim([2.49,-3.9])
ax10_9.set_ylim([5,0.01])
ax10_9.set_xscale(u'linear')
ax10_9.set_yscale(u'linear')
ax10_9.set_yticks([5,4,3,2,1])
ax10_9.yaxis.set_major_formatter(plt.NullFormatter())
#ax10_9.set_xticklabels(vticks,rotation=0)
ax10_9.set_xticks([2,1,0,-1,-2,-3])
ax10_9.plot(iso200_r,iso200_logg,lw=1,color='k',label=r"[Fe/H]=$-2.0$",ls='-')
ax10_9.plot(iso170_r,iso170_logg,lw=1,color='k',label=r"[Fe/H]=$-1.7$",ls=':')
ax10_9.plot(iso100_r,iso100_logg,lw=1,color='k',label=r"[Fe/H]=$-1.0$",ls='--')
#ax10_9.plot(iso000_r+dmodulus,iso000_logg,lw=1,color='g',label=r"[Fe/H]=$0$")
#ax10_9.errorbar(rmag,logg,xerr=sigteff-sigteff,yerr=siglogg,elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='k',rasterized=True)
ax10_9.errorbar(cra2_mag[cra2_mem]-cra2_dmodulus,cra2_logg[cra2_mem],xerr=cra2_sigteff[cra2_mem]-cra2_sigteff[cra2_mem],yerr=cra2_siglogg[cra2_mem],elinewidth=0.5,fmt='.',capsize=0,alpha=0.65,color='r',rasterized=True)
#ax10_9.legend(loc=2,fontsize=12,handlelength=0,shadow=False)
#ax2_0.text(-0.4,16.5,'Crater',fontsize=10)

g1.write(r'\newcommand{\cranobs}{$'+str(len(cra2_v))+r'$}'+'\n')
g1.write(r'\newcommand{\cragoodnobs}{$'+str(len(cra2_v[cra2_keep]))+r'$}'+'\n')
#g1.write(r'\newcommand{\nred}{$'+str(len(cra2_v[mem]))+r'$}'+'\n')
#g1.write(r'\newcommand{\nblue}{$'+str(len(v[mem3]))+r'$}'+'\n')
g1.write(r'\newcommand{\cramembers}{$'+str(np.size(cra2_mem))+r'$}'+'\n')
g1.close()

plotfilename='cra2pm_params.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
