import numpy as np
import astropy
from astropy.io import fits
import matplotlib
import matplotlib.pyplot as plt
from astropy.nddata import NDData
from astropy.nddata import StdDevUncertainty
from astropy.nddata import CCDData
from astropy.coordinates import SkyCoord, EarthLocation
import ccdproc
import astropy.units as u
from astropy.modeling import models
from ccdproc import Combiner
import os
import scipy
import time
import hecto_process as hecto
import mycode
matplotlib.use('TkAgg')
#matplotlib.use('pdf')

shite=fits.open('nelson_all.fits')
good=np.where((shite[1].data['vlos_error']<5.)&(np.abs(shite[1].data['vlos_skew'])<1.)&(np.abs(shite[1].data['vlos_kurtosis'])<1.))[0]
good2=np.where((shite[1].data['vlos_error']<1.)&(np.abs(shite[1].data['vlos_skew'])<1.)&(np.abs(shite[1].data['vlos_kurtosis'])<1.)&(shite[1].data['vlos']<-2000.))[0]

dist=np.sqrt((shite[1].data['ra_deg']-shite[1].data['ra_deg'][good2])**2+(shite[1].data['dec_deg']-shite[1].data['dec_deg'][good2])**2)*3600.
this=np.where(dist<1.)[0]

plt.scatter(shite[1].data['vlos'][good],shite[1].data['z'][good],s=10,alpha=0.99)
plt.show()
plt.close()

for i in range(0,len(this)):
#for i in range(0,1):
    postfit=fits.open(shite[1].data['fits_filename'][this[i]])
    index=np.long(shite[1].data['fits_index'][this[i]])
    wav=postfit[0].data[index]
    err=np.sqrt(postfit[2].data[index])
    spec=postfit[1].data[index]
    mask=postfit[3].data[index]

    keep=np.where(err<1000.)[0]

    bestfit=postfit[4].data[index]
    plt.plot(wav[keep],spec[keep],color='k',lw=0.5)
#    plt.plot(wav[keep],spec[keep]+err[keep],color='r')
#    plt.plot(wav[keep],spec[keep]-err[keep],color='r')
    plt.plot(wav[keep],bestfit[keep],color='r',lw=0.5)
    plt.xlim([5150,5300])
#    plt.ylim([-1000,10000])
    pdf_name='wtf_'+str(i)+'.pdf'
    plt.savefig(pdf_name,dpi=200)
    plt.show()
    plt.close()

