import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import scipy.integrate as integrate
import scipy.special as special
import scipy.optimize as optimize
from scipy.integrate import quad
import random
import matplotlib.lines as lines
from matplotlib.colors import LogNorm
from matplotlib.pyplot import *
from scipy import integrate
np.set_printoptions(threshold='nan')
import sys

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='7')
plt.rc('ytick',labelsize='7')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)
plt.rc('path',simplify='True')

maxsigv=10.
dsph='dra'

rbins=50
vbins=75
zbins=50
gbins=50
rlim1=[0,89]
rlim2=[0,170]
gammabins=50
vlim=[-100,225]
backwardsvlim=[90,-400]
zlim=[-3.9,0.9]
glim=[0.01,6]
backwardszlim=[0.9,-2.9]
gammalim=[0,10]
rticks2=[0,50,100,150]
rprobticks=[0,20,40,60]
candrprobticks=[0,100,200]
rprobticklabels=rprobticks
candrprobticklabels=rprobticks
zprobticks=[10,20,30]
gprobticks=[25,50,75]
rproblim=[0,350]
candrproblim=[0,250]
vproblim=[0,50]
zproblim=[0,50]
gproblim=[0,75]
vprobticks=[10,20,30,40,50]

with open('/physics2/mgwalker/data/cra2_wpgs.dat') as f:
    data=f.readlines()
ra=[]
dec=[]
xi=[]
eta=[]
r=[]
theta=[]
col=[]
sigcol=[]
mag=[]
sigmag=[]
v=[]
sigv=[]
z=[]
sigz=[]
teff=[]
sigteff=[]
logg=[]
siglogg=[]
pmem=[]
spec=[]
racenter=[]
deccenter=[]
distance=[]
rhalf=[]
for line in data:
    p=line.split()
    ra.append(float(p[0]))
    dec.append(float(p[1]))
    xi.append(float(p[2]))
    eta.append(float(p[3]))
    r.append(float(p[4]))
    theta.append(float(p[5]))
    col.append(float(p[6]))
    sigcol.append(float(p[7]))
    mag.append(float(p[8]))
    sigmag.append(float(p[9]))
    v.append(float(p[10]))
    sigv.append(float(p[11]))
    z.append(float(p[12]))
    sigz.append(float(p[13]))
    teff.append(float(p[14]))
    sigteff.append(float(p[15]))
    logg.append(float(p[16]))
    siglogg.append(float(p[17]))
    pmem.append(float(p[18]))
    spec.append(float(p[19]))
    racenter.append(float(p[20]))
    deccenter.append(float(p[21]))
    distance.append(float(p[22]))
    rhalf.append(float(p[23]))
ra=np.array(ra)
dec=np.array(dec)
xi=np.array(xi)
eta=np.array(eta)
r=np.array(r)
theta=np.array(theta)
col=np.array(col)
sigcol=np.array(sigcol)
mag=np.array(mag)
sigmag=np.array(sigmag)
v=np.array(v)
sigv=np.array(sigv)
z=np.array(z)
sigz=np.array(sigz)
teff=np.array(teff)
sigteff=np.array(sigteff)
logg=np.array(logg)
siglogg=np.array(siglogg)
pmem=np.array(pmem)
spec=np.array(spec)
racenter=np.array(racenter)
deccenter=np.array(deccenter)
distance=np.array(distance)
rhalf=np.array(rhalf)

radeg=ra*180./np.pi
decdeg=dec*180./np.pi
nspec=len((np.where(spec==1))[0])
nrgb=len(ra)
spectra=np.where(spec==1)

with open('/physics2/mgwalker/chains/cra2jeanslight.specpop') as f: # read data file
    data=f.readlines()[1:]
cra2_ra=[]
cra2_dec=[]
cra2_xi=[]
cra2_eta=[]
cra2_r=[]
cra2_theta=[]
cra2_hjd=[]
cra2_v=[]
cra2_sigv=[]
cra2_skewv=[]
cra2_kurtv=[]
cra2_teff=[]
cra2_sigteff=[]
cra2_skewteff=[]
cra2_kurtteff=[]
cra2_logg=[]
cra2_siglogg=[]
cra2_skewlogg=[]
cra2_kurtlogg=[]
cra2_z=[]
cra2_sigz=[]
cra2_skewz=[]
cra2_kurtz=[]
cra2_snratio=[]
cra2_gmag=[]
cra2_siggmag=[]
cra2_rmag=[]
cra2_sigrmag=[]
cra2_imag=[]
cra2_sigimag=[]
cra2_pmem=[]
cra2_pmemlo1=[]
cra2_pmemhi1=[]
cra2_pmemlo2=[]
cra2_pmemhi2=[]
cra2_pnon=[]
cra2_pnonlo1=[]
cra2_pnonhi1=[]
cra2_pnonlo2=[]
cra2_pnonhi2=[]

for line in data: # fill arrays
    p=line.split()
    cra2_ra.append(float(p[0]))
    cra2_dec.append(float(p[1]))
    cra2_xi.append(float(p[2]))
    cra2_eta.append(float(p[3]))
    cra2_r.append(float(p[4]))
    cra2_theta.append(float(p[5]))
    cra2_hjd.append(float(p[6]))
    cra2_v.append(float(p[7]))
    cra2_sigv.append(float(p[8]))
    cra2_skewv.append(float(p[9]))
    cra2_kurtv.append(float(p[10]))
    cra2_teff.append(float(p[11]))
    cra2_sigteff.append(float(p[12]))
    cra2_skewteff.append(float(p[13]))
    cra2_kurtteff.append(float(p[14]))
    cra2_logg.append(float(p[15]))
    cra2_siglogg.append(float(p[16]))
    cra2_skewlogg.append(float(p[17]))
    cra2_kurtlogg.append(float(p[18]))
    cra2_z.append(float(p[19]))
    cra2_sigz.append(float(p[20]))
    cra2_skewz.append(float(p[21]))
    cra2_kurtz.append(float(p[22]))
    cra2_snratio.append(float(p[24]))
    cra2_gmag.append(float(p[25]))
    cra2_siggmag.append(float(p[26]))
    cra2_rmag.append(float(p[27]))
    cra2_sigrmag.append(float(p[28]))
    cra2_imag.append(float(p[29]))
    cra2_sigimag.append(float(p[30]))
    cra2_pmem.append(float(p[31]))
    cra2_pmemlo1.append(float(p[32]))
    cra2_pmemhi1.append(float(p[33]))
    cra2_pmemlo2.append(float(p[34]))
    cra2_pmemhi2.append(float(p[35]))
    cra2_pnon.append(float(p[36]))
    cra2_pnonlo1.append(float(p[37]))
    cra2_pnonhi1.append(float(p[38]))
    cra2_pnonlo2.append(float(p[39]))
    cra2_pnonhi2.append(float(p[40]))

cra2_ra=np.array(cra2_ra)
cra2_dec=np.array(cra2_dec)
cra2_xi=np.array(cra2_xi)
cra2_eta=np.array(cra2_eta)
cra2_r=np.array(cra2_r)
cra2_theta=np.array(cra2_theta)
cra2_hjd=np.array(cra2_hjd)
cra2_v=np.array(cra2_v)
cra2_sigv=np.array(cra2_sigv)
cra2_skewv=np.array(cra2_skewv)
cra2_kurtv=np.array(cra2_kurtv)
cra2_teff=np.array(cra2_teff)
cra2_sigteff=np.array(cra2_sigteff)
cra2_skewteff=np.array(cra2_skewteff)
cra2_kurtteff=np.array(cra2_kurtteff)
cra2_logg=np.array(cra2_logg)
cra2_siglogg=np.array(cra2_siglogg)
cra2_skewlogg=np.array(cra2_skewlogg)
cra2_kurtlogg=np.array(cra2_kurtlogg)
cra2_z=np.array(cra2_z)
cra2_sigz=np.array(cra2_sigz)
cra2_skewz=np.array(cra2_skewz)
cra2_kurtz=np.array(cra2_kurtz)
cra2_pmem=np.array(cra2_pmem)
cra2_snratio=np.array(cra2_snratio)
cra2_gmag=np.array(cra2_gmag)
cra2_siggmag=np.array(cra2_siggmag)
cra2_rmag=np.array(cra2_rmag)
cra2_sigrmag=np.array(cra2_sigrmag)
cra2_imag=np.array(cra2_imag)
cra2_sigimag=np.array(cra2_sigimag)
cra2_pmem=np.array(cra2_pmem)
cra2_pmemlo1=np.array(cra2_pmemlo1)
cra2_pmemhi1=np.array(cra2_pmemhi1)
cra2_pmemlo2=np.array(cra2_pmemlo2)
cra2_pmemhi2=np.array(cra2_pmemhi2)
cra2_pnon=np.array(cra2_pnon)
cra2_pnonlo1=np.array(cra2_pnonlo1)
cra2_pnonhi1=np.array(cra2_pnonhi1)
cra2_pnonlo2=np.array(cra2_pnonlo2)
cra2_pnonhi2=np.array(cra2_pnonhi2)
    
cra2_mag=cra2_imag
cra2_col=cra2_gmag-cra2_imag
cra2_sigr=cra2_r-cra2_r+0.000001

cra2_keep=np.where((cra2_sigv < maxsigv) & (cra2_skewv >= -1.) & (cra2_skewv <= 1.) & (cra2_kurtv >= -1) & (cra2_kurtv <= 1))
cra2_mem=np.where((cra2_pmem >= 0.5) & (cra2_sigv < maxsigv) & (np.abs(cra2_skewv) >= -1.) & (np.abs(cra2_skewv) <= 1.) & (np.abs(cra2_kurtv) >= -1.) & (np.abs(cra2_kurtv) <= 1.))
#cra2_mem=np.where((cra2_sigv < maxsigv) & (cra2_skewv > -1.) & (cra2_skewv < 1.) & (cra2_kurtv > -1.) & (cra2_kurtv < 1.) & (cra2_pmem > 0.9))
cra2_nonmem=np.where((cra2_pmem < 0.5) & (cra2_sigv < maxsigv) & (np.abs(cra2_skewv) >= -1.) & (np.abs(cra2_skewv) <= 1.) & (np.abs(cra2_kurtv) >= -1.) & (np.abs(cra2_kurtv) <= 1.))

with open('/physics2/mgwalker/chains/cra2jeanslight.params') as f:
    data=f.readlines()
nu0=[]
rs=[]
vvar=[]
zvar=[]
vmean=[]
zmean=[]
mualpha=[]
mudelta=[]
bigsigmab=[]
for line in data:
    p=line.split()
    nu0.append(float(p[0]))
    rs.append(float(p[1]))
    vvar.append(float(p[2]))
    zvar.append(float(p[3]))
    vmean.append(float(p[4]))
    zmean.append(float(p[5]))
    mualpha.append(float(p[6]))
    mudelta.append(float(p[7]))
    bigsigmab.append(float(p[8]))
nu0=np.array(nu0)
rs=np.array(rs)
vvar=np.array(vvar)
zvar=np.array(zvar)
vmean=np.array(vmean)
zmean=np.array(zmean)
mualpha=np.array(mualpha)
mudelta=np.array(mudelta)
bigsigmab=np.array(bigsigmab)

with open('/physics2/mgwalker/chains/cra2jeanslight.pr') as f:
    data=f.readlines()

rad=[]
radmedian1=[]
radlo11=[]
radhi11=[]
radlo12=[]
radhi12=[]
radmedian3=[]
radlo31=[]
radhi31=[]
radlo32=[]
radhi32=[]
radmedian=[]
radlo1=[]
radhi1=[]
radlo2=[]
radhi2=[]

for line in data:
    p=line.split()
    rad.append(float(p[0]))
    radmedian1.append(float(p[1]))
    radlo11.append(float(p[2]))
    radhi11.append(float(p[3]))
    radlo12.append(float(p[4]))
    radhi12.append(float(p[5]))
    radmedian3.append(float(p[6]))
    radlo31.append(float(p[7]))
    radhi31.append(float(p[8]))
    radlo32.append(float(p[9]))
    radhi32.append(float(p[10]))
    radmedian.append(float(p[11]))
    radlo1.append(float(p[12]))
    radhi1.append(float(p[13]))
    radlo2.append(float(p[14]))
    radhi2.append(float(p[15]))

rad=np.array(rad)
radmedian1=np.array(radmedian1)
radlo11=np.array(radlo11)
radhi11=np.array(radhi11)
radlo12=np.array(radlo12)
radhi12=np.array(radhi12)
radmedian3=np.array(radmedian3)
radlo31=np.array(radlo31)
radhi31=np.array(radhi31)
radlo32=np.array(radlo32)
radhi32=np.array(radhi32)
radmedian=np.array(radmedian)
radlo1=np.array(radlo1)
radhi1=np.array(radhi1)
radlo2=np.array(radlo2)
radhi2=np.array(radhi2)

with open('/physics2/mgwalker/chains/cra2jeanslight.pv') as f:
    data=f.readlines()

vel=[]
velmedian1=[]
vello11=[]
velhi11=[]
vello12=[]
velhi12=[]
velmedian3=[]
vello31=[]
velhi31=[]
vello32=[]
velhi32=[]
velmedian=[]
vello1=[]
velhi1=[]
vello2=[]
velhi2=[]

for line in data:
    p=line.split()
    vel.append(float(p[0]))
    velmedian1.append(float(p[1]))
    vello11.append(float(p[2]))
    velhi11.append(float(p[3]))
    vello12.append(float(p[4]))
    velhi12.append(float(p[5]))
    velmedian3.append(float(p[6]))
    vello31.append(float(p[7]))
    velhi31.append(float(p[8]))
    vello32.append(float(p[9]))
    velhi32.append(float(p[10]))
    velmedian.append(float(p[11]))
    vello1.append(float(p[12]))
    velhi1.append(float(p[13]))
    vello2.append(float(p[14]))
    velhi2.append(float(p[15]))

vel=np.array(vel)
velmedian1=np.array(velmedian1)
vello11=np.array(vello11)
velhi11=np.array(velhi11)
vello12=np.array(vello12)
velhi12=np.array(velhi12)
velmedian3=np.array(velmedian3)
vello31=np.array(vello31)
velhi31=np.array(velhi31)
vello32=np.array(vello32)
velhi32=np.array(velhi32)
velmedian=np.array(velmedian)
vello1=np.array(vello1)
velhi1=np.array(velhi1)
vello2=np.array(vello2)
velhi2=np.array(velhi2)

with open('/physics2/mgwalker/chains/cra2jeanslight.pz') as f:
    data=f.readlines()

feh=[]
zmedian1=[]
zlo11=[]
zhi11=[]
zlo12=[]
zhi12=[]
zmedian3=[]
zlo31=[]
zhi31=[]
zlo32=[]
zhi32=[]
zmedian=[]
zlo1=[]
zhi1=[]
zlo2=[]
zhi2=[]

for line in data:
    p=line.split()
    feh.append(float(p[0]))
    zmedian1.append(float(p[1]))
    zlo11.append(float(p[2]))
    zhi11.append(float(p[3]))
    zlo12.append(float(p[4]))
    zhi12.append(float(p[5]))
    zmedian3.append(float(p[6]))
    zlo31.append(float(p[7]))
    zhi31.append(float(p[8]))
    zlo32.append(float(p[9]))
    zhi32.append(float(p[10]))
    zmedian.append(float(p[11]))
    zlo1.append(float(p[12]))
    zhi1.append(float(p[13]))
    zlo2.append(float(p[14]))
    zhi2.append(float(p[15]))

feh=np.array(feh)
zmedian1=np.array(zmedian1)
zlo11=np.array(zlo11)
zhi11=np.array(zhi11)
zlo12=np.array(zlo12)
zhi12=np.array(zhi12)
zmedian3=np.array(zmedian3)
zlo31=np.array(zlo31)
zhi31=np.array(zhi31)
zlo32=np.array(zlo32)
zhi32=np.array(zhi32)
zmedian=np.array(zmedian)
zlo1=np.array(zlo1)
zhi1=np.array(zhi1)
zlo2=np.array(zlo2)
zhi2=np.array(zhi2)







with open('/physics2/mgwalker/chains/cra2jeanslight.pg') as f:
    data=f.readlines()

grav=[]
gmedian1=[]
glo11=[]
ghi11=[]
glo12=[]
ghi12=[]
gmedian3=[]
glo31=[]
ghi31=[]
glo32=[]
ghi32=[]
gmedian=[]
glo1=[]
ghi1=[]
glo2=[]
ghi2=[]

for line in data:
    p=line.split()
    grav.append(float(p[0]))
    gmedian1.append(float(p[1]))
    glo11.append(float(p[2]))
    ghi11.append(float(p[3]))
    glo12.append(float(p[4]))
    ghi12.append(float(p[5]))
    gmedian3.append(float(p[6]))
    glo31.append(float(p[7]))
    ghi31.append(float(p[8]))
    glo32.append(float(p[9]))
    ghi32.append(float(p[10]))
    gmedian.append(float(p[11]))
    glo1.append(float(p[12]))
    ghi1.append(float(p[13]))
    glo2.append(float(p[14]))
    ghi2.append(float(p[15]))

grav=np.array(grav)
gmedian1=np.array(gmedian1)
glo11=np.array(glo11)
ghi11=np.array(ghi11)
glo12=np.array(glo12)
ghi12=np.array(ghi12)
gmedian3=np.array(gmedian3)
glo31=np.array(glo31)
ghi31=np.array(ghi31)
glo32=np.array(glo32)
ghi32=np.array(ghi32)
gmedian=np.array(gmedian)
glo1=np.array(glo1)
ghi1=np.array(ghi1)
glo2=np.array(glo2)
ghi2=np.array(ghi2)





gs=plt.GridSpec(16,16) # define multi-panel plot
gs2=plt.GridSpec(32,32) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
gs2.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
ax1_0=fig.add_subplot(gs[11:16,0:5])
ax0_0=fig.add_subplot(gs[6:11,0:5])
ax4_0=fig.add_subplot(gs[1:6,0:5])
ax3_2=fig.add_subplot(gs[0:4,10:16])
#ax4_0=fig.add_subplot(gs[0:3,0:5])
ax3_1=fig.add_subplot(gs[11:16,5:8])
ax2_1=fig.add_subplot(gs[6:11,5:8])
ax4_1=fig.add_subplot(gs[1:6,5:8])

nlabel=[r'N']
bigrlabel=[r'$R$ [arcmin]']
vlabel=[r'$v_{\rm los}$ [km/s]']
zlabel=[r'[Fe/H]']
glabel=[r'$\log g$']
gammalabel=[r'$\Gamma_0$']

#ax1_0.xaxis.set_major_formatter(plt.NullFormatter())
ax1_0.set_xlabel(bigrlabel[0],fontsize=12,rotation=0,labelpad=1)
ax1_0.set_ylabel(vlabel[0],fontsize=12,rotation=90,labelpad=1)
ax1_0.set_xlim(rlim1)
ax1_0.set_ylim(vlim)
#ax1_0.set_xticklabels(rtickslabels0)
ax1_0.set_xscale(u'linear')
ax1_0.set_yscale(u'linear')
ax1_0.scatter(r[spectra],v[spectra],s=10,lw=1,edgecolor='none',alpha=0.65,marker='.',color='k',rasterized=False,label='MMT')
ax1_0.scatter(cra2_r[cra2_mem],cra2_v[cra2_mem],s=10,lw=1,edgecolor='none',alpha=1,marker='.',color='r',rasterized=False)
#ax1_0.plot(np.log10(r),np.log10(nfw_rho),color='k',lw=1,rasterized=False,label='NFW')    
#ax1_0.plot(np.log10(r),np.log10(core_rho),color='k',lw=1,linestyle='--',rasterized=False,label='core')    
#ax1_0.legend(loc=3,fontsize=10,handlelength=3,numpoints=1,shadow=False)

ax0_0.axes.get_xaxis().set_visible(False)
ax0_0.set_xlabel(bigrlabel[0],fontsize=12,rotation=0,labelpad=1)
ax0_0.set_ylabel(zlabel[0],fontsize=12,rotation=90,labelpad=1)
ax0_0.set_xlim(rlim1)
ax0_0.set_ylim(zlim)
#ax0_0.set_xticklabels(rtickslabels0)
ax0_0.set_xscale(u'linear')
ax0_0.set_yscale(u'linear')
ax0_0.scatter(r[spectra],z[spectra],s=10,lw=1,edgecolor='none',alpha=0.65,marker='.',color='k',rasterized=False)
ax0_0.scatter(cra2_r[cra2_mem],cra2_z[cra2_mem],s=10,lw=1,edgecolor='none',alpha=1,marker='.',color='r',rasterized=False)
#ax0_0.plot(np.log10(r),np.log10(nfw_rho),color='k',lw=1,rasterized=False,label='NFW')    
#ax0_0.plot(np.log10(r),np.log10(core_rho),color='k',lw=1,linestyle='--',rasterized=False,label='core')    
#ax0_0.legend(loc=3,fontsize=10,handlelength=3,numpoints=1,shadow=False)

ax4_0.axes.get_xaxis().set_visible(False)
ax4_0.set_xlabel(bigrlabel[0],fontsize=12,rotation=0,labelpad=1)
ax4_0.set_ylabel(glabel[0],fontsize=12,rotation=90,labelpad=1)
ax4_0.set_xlim(rlim1)
ax4_0.set_ylim(glim)
#ax0_0.set_xticklabels(rtickslabels0)
ax4_0.set_xscale(u'linear')
ax4_0.set_yscale(u'linear')
ax4_0.scatter(r[spectra],logg[spectra],s=10,lw=1,edgecolor='none',alpha=0.65,marker='.',color='k',rasterized=False)
ax4_0.scatter(cra2_r[cra2_mem],cra2_logg[cra2_mem],s=10,lw=1,edgecolor='none',alpha=1,marker='.',color='r',rasterized=False)
#ax0_0.plot(np.log10(r),np.log10(nfw_rho),color='k',lw=1,rasterized=False,label='NFW')    
#ax0_0.plot(np.log10(r),np.log10(core_rho),color='k',lw=1,linestyle='--',rasterized=False,label='core')    
#ax0_0.legend(loc=3,fontsize=10,handlelength=3,numpoints=1,shadow=False)

ax3_2.set_xlabel(r'$R$ [arcmin]',fontsize=12,rotation=0,labelpad=1)
ax3_2.set_ylabel(r'$\mathrm{N}_{\rm RGB}$',fontsize=12,rotation=90,labelpad=1)
#ax3_2.axes.get_yaxis().set_ticks([])
#ax3_2.axes.get_xaxis().set_visible(False)
#ax3_2.xaxis.set_major_formatter(plt.NullFormatter())
#ax3_2.set_xlabel(bigrlabel[0],fontsize=12,rotation=0,labelpad=1)
ax3_2.set_xlim(rlim2)
ax3_2.axes.set_ylim(rproblim)
ax3_2.axes.set_yticks(rprobticks)
ax3_2.axes.set_xticks(rticks2)
ax3_2.axes.set_xticklabels(rticks2)
ax3_2.set_xscale(u'linear')
ax3_2.set_yscale(u'linear')
ax3_2.hist(r,bins=rbins,range=rlim2,normed=False,histtype='step',align='mid',rwidth=0,orientation='vertical',color='k',linewidth=0.5)

ax3_2.plot(rad,radmedian1*len(ra)*(rlim2[1]-rlim2[0])/rbins,lw=0.5,linestyle='-',color='r',rasterized=False,label='Cra2')
ax3_2.fill_between(rad,radlo11*len(ra)*(rlim2[1]-rlim2[0])/rbins,radhi11*len(ra)*(rlim2[1]-rlim2[0])/rbins,facecolor='r',alpha=0.5,rasterized=False,edgecolor='None')
ax3_2.plot(rad,radmedian3*len(ra)*(rlim2[1]-rlim2[0])/rbins,lw=0.5,linestyle='-',color='b',rasterized=False,label='MW')
ax3_2.fill_between(rad,radlo31*len(ra)*(rlim2[1]-rlim2[0])/rbins,radhi31*len(ra)*(rlim2[1]-rlim2[0])/rbins,facecolor='b',alpha=0.5,rasterized=False,edgecolor='None')
ax3_2.plot(rad,radmedian*len(ra)*(rlim2[1]-rlim2[0])/rbins,lw=0.5,linestyle='-',color='k',rasterized=False,label='sum')
ax3_2.fill_between(rad,radlo1*len(ra)*(rlim2[1]-rlim2[0])/rbins,radhi1*len(ra)*(rlim2[1]-rlim2[0])/rbins,facecolor='k',alpha=0.5,rasterized=False,edgecolor='None')
ax3_2.legend(loc=2,fontsize=7,handlelength=1,numpoints=1,shadow=False)

#ax3_1.xaxis.set_major_formatter(plt.NullFormatter())
ax3_1.yaxis.set_major_formatter(plt.NullFormatter())
ax3_1.set_ylim(vlim)
ax3_1.set_xlim(vproblim)
ax3_1.set_xticks(vprobticks)
ax3_1.set_xlabel(r'$\mathrm{N}_{\rm obs}$',fontsize=12,rotation=0,labelpad=5)
ax3_1.hist(v[spectra],bins=vbins,range=vlim,normed=False,histtype='step',align='mid',rwidth=0,orientation='horizontal',color='k',linewidth=0.5)
ax3_1.plot(velmedian1*np.float(nspec)*(vlim[1]-vlim[0])/vbins,vel,lw=0.5,linestyle='-',color='r',rasterized=False,label='Cra2')
ax3_1.fill_betweenx(vel,vello11*np.float(nspec)*(vlim[1]-vlim[0])/vbins,velhi11*np.float(nspec)*(vlim[1]-vlim[0])/vbins,lw=0.5,linestyle='--',facecolor='r',rasterized=False,alpha=0.5,edgecolor='None')
ax3_1.plot(velmedian3*np.float(nspec)*(vlim[1]-vlim[0])/vbins,vel,lw=0.5,linestyle='-',color='b',rasterized=False,label='MW')
ax3_1.fill_betweenx(vel,vello31*np.float(nspec)*(vlim[1]-vlim[0])/vbins,velhi31*np.float(nspec)*(vlim[1]-vlim[0])/vbins,lw=0.5,linestyle='--',facecolor='b',rasterized=False,alpha=0.5,edgecolor='None')
ax3_1.plot(velmedian*np.float(nspec)*(vlim[1]-vlim[0])/vbins,vel,lw=0.5,linestyle='-',color='k',rasterized=False,label='sum')
ax3_1.fill_betweenx(vel,vello1*np.float(nspec)*(vlim[1]-vlim[0])/vbins,velhi1*np.float(nspec)*(vlim[1]-vlim[0])/vbins,lw=0.5,linestyle='--',facecolor='k',rasterized=False,alpha=0.5,edgecolor='None')
ax3_1.legend(loc=4,fontsize=7,handlelength=1,numpoints=1,shadow=False)


ax2_1.xaxis.set_major_formatter(plt.NullFormatter())
ax2_1.yaxis.set_major_formatter(plt.NullFormatter())
#ax2_1.xaxis.set_label_position('top')
ax2_1.xaxis.set_ticks_position('top')
#ax2_1.set_xlabel(r'$\mathrm{N}_{\rm obs}$',fontsize=12)
ax2_1.set_ylim(zlim)
ax2_1.set_xlim(zproblim)
ax2_1.set_xticks(zprobticks)
ax2_1.hist(z[spectra],bins=zbins,range=zlim,normed=False,histtype='step',align='mid',rwidth=0,orientation='horizontal',color='k',linewidth=0.5)
ax2_1.plot(zmedian1*np.float(nspec)*(zlim[1]-zlim[0])/zbins,feh,lw=0.5,linestyle='-',color='r',rasterized=False)
ax2_1.fill_betweenx(feh,zlo11*np.float(nspec)*(zlim[1]-zlim[0])/zbins,zhi11*np.float(nspec)*(zlim[1]-zlim[0])/zbins,lw=0.5,linestyle='--',facecolor='r',rasterized=False,alpha=0.5,edgecolor='None')
ax2_1.plot(zmedian3*np.float(nspec)*(zlim[1]-zlim[0])/zbins,feh,lw=0.5,linestyle='-',color='b',rasterized=False)
ax2_1.fill_betweenx(feh,zlo31*np.float(nspec)*(zlim[1]-zlim[0])/zbins,zhi31*np.float(nspec)*(zlim[1]-zlim[0])/zbins,lw=0.5,linestyle='--',facecolor='b',rasterized=False,alpha=0.5,edgecolor='None')
ax2_1.plot(zmedian*np.float(nspec)*(zlim[1]-zlim[0])/zbins,feh,lw=0.5,linestyle='-',color='k',rasterized=False)
ax2_1.fill_betweenx(feh,zlo1*np.float(nspec)*(zlim[1]-zlim[0])/zbins,zhi1*np.float(nspec)*(zlim[1]-zlim[0])/zbins,lw=0.5,linestyle='--',facecolor='k',rasterized=False,alpha=0.5,edgecolor='None')

#ax4_1.xaxis.set_major_formatter(plt.NullFormatter())
ax4_1.yaxis.set_major_formatter(plt.NullFormatter())
#ax4_1.xaxis.set_label_position('top')
ax4_1.xaxis.set_ticks_position('top')
#ax4_1.set_xlabel(r'$\mathrm{N}_{\rm obs}$',fontsize=12)
ax4_1.set_ylim(glim)
ax4_1.set_xlim(gproblim)
ax4_1.set_xticks(gprobticks)
ax4_1.hist(logg[spectra],bins=gbins,range=glim,normed=False,histtype='step',align='mid',rwidth=0,orientation='horizontal',color='k',linewidth=0.5)
ax4_1.plot(gmedian1*np.float(nspec)*(glim[1]-glim[0])/np.float(gbins),grav,lw=0.5,linestyle='-',color='r',rasterized=False)
ax4_1.fill_betweenx(grav,glo11*np.float(nspec)*(glim[1]-glim[0])/gbins,ghi11*np.float(nspec)*(glim[1]-glim[0])/gbins,lw=0.5,linestyle='--',facecolor='r',rasterized=False,alpha=0.5,edgecolor='None')
ax4_1.plot(gmedian3*np.float(nspec)*(glim[1]-glim[0])/gbins,grav,lw=0.5,linestyle='-',color='b',rasterized=False)
ax4_1.fill_betweenx(grav,glo31*np.float(nspec)*(glim[1]-glim[0])/gbins,ghi31*np.float(nspec)*(glim[1]-glim[0])/gbins,lw=0.5,linestyle='--',facecolor='b',rasterized=False,alpha=0.5,edgecolor='None')
ax4_1.plot(gmedian*np.float(nspec)*(glim[1]-glim[0])/gbins,grav,lw=0.5,linestyle='-',color='k',rasterized=False)
ax4_1.fill_betweenx(grav,glo1*np.float(nspec)*(glim[1]-glim[0])/gbins,ghi1*np.float(nspec)*(glim[1]-glim[0])/gbins,lw=0.5,linestyle='--',facecolor='k',rasterized=False,alpha=0.5,edgecolor='None')

plotfilename='cra2jeanslight_scatter.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
