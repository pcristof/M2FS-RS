import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.5)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='6')
plt.rc('ytick',labelsize='6')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

g=0.0043# grav constant in galaxy units        
    
with open('for_jeanscounts_profile.vdisp') as f: # read data file
    data=f.readlines()
r=[]
sigr=[]
vmean=[]
sigvmean=[]
vdisp=[]
sigvdisp=[]
membin=[]
nbin=[]
rpc=[]
sigrpc=[]
for line in data: # fill arrays
    p=line.split()
    r.append(float(p[0]))
    sigr.append(float(p[1]))
    vmean.append(float(p[2]))
    sigvmean.append(float(p[3]))
    vdisp.append(float(p[4]))
    sigvdisp.append(float(p[5]))
    membin.append(float(p[6]))
    nbin.append(float(p[7]))
    rpc.append(float(p[8]))
    sigrpc.append(float(p[9]))

r=np.array(r)
sigr=np.array(sigr)
vmean=np.array(vmean)
sigvmean=np.array(sigvmean)
vdisp=np.array(vdisp)
sigvdisp=np.array(sigvdisp)
membin=np.array(membin)
nbin=np.array(nbin)
rpc=np.array(rpc)
sigrpc=np.array(sigrpc)

with open('/physics2/mgwalker/chains/for_jeanscounts.profiles') as f: # read data file
    data=f.readlines()
rho_rad=[]
rho_radpc=[]
rho_rho=[]
rho_rholo1=[]
rho_rholo2=[]
rho_rhohi1=[]
rho_rhohi2=[]
rho_mass=[]
rho_masslo1=[]
rho_masslo2=[]
rho_masshi1=[]
rho_masshi2=[]
rho_vdisp=[]
rho_vdisplo1=[]
rho_vdisplo2=[]
rho_vdisphi1=[]
rho_vdisphi2=[]
rho_nstar=[]
rho_nstarlo1=[]
rho_nstarlo2=[]
rho_nstarhi1=[]
rho_nstarhi2=[]
rho_stellarmass=[]
rho_stellarmasslo1=[]
rho_stellarmasslo2=[]
rho_stellarmasshi1=[]
rho_stellarmasshi2=[]
rho_nustar=[]
rho_nustarlo1=[]
rho_nustarlo2=[]
rho_nustarhi1=[]
rho_nustarhi2=[]
rho_mtot=[]
rho_mtotlo1=[]
rho_mtotlo2=[]
rho_mtothi1=[]
rho_mtothi2=[]
rho_dmfraction=[]
rho_dmfractionlo1=[]
rho_dmfractionlo2=[]
rho_dmfractionhi1=[]
rho_dmfractionhi2=[]
rho_dratio=[]
rho_dratiolo1=[]
rho_dratiolo2=[]
rho_dratiohi1=[]
rho_dratiohi2=[]
rho_rhostar=[]
rho_rhostarlo1=[]
rho_rhostarlo2=[]
rho_rhostarhi1=[]
rho_rhostarhi2=[]
rho_mstacy=[]
rho_mstacylo1=[]
rho_mstacylo2=[]
rho_mstacyhi1=[]
rho_mstacyhi2=[]
rho_slopedm=[]
rho_slopedmlo1=[]
rho_slopedmlo2=[]
rho_slopedmhi1=[]
rho_slopedmhi2=[]
rho_gbar=[]
rho_gbarlo1=[]
rho_gbarlo2=[]
rho_gbarhi1=[]
rho_gbarhi2=[]
rho_gobs=[]
rho_gobslo1=[]
rho_gobslo2=[]
rho_gobshi1=[]
rho_gobshi2=[]
rho_mondgobs=[]
rho_mondgobslo1=[]
rho_mondgobslo2=[]
rho_mondgobshi1=[]
rho_mondgobshi2=[]

for line in data: # fill arrays
    p=line.split()
    rho_rad.append(float(p[0]))
    rho_radpc.append(float(p[1]))
    rho_rho.append(float(p[17]))
    rho_rholo1.append(float(p[18]))
    rho_rholo2.append(float(p[20]))
    rho_rhohi1.append(float(p[19]))
    rho_rhohi2.append(float(p[21]))
    rho_mass.append(float(p[22]))
    rho_masslo1.append(float(p[23]))
    rho_masslo2.append(float(p[25]))
    rho_masshi1.append(float(p[24]))
    rho_masshi2.append(float(p[26]))
    rho_vdisp.append(float(p[27]))
    rho_vdisplo1.append(float(p[28]))
    rho_vdisplo2.append(float(p[30]))
    rho_vdisphi1.append(float(p[29]))
    rho_vdisphi2.append(float(p[31]))
    rho_nstar.append(float(p[32]))
    rho_nstarlo1.append(float(p[33]))
    rho_nstarlo2.append(float(p[35]))
    rho_nstarhi1.append(float(p[34]))
    rho_nstarhi2.append(float(p[36]))
    rho_stellarmass.append(float(p[37]))
    rho_stellarmasslo1.append(float(p[38]))
    rho_stellarmasslo2.append(float(p[40]))
    rho_stellarmasshi1.append(float(p[39]))
    rho_stellarmasshi2.append(float(p[41]))
    rho_nustar.append(float(p[42]))
    rho_nustarlo1.append(float(p[43]))
    rho_nustarlo2.append(float(p[45]))
    rho_nustarhi1.append(float(p[44]))
    rho_nustarhi2.append(float(p[46]))
    rho_mtot.append(float(p[47]))
    rho_mtotlo1.append(float(p[48]))
    rho_mtotlo2.append(float(p[50]))
    rho_mtothi1.append(float(p[49]))
    rho_mtothi2.append(float(p[51]))
    rho_dmfraction.append(float(p[52]))
    rho_dmfractionlo1.append(float(p[53]))
    rho_dmfractionlo2.append(float(p[55]))
    rho_dmfractionhi1.append(float(p[54]))
    rho_dmfractionhi2.append(float(p[56]))
    rho_dratio.append(float(p[57]))
    rho_dratiolo1.append(float(p[58]))
    rho_dratiolo2.append(float(p[60]))
    rho_dratiohi1.append(float(p[59]))
    rho_dratiohi2.append(float(p[61]))
    rho_rhostar.append(float(p[62]))
    rho_rhostarlo1.append(float(p[63]))
    rho_rhostarlo2.append(float(p[65]))
    rho_rhostarhi1.append(float(p[64]))
    rho_rhostarhi2.append(float(p[66]))
    rho_mstacy.append(float(p[67]))
    rho_mstacylo1.append(float(p[68]))
    rho_mstacylo2.append(float(p[70]))
    rho_mstacyhi1.append(float(p[69]))
    rho_mstacyhi2.append(float(p[71]))
    rho_slopedm.append(float(p[72]))
    rho_slopedmlo1.append(float(p[73]))
    rho_slopedmlo2.append(float(p[75]))
    rho_slopedmhi1.append(float(p[74]))
    rho_slopedmhi2.append(float(p[76]))
    rho_gbar.append(float(p[77]))
    rho_gbarlo1.append(float(p[78]))
    rho_gbarlo2.append(float(p[80]))
    rho_gbarhi1.append(float(p[79]))
    rho_gbarhi2.append(float(p[81]))
    rho_gobs.append(float(p[82]))
    rho_gobslo1.append(float(p[83]))
    rho_gobslo2.append(float(p[85]))
    rho_gobshi1.append(float(p[84]))
    rho_gobshi2.append(float(p[86]))
    rho_mondgobs.append(float(p[87]))
    rho_mondgobslo1.append(float(p[88]))
    rho_mondgobslo2.append(float(p[90]))
    rho_mondgobshi1.append(float(p[89]))
    rho_mondgobshi2.append(float(p[91]))

rho_rad=np.array(rho_rad)
rho_radpc=np.array(rho_radpc)
rho_rho=np.array(rho_rho)
rho_rholo1=np.array(rho_rholo1)
rho_rholo2=np.array(rho_rholo2)
rho_rhohi1=np.array(rho_rhohi1)
rho_rhohi2=np.array(rho_rhohi2)
rho_mass=np.array(rho_mass)
rho_masslo1=np.array(rho_masslo1)
rho_masslo2=np.array(rho_masslo2)
rho_masshi1=np.array(rho_masshi1)
rho_masshi2=np.array(rho_masshi2)
rho_vdisp=np.array(rho_vdisp)
rho_vdisplo1=np.array(rho_vdisplo1)
rho_vdisplo2=np.array(rho_vdisplo2)
rho_vdisphi1=np.array(rho_vdisphi1)
rho_vdisphi2=np.array(rho_vdisphi2)
rho_nstar=np.array(rho_nstar)
rho_nstarlo1=np.array(rho_nstarlo1)
rho_nstarlo2=np.array(rho_nstarlo2)
rho_nstarhi1=np.array(rho_nstarhi1)
rho_nstarhi2=np.array(rho_nstarhi2)
rho_stellarmass=np.array(rho_stellarmass)
rho_stellarmasslo1=np.array(rho_stellarmasslo1)
rho_stellarmasslo2=np.array(rho_stellarmasslo2)
rho_stellarmasshi1=np.array(rho_stellarmasshi1)
rho_stellarmasshi2=np.array(rho_stellarmasshi2)
rho_nustar=np.array(rho_nustar)
rho_nustarlo1=np.array(rho_nustarlo1)
rho_nustarlo2=np.array(rho_nustarlo2)
rho_nustarhi1=np.array(rho_nustarhi1)
rho_nustarhi2=np.array(rho_nustarhi2)
rho_mtot=np.array(rho_mtot)
rho_mtotlo1=np.array(rho_mtotlo1)
rho_mtotlo2=np.array(rho_mtotlo2)
rho_mtothi1=np.array(rho_mtothi1)
rho_mtothi2=np.array(rho_mtothi2)
rho_dmfraction=np.array(rho_dmfraction)
rho_dmfractionlo1=np.array(rho_dmfractionlo1)
rho_dmfractionlo2=np.array(rho_dmfractionlo2)
rho_dmfractionhi1=np.array(rho_dmfractionhi1)
rho_dmfractionhi2=np.array(rho_dmfractionhi2)
rho_dratio=np.array(rho_dratio)
rho_dratiolo1=np.array(rho_dratiolo1)
rho_dratiolo2=np.array(rho_dratiolo2)
rho_dratiohi1=np.array(rho_dratiohi1)
rho_dratiohi2=np.array(rho_dratiohi2)
rho_rhostar=np.array(rho_rhostar)
rho_rhostarlo1=np.array(rho_rhostarlo1)
rho_rhostarlo2=np.array(rho_rhostarlo2)
rho_rhostarhi1=np.array(rho_rhostarhi1)
rho_rhostarhi2=np.array(rho_rhostarhi2)
rho_mstacy=np.array(rho_mstacy)
rho_mstacylo1=np.array(rho_mstacylo1)
rho_mstacylo2=np.array(rho_mstacylo2)
rho_mstacyhi1=np.array(rho_mstacyhi1)
rho_mstacyhi2=np.array(rho_mstacyhi2)
rho_slopedm=np.array(rho_slopedm)
rho_slopedmlo1=np.array(rho_slopedmlo1)
rho_slopedmlo2=np.array(rho_slopedmlo2)
rho_slopedmhi1=np.array(rho_slopedmhi1)
rho_slopedmhi2=np.array(rho_slopedmhi2)
rho_gbar=np.array(rho_gbar)
rho_gbarlo1=np.array(rho_gbarlo1)
rho_gbarlo2=np.array(rho_gbarlo2)
rho_gbarhi1=np.array(rho_gbarhi1)
rho_gbarhi2=np.array(rho_gbarhi2)
rho_gobs=np.array(rho_gobs)
rho_gobslo1=np.array(rho_gobslo1)
rho_gobslo2=np.array(rho_gobslo2)
rho_gobshi1=np.array(rho_gobshi1)
rho_gobshi2=np.array(rho_gobshi2)
rho_mondgobs=np.array(rho_mondgobs)
rho_mondgobslo1=np.array(rho_mondgobslo1)
rho_mondgobslo2=np.array(rho_mondgobslo2)
rho_mondgobshi1=np.array(rho_mondgobshi1)
rho_mondgobshi2=np.array(rho_mondgobshi2)

with open('/physics2/mgwalker/chains/for_counts.profiles') as f: # read data file
    data=f.readlines()
counts_rad=[]
counts_radpc=[]
counts_mstacy=[]
counts_mstacylo1=[]
counts_mstacylo2=[]
counts_mstacyhi1=[]
counts_mstacyhi2=[]
counts_rhostacy=[]
counts_rhostacylo1=[]
counts_rhostacylo2=[]
counts_rhostacyhi1=[]
counts_rhostacyhi2=[]
counts_slopestacy=[]
counts_slopestacylo1=[]
counts_slopestacylo2=[]
counts_slopestacyhi1=[]
counts_slopestacyhi2=[]
counts_slopestellarmass=[]
counts_slopestellarmasslo1=[]
counts_slopestellarmasslo2=[]
counts_slopestellarmasshi1=[]
counts_slopestellarmasshi2=[]

for line in data: # fill arrays
    p=line.split()
    counts_rad.append(float(p[0]))
    counts_radpc.append(float(p[1]))
    counts_mstacy.append(float(p[27]))
    counts_mstacylo1.append(float(p[28]))
    counts_mstacylo2.append(float(p[30]))
    counts_mstacyhi1.append(float(p[29]))
    counts_mstacyhi2.append(float(p[31]))
    counts_rhostacy.append(float(p[32]))
    counts_rhostacylo1.append(float(p[33]))
    counts_rhostacylo2.append(float(p[35]))
    counts_rhostacyhi1.append(float(p[34]))
    counts_rhostacyhi2.append(float(p[36]))
    counts_slopestacy.append(float(p[37]))
    counts_slopestacylo1.append(float(p[38]))
    counts_slopestacylo2.append(float(p[40]))
    counts_slopestacyhi1.append(float(p[39]))
    counts_slopestacyhi2.append(float(p[41]))
    counts_slopestellarmass.append(float(p[42]))
    counts_slopestellarmasslo1.append(float(p[43]))
    counts_slopestellarmasslo2.append(float(p[45]))
    counts_slopestellarmasshi1.append(float(p[44]))
    counts_slopestellarmasshi2.append(float(p[46]))

counts_rad=np.array(counts_rad)
counts_radpc=np.array(counts_radpc)
counts_mstacy=np.array(counts_mstacy)
counts_mstacylo1=np.array(counts_mstacylo1)
counts_mstacylo2=np.array(counts_mstacylo2)
counts_mstacyhi1=np.array(counts_mstacyhi1)
counts_mstacyhi2=np.array(counts_mstacyhi2)
counts_rhostacy=np.array(counts_rhostacy)
counts_rhostacylo1=np.array(counts_rhostacylo1)
counts_rhostacylo2=np.array(counts_rhostacylo2)
counts_rhostacyhi1=np.array(counts_rhostacyhi1)
counts_rhostacyhi2=np.array(counts_rhostacyhi2)
counts_slopestacy=np.array(counts_slopestacy)
counts_slopestacylo1=np.array(counts_slopestacylo1)
counts_slopestacylo2=np.array(counts_slopestacylo2)
counts_slopestacyhi1=np.array(counts_slopestacyhi1)
counts_slopestacyhi2=np.array(counts_slopestacyhi2)
counts_slopestellarmass=np.array(counts_slopestellarmass)
counts_slopestellarmasslo1=np.array(counts_slopestellarmasslo1)
counts_slopestellarmasslo2=np.array(counts_slopestellarmasslo2)
counts_slopestellarmasshi1=np.array(counts_slopestellarmasshi1)
counts_slopestellarmasshi2=np.array(counts_slopestellarmasshi2)

gs=plt.GridSpec(20,20) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size

ax3_0=fig.add_subplot(gs[0:5,0:8])
ax1_0=fig.add_subplot(gs[5:10,0:8])
ax2_0=fig.add_subplot(gs[10:15,0:8])
#ax0_0=fig.add_subplot(gs[10:15,0:8])
ax0_1=fig.add_subplot(gs[15:20,12:20])
#ax3=fig.add_subplot(gs[15:20,4:10])

rho_gbar=rho_gbar*(1000.**2)/3.09e+16
rho_gobs=rho_gobs*(1000.**2)/3.09e+16
rho_gbarlo1=rho_gbarlo1*(1000.**2)/3.09e+16
rho_gobslo1=rho_gobslo1*(1000.**2)/3.09e+16
rho_gbarlo2=rho_gbarlo2*(1000.**2)/3.09e+16
rho_gobslo2=rho_gobslo2*(1000.**2)/3.09e+16
rho_gbarhi1=rho_gbarhi1*(1000.**2)/3.09e+16
rho_gobshi1=rho_gobshi1*(1000.**2)/3.09e+16
rho_gbarhi2=rho_gbarhi2*(1000.**2)/3.09e+16
rho_gobshi2=rho_gobshi2*(1000.**2)/3.09e+16
rho_mondgobs=rho_mondgobs*(1000.**2)/3.09e+16
rho_mondgobslo1=rho_mondgobslo1*(1000.**2)/3.09e+16
rho_mondgobshi1=rho_mondgobshi1*(1000.**2)/3.09e+16
rho_mondgobslo2=rho_mondgobslo2*(1000.**2)/3.09e+16
rho_mondgobshi2=rho_mondgobshi2*(1000.**2)/3.09e+16

rho_obsgobs=rho_mstacy*g/rho_radpc**2*(1000.**2)/3.09e+16

#ax0_1.xaxis.set_major_formatter(plt.NullFormatter())
ax0_1.set_ylabel(r'$\sigma_{v_{los}}$ [km/s]',fontsize=10,rotation=90)
ax0_1.set_xlabel(r'$R$ [arcmin]',fontsize=10,rotation=0,labelpad=5)
ax0_1.set_xlim([0.5,100])
ax0_1.set_ylim([0,19])
ax0_1.set_xscale(u'log')
ax0_1.set_yscale(u'linear')
#ax0_1.set_yticks([1,10,100])
#ax0_1.set_yticklabels([1,10,100],fontsize=10)
#ax0_1.scatter(np.median(_rhalf0),np.median(_vdisp0),s=10,lw=0,edgecolor='none',alpha=0.69,marker='s',color='b',rasterized=True,label='Cra 2')
#ax0_1.fill_between(rho_rad,rho_vdisplo2,rho_vdisphi2,facecolor=(0.5,0.0,1.0),alpha=0.6,rasterized=False,edgecolor='None')
ax0_1.fill_between(rho_rad,rho_vdisplo2,rho_vdisphi2,facecolor='indigo',alpha=0.85,rasterized=False,edgecolor='None')
ax0_1.errorbar(r,vdisp,xerr=sigr,yerr=sigvdisp,elinewidth=0.75,fmt='o',capsize=0,alpha=1,color='k',rasterized=False)
#ax0_1.errorbar(light_r,light_vdisp,xerr=light_sigr,yerr=light_sigvdisp,elinewidth=0.25,fmt='o',capsize=0,alpha=1,color='r',rasterized=True)
#ax0_1.fill_between(rho_rad,rho_vdisplo2,rho_vdisphi2,facecolor='0.6',alpha=0.5,rasterized=False,edgecolor='None')
#ax0_1.plot(rho_rad,rho_vdisp,lw=0.5,color='k')
ax0_1.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='indigo',label='DM+stars',alpha=0.7)
ax0_1.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars only')
#ax0_1.legend(loc=1,fontsize=6,handlelength=1,numpoints=1,scatterpoints=1,shadow=False)
axtop=ax0_1.twiny()
shite=ax0_1.get_xlim()
distance=117000.
shite2=[]
shite2.append(shite[0])
shite2.append(shite[1])
shite2=np.array(shite2)
shite3=distance*np.tan(shite2/60.*np.pi/180.)
axtop.set_xlim(shite3)
axtop.set_xscale(u'log')
axtop.set_xlabel(r'$R$ [pc]',fontsize=10,rotation=0,labelpad=7)
#ax1_0.xaxis.set_major_formatter(plt.NullFormatter())

ax3_0.xaxis.set_major_formatter(plt.NullFormatter())
ax3_0.set_ylabel(r'd$\log M_{\rm enclosed}$/d$\log r$',fontsize=10,rotation=90)
#ax2_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
#ax3_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
ax3_0.set_xlim([10,10000])
ax3_0.set_ylim([0.1,3])
ax3_0.set_xscale(u'log')
ax3_0.set_yscale(u'linear')
#ax3_0.set_yticks([1,10,100])
#ax3_0.set_yticklabels([1,10,100],fontsize=10)
#ax3_0.scatter(np.median(_rhalf0),np.median(_vdisp0),s=10,lw=0,edgecolor='none',alpha=0.69,marker='s',color='b',rasterized=True,label='Cra 2')
ax3_0.fill_between(rho_radpc,rho_slopedmlo2,rho_slopedmhi2,facecolor='navy',alpha=0.6,rasterized=False,edgecolor='None')
ax3_0.fill_between(counts_radpc,counts_slopestellarmasslo2,counts_slopestellarmasshi2,facecolor='darkred',alpha=0.6,rasterized=False,edgecolor='None')
#ax3_0.plot(rho_radpc,rho_rho,lw=0.5,color='k')
ax3_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='navy',label='dark matter')
ax3_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars')
ax3_0.xaxis.set_major_formatter(plt.NullFormatter())
ax3_0.legend(loc=3,fontsize=6,handlelength=1,numpoints=1,scatterpoints=1,shadow=False)


ax1_0.xaxis.set_major_formatter(plt.NullFormatter())
ax1_0.set_ylabel(r'$\rho$ [M$_{\odot}$/pc$^3$]',fontsize=10,rotation=90)
#ax2_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
#ax1_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
ax1_0.set_xlim([10,10000])
ax1_0.set_ylim([0.00000005,9])
ax1_0.set_xscale(u'log')
ax1_0.set_yscale(u'log')
#ax1_0.set_yticks([1,10,100])
#ax1_0.set_yticklabels([1,10,100],fontsize=10)
#ax1_0.scatter(np.median(_rhalf0),np.median(_vdisp0),s=10,lw=0,edgecolor='none',alpha=0.69,marker='s',color='b',rasterized=True,label='Cra 2')
ax1_0.fill_between(rho_radpc,rho_rholo2,rho_rhohi2,facecolor='navy',alpha=0.6,rasterized=False,edgecolor='None',label='dark matter')
ax1_0.fill_between(rho_radpc,rho_rhostarlo2,rho_rhostarhi2,facecolor='darkred',alpha=0.6,rasterized=False,edgecolor='None',label='stars')
#ax1_0.plot(counts_radpc,counts_rhostacy,color='g',lw=2)
#ax1_0.plot(rho_radpc,rho_rho,lw=0.5,color='k')
ax1_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='navy',label='dark matter')
ax1_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars')
ax1_0.xaxis.set_major_formatter(plt.NullFormatter())

ax2_0.xaxis.set_major_formatter(plt.NullFormatter())
ax2_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
ax2_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
ax2_0.set_xlim([10,10000])
ax2_0.set_ylim([100,70000000000])
ax2_0.set_xscale(u'log')
ax2_0.set_yscale(u'log')
#ax2_0.fill_between(rho_radpc,rho_masslo2,rho_masshi2,facecolor='0.1',alpha=0.60,rasterized=False,edgecolor='None')
ax2_0.fill_between(rho_radpc,rho_masslo2,rho_masshi2,facecolor='navy',alpha=0.6,rasterized=False,edgecolor='None')
ax2_0.fill_between(rho_radpc,rho_stellarmasslo2,rho_stellarmasshi2,facecolor='darkred',alpha=0.6,rasterized=False,edgecolor='None')
#ax2_0.fill_between(rho_radpc,rho_mstacylo2,rho_mstacyhi2,facecolor='y',alpha=0.6,rasterized=False,edgecolor='None')
#ax2_0.plot(counts_radpc,counts_mstacy,color='g',lw=2)
#ax2_0.errorbar([_rhalf0],[_mrhalf0],xerr=[_sigrhalf0],yerr=[_sigmrhalf0],elinewidth=0.5,fmt='.',capsize=0,alpha=1,color='white',rasterized=False)
#ax2_0.errorbar([_rwolf],[_mwolf],xerr=[_sigrwolf],yerr=[_sigmwolf],elinewidth=0.5,fmt='.',capsize=0,alpha=1,color='white',rasterized=False)
#ax2_0.fill_between(rho_radpc,rho_mtotlo2,rho_mtothi2,facecolor='k',alpha=0.60,rasterized=False,edgecolor='None')
#ax2_0.plot(rho_radpc,rho_mtot,lw=0.5,color='k')
#ax2_0.xaxis.set_major_formatter(plt.NullFormatter())
ax2_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='navy',label='dark matter')
ax2_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars')


plotfilename='dave_for_jeanscounts_profiles.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
