import numpy as np
import astropy
from astropy.io import fits
import matplotlib
import matplotlib.pyplot as plt
from astropy.nddata import NDData
from astropy.nddata import StdDevUncertainty
from astropy.nddata import CCDData
from astropy.coordinates import SkyCoord, EarthLocation
import ccdproc
import astropy.units as u
from astropy.modeling import models
from ccdproc import Combiner
import os
import scipy
import time
import hecto_process as hecto
matplotlib.use('TkAgg')

make_skysub=False#generate 1d sky-subtracted spectra?
compile_fits=False#fit is done, do post-processing of multinest output
analyze=True#analyze post-processed data

data_directory='/nfs/nas-0-9/mgwalker.proj/hecto_data/'
fit_directory='/nfs/nas-0-9/mgwalker.proj/hecto_chains/'

with open('nelson_sextans_files') as f:
#with open('nelson_sextans_files') as f:
#with open('nelson_draco_files') as f:
    data=f.readlines()
fitsfile=[]
obj=[]
for line in data:
    p=line.split()
    fitsfile.append(p[0])
    obj.append(p[1])
fitsfile=np.array(fitsfile)
obj=np.array(obj)

postfit_radeg=[]
postfit_decdeg=[]
postfit_hjd=[]
postfit_vhelio_correction=[]
postfit_vmoments=[]
postfit_teffmoments=[]
postfit_loggmoments=[]
postfit_zmoments=[]        

for i in range(0,len(fitsfile)):
    hdul=fits.open(fitsfile[i])
    fitsobject=hecto.nelson_getfromfits(hdul)
    hdul.close()

    root=[]
    for j in range(0,len(fitsobject.obj)):
        root.append('hecto_nelson_'+obj[i]+'_ra'+str.format('{0:.6f}',round(fitsobject.radeg[j],6)).zfill(6)+'_dec'+str.format('{0:.6f}',round(fitsobject.decdeg[j],6)).zfill(6)+'_hjd'+str.format('{0:.3f}',round(fitsobject.hjd[j],5)))
#        root.append('hecto_nelson'+'_ra'+str.format('{0:.6f}',round(fitsobject.radeg[j],6)).zfill(6)+'_dec'+str.format('{0:.6f}',round(fitsobject.decdeg[j],6)).zfill(6)+'_hjd'+str.format('{0:.3f}',round(fitsobject.hjd[j],5)))
#        if(('SKY' in fitsobject.obj[j])|('UNUSED' in fitsobject.obj[j])|('REJECT' in fitsobject.obj[j])|('sky' in fitsobject.obj[j])|('unused' in fitsobject.obj[j])|('reject' in fitsobject.obj[j])):
#            target[j]=0
    root=np.array(root)
    skies=np.where(fitsobject.obj=='SKY')[0]
    targets=np.where(fitsobject.icode>0)[0]

    if make_skysub:#write skysub.dat file

        for j in targets:
            out=data_directory+root[j]+'_skysub.dat'
            print('writing .skysub.dat file for frame ',i,root[j])
            g1=open(out,'w')
            for k in range(0,len(fitsobject.wav[j])):
                string=str(round(fitsobject.wav[j][k],10))+' '+str(round(fitsobject.spec[j][k],3))+' '+str(round(fitsobject.var[j][k],5))+' \n'
                g1.write(string)
            g1.close()

    if compile_fits:#process posterior files and put results into new fits file

        multinest=hecto.sspphecto_multinest(fit_directory,root,targets)#object containing sample of posterior, moments thereof, bestfit wavelength and bestfit spectrum

        hdr=fits.Header(fitsobject.header)
        primary_hdu=fits.PrimaryHDU(header=hdr)
        new_hdul=fits.HDUList([primary_hdu])

        col1=fits.Column(name='ra_deg',format='D',array=fitsobject.radeg[targets])
        col2=fits.Column(name='dec_deg',format='D',array=fitsobject.decdeg[targets])
        col3=fits.Column(name='hjd',format='D',array=fitsobject.hjd[targets])
        col4=fits.Column(name='vhelio_correction',format='D',array=fitsobject.vheliocorr[targets])
        col5=fits.Column(name='posterior_moments',format='64D',dim='(16,4)',array=multinest.moments)
        col6=fits.Column(name='posterior_1000',format='16000D',dim='(16,1000)',array=multinest.posterior_1000)
        cols=fits.ColDefs([col1,col2,col3,col4,col5,col6])
        table_hdu=fits.FITS_rec.from_columns(cols)#BinTableHDU.from_columns(cols)

        primary_hdu=fits.PrimaryHDU(fitsobject.wav[targets],header=hdr)
        new_hdul=fits.HDUList([primary_hdu])
        new_hdul.append(fits.ImageHDU(fitsobject.spec[targets]))
        new_hdul.append(fits.ImageHDU(fitsobject.var[targets]))
        new_hdul.append(fits.ImageHDU(fitsobject.mask[targets]))
        new_hdul.append(fits.ImageHDU(multinest.bestfit_fit))
        new_hdul.append(fits.BinTableHDU(table_hdu))

#        for j in range(0,len(targets)):
#            diff=np.where(fitsobject.wav[targets[j]]!=multinest.bestfit_wav[j])
#            if len(diff)>0: 
#                print('ERROR: wavelengths do not match in input fits file and best-fit model filt')
#                np.pause()

        outfile=fitsfile[i].split('.fits')[0]+'_postfit.fits'
        print('writing fit results to '+outfile)
        new_hdul.writeto(outfile,overwrite=True)

    if analyze:

        infile=fitsfile[i].split('.fits')[0]+'_postfit.fits'
        postfit=fits.open(infile)
        for j in range(0,len(postfit[5].data)):
            radeg.append(postfit[5].data['ra_deg'][j])
            decdeg.append(postfit[5].data['dec_deg'][j])
            hjd.append(postfit[5].data['hjd'][j])
            vhelio_correction.append(postfit[5].data['vhelio_correction'][j])
            vmoments.append(postfit[5].data['posterior_moments'][j])
            teffmoments.append()
            loggmoments.append()
            zmoments.append()

#        for j in range(0,len(new_hdul[0].data)):
#            plt.plot(new_hdul[0].data[j],new_hdul[1].data[j],color='k',lw=0.3)
#            plt.plot(new_hdul[0].data[j],new_hdul[4].data[j],color='r',lw=0.3)
#            plt.xlim([5160,5280])
#            plt.show()
#            time.sleep(3)
#            plt.close('all')

