import numpy as np
import astropy
from astropy.io import fits
import hecto_process as hecto
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('TkAgg')

data_directory='/nfs/nas-0-9/mgwalker.proj/hecto_data/'
fit_directory='/nfs/nas-0-9/mgwalker.proj/hecto_chains/'

#with open('oldnelson_cra2_files') as f:
#with open('oldnelson_umi_files') as f:
with open('oldnelson_sextans_files') as f:
    data=f.readlines()
fitsfile=[]
var_fitsfile=[]
for line in data:
    p=line.split()
    fitsfile.append(p[0])
    var_fitsfile.append(p[1])
fitsfile=np.array(fitsfile)
var_fitsfile=np.array(var_fitsfile)

for i in range(0,len(fitsfile)):
    hdul=fits.open(fitsfile[i])#sky-subbed spectra frame
    data=hdul[0].data
    hdr=fits.Header(hdul[0].header)
    wavobject=hecto.nelson_oldformat_getwav(hdul)

    plugmap_table_hdu=hecto.nelson_oldformat_getplugmap(hdul)
    hdul.close()

    hdul=fits.open(var_fitsfile[i])#variance frame (nelson's nomenclature adds 's' before filename of data frame
    var=hdul[0].data
    var_hdr=fits.Header(hdul[0].header)
    var_wavobject=hecto.nelson_oldformat_getwav(hdul)
    hdul.close()

    for j in range(0,len(wavobject.wav)):
        diff=np.where(wavobject.wav[j]!=var_wavobject.wav[j])[0]
        if len(diff)>0:
            print('ERROR: wavelengths of skysub and variance are different!!!!')
            np.pause()

    ivar=1./var
    mask_or=1-wavobject.wavcal#only masked pixels are those where wavelength solution does not apply
    mask_and=1-wavobject.wavcal#only masked pixels are those where wavelength solution does not apply (same as mask_or)
    sky=data-data#don't have these in old format
    summed=data-data#don't have these in old format
    masked=np.where(mask_or==1)[0]

    skies=np.where(plugmap_table_hdu.ICODE<0)[0]
    targets=np.where(plugmap_table_hdu.ICODE>0)[0]
    err=np.sqrt(var)
    meansky=hecto.get_meansky(data,wavobject,err,mask_or,plugmap_table_hdu)

    sky_array=[]
    skysubtract_array=[]
    skysubtract_err_array=[]
    skysubtract_mask_array=[]
    for k in range(0,len(data)):
        sky,skysubtract=hecto.get_skysubtract(meansky,k,data,err,mask_or,wavobject)
        sky_array.append(sky)
        skysubtract_array.append(skysubtract)
    gs=plt.GridSpec(7,7) # define multi-panel plot
    gs.update(wspace=0,hspace=0) # specify inter-panel spacing
    fig=plt.figure(figsize=(6,6)) # define plot size
    ax1=fig.add_subplot(gs[0:7,0:3])
    ax2=fig.add_subplot(gs[0:7,4:7])
    for k in range(0,len(skies)):
        ax1.plot(wavobject.wav[skies[k]],data[skies[k]],lw=0.3)
        ax1.plot(meansky.spectral_axis,meansky.flux,color='k',lw=1)
    for k in range(0,len(targets)):
        ax2.plot(wavobject.wav[targets[k]],data[targets[k]],lw=0.3)
    ax1.set_xlim([5150,5300])
    ax2.set_xlim([5150,5300])
    ax1.set_ylim([-200,1000])
    ax2.set_ylim([-200,1000])
    plt.show()
    plt.close()

    gs=plt.GridSpec(7,7) # define multi-panel plot
    gs.update(wspace=0,hspace=0) # specify inter-panel spacing
    fig=plt.figure(figsize=(6,6)) # define plot size
    ax1=fig.add_subplot(gs[0:7,0:3])
    ax2=fig.add_subplot(gs[0:7,4:7])
    for k in range(0,len(skies)):
        ax1.plot(wavobject.wav[skies[k]],skysubtract_array[skies[k]].flux,lw=0.3)
    for k in range(0,len(targets)):
        ax2.plot(wavobject.wav[targets[k]],skysubtract_array[targets[k]].flux,lw=0.3)
    ax1.set_xlim([5150,5300])
    ax2.set_xlim([5150,5300])
    ax1.set_ylim([0,1000])
    ax2.set_ylim([0,1000])
    plt.show()
    plt.close()

    primary_hdu=fits.PrimaryHDU(wavobject.wav,header=hdr)
    new_hdul=fits.HDUList([primary_hdu])
#    new_hdul.append(fits.ImageHDU(data))
    new_hdul.append(fits.ImageHDU([skysubtract_array[q].flux.value for q in range(0,len(skysubtract_array))]))
    new_hdul.append(fits.ImageHDU(1./np.array([skysubtract_array[q].uncertainty.quantity.value for q in range(0,len(skysubtract_array))])**2))
#    new_hdul.append(fits.ImageHDU(ivar))
    new_hdul.append(fits.ImageHDU([skysubtract_array[q].mask for q in range(0,len(skysubtract_array))]))
    new_hdul.append(fits.ImageHDU([skysubtract_array[q].mask for q in range(0,len(skysubtract_array))]))
#    new_hdul.append(fits.ImageHDU(mask_and))
#    new_hdul.append(fits.ImageHDU(mask_or))
    new_hdul.append(fits.BinTableHDU(plugmap_table_hdu))
    new_hdul.append(fits.ImageHDU([sky_array[q].value for q in range(0,len(sky_array))]))
#    new_hdul.append(fits.ImageHDU(sky))
    new_hdul.append(fits.ImageHDU(summed))

    newfits=fitsfile[i].split('.fits')[0]+'_new.fits'
    print('writing '+newfits)
    new_hdul.writeto(newfits,overwrite=True)
