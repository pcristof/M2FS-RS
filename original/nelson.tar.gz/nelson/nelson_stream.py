import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.isotonic import IsotonicRegression
from sklearn.utils import check_random_state
np.set_printoptions(threshold='nan')

#user input
###############################
infile='em_info.tab'
outfile='nelson_stream.dat'
plotfilename='nelson_stream.pdf'
vcut1=-100.#artificial lower Vlos limit (km/s) for members (anything with Vlos<vcut1 is automatically given Pmem=0)
vcut2=1000.#artificial upper Vlos limit (km/s) for members (anything with Vlos>vcut2 is automatically given Pmem=0)
iterations=500#number of iterations of EM algorithm
###############################

def standardcoords(rarad,decrad,racenter,deccenter):
    xi=np.zeros(len(rarad))
    eta=np.zeros(len(rarad))
    for i in range(len(rarad)):
        xi[i]=np.cos(decrad[i])*np.sin(rarad[i]-racenter)/(np.sin(deccenter)*np.sin(decrad[i])+np.cos(deccenter)*np.cos(decrad[i])*np.cos(rarad[i]-racenter))*180.*60./np.pi
        eta[i]=(np.cos(deccenter)*np.sin(decrad[i])-np.sin(deccenter)*np.cos(decrad[i])*np.cos(rarad[i]-racenter))/(np.sin(deccenter)*np.sin(decrad[i])+np.cos(deccenter)*np.cos(decrad[i])*np.cos(rarad[i]-racenter))*180.*60./np.pi
#        print rarad[i],decrad[i],xi[i],eta[i]
    return xi,eta

def fitline(x,y,p):
    xmean=np.sum(p*x)/np.sum(p)
    ymean=np.sum(p*y)/np.sum(p)
    m=np.sum(p*(x-xmean)*(y-ymean))/np.sum(p*(x-xmean)**2)
    b=ymean-m*xmean
    return m,b

def stats(x,y,v,sigv,p,oldmean,olddisp,oldkx,oldky):
    n=np.size(x)
    disp2=np.sum(p*(v-oldmean-oldkx*x-oldky*y)**2/(1.+sigv**2/olddisp**2))/np.sum(p/(1.+sigv**2/olddisp**2))
    disp=np.sqrt(disp2)
    mean=np.sum(p*(v-oldkx*x-oldky*y)/(olddisp**2+sigv**2))/np.sum(p/(olddisp**2+sigv**2))
    kx=np.sum(p*x*(v-oldmean-oldky*y)/(olddisp**2+sigv**2))/np.sum(p*x**2/(olddisp**2+sigv**2))
    ky=np.sum(p*y*(v-oldmean-oldkx*x)/(olddisp**2+sigv**2))/np.sum(p*y**2/(olddisp**2+sigv**2))
    return mean,disp,kx,ky

#read input file into arrays for each column
#
with open(infile) as f:
    header=f.readlines()[0:1]
with open(infile) as f:
    data=f.readlines()[2:]
#initialize column arrays
radeg=[]
decdeg=[]
vlos=[]
czerr=[]
czxcr=[]
mgb=[]
sigmgb=[]
havg=[]
sighavg=[]
pmra=[]
sigpmra=[]
pmdec=[]
sigpmdec=[]
#append data from input file
for line in data: # fill arrays
    p=line.split()
    radeg.append(float(p[1]))
    decdeg.append(float(p[2]))
    vlos.append(float(p[15]))
    czerr.append(float(p[17]))
    czxcr.append(float(p[18]))
    mgb.append(float(p[21]))
    sigmgb.append(float(p[22]))
    havg.append(float(p[23]))
    sighavg.append(float(p[24]))
    pmra.append(float(p[27]))
    sigpmra.append(float(p[28]))
    pmdec.append(float(p[29]))
    sigpmdec.append(float(p[30]))
#convert to numpy arrays
radeg=np.array(radeg)
decdeg=np.array(decdeg)
vlos=np.array(vlos)
czerr=np.array(czerr)
czxcr=np.array(czxcr)
mgb=np.array(mgb)
sigmgb=np.array(sigmgb)
havg=np.array(havg)
sighavg=np.array(sighavg)
pmra=np.array(pmra)
sigpmra=np.array(sigpmra)
pmdec=np.array(pmdec)
sigpmdec=np.array(sigpmdec)

sigvlos=czerr

#discard observations with |Vlos| > 1000 km/s
keep=(np.where(abs(vlos)<1000.))[0]

ra=radeg*np.pi/180.#ra in radians
dec=decdeg*np.pi/180.# dec in radians

#take median ra,dec as fiducial center
radegcenter=np.median(radeg[keep])#fiducial center
decdegcenter=np.median(decdeg[keep])#fiducial center
racenter=radegcenter*np.pi/180.#fiducial center in radians
deccenter=decdegcenter*np.pi/180.#fiducial center in radians
#get standard coordinates (xi,eta) about this nominal center - (xi,eta) have units of arcmin and give angular separation from fiducial center
xi,eta=standardcoords(ra,dec,racenter,deccenter)#arcmin

pmem=np.zeros(len(ra))+0.5#initialize Pmem = 0.5 for all stars
pnon=1.-pmem

#fit straight line to member positions, given Pmem
slope,intercept=fitline(xi[keep],eta[keep],pmem[keep])
b=1.
a=-b*slope
c=-b*intercept
x0=(b*(b*xi-a*eta)-a*c)/(a**2+b**2)
y0=(a*(a*eta-b*xi)-b*c)/(a**2+b**2)
dist=np.sqrt((xi-x0)**2+(eta-y0)**2)#distance from star to best-fit line in (xi,eta) space

#initialize means, dispersions and gradients of Gaussian distributions that we will fit to Vlos, pmRA and pmDec distributions.  I just use 0 for all the gradients ('gradx' and 'grady'), the mean of the observable for all the means ('center') and the standard deviation of the observable for all the dispersions ('scale'), for both members ('mem') and nonmembers ('non')
vlos_center_mem=np.mean(vlos[keep])
vlos_center_non=np.mean(vlos[keep])
pmra_center_mem=np.mean(pmra[keep])
pmra_center_non=np.mean(pmra[keep])
pmdec_center_mem=np.mean(pmdec[keep])
pmdec_center_non=np.mean(pmdec[keep])
mgb_center_mem=np.mean(mgb[keep])
mgb_center_non=np.mean(mgb[keep])
havg_center_mem=np.mean(havg[keep])
havg_center_non=np.mean(havg[keep])

vlos_scale_mem=np.std(vlos[keep])
vlos_scale_non=np.std(vlos[keep])
pmra_scale_mem=np.std(pmra[keep])
pmra_scale_non=np.std(pmra[keep])
pmdec_scale_mem=np.std(pmdec[keep])
pmdec_scale_non=np.std(pmdec[keep])
mgb_scale_mem=np.std(mgb[keep])
mgb_scale_non=np.std(mgb[keep])
havg_scale_mem=np.std(havg[keep])
havg_scale_non=np.std(havg[keep])

vlos_gradx_mem=0.
vlos_grady_mem=0.
pmra_gradx_mem=0.
pmra_grady_mem=0.
pmdec_gradx_mem=0.
pmdec_grady_mem=0.
mgb_gradx_mem=0.
mgb_grady_mem=0.
havg_gradx_mem=0.
havg_grady_mem=0.

vlos_gradx_non=0.
vlos_grady_non=0.
pmra_gradx_non=0.
pmra_grady_non=0.
pmdec_gradx_non=0.
pmdec_grady_non=0.
mgb_gradx_non=0.
mgb_grady_non=0.
havg_gradx_non=0.
havg_grady_non=0.

#perform isotonic regression to initialize member fraction as function of distance (from line that represents stream locus)
ir=IsotonicRegression()
fraction0=1.-ir.fit_transform(dist[keep],pnon[keep])
fraction=np.zeros(len(vlos),dtype='float')
for i in range(0,len(keep)):
    fraction[keep[i]]=fraction0[i]

#now iterate the EM algorithm
for i in range(0,iterations):
    #estimate mean, dispersion, gradient in x, gradient in y for vlos, pmRA, pmDec, for both members and non-members (using Pmem as weights)
    vlos_center_mem,vlos_scale_mem,vlos_gradx_mem,vlos_grady_mem=stats(xi[keep],eta[keep],vlos[keep],sigvlos[keep],pmem[keep],vlos_center_mem,vlos_scale_mem,vlos_gradx_mem,vlos_grady_mem)
    vlos_center_non,vlos_scale_non,vlos_gradx_non,vlos_grady_non=stats(xi[keep],eta[keep],vlos[keep],sigvlos[keep],pnon[keep],vlos_center_non,vlos_scale_non,vlos_gradx_non,vlos_grady_non)
    pmra_center_mem,pmra_scale_mem,pmra_gradx_mem,pmra_grady_mem=stats(xi[keep],eta[keep],pmra[keep],sigpmra[keep],pmem[keep],pmra_center_mem,pmra_scale_mem,pmra_gradx_mem,pmra_grady_mem)
    pmra_center_non,pmra_scale_non,pmra_gradx_non,pmra_grady_non=stats(xi[keep],eta[keep],pmra[keep],sigpmra[keep],pnon[keep],pmra_center_non,pmra_scale_non,pmra_gradx_non,pmra_grady_non)
    pmdec_center_mem,pmdec_scale_mem,pmdec_gradx_mem,pmdec_grady_mem=stats(xi[keep],eta[keep],pmdec[keep],sigpmdec[keep],pmem[keep],pmdec_center_mem,pmdec_scale_mem,pmdec_gradx_mem,pmdec_grady_mem)
    pmdec_center_non,pmdec_scale_non,pmdec_gradx_non,pmdec_grady_non=stats(xi[keep],eta[keep],pmdec[keep],sigpmdec[keep],pnon[keep],pmdec_center_non,pmdec_scale_non,pmdec_gradx_non,pmdec_grady_non)
    mgb_center_mem,mgb_scale_mem,mgb_gradx_mem,mgb_grady_mem=stats(xi[keep],eta[keep],mgb[keep],sigmgb[keep],pmem[keep],mgb_center_mem,mgb_scale_mem,mgb_gradx_mem,mgb_grady_mem)
    mgb_center_non,mgb_scale_non,mgb_gradx_non,mgb_grady_non=stats(xi[keep],eta[keep],mgb[keep],sigmgb[keep],pnon[keep],mgb_center_non,mgb_scale_non,mgb_gradx_non,mgb_grady_non)
    havg_center_mem,havg_scale_mem,havg_gradx_mem,havg_grady_mem=stats(xi[keep],eta[keep],havg[keep],sighavg[keep],pmem[keep],havg_center_mem,havg_scale_mem,havg_gradx_mem,havg_grady_mem)
    havg_center_non,havg_scale_non,havg_gradx_non,havg_grady_non=stats(xi[keep],eta[keep],havg[keep],sighavg[keep],pnon[keep],havg_center_non,havg_scale_non,havg_gradx_non,havg_grady_non)

    #compute probability density corresponding to each observable, for both member and nonmember distributions, given the means/dispersions/gradients estimated above
    vlos_pm=1./(2.*np.pi*np.sqrt(vlos_scale_mem**2+sigvlos**2))*np.exp(-0.5*(vlos-vlos_center_mem-vlos_gradx_mem*xi-vlos_grady_mem*eta)**2/(vlos_scale_mem**2+sigvlos**2))
    vlos_pn=1./(2.*np.pi*np.sqrt(vlos_scale_non**2+sigvlos**2))*np.exp(-0.5*(vlos-vlos_center_non-vlos_gradx_non*xi-vlos_grady_non*eta)**2/(vlos_scale_non**2+sigvlos**2))
    pmra_pm=1./(2.*np.pi*np.sqrt(pmra_scale_mem**2+sigpmra**2))*np.exp(-0.5*(pmra-pmra_center_mem-pmra_gradx_mem*xi-pmra_grady_mem*eta)**2/(pmra_scale_mem**2+sigpmra**2))
    pmra_pn=1./(2.*np.pi*np.sqrt(pmra_scale_non**2+sigpmra**2))*np.exp(-0.5*(pmra-pmra_center_non-pmra_gradx_non*xi-pmra_grady_non*eta)**2/(pmra_scale_non**2+sigpmra**2))
    pmdec_pm=1./(2.*np.pi*np.sqrt(pmdec_scale_mem**2+sigpmdec**2))*np.exp(-0.5*(pmdec-pmdec_center_mem-pmdec_gradx_mem*xi-pmdec_grady_mem*eta)**2/(pmdec_scale_mem**2+sigpmdec**2))
    pmdec_pn=1./(2.*np.pi*np.sqrt(pmdec_scale_non**2+sigpmdec**2))*np.exp(-0.5*(pmdec-pmdec_center_non-pmdec_gradx_non*xi-pmdec_grady_non*eta)**2/(pmdec_scale_non**2+sigpmdec**2))
    mgb_pm=1./(2.*np.pi*np.sqrt(mgb_scale_mem**2+sigmgb**2))*np.exp(-0.5*(mgb-mgb_center_mem-mgb_gradx_mem*xi-mgb_grady_mem*eta)**2/(mgb_scale_mem**2+sigmgb**2))
    mgb_pn=1./(2.*np.pi*np.sqrt(mgb_scale_non**2+sigmgb**2))*np.exp(-0.5*(mgb-mgb_center_non-mgb_gradx_non*xi-mgb_grady_non*eta)**2/(mgb_scale_non**2+sigmgb**2))
    havg_pm=1./(2.*np.pi*np.sqrt(havg_scale_mem**2+sighavg**2))*np.exp(-0.5*(havg-havg_center_mem-havg_gradx_mem*xi-havg_grady_mem*eta)**2/(havg_scale_mem**2+sighavg**2))
    havg_pn=1./(2.*np.pi*np.sqrt(havg_scale_non**2+sighavg**2))*np.exp(-0.5*(havg-havg_center_non-havg_gradx_non*xi-havg_grady_non*eta)**2/(havg_scale_non**2+sighavg**2))
    pm=vlos_pm*pmra_pm*pmdec_pm*mgb_pm*havg_pm#product of all individual-dimension probability densities (for Vlos, pmRA, pmDec) for members
    pn=vlos_pn*pmra_pn*pmdec_pn*mgb_pn*havg_pn#product of all individual-dimension probability densities (for Vlos, pmRA, pmDec) for nonmembers
    #update membership probabilities
    pmem=fraction*pm/(fraction*pm+(1.-fraction)*pn)

    #impose artificial membership cuts based on Vlos
    for j in range(0,len(vlos)):
        if vlos[j]<vcut1:
            pmem[j]=0.
        if vlos[j]>vcut2:
            pmem[j]=0.

    pnon=1.-pmem

#fit straight line to member positions, given Pmem
    slope,intercept=fitline(xi[keep],eta[keep],pmem[keep])
    b=1.
    a=-b*slope
    c=-b*intercept
    x0=(b*(b*xi-a*eta)-a*c)/(a**2+b**2)
    y0=(a*(a*eta-b*xi)-b*c)/(a**2+b**2)
    dist=np.sqrt((xi-x0)**2+(eta-y0)**2)#distance from star to best-fit line in (xi,eta) space

#perform isotonic regression to initialize member fraction as function of distance (from line that represents stream locus)
    ir=IsotonicRegression()
    fraction0=1.-ir.fit_transform(dist[keep],pnon[keep])
    for j in range(0,len(keep)):
        fraction[keep[j]]=fraction0[j]

    #print output to screen
    print 'Iteration ',i+1
    print 'Vlos_center_mem, Vlos_scale_mem, Vlos_center_non, Vlos_scale_non, Vlos_gradx_mem, Vlos_grady_mem, Vlos_gradx_non, Vlos_grady_non'
    print 'units are km/s and km/s/arcmin'
    print vlos_center_mem,vlos_scale_mem,vlos_center_non,vlos_scale_non,vlos_gradx_mem,vlos_grady_mem,vlos_gradx_non,vlos_grady_non
    print 'pmRA_center_mem, pmRA_scale_mem, pmRA_center_non, pmRA_scale_non, pmRA_gradx_mem, pmRA_grady_mem, pmRA_gradx_non, pmRA_grady_non'
    print 'units are mas/yr and mas/yr/arcmin'
    print pmra_center_mem,pmra_scale_mem,pmra_center_non,pmra_scale_non,pmra_gradx_mem,pmra_grady_mem,pmra_gradx_non,pmra_grady_non
    print 'pmDec_center_mem, pmDec_scale_mem, pmDec_center_non, pmDec_scale_non, pmDec_gradx_mem, pmDec_grady_mem, pmDec_gradx_non, pmDec_grady_non'
    print 'units are mas/yr and mas/yr/arcmin'
    print pmdec_center_mem,pmdec_scale_mem,pmdec_center_non,pmdec_scale_non,pmdec_gradx_mem,pmdec_grady_mem,pmdec_gradx_non,pmdec_grady_non
    print 'Mgb_center_mem, Mgb_scale_mem, Mgb_center_non, Mgb_scale_non, Mgb_gradx_mem, Mgb_grady_mem, Mgb_gradx_non, Mgb_grady_non'
    print 'units are Angstroms and Angstroms/arcmin'
    print mgb_center_mem,mgb_scale_mem,mgb_center_non,mgb_scale_non,mgb_gradx_mem,mgb_grady_mem,mgb_gradx_non,mgb_grady_non
    print 'Havg_center_mem, Havg_scale_mem, Havg_center_non, Havg_scale_non, Havg_gradx_mem, Havg_grady_mem, Havg_gradx_non, Havg_grady_non'
    print 'units are Angstroms and Angstroms/arcmin'
    print havg_center_mem,havg_scale_mem,havg_center_non,havg_scale_non,havg_gradx_mem,havg_grady_mem,havg_gradx_non,havg_grady_non
    print 'sum(Pmem), sum(Pnon)'
    print np.sum(pmem),np.sum(pnon)
    print ' '

#write output file that appends Pmem to input data
g1=open(outfile,'w')
for line in header:
    p=line.split('\n')
    g1.write(p[0]+'    Pmem \n')
i=0
for line in data:
    p=line.split('\n')
    g1.write(p[0]+' '+str(round(pmem[i],5))+' \n')
    i=i+1
#for i in range(0,len(ra)):
#    string=str(round(radeg[i],10))+' '+str(round(decdeg[i],10))+' '+str(round(xi[i],6))+' '+str(round(eta[i],6))+' '+str(round(vlos[i],2))+' '+str(round(sigvlos[i],2))+' '+str(round(pmra[i],6))+' '+str(round(sigpmra[i],6))+' '+str(round(pmdec[i],6))+' '+str(round(sigpmdec[i],6))+' \n'
#    g1.write(string)
g1.close()


gs=plt.GridSpec(7,7) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
ax=fig.add_subplot(gs[0:6,0:6])

x=np.linspace(-250,250,100)
y=slope*x+intercept
ax.set_xlim([-4,4])
ax.set_ylim([-4,4])
ax.set_xlabel(r'$\Delta$ R.A. [deg]')
ax.set_ylabel(r'$\Delta$ Dec. [deg]')
ax.scatter(xi/60.,eta/60.,s=3,alpha=0.3,label=r'$P_{\rm mem} <0.5$')
#ax.scatter(xi[mem='Y'],eta[mem=='Y'],s=4,color='r')
ax.scatter(xi[pmem >0.99]/60.,eta[pmem >0.99]/60.,s=5,color='r',label=r'$P_{\rm mem}>0.5$')
ax.plot(x/60.,y/60.,color='k',label='stream')
ax.legend()

plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
