import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
from scipy.stats import kde
import random
import mycode2
import scipy.optimize as optimize
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.8)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='10')
plt.rc('ytick',labelsize='10')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

with open('/physics2/mgwalker/chains/prash.cra2') as f: # read data file
    data=f.readlines()[0:]
ncra2=[]
sigma=[]
sigma8=[]
for line in data: # fill arrays
    p=line.split()
    ncra2.append(float(p[1]))
    sigma.append(float(p[2]))
    sigma8.append(float(p[3]))
ncra2=np.array(ncra2)
sigma=np.array(sigma)
sigma8=np.array(sigma8)

with open('/physics2/mgwalker/chains/prash.bincounts') as f: # read data file
    data=f.readlines()[0:]
bin1=[]
bin2=[]
dbin=[]
binmedian=[]
binlo1=[]
binhi1=[]
binlo2=[]
binhi2=[]
binmin=[]
binmax=[]
for line in data: # fill arrays
    p=line.split()
    bin1.append(float(p[1]))
    bin2.append(float(p[2]))
    dbin.append(float(p[3]))
    binmedian.append(float(p[4]))
    binlo1.append(float(p[5]))
    binhi1.append(float(p[6]))
    binlo2.append(float(p[7]))
    binhi2.append(float(p[8]))
    binmin.append(float(p[9]))
    binmax.append(float(p[10]))
bin1=np.array(bin1)
bin2=np.array(bin2)
dbin=np.array(dbin)
binmedian=np.array(binmedian)
binlo1=np.array(binlo1)
binhi1=np.array(binhi1)
binlo2=np.array(binlo2)
binhi2=np.array(binhi2)
binmin=np.array(binmin)
binmax=np.array(binmax)

with open('/physics2/mgwalker/chains/prash.smhm2') as f: # read data file
    data=f.readlines()[0:]
mvir=[]
mvirpeak=[]
mstar_median=[]
mstar_lo1=[]
mstar_hi1=[]
mstar_lo2=[]
mstar_hi2=[]
mstar_min=[]
mstar_max=[]
for line in data: # fill arrays
    p=line.split()
    mvir.append(float(p[0]))
    mvirpeak.append(float(p[1]))
    mstar_median.append(float(p[2]))
    mstar_lo1.append(float(p[3]))
    mstar_hi1.append(float(p[4]))
    mstar_lo2.append(float(p[5]))
    mstar_hi2.append(float(p[6]))
    mstar_min.append(float(p[7]))
    mstar_max.append(float(p[8]))
mvir=np.array(mvir)
mvirpeak=np.array(mvirpeak)
mstar_median=np.array(mstar_median)
mstar_lo1=np.array(mstar_lo1)
mstar_hi1=np.array(mstar_hi1)
mstar_lo2=np.array(mstar_lo2)
mstar_hi2=np.array(mstar_hi2)
mstar_min=np.array(mstar_min)
mstar_max=np.array(mstar_max)

gs=plt.GridSpec(12,12) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
axm200=fig.add_subplot(gs[0:5,0:5])
axbin=fig.add_subplot(gs[7:12,0:5])
axcra2=fig.add_subplot(gs[7:12,7:12])
axscatter=fig.add_subplot(gs[0:5,7:12])

#axm200.xaxis.set_major_formatter(plt.NullFormatter())
axm200.set_xlabel(r'$\log_{10}[M_{\rm vir}/M_{\odot}]$',fontsize=11,rotation=0)
axm200.set_ylabel(r'$\log_{10}[M_{*}/M_{\odot}]$',fontsize=11,rotation=90)
#axm200.set_xlabel(r'$\log_{10}[c_{200}]$',fontsize=12,rotation=90)
#axm200.set_xlabel(r'$R_{\rm h}$ [pc]',fontsize=11,rotation=0,labelpad=5)
axm200.set_ylim([2,9])
axm200.set_xlim([6,11])
axm200.set_xscale(u'linear')
axm200.set_yscale(u'linear')
#axm200.xaxis.set_major_formatter(plt.NullFormatter())
axm200.plot(np.log10(mvirpeak),np.log10(mstar_median),color='k',alpha=1,rasterized=True)
axm200.plot(np.log10(mvirpeak),np.log10(mstar_min),color='k',alpha=0.35,rasterized=True)
axm200.plot(np.log10(mvirpeak),np.log10(mstar_max),color='k',alpha=0.35,rasterized=True)

#axbin.xaxis.set_major_formatter(plt.NullFormatter())
axbin.set_xlabel(r'$M_V$',fontsize=11,rotation=0)
axbin.set_ylabel(r'N',fontsize=11,rotation=90)
axbin.set_ylim([0,25])
axbin.set_xlim([-1,-20])
axbin.set_xscale(u'linear')
axbin.set_yscale(u'linear')
#axbin.xaxis.set_major_formatter(plt.NullFormatter())
axbin.scatter((bin1+bin2)/2.,dbin,marker='o',color='k',s=10,alpha=1,rasterized=True)
axbin.fill_between([bin1[0],bin2[0]],[binlo1[0],binlo1[0]],[binhi1[0],binhi1[0]],color='b',alpha=0.6,zorder=10)
axbin.fill_between([bin1[0],bin2[0]],[binlo2[0],binlo2[0]],[binhi2[0],binhi2[0]],color='b',alpha=0.3,zorder=5)
axbin.fill_between([bin1[1],bin2[1]],[binlo1[1],binlo1[1]],[binhi1[1],binhi1[1]],color='b',alpha=0.6,zorder=10)
axbin.fill_between([bin1[1],bin2[1]],[binlo2[1],binlo2[1]],[binhi2[1],binhi2[1]],color='b',alpha=0.3,zorder=5)
axbin.fill_between([bin1[2],bin2[2]],[binlo1[2],binlo1[2]],[binhi1[2],binhi1[2]],color='b',alpha=0.6,zorder=10)
axbin.fill_between([bin1[2],bin2[2]],[binlo2[2],binlo2[2]],[binhi2[2],binhi2[2]],color='b',alpha=0.3,zorder=5)
axbin.fill_between([bin1[3],bin2[3]],[binlo1[3],binlo1[3]],[binhi1[3],binhi1[3]],color='b',alpha=0.6,zorder=10)
axbin.fill_between([bin1[3],bin2[3]],[binlo2[3],binlo2[3]],[binhi2[3],binhi2[3]],color='b',alpha=0.3,zorder=5)
axbin.fill_between([bin1[4],bin2[4]],[binlo1[4],binlo1[4]],[binhi1[4],binhi1[4]],color='b',alpha=0.6,zorder=10)
axbin.fill_between([bin1[4],bin2[4]],[binlo2[4],binlo2[4]],[binhi2[4],binhi2[4]],color='b',alpha=0.3,zorder=5)
axbin.fill_between([bin1[5],bin2[5]],[binlo1[5],binlo1[5]],[binhi1[5],binhi1[5]],color='b',alpha=0.6,zorder=10)
axbin.fill_between([bin1[5],bin2[5]],[binlo2[5],binlo2[5]],[binhi2[5],binhi2[5]],color='b',alpha=0.3,zorder=5)

#axcra2.xaxis.set_major_formatter(plt.NullFormatter())
axcra2.set_xlabel(r'$N_{\rm Cra2}$',fontsize=11,rotation=0)
axcra2.set_ylabel(r'$N$',fontsize=11,rotation=90)
#axcra2.set_xlabel(r'$\log_{10}[c_{200}]$',fontsize=12,rotation=90)
#axcra2.set_xlabel(r'$R_{\rm h}$ [pc]',fontsize=11,rotation=0,labelpad=5)
#axcra2.set_ylim([2,9])
#axcra2.set_xlim([6,11])
axcra2.set_xscale(u'linear')
axcra2.set_yscale(u'linear')
#axcra2.xaxis.set_major_formatter(plt.NullFormatter())
axcra2.hist(ncra2,bins=50,range=[0,max(ncra2)*1.1],histtype='step',normed=False,align='mid',rwidth=0,orientation='vertical')

#axscatter.xaxis.set_major_formatter(plt.NullFormatter())
axscatter.set_xlabel(r'$N_{\rm Cra2}$',fontsize=11,rotation=0)
axscatter.set_ylabel(r'$N$',fontsize=11,rotation=90)
#axscatter.set_xlabel(r'$\log_{10}[c_{200}]$',fontsize=12,rotation=90)
#axscatter.set_xlabel(r'$R_{\rm h}$ [pc]',fontsize=11,rotation=0,labelpad=5)
#axscatter.set_ylim([2,9])
#axscatter.set_xlim([6,11])
axscatter.set_xscale(u'linear')
axscatter.set_yscale(u'linear')
#axscatter.xaxis.set_major_formatter(plt.NullFormatter())
axscatter.scatter(ncra2,sigma,marker='o',color='k',s=1,alpha=0.35,rasterized=True)

plotfilename='cra2_prash2.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
