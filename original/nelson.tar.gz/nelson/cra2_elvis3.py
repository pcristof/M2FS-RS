import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
from scipy.stats import kde
import random
import scipy.optimize as optimize
from galpy.potential import MWPotential2014
from galpy.potential import NFWPotential
from galpy.orbit import Orbit
from galpy.potential import vesc
from astropy import units
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.8)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='10')
plt.rc('ytick',labelsize='10')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

with open('/nfs/nas-0-9/mgwalker.proj/ELVIS_Halo_Catalogs/HiResCatalogs/iKauket_HiRes.txt') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()[4:]
kauket_halo=[]
kauket_x=[]
kauket_y=[]
kauket_z=[]
kauket_vx=[]
kauket_vy=[]
kauket_vz=[]
kauket_vmax=[]
kauket_vpeak=[]
kauket_mvir=[]
kauket_mpeak=[]
kauket_rvir=[]
kauket_rmax=[]
kauket_apeak=[]
kauket_mstar1=[]
kauket_mstar2=[]
kauket_particles=[]
kauket_parent=[]
kauket_topmost=[]
for line in data: # fill arrays
    p=line.split()
    kauket_halo.append(str(p[0]))
    kauket_x.append(float(p[1]))
    kauket_y.append(float(p[2]))
    kauket_z.append(float(p[3]))
    kauket_vx.append(float(p[4]))
    kauket_vy.append(float(p[5]))
    kauket_vz.append(float(p[6]))
    kauket_vmax.append(float(p[7]))
    kauket_vpeak.append(float(p[8]))
    kauket_mvir.append(float(p[9]))
    kauket_mpeak.append(float(p[10]))
    kauket_rvir.append(float(p[11]))
    kauket_rmax.append(float(p[12]))
    kauket_apeak.append(float(p[13]))
    kauket_mstar1.append(float(p[14]))
    kauket_mstar2.append(float(p[15]))
    kauket_particles.append(float(p[16]))
    kauket_parent.append(float(p[17]))
    kauket_topmost.append(float(p[18]))
kauket_halo=np.array(kauket_halo)
kauket_x=np.array(kauket_x)
kauket_y=np.array(kauket_y)
kauket_z=np.array(kauket_z)
kauket_vx=np.array(kauket_vx)
kauket_vy=np.array(kauket_vy)
kauket_vz=np.array(kauket_vz)
kauket_vmax=np.array(kauket_vmax)
kauket_vpeak=np.array(kauket_vpeak)
kauket_mvir=np.array(kauket_mvir)
kauket_mpeak=np.array(kauket_mpeak)
kauket_rvir=np.array(kauket_rvir)
kauket_rmax=np.array(kauket_rmax)
kauket_apeak=np.array(kauket_apeak)
kauket_mstar1=np.array(kauket_mstar1)
kauket_mstar2=np.array(kauket_mstar2)
kauket_particles=np.array(kauket_particles)
kauket_parent=np.array(kauket_parent)
kauket_topmost=np.array(kauket_topmost)

kauket_rs=kauket_rmax/2.16
kauket_cvir=kauket_rvir/kauket_rs

kauket_h=0.71
kauket_x=(kauket_x-25./kauket_h)*1.e+6
kauket_y=(kauket_y-25./kauket_h)*1.e+6
kauket_z=(kauket_z-25./kauket_h)*1.e+6
kauket_distance=np.sqrt(kauket_x**2+kauket_y**2+kauket_z**2)/1000.

with open('/nfs/nas-0-9/mgwalker.proj/ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()[4:]
scylla_halo=[]
scylla_x=[]
scylla_y=[]
scylla_z=[]
scylla_vx=[]
scylla_vy=[]
scylla_vz=[]
scylla_vmax=[]
scylla_vpeak=[]
scylla_mvir=[]
scylla_mpeak=[]
scylla_rvir=[]
scylla_rmax=[]
scylla_apeak=[]
scylla_mstar1=[]
scylla_mstar2=[]
scylla_particles=[]
scylla_parent=[]
scylla_topmost=[]
for line in data: # fill arrays
    p=line.split()
    scylla_halo.append(str(p[0]))
    scylla_x.append(float(p[1]))
    scylla_y.append(float(p[2]))
    scylla_z.append(float(p[3]))
    scylla_vx.append(float(p[4]))
    scylla_vy.append(float(p[5]))
    scylla_vz.append(float(p[6]))
    scylla_vmax.append(float(p[7]))
    scylla_vpeak.append(float(p[8]))
    scylla_mvir.append(float(p[9]))
    scylla_mpeak.append(float(p[10]))
    scylla_rvir.append(float(p[11]))
    scylla_rmax.append(float(p[12]))
    scylla_apeak.append(float(p[13]))
    scylla_mstar1.append(float(p[14]))
    scylla_mstar2.append(float(p[15]))
    scylla_particles.append(float(p[16]))
    scylla_parent.append(float(p[17]))
    scylla_topmost.append(float(p[18]))
scylla_halo=np.array(scylla_halo)
scylla_x=np.array(scylla_x)
scylla_y=np.array(scylla_y)
scylla_z=np.array(scylla_z)
scylla_vx=np.array(scylla_vx)
scylla_vy=np.array(scylla_vy)
scylla_vz=np.array(scylla_vz)
scylla_vmax=np.array(scylla_vmax)
scylla_vpeak=np.array(scylla_vpeak)
scylla_mvir=np.array(scylla_mvir)
scylla_mpeak=np.array(scylla_mpeak)
scylla_rvir=np.array(scylla_rvir)
scylla_rmax=np.array(scylla_rmax)
scylla_apeak=np.array(scylla_apeak)
scylla_mstar1=np.array(scylla_mstar1)
scylla_mstar2=np.array(scylla_mstar2)
scylla_particles=np.array(scylla_particles)
scylla_parent=np.array(scylla_parent)
scylla_topmost=np.array(scylla_topmost)

scylla_rs=scylla_rmax/2.16
scylla_cvir=scylla_rvir/scylla_rs

scylla_h=0.71
scylla_x=(scylla_x-25./scylla_h)*1.e+6
scylla_y=(scylla_y-25./scylla_h)*1.e+6
scylla_z=(scylla_z-25./scylla_h)*1.e+6
scylla_distance=np.sqrt(scylla_x**2+scylla_y**2+scylla_z**2)/1000.

with open('/nfs/nas-0-9/mgwalker.proj/ELVIS_Halo_Catalogs/HiResCatalogs/iHall_HiRes.txt') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()[4:]
hall_halo=[]
hall_x=[]
hall_y=[]
hall_z=[]
hall_vx=[]
hall_vy=[]
hall_vz=[]
hall_vmax=[]
hall_vpeak=[]
hall_mvir=[]
hall_mpeak=[]
hall_rvir=[]
hall_rmax=[]
hall_apeak=[]
hall_mstar1=[]
hall_mstar2=[]
hall_particles=[]
hall_parent=[]
hall_topmost=[]
for line in data: # fill arrays
    p=line.split()
    hall_halo.append(str(p[0]))
    hall_x.append(float(p[1]))
    hall_y.append(float(p[2]))
    hall_z.append(float(p[3]))
    hall_vx.append(float(p[4]))
    hall_vy.append(float(p[5]))
    hall_vz.append(float(p[6]))
    hall_vmax.append(float(p[7]))
    hall_vpeak.append(float(p[8]))
    hall_mvir.append(float(p[9]))
    hall_mpeak.append(float(p[10]))
    hall_rvir.append(float(p[11]))
    hall_rmax.append(float(p[12]))
    hall_apeak.append(float(p[13]))
    hall_mstar1.append(float(p[14]))
    hall_mstar2.append(float(p[15]))
    hall_particles.append(float(p[16]))
    hall_parent.append(float(p[17]))
    hall_topmost.append(float(p[18]))
hall_halo=np.array(hall_halo)
hall_x=np.array(hall_x)
hall_y=np.array(hall_y)
hall_z=np.array(hall_z)
hall_vx=np.array(hall_vx)
hall_vy=np.array(hall_vy)
hall_vz=np.array(hall_vz)
hall_vmax=np.array(hall_vmax)
hall_vpeak=np.array(hall_vpeak)
hall_mvir=np.array(hall_mvir)
hall_mpeak=np.array(hall_mpeak)
hall_rvir=np.array(hall_rvir)
hall_rmax=np.array(hall_rmax)
hall_apeak=np.array(hall_apeak)
hall_mstar1=np.array(hall_mstar1)
hall_mstar2=np.array(hall_mstar2)
hall_particles=np.array(hall_particles)
hall_parent=np.array(hall_parent)
hall_topmost=np.array(hall_topmost)

hall_rs=hall_rmax/2.16
hall_cvir=hall_rvir/hall_rs

hall_h=0.71
hall_x=(hall_x-25./hall_h)*1.e+6
hall_y=(hall_y-25./hall_h)*1.e+6
hall_z=(hall_z-25./hall_h)*1.e+6
hall_distance=np.sqrt(hall_x**2+hall_y**2+hall_z**2)/1000.

kauket_mvir_peak=kauket_mpeak
scylla_mvir_peak=scylla_mpeak
hall_mvir_peak=hall_mpeak

kauket_main_m97=1.03e+12
scylla_main_m97=1.61e+12
hall_main_m97=1.67e+12
kauket_main_r97=263000.
scylla_main_r97=305000.
hall_main_r97=309000.
kauket_main_c97=11.8
scylla_main_c97=9.5
hall_main_c97=5.8
kauket_main_rs=kauket_main_r97/kauket_main_c97
scylla_main_rs=scylla_main_r97/scylla_main_c97
hall_main_rs=hall_main_r97/hall_main_c97
kauket_main_rhos=kauket_main_m97/4./np.pi/kauket_main_rs/(np.log(1.+kauket_main_c97)-kauket_main_c97/(1.+kauket_main_c97))
scylla_main_rhos=scylla_main_m97/4./np.pi/scylla_main_rs/(np.log(1.+scylla_main_c97)-scylla_main_c97/(1.+scylla_main_c97))
hall_main_rhos=hall_main_m97/4./np.pi/hall_main_rs/(np.log(1.+hall_main_c97)-hall_main_c97/(1.+hall_main_c97))

gs=plt.GridSpec(12,12) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
axelvis=fig.add_subplot(gs[0:3,0:5])
axtide=fig.add_subplot(gs[3:6,0:5])

##########assign stellar masses
kauket_mstar0=kauket_mstar1
scylla_mstar0=scylla_mstar1
hall_mstar0=hall_mstar1

ntrials=1000

scatter=[]
kauket_ncra2=[]
kauket_ngal5=[]
scylla_ncra2=[]
scylla_ngal5=[]
hall_ncra2=[]
hall_ngal5=[]

kauket_cra2tide=[]
kauket_gal5tide=[]
scylla_cra2tide=[]
scylla_gal5tide=[]
hall_cra2tide=[]
hall_gal5tide=[]
for i in range(0,22):
    sigma=0.000001+np.float(i)*0.1
    alpha=0.14*sigma**2+0.14*sigma+1.79

    kauket_ncra2_0=[]
    kauket_ngal5_0=[]
    scylla_ncra2_0=[]
    scylla_ngal5_0=[]
    hall_ncra2_0=[]
    hall_ngal5_0=[]

    kauket_cra2tide_0=[]
    kauket_gal5tide_0=[]
    scylla_cra2tide_0=[]
    scylla_gal5tide_0=[]
    hall_cra2tide_0=[]
    hall_gal5tide_0=[]
    for j in range(0,ntrials):
        kauket_dev=np.random.normal(0.,sigma,np.size(kauket_mvir))
        scylla_dev=np.random.normal(0.,sigma,np.size(scylla_mvir))
        hall_dev=np.random.normal(0.,sigma,np.size(hall_mvir))
        kauket_logmstar=np.log10(5.e+9/10.**(11.5*alpha))+alpha*np.log10(kauket_mvir_peak)+kauket_dev
        kauket_mstar=10.**kauket_logmstar
        scylla_logmstar=np.log10(5.e+9/10.**(11.5*alpha))+alpha*np.log10(scylla_mvir_peak)+scylla_dev
        scylla_mstar=10.**scylla_logmstar
        hall_logmstar=np.log10(5.e+9/10.**(11.5*alpha))+alpha*np.log10(hall_mvir_peak)+hall_dev
        hall_mstar=10.**hall_logmstar
        
        kauket_gal2=np.where((kauket_mstar > 1.e+2)&(kauket_mstar <1.e+3)&(kauket_distance<300.))
        kauket_gal3=np.where((kauket_mstar > 1.e+3)&(kauket_mstar <1.e+4)&(kauket_distance<300.))
        kauket_gal4=np.where((kauket_mstar > 1.e+4)&(kauket_mstar <1.e+5)&(kauket_distance<300.))
        kauket_gal5=np.where((kauket_mstar > 1.e+5)&(kauket_distance<300.))
        scylla_gal2=np.where((scylla_mstar > 1.e+2)&(scylla_mstar <1.e+3)&(scylla_distance<300.))
        scylla_gal3=np.where((scylla_mstar > 1.e+3)&(scylla_mstar <1.e+4)&(scylla_distance<300.))
        scylla_gal4=np.where((scylla_mstar > 1.e+4)&(scylla_mstar <1.e+5)&(scylla_distance<300.))
        scylla_gal5=np.where((scylla_mstar > 1.e+5)&(scylla_distance<300.))
        hall_gal2=np.where((hall_mstar > 1.e+2)&(hall_mstar <1.e+3)&(hall_distance<300.))
        hall_gal3=np.where((hall_mstar > 1.e+3)&(hall_mstar <1.e+4)&(hall_distance<300.))
        hall_gal4=np.where((hall_mstar > 1.e+4)&(hall_mstar <1.e+5)&(hall_distance<300.))
        hall_gal5=np.where((hall_mstar > 1.e+5)&(hall_distance<300.))
        
        kauket_cra2=np.where((kauket_mstar>1.e+5)&(kauket_mvir<1.e+7)&(kauket_distance<300.))
        scylla_cra2=np.where((scylla_mstar>1.e+5)&(scylla_mvir<1.e+7)&(scylla_distance<300.))
        hall_cra2=np.where((hall_mstar>1.e+5)&(hall_mvir<1.e+7)&(hall_distance<300.))

        kauket_ncra2_0.append(np.size(kauket_cra2))
        kauket_ngal5_0.append(np.size(kauket_gal5))
        scylla_ncra2_0.append(np.size(scylla_cra2))
        scylla_ngal5_0.append(np.size(scylla_gal5))
        hall_ncra2_0.append(np.size(hall_cra2))
        hall_ngal5_0.append(np.size(hall_gal5))

        if(np.size(kauket_cra2)>=1):
            kauket_cra2tide_0.append(np.median(np.log10(kauket_mvir[kauket_cra2]/kauket_mvir_peak[kauket_cra2])))
        if(np.size(kauket_gal5)>=1):
            kauket_gal5tide_0.append(np.median(np.log10(kauket_mvir[kauket_gal5]/kauket_mvir_peak[kauket_gal5])))
        if(np.size(scylla_cra2)>=1):
            scylla_cra2tide_0.append(np.median(np.log10(scylla_mvir[scylla_cra2]/scylla_mvir_peak[scylla_cra2])))
        if(np.size(scylla_gal5)>=1):
            scylla_gal5tide_0.append(np.median(np.log10(scylla_mvir[scylla_gal5]/scylla_mvir_peak[scylla_gal5])))
        if(np.size(hall_cra2)>=1):
            hall_cra2tide_0.append(np.median(np.log10(hall_mvir[hall_cra2]/hall_mvir_peak[hall_cra2])))
        if(np.size(hall_gal5)>=1):
            hall_gal5tide_0.append(np.median(np.log10(hall_mvir[hall_gal5]/hall_mvir_peak[hall_gal5])))

    kauket_ncra2_0=np.array(kauket_ncra2_0)
    kauket_ngal5_0=np.array(kauket_ngal5_0)
    scylla_ncra2_0=np.array(scylla_ncra2_0)
    scylla_ngal5_0=np.array(scylla_ngal5_0)
    hall_ncra2_0=np.array(hall_ncra2_0)
    hall_ngal5_0=np.array(hall_ngal5_0)

    kauket_cra2tide_0=np.array(kauket_cra2tide_0)
    kauket_gal5tide_0=np.array(kauket_gal5tide_0)
    scylla_cra2tide_0=np.array(scylla_cra2tide_0)
    scylla_gal5tide_0=np.array(scylla_gal5tide_0)
    hall_cra2tide_0=np.array(hall_cra2tide_0)
    hall_gal5tide_0=np.array(hall_gal5tide_0)

    
    scatter.append(sigma)
    kauket_ncra2.append(np.median(kauket_ncra2_0))
    kauket_ngal5.append(np.median(kauket_ngal5_0))
    scylla_ncra2.append(np.median(scylla_ncra2_0))
    scylla_ngal5.append(np.median(scylla_ngal5_0))
    hall_ncra2.append(np.median(hall_ncra2_0))
    hall_ngal5.append(np.median(hall_ngal5_0))

    kauket_cra2tide.append(np.median(kauket_cra2tide_0))
    kauket_gal5tide.append(np.median(kauket_gal5tide_0))
    scylla_cra2tide.append(np.median(scylla_cra2tide_0))
    scylla_gal5tide.append(np.median(scylla_gal5tide_0))
    hall_cra2tide.append(np.median(hall_cra2tide_0))
    hall_gal5tide.append(np.median(hall_gal5tide_0))

scatter=np.array(scatter)
kauket_ncra2=np.array(kauket_ncra2)
kauket_ngal5=np.array(kauket_ngal5)
scylla_ncra2=np.array(scylla_ncra2)
scylla_ngal5=np.array(scylla_ngal5)
hall_ncra2=np.array(hall_ncra2)
hall_ngal5=np.array(hall_ngal5)

kauket_cra2tide=np.array(kauket_cra2tide)
kauket_gal5tide=np.array(kauket_gal5tide)
scylla_cra2tide=np.array(scylla_cra2tide)
scylla_gal5tide=np.array(scylla_gal5tide)
hall_cra2tide=np.array(hall_cra2tide)
hall_gal5tide=np.array(hall_gal5tide)

axtide.set_xlim([0.2,2.])
axtide.set_ylim([-3,-0.1])
axtide.set_xticks([0.5,1.,1.5,2])
axtide.set_xticklabels([0.5,1.,1.5,2])
axtide.set_xlabel(r'scatter in SMHM [dex]')
axtide.set_ylabel(r'$\log_{10}[M_{\rm vir}/M_{\rm peak}]$')
axtide.plot(scatter,kauket_gal5tide,color='r',linestyle='--')
axtide.plot(scatter,kauket_cra2tide,color='r')
axtide.plot(scatter,scylla_gal5tide,color='b',linestyle='--')
axtide.plot(scatter,scylla_cra2tide,color='b')
axtide.plot(scatter,hall_gal5tide,color='m',linestyle='--')
axtide.plot(scatter,hall_cra2tide,color='m')
axtide.plot([1,1.3],[-12.5,-12.5],color='k',linestyle='--',label=r'$M_*>10^5M_{\odot}$')
axtide.plot([1,1.3],[-12,-12],color='k',label=r'$M_*>10^5M_{\odot},M_{\rm halo}<10^7M_{\odot}$')
axtide.legend(loc=4,fontsize=4,handlelength=4.5,scatterpoints=1,borderaxespad=0)

#axtide.plot(scylla_tide_x,scylla_tide,color='b')
#axtide.plot(hall_tide_x,hall_tide,color='c')
#axtide.plot(kauket_tide_x,kauket_tide2,color='r',linestyle='--')
#axtide.plot(scylla_tide_x,scylla_tide2,color='b',linestyle='--')
#axtide.plot(hall_tide_x,hall_tide2,color='c',linestyle='--')
#axtide.plot(tide_x,scylla_tide,color='b')
#axtide.plot(tide_x,hall_tide,color='c')

axelvis.set_xlim([0.2,2.])
axelvis.set_ylim([0.5,1000])
axelvis.set_xscale(u'linear')
axelvis.set_yscale(u'log')
axelvis.xaxis.set_major_formatter(plt.NullFormatter())
#axelvis.set_xlabel(r'scatter in SMHM [dex]')
axelvis.set_ylabel(r'$N_{\rm satellites}$')
#axelvis.plot(scylla_x,scylla_y0,color='b',alpha=1,label=r'$M_{\rm host}=1.6\times 10^{12}M_{\odot}$',zorder=5)
#axelvis.plot(hall_x,hall_y0,color='c',alpha=1,label=r'$M_{\rm host}=1.7\times 10^{12}M_{\odot}$',zorder=5)
axelvis.plot(scatter,kauket_ngal5,color='r',alpha=1,linestyle='--',lw=1.4)
axelvis.plot(scatter,kauket_ncra2,color='r',alpha=1,lw=1.4)
axelvis.plot(scatter,scylla_ngal5,color='b',alpha=1,linestyle='--')
axelvis.plot(scatter,scylla_ncra2,color='b',alpha=1)
axelvis.plot(scatter,hall_ngal5,color='m',alpha=1,linestyle='--')
axelvis.plot(scatter,hall_ncra2,color='m',alpha=1)
axelvis.plot([1,2],[10000,10000],color='r',label=r'$M_{\rm host}=1.0\times 10^{12}M_{\odot}$')
axelvis.plot([1,2],[10000,10000],color='b',label=r'$M_{\rm host}=1.6\times 10^{12}M_{\odot}$')
axelvis.plot([1,2],[10000,10000],color='m',label=r'$M_{\rm host}=1.7\times 10^{12}M_{\odot}$')
#axelvis.plot(scylla_x,scylla_y02,color='b',alpha=1,label=r'$M_{\rm host}=1.6\times 10^{12}M_{\odot}$',zorder=5,linestyle='--')
#axelvis.plot(hall_x,hall_y02,color='c',alpha=1,label=r'$M_{\rm host}=1.7\times 10^{12}M_{\odot}$',zorder=5,linestyle='--')
#axelvis.plot(kauket_x,kauket_y02,color='r',alpha=1,label=r'$M_{\rm host}=1.0\times 10^{12}M_{\odot}$',zorder=10,linestyle='--')
#axelvis.legend(loc=2,fontsize=5,scatterpoints=1,borderaxespad=0)
axelvis.legend(loc=1,fontsize=4,handlelength=4.5,scatterpoints=1,borderaxespad=0)

plotfilename='cra2_elvis3.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
