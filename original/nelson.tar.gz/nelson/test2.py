import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
import scipy.special as special
import scipy.optimize as optimize
import scipy.integrate as integrate
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.99)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='8')
plt.rc('ytick',labelsize='8')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

m200=1.e10
c200=10.
n=0.5
n2=1.
n3=1.5
rsrc=2.

gc=1./(np.log(1.+c200)-c200/(1.+c200))

x=np.linspace(0,10,1000)

mnfw=m200*gc*(np.log(1.+x)-x/(1.+x))
mnfwcore=mnfw*(np.tanh(x*rsrc))**n
mnfwcore2=mnfw*(np.tanh(x*rsrc))**n2
mnfwcore3=mnfw*(np.tanh(x*rsrc))**n3

fnfw=1.
fnfwcore=(np.tanh(x*rsrc))**n
fnfwcore2=(np.tanh(x*rsrc))**n2
fnfwcore3=(np.tanh(x*rsrc))**n3

rhos=136.05*200.*gc*(c200)**3/3.
rhonfw=rhos/x/(1.+x)**2
rhonfwcore=rhonfw*fnfwcore+xxx
rhonfwcore2=rhonfw*fnfwcore2+xxx
rhonfwcore3=rhonfw*fnfwcore3+xxx

plt.plot(np.log10(x),np.log10(rhonfw),color='k')
plt.plot(np.log10(x),np.log10(rhonfwcore),color='r')
plt.plot(np.log10(x),np.log10(rhonfwcore2),color='g')
plt.plot(np.log10(x),np.log10(rhonfwcore3),color='b')
plt.show()
plt.close()
plotfilename='test.pdf'
#plt.savefig(plotfilename,dpi=400)
#plt.show()
#plt.close()
