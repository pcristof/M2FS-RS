import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
from scipy.stats import kde
import random
import scipy.optimize as optimize
from galpy.potential import MWPotential2014
from galpy.potential import NFWPotential
from galpy.orbit import Orbit
from galpy.potential import vesc
from astropy import units
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.8)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='10')
plt.rc('ytick',labelsize='10')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

with open('/physics2/mgwalker/chains/prash2post_equal_weights.dat') as f:
    data=f.readlines()
prash_m11=[]
prash_alpha=[]
prash_sigma8=[]
for line in data: # fill arrays
    p=line.split()
    prash_m11.append(float(p[0]))
    prash_alpha.append(float(p[1]))
    prash_sigma8.append(float(p[2]))
prash_m11=np.array(prash_m11)
prash_alpha=np.array(prash_alpha)
prash_sigma8=np.array(prash_sigma8)
prash_alpha=np.tan(prash_alpha)

sort=np.argsort(prash_sigma8)
prash_m11=prash_m11[sort]
prash_alpha=prash_alpha[sort]
prash_sigma8=prash_sigma8[sort]

bins=50
perbin=np.long(np.float(len(prash_m11))/np.float(bins))
bin=[]
for i in range(0,len(prash_m11)):
    shite=np.long(np.float(i)/np.float(perbin))+1
    if(shite>bins):
        shite=bins
    bin.append(shite)
bin=np.array(bin)

with open('/nfs/nas-0-9/mgwalker.proj/catalogues_matt_crater2/sim6_hr_disk.csv') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()[1:]
sim0_mvir=[]
sim0_rvir=[]
sim0_rs=[]
sim0_a_peak=[]
sim0_mvir_peak=[]
sim0_rvir_peak=[]
sim0_rs_peak=[]
sim0_a_acc=[]
sim0_r_min=[]
sim0_r_max=[]
sim0_x_min=[]
sim0_x_max=[]
sim0_x=[]
sim0_y=[]
sim0_z=[]
sim0_vx=[]
sim0_vy=[]
sim0_vz=[]
sim0_mstar_fid=[]
sim0_mstar_sca=[]
sim0_mstar_ho=[]
for line in data: # fill arrays
    p=line.split()
    sim0_mvir.append(float(p[0]))
    sim0_rvir.append(float(p[1]))
    sim0_rs.append(float(p[2]))
    sim0_a_peak.append(float(p[3]))
    sim0_mvir_peak.append(float(p[4]))
    sim0_rvir_peak.append(float(p[5]))
    sim0_rs_peak.append(float(p[6]))
    sim0_a_acc.append(float(p[7]))
    sim0_r_min.append(float(p[8]))
    sim0_r_max.append(float(p[9]))
    sim0_x_min.append(float(p[10]))
    sim0_x_max.append(float(p[11]))
    sim0_x.append(float(p[12]))
    sim0_y.append(float(p[13]))
    sim0_z.append(float(p[14]))
    sim0_vx.append(float(p[15]))
    sim0_vy.append(float(p[16]))
    sim0_vz.append(float(p[17]))
    sim0_mstar_fid.append(float(p[18]))
    sim0_mstar_sca.append(float(p[19]))
    sim0_mstar_ho.append(float(p[20]))
sim0_mvir=np.array(sim0_mvir)
sim0_rvir=np.array(sim0_rvir)
sim0_rs=np.array(sim0_rs)
sim0_a_peak=np.array(sim0_a_peak)
sim0_mvir_peak=np.array(sim0_mvir_peak)
sim0_rvir_peak=np.array(sim0_rvir_peak)
sim0_rs_peak=np.array(sim0_rs_peak)
sim0_a_acc=np.array(sim0_a_acc)
sim0_r_min=np.array(sim0_r_min)
sim0_r_max=np.array(sim0_r_max)
sim0_x_min=np.array(sim0_x_min)
sim0_x_max=np.array(sim0_x_max)
sim0_x=np.array(sim0_x)
sim0_y=np.array(sim0_y)
sim0_z=np.array(sim0_z)
sim0_vx=np.array(sim0_vx)
sim0_vy=np.array(sim0_vy)
sim0_vz=np.array(sim0_vz)
sim0_mstar_fid=np.array(sim0_mstar_fid)
sim0_mstar_sca=np.array(sim0_mstar_sca)
sim0_mstar_ho=np.array(sim0_mstar_ho)

sim0_distance=np.sqrt(sim0_x**2+sim0_y**2+sim0_z**2)
sim0_mstar0=sim0_mstar_sca

scatter=[]
ncra2=[]
ngal=[]
cra2ratio=[]
galratio=[]
ncra2lo=[]
ncra2hi=[]
ngallo=[]
ngalhi=[]
cra2ratiolo=[]
cra2ratiohi=[]
galratiolo=[]
galratiohi=[]
cra2apo=[]
cra2apolo=[]
cra2apohi=[]
galapo=[]
galapolo=[]
galapohi=[]
cra2peri=[]
cra2perilo=[]
cra2perihi=[]
galperi=[]
galperilo=[]
galperihi=[]

#for i in range(1,10):
for i in range(1,bins):
    print i
    ncra2_0=[]
    ngal_0=[]
    cra2ratio_0=[]
    galratio_0=[]
    cra2apo_0=[]
    cra2peri_0=[]
    galapo_0=[]
    galperi_0=[]
    
    for k in range(0,len(prash_m11)):
        if(bin[k]==i):
#for i in range(8500,9001):
            prash_logmstar=[]
            for j in range(0,len(sim0_mvir)):
                if(sim0_mvir_peak[j] > 1.e+11):
                    sigma=0.2
                if(sim0_mvir_peak[j] <= 1.e+11):
                    sigma=(0.2-prash_sigma8[k])/3.*(np.log10(sim0_mvir_peak[j])-8.)+prash_sigma8[k]
                dev=np.random.normal(0.,sigma)
#        print j,dev
                prash_logmstar.append(np.min([prash_m11[k]+prash_alpha[k]*np.log10(sim0_mvir_peak[j]/1.e+11)+dev,0.1*sim0_mvir_peak[j]]))
            prash_logmstar=np.array(prash_logmstar)
            prash_mstar=10.**prash_logmstar
            prash_lum=prash_mstar/2.
            prash_absvmag=4.83-2.5*np.log10(prash_lum)
            cra2=np.where((prash_mstar>1.e+5)&(sim0_mvir<1.e+7)&(sim0_distance<300.)&(prash_absvmag<(1.1-np.log10(sim0_distance))/0.228))
            gal=np.where((prash_mstar>1.e+5)&(sim0_distance<300.)&(prash_absvmag<(1.1-np.log10(sim0_distance))/0.228))
            ncra2_0.append(np.size(cra2))
            ngal_0.append(np.size(gal))
            cra2ratio_0.append(np.median(np.log10(sim0_mvir[cra2]/sim0_mvir_peak[cra2])))
            galratio_0.append(np.median(np.log10(sim0_mvir[gal]/sim0_mvir_peak[gal])))
            cra2apo_0.append(np.median(sim0_r_max[cra2]))
            cra2peri_0.append(np.median(sim0_r_min[cra2]))
            galapo_0.append(np.median(sim0_r_max[gal]))
            galperi_0.append(np.median(sim0_r_min[gal]))
    ncra2_0=np.array(ncra2_0)
    ngal_0=np.array(ngal_0)
    cra2ratio_0=np.array(cra2ratio_0)
    galratio_0=np.array(galratio_0)
    cra2apo_0=np.array(cra2apo_0)
    cra2peri_0=np.array(cra2peri_0)
    galapo_0=np.array(galapo_0)
    galperi_0=np.array(galperi_0)
    scatter.append(np.median(prash_sigma8[bin==i]))
    print ncra2_0,ngal_0
    ncra2.append(np.median(ncra2_0))
    ngal.append(np.median(ngal_0))    
    shite=np.where(cra2ratio_0==cra2ratio_0)
    if(np.size(shite)>0):
        cra2ratio.append(np.median(cra2ratio_0[shite]))
        cra2ratiolo.append(np.percentile(cra2ratio_0[shite],16))
        cra2ratiohi.append(np.percentile(cra2ratio_0[shite],84))
        cra2apo.append(np.median(cra2apo_0[shite]))
        cra2apolo.append(np.percentile(cra2apo_0[shite],16))
        cra2apohi.append(np.percentile(cra2apo_0[shite],84))
        cra2peri.append(np.median(cra2peri_0[shite]))
        cra2perilo.append(np.percentile(cra2peri_0[shite],16))
        cra2perihi.append(np.percentile(cra2peri_0[shite],84))
    if(np.size(shite)==0):
        cra2ratio.append('nan')
        cra2ratiolo.append('nan')
        cra2ratiohi.append('nan')
        cra2apo.append('nan')
        cra2apolo.append('nan')
        cra2apohi.append('nan')
        cra2peri.append('nan')
        cra2perilo.append('nan')
        cra2perihi.append('nan')
    shite=np.where(galratio_0==galratio_0)
    if(np.size(shite)>0):
        galratio.append(np.median(galratio_0[shite]))
        galratiolo.append(np.percentile(galratio_0[shite],16))
        galratiohi.append(np.percentile(galratio_0[shite],84))
        galapo.append(np.median(galapo_0[shite]))
        galapolo.append(np.percentile(galapo_0[shite],16))
        galapohi.append(np.percentile(galapo_0[shite],84))
        galperi.append(np.median(galperi_0[shite]))
        galperilo.append(np.percentile(galperi_0[shite],16))
        galperihi.append(np.percentile(galperi_0[shite],84))
    if(np.size(shite)==0):
        galratio.append('nan')
        galratiolo.append('nan')
        galratiohi.append('nan')
        galapo.append('nan')
        galapolo.append('nan')
        galapohi.append('nan')
        galperi.append('nan')
        galperilo.append('nan')
        galperihi.append('nan')
    ncra2lo.append(np.percentile(ncra2_0[shite],16))
    ncra2hi.append(np.percentile(ncra2_0[shite],84))
    ngallo.append(np.percentile(ngal_0,16))
    ngalhi.append(np.percentile(ngal_0,84))
ncra2=np.array(ncra2)
ngal=np.array(ngal)
scatter=np.array(scatter)
cra2ratio=np.array(cra2ratio)
galratio=np.array(galratio)
cra2apo=np.array(cra2apo)
cra2peri=np.array(cra2peri)
galapo=np.array(galapo)
galperi=np.array(galperi)
ncra2lo=np.array(ncra2lo)
ncra2hi=np.array(ncra2hi)
ngallo=np.array(ngallo)
ngalhi=np.array(ngalhi)
cra2ratiolo=np.array(cra2ratiolo)
cra2ratiohi=np.array(cra2ratiohi)
cra2apolo=np.array(cra2apolo)
cra2apohi=np.array(cra2apohi)
cra2perilo=np.array(cra2perilo)
cra2perihi=np.array(cra2perihi)
galratiolo=np.array(galratiolo)
galratiohi=np.array(galratiohi)
galapolo=np.array(galapolo)
galapohi=np.array(galapohi)
galperilo=np.array(galperilo)
galperihi=np.array(galperihi)

gs=plt.GridSpec(12,12) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
axelvis=fig.add_subplot(gs[0:3,0:5])
axtide=fig.add_subplot(gs[5:8,0:5])
axgal=fig.add_subplot(gs[5:8,7:12])

axelvis.set_yscale('linear')
axelvis.set_xscale('linear')
axelvis.set_xlim([0.2,2.])
axelvis.plot(scatter,ncra2,color='r')
axelvis.plot(scatter,ncra2lo,color='r',linestyle=':')
axelvis.plot(scatter,ncra2hi,color='r',linestyle=':')
axelvis.plot(scatter,ngal,color='b')
axelvis.plot(scatter,ngallo,color='b',linestyle=':')
axelvis.plot(scatter,ngalhi,color='b',linestyle=':')

axtide.set_yscale('linear')
axtide.set_xscale('linear')
axtide.set_xlim([0.2,2.])
axtide.plot(scatter,cra2ratio,color='r')
axtide.plot(scatter,cra2ratiolo,color='r',linestyle=':')
axtide.plot(scatter,cra2ratiohi,color='r',linestyle=':')
axtide.plot(scatter,galratio,color='b')
axtide.plot(scatter,galratiolo,color='b',linestyle=':')
axtide.plot(scatter,galratiohi,color='b',linestyle=':')

axgal.set_yscale('linear')
axgal.set_xscale('linear')
axgal.set_xlim([0.2,2.])
axgal.plot(scatter,cra2peri,color='r')
axgal.plot(scatter,cra2perilo,color='r',linestyle=':')
axgal.plot(scatter,cra2perihi,color='r',linestyle=':')
axgal.plot(scatter,galperi,color='b')
axgal.plot(scatter,galperilo,color='b',linestyle=':')
axgal.plot(scatter,galperihi,color='b',linestyle=':')

plotfilename='cra2_prash3.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
