import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.5)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='6')
plt.rc('ytick',labelsize='6')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)
    
g=0.0043# grav constant in galaxy units        
data7='/physics2/mgwalker/chains/n6229_vdisppost_equal_weights.dat'

with open(data7) as f: # read data file
    data=f.readlines()
vmean=[]
vdisp=[]
for line in data: # fill arrays
    p=line.split()
    vmean.append(float(p[0]))
    vdisp.append(float(p[1]))
vmean=np.array(vmean)
vdisp=np.array(vdisp)

absvmag0=-8.06
sigabsvmag0=0.1
rhalf0=3.2
sigrhalf0=0.2
absvmag=np.random.normal(loc=absvmag0,scale=sigabsvmag0,size=len(vdisp))
luminosity=10.**((absvmag-4.83)/(-2.5))
mrhalf=580.*rhalf0*vdisp**2
mlratio=mrhalf/(luminosity)

