import numpy as np
import astropy
from astropy.io import fits
import matplotlib
import matplotlib.pyplot as plt
from astropy.nddata import NDData
from astropy.nddata import StdDevUncertainty
from astropy.nddata import CCDData
import ccdproc
import dustmaps.sfd
import astropy.units as u
from astropy.modeling import models
from ccdproc import Combiner
import os
from os import path
import scipy
import m2fs_process as m2fs
import mycode
import crossmatcher
matplotlib.use('TkAgg')
import dill as pickle
#matplotlib.use('pdf')

shite=fits.open('nelson_all_ian.fits')

keep=np.where((shite[1].data['object']=='dra')|(shite[1].data['object']=='umi'))[0]
gaia_objid,gaia_gmag,gaia_bpmag,gaia_rpmag,gaia_gflux,gaia_bpflux,gaia_rpflux,gaia_siggflux,gaia_sigbpflux,gaia_sigrpflux,parallax=crossmatcher.doit('gaia_edr3.gaia_source',shite[1].data['ra_deg'][keep],shite[1].data['dec_deg'][keep],'source_id,phot_g_mean_mag,phot_bp_mean_mag,phot_rp_mean_mag,phot_g_mean_flux,phot_bp_mean_flux,phot_rp_mean_flux,phot_g_mean_flux_error,phot_bp_mean_flux_error,phot_rp_mean_flux_error,parallax',rad=1.,db='wsdb',host='wsdb.hpc1.cs.cmu.edu',user='matt_walker',password='5UN*ur8Y')

plt.scatter(gaia_gmag,shite[1].data['sn_ratio'][keep],s=1,alpha=0.3,color='k',rasterized=True)
plt.xscale('linear')
plt.xlim([22,15])
plt.yscale('log')
plt.ylim([0.1,100])
plt.xlabel('Gaia G magnitude')
plt.ylabel('median S/N/pixel')
plt.savefig('for_ed.pdf',dpi=200)
plt.show()
plt.close()

