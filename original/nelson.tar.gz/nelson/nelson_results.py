import numpy as np
import astropy
from astropy.io import fits
import matplotlib
import matplotlib.pyplot as plt
from astropy.nddata import NDData
from astropy.nddata import StdDevUncertainty
from astropy.nddata import CCDData
from astropy import time, coordinates as coord, units as u
from astropy.time import Time
from astropy.coordinates import SkyCoord, EarthLocation
import ccdproc
import astropy.units as u
from astropy.modeling import models
from ccdproc import Combiner
import os
import scipy
import hecto_process as hecto
matplotlib.use('TkAgg')

fit_done=1
data_directory='/nfs/nas-0-9/mgwalker.proj/hecto_data/'
fit_directory='/nfs/nas-0-9/mgwalker.proj/hecto_chains/'

with open('nelson_sextans_files') as f:
    data=f.readlines()
fitsfile=[]
for line in data:
    p=line.split()
    fitsfile.append(p[0])
fitsfile=np.array(fitsfile)

for i in range(0,len(fitsfile)):
    nddata=astropy.nddata.CCDData.read(fitsfile[i],unit=u.electron)
    hdul=fits.open(fitsfile[i])
    wav=hdul[0].data
    cfa_skysub=hdul[1].data
    ivar=hdul[2].data
    mask_and=hdul[3].data
    mask_or=hdul[4].data
    var=1./ivar
    fiber=hdul[5].data
    obj=fiber['OBJTYPE']
    skies=np.where(obj=='SKY')[0]
    targets=np.where(obj=='TARGET')[0]

    posterior=[]
    moments=[]
    bestfit_fit=[]
    for j in targets:
        ra,dec=fiber[j]['RA'],fiber[j]['DEC']
        coords=coord.SkyCoord(ra,dec,unit=(u.deg,u.deg),frame='icrs')
        mmt=coord.EarthLocation.of_site('mmt')
        times=time.Time(hdul[0].header['DATE-OBS'],location=mmt)
        light_travel_time_helio=times.light_travel_time(coords,'heliocentric')
        hjd=Time(hdul[0].header['DATE-OBS']).jd+light_travel_time_helio
        np.pause()
        heliocorr=coords.radial_velocity_correction('heliocentric',obstime=times).to(u.km/u.s)
        bad=np.where(mask_or[j]==1)[0]
        var[j][bad]=1.e+30

        out='hecto_nelson_ra'+str.format('{0:.6f}',round(ra,6)).zfill(6)+'_dec'+str.format('{0:.6f}',round(dec,6)).zfill(6)+'_hjd'+str.format('{0:.5f}',round(times.jd,5))+'_skysub.dat'
        print('frame ',i,out)
        g1=open(out,'w')
        for k in range(0,len(wav[j])):
            string=str(round(wav[j][k],10))+' '+str(round(cfa_skysub[j][k],3))+' '+str(round(var[j][k],5))+' \n'
            g1.write(string)
        g1.close()
        
        if fit_done==1:
            multinest_in=fit_directory+'hecto_nelson_ra'+str.format('{0:.6f}',round(ra,6)).zfill(6)+'_dec'+str.format('{0:.6f}',round(dec,6)).zfill(6)+'_hjd'+str.format('{0:.5f}',round(times.jd,5))+'post_equal_weights.dat'
            bestfit_in=fit_directory+'hecto_nelson_ra'+str.format('{0:.6f}',round(ra,6)).zfill(6)+'_dec'+str.format('{0:.6f}',round(dec,6)).zfill(6)+'_hjd'+str.format('{0:.5f}',round(times.jd,5))+'_bestfit.dat'
            print('frame ',i,multinest_in)

            posterior0,moments0=hecto.sspphecto_multinest(multinest_in)#retrieve sampling of posterior, and moments of posterior distributions for physical parameters
            bestfit_wav0,bestfit_counts0,bestfit_varcounts0,bestfit_fit0=hecto.sspphecto_bestfit(bestfit_in)#retrieve best fitting spectrum

            posterior.append(posterior0)
            moments.append(moments0)
            bestfit_fit.append(bestfit_fit0)
            print('bbb')
#        vlos=deltav+heliocorr.value

#        plt.plot(wav[j][keep],cfa_skysub[j][keep],color='k',lw=0.5)
#        plt.plot(wav[j][keep],bestfit_fit[j],color='r',lw=0.5)
#        plt.show()
#        plt.close()
            shite=(np.where(wav[j][keep[k]] != bestfit_wav[k] for k in range(0,len(keep))))[0]
            if shite[0]>0:
                print('ERROR in wavelengths!!!')
                np.pause()
#        for k in range(0,len(keep)):
#            print(wav[j][keep[k]],bestfit_wav[k],len(keep),len(bestfit_wav))

        posterior=np.array(posterior)
        moments=np.array(moments)
        bestfit_fit=np.array(bestfit_fit)

        hdul.append(fits.ImageHDU(bestfit_fit))
#    col1=fits.Column(name='pdf_v',format='e',dim='(208,1000)',array=posterior[:,:,0])
#    coldefs=fits.ColDefs([col1])
#    hdu=fits.BinTableHDU.from_columns([col1])
#    hdul.append(hdu)

#    np.pause()


