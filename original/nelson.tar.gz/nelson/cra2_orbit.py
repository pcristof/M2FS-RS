import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
from astropy.coordinates import SkyCoord,Distance,ICRS
from galpy.potential import MWPotential2014
from galpy.orbit import Orbit
from galpy.potential import vesc
from astropy import units
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='5')
plt.rc('ytick',labelsize='5')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

##use van der marel 2002 formalism to calculate velocities in GRF, XYZ system
mw=MWPotential2014
r0=8.29#kpc mcmillan 2011
usun=11.1#schonrich 2010
vsun=12.24#schonrich 2010
wsun=7.25#schonrich 2010
vlsr=239.#mcmillan 2011
rsolar=np.array([-r0,0,0],dtype=float)
vsolar=np.array([usun,vsun+vlsr,wsun])

cra2_radegcenter=177.310#deg
cra2_decdegcenter=-18.413
cra2_racenter=cra2_radegcenter*np.pi/180.#rad
cra2_deccenter=cra2_decdegcenter*np.pi/180.#rad
cra2_distance=117.5#kpc
cra2_coords=SkyCoord(cra2_racenter,cra2_deccenter,unit=['rad','rad'])
cra2_lcenter=cra2_coords.galactic.l.radian
cra2_bcenter=cra2_coords.galactic.b.radian

alpha0=np.linspace(cra2_racenter-0.000001,cra2_racenter+0.000001,1000)
dalpha0=alpha0[1]-alpha0[0]
coords=SkyCoord(alpha0,np.zeros(len(alpha0))+cra2_deccenter,unit=['rad','rad'])
l0=coords.galactic.l.radian
b0=coords.galactic.b.radian
dldalpha=(np.gradient(l0,dalpha0))[499]
dbdalpha=(np.gradient(b0,dalpha0))[499]

delta0=np.linspace(cra2_deccenter-0.000001,cra2_deccenter+0.000001,1000)
ddelta=delta0[1]-delta0[0]
coords=SkyCoord(np.zeros(len(delta0))+cra2_racenter,delta0,unit=['rad','rad'])
l0=coords.galactic.l.radian
b0=coords.galactic.b.radian
dlddelta=(np.gradient(l0,ddelta))[499]
dbddelta=(np.gradient(b0,ddelta))[499]

u1=np.array([np.cos(cra2_bcenter)*np.cos(cra2_lcenter),np.cos(cra2_bcenter)*np.sin(cra2_lcenter),np.sin(cra2_bcenter)])
u2=np.array([-np.sin(cra2_bcenter)*np.cos(cra2_lcenter)*dbdalpha-np.cos(cra2_bcenter)*np.sin(cra2_lcenter)*dldalpha,-np.sin(cra2_bcenter)*np.sin(cra2_lcenter)*dbdalpha+np.cos(cra2_bcenter)*np.cos(cra2_lcenter)*dldalpha,np.cos(cra2_bcenter)*dbdalpha])
u2=-u2/np.cos(cra2_deccenter)#correction for -cos(dec)
u3=np.array([-np.sin(cra2_bcenter)*np.cos(cra2_lcenter)*dbddelta-np.cos(cra2_bcenter)*np.sin(cra2_lcenter)*dlddelta,-np.sin(cra2_bcenter)*np.sin(cra2_lcenter)*dbddelta+np.cos(cra2_bcenter)*np.cos(cra2_lcenter)*dlddelta,np.cos(cra2_bcenter)*dbddelta])

cra2_r=rsolar+cra2_distance*u1
cra2_rmod=np.sqrt(cra2_r[0]**2+cra2_r[1]**2+cra2_r[2]**2)
####
cra2_data1='/physics2/mgwalker/chains/cra2pmpost_equal_weights.dat'

out1='cra2orbit_commands.tex'
g1=open(out1,'w')

with open(cra2_data1) as f: # read data file
    data=f.readlines()#[15000:15100]

cra2_bigsigma0=[]
cra2_logrs=[]
cra2_bigsigmab=[]
cra2_bigsigmagrad=[]
cra2_gradtheta=[]
cra2_vmean=[]
cra2_vvar=[]
cra2_mualpha=[]
cra2_mudelta=[]
cra2_fehmean=[]
cra2_zvar=[]
cra2_fehgrad=[]
cra2_like=[]

for line in data: # fill arrays
    p=line.split()
    cra2_vmean.append(float(p[4]))
    cra2_vvar.append(float(p[2]))
    cra2_mualpha.append(float(p[6]))
    cra2_mudelta.append(float(p[7]))
    cra2_fehmean.append(float(p[5]))
    cra2_zvar.append(float(p[3]))
    cra2_fehgrad.append(float(p[11]))
    cra2_like.append(float(p[12]))
    cra2_bigsigma0.append(float(p[0]))
    cra2_logrs.append(float(p[1]))
    cra2_bigsigmab.append(float(p[8]))
    cra2_bigsigmagrad.append(float(p[9]))
    cra2_gradtheta.append(float(p[10]))

cra2_vmean=np.array(cra2_vmean)
cra2_vvar=np.array(cra2_vvar)
cra2_mualpha=np.array(cra2_mualpha)
cra2_mudelta=np.array(cra2_mudelta)
cra2_fehmean=np.array(cra2_fehmean)
cra2_zvar=np.array(cra2_zvar)
cra2_fehgrad=np.array(cra2_fehgrad)
cra2_like=np.array(cra2_like)
cra2_bigsigma0=np.array(cra2_bigsigma0)
cra2_logrs=np.array(cra2_logrs)
cra2_bigsigmab=np.array(cra2_bigsigmab)
cra2_bigsigmagrad=np.array(cra2_bigsigmagrad)
cra2_gradtheta=np.array(cra2_gradtheta)

cra2_rs=10.**cra2_logrs
cra2_vdisp=np.sqrt(10.**cra2_vvar)
cra2_fehdisp=np.sqrt(10.**cra2_zvar)
cra2_gradtheta=cra2_gradtheta*180./np.pi

cra2_muwest=-cra2_mualpha/100.*np.cos(cra2_deccenter)#mas/yr
cra2_munorth=cra2_mudelta/100.#mas/yr
#cra2_mualpha=cra2_mualpha-cra2_mualpha-0.181e2
#cra2_mudelta=cra2_mudelta-cra2_mudelta-0.152e2
#cra2_muwest=-cra2_mualpha*np.cos(cra2_deccenter)#mas/yr  use this if plugging in PMs by hand
#cra2_munorth=cra2_mudelta#mas/yr use this if plugging in PMs by hand

cra2_vsys=cra2_vmean#HRF LOS velocity in km/s
cra2_vx=cra2_distance*cra2_muwest*3.09e+16/1000./3600./180.*np.pi/365./24./3600.#km/s
cra2_vy=cra2_distance*cra2_munorth*3.09e+16/1000./3600./180.*np.pi/365./24./3600.#km/s
cra2_v=[]
cra2_vrad=[]
cra2_vtan=[]
cra2_apo=[]
cra2_peri=[]
cra2_ecc=[]
cra2_vesc=[]
for i in range(0,len(cra2_vsys)):
    vec=vsolar+cra2_vsys[i]*u1+cra2_vx[i]*u2+cra2_vy[i]*u3
    mag=np.sqrt(vec[0]**2+vec[1]**2+vec[2]**2)
    rad=np.dot(vec,cra2_r/np.sqrt(cra2_r[0]**2+cra2_r[1]**2+cra2_r[2]**2))
    tan=np.sqrt(mag**2-rad**2)
    cra2_v.append(vec)
    cra2_vrad.append(rad)
    cra2_vtan.append(tan)
    o=Orbit(vxvv=[cra2_rmod,rad,tan],ro=r0,vo=vlsr)
    o1=Orbit(vxvv=[cra2_radegcenter,cra2_decdegcenter,cra2_distance,cra2_mualpha[i]/100.*np.cos(cra2_deccenter),cra2_mudelta[i]/100.,cra2_vmean[i]],radec=True,solarmotion='schoenrich',ro=r0,vo=vlsr)
    ts=np.linspace(0,-10.,10000)*units.Gyr
#    o.integrate(ts,mw)
    o1.integrate(ts,mw)
    cra2_apo.append(o1.rap())
    cra2_peri.append(o1.rperi())
    cra2_ecc.append(o1.e())
    vescape=vesc(MWPotential2014,cra2_rmod*units.kpc)*vlsr
    cra2_vesc.append(mag/vescape)
    print i,o1.rap(),o1.rperi(),o1.e(),mag,rad,tan,mag/vescape
    np.pause()
#    print i,o1.vx(),o1.vy(),o1.vz(),vec[0],vec[1],vec[2]
cra2_v=np.array(cra2_v)
cra2_vrad=np.array(cra2_vrad)
cra2_vtan=np.array(cra2_vtan)
cra2_apo=np.array(cra2_apo)
cra2_peri=np.array(cra2_peri)
cra2_ecc=np.array(cra2_ecc)
cra2_vesc=np.array(cra2_vesc)
bound=np.where(cra2_vesc<=1.)
disrupt=np.where(cra2_peri<30.)

gs=plt.GridSpec(20,20) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
#fig.set_

cra2_statsperi=np.percentile(cra2_peri,[2.5,16.,50.,84.,97.5])
cra2_statsapo=np.percentile(cra2_apo,[2.5,16.,50.,84.,97.5])
cra2_statsvesc=np.percentile(cra2_vesc,[2.5,16.,50.,84.,97.5])

axpm=fig.add_subplot(gs[5:12,0:7])
axorbit=fig.add_subplot(gs[5:12,12:19])
axperihist=fig.add_subplot(gs[5:12,15:17])
axapohist=fig.add_subplot(gs[3:5,12:17])
axmudeltahist=fig.add_subplot(gs[5:12,7:9])
axmualphahist=fig.add_subplot(gs[3:5,0:7])

axpm.set_xlim([-1.5,1.5])
axpm.set_ylim([-1.5,1.5])
axpm.set_xlabel(r'$\mu_{\alpha}$ [mas/year]',fontsize=10)
axpm.set_ylabel(r'$\mu_{\delta}$ [mas/year]',fontsize=10)
axpm.set_xticks([-1,0,1])
axpm.set_xticklabels(['-1','0','1'],fontsize=5)
axpm.set_yticks([-1,0,1])
axpm.set_yticklabels(['-1','0','1'],fontsize=5)
axpm.set_xscale(u'linear')
axpm.set_yscale(u'linear')
axpm.scatter(cra2_mualpha/100.,cra2_mudelta/100.,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='r',rasterized=True)
axpm.scatter(cra2_mualpha[bound]/100.,cra2_mudelta[bound]/100.,s=1,lw=0,edgecolor='none',alpha=0.5,marker='.',color='b',rasterized=True)
axpm.scatter(cra2_mualpha[disrupt]/100.,cra2_mudelta[disrupt]/100.,s=1,lw=0,edgecolor='none',alpha=0.5,marker='.',color='g',rasterized=True)
axpm.scatter([-1000],[-1000],s=10,lw=0,edgecolor='none',alpha=0.7,marker='.',color='r',rasterized=True,label=r'unbound')
axpm.scatter([-1000],[-1000],s=10,lw=0,edgecolor='none',alpha=0.7,marker='.',color='b',rasterized=True,label=r'bound, $r_{\rm peri}\geq 30$ kpc')
axpm.scatter([-1000],[-1000],s=10,lw=0,edgecolor='none',alpha=0.7,marker='.',color='g',rasterized=True,label=r'bound, $r_{\rm peri}< 30$ kpc')
axpm.legend(loc=2,fontsize=5,handlelength=1,scatterpoints=1,borderaxespad=0,shadow=False)

axmudeltahist.xaxis.set_major_formatter(plt.NullFormatter())
axmudeltahist.yaxis.set_major_formatter(plt.NullFormatter())
axmudeltahist.set_xlabel(r'prob.',fontsize=10)
axmudeltahist.set_ylim([-1.5,1.5])
axmudeltahist.set_xscale(u'linear')
axmudeltahist.set_yscale(u'linear')
axmudeltahist.hist(cra2_mudelta/100.,bins=50,range=[-2,2],normed=True,histtype='step',align='mid',rwidth=0,orientation='horizontal',linewidth=0.5,color='k')
axmudeltahist.hist(cra2_mudelta[bound]/100.,bins=50,range=[-2,2],normed=True,histtype='step',align='mid',rwidth=0,orientation='horizontal',linewidth=0.5,color='b',label='bound')
axmudeltahist.hist(cra2_mudelta[disrupt]/100.,bins=50,range=[-2,2],normed=True,histtype='step',align='mid',rwidth=0,orientation='horizontal',linewidth=0.5,color='g',label=r'$r_{\rm peri}<30$ kpc')
axmudeltahist.xaxis.set_major_formatter(plt.NullFormatter())
axmudeltahist.yaxis.set_major_formatter(plt.NullFormatter())

axmualphahist.xaxis.set_major_formatter(plt.NullFormatter())
axmualphahist.yaxis.set_major_formatter(plt.NullFormatter())
axmualphahist.set_ylabel(r'prob.',fontsize=10)
axmualphahist.set_xlim([-1.49,1.5])
axmualphahist.set_xscale(u'linear')
axmualphahist.set_yscale(u'linear')
axmualphahist.hist(cra2_mualpha/100.,bins=50,range=[-2,2],normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',linewidth=0.5,color='k')
axmualphahist.hist(cra2_mualpha[bound]/100.,bins=50,range=[-2,2],normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',linewidth=1,color='b')
axmualphahist.hist(cra2_mualpha[disrupt]/100.,bins=50,range=[-2,2],normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',linewidth=1,color='g')
axmualphahist.xaxis.set_major_formatter(plt.NullFormatter())
axmualphahist.yaxis.set_major_formatter(plt.NullFormatter())

axorbit.set_xlabel(r'$r_{\rm apo}$ [kpc]',fontsize=10)
axorbit.set_ylabel(r'$r_{\rm peri}$ [kpc]',fontsize=10)
axorbit.set_xticks([100,200,300,400])
axorbit.set_yticks([0,50,100])
axorbit.set_xticklabels([100,200,300,400])
axorbit.set_yticklabels([0,50,100])
axorbit.set_xlim([100,450])
axorbit.set_ylim([0,120])
axorbit.set_xscale(u'linear')
axorbit.set_yscale(u'linear')
axorbit.scatter(cra2_apo,cra2_peri,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)
axorbit.scatter(cra2_apo[bound],cra2_peri[bound],s=1,lw=0,edgecolor='none',alpha=0.5,marker='.',color='dodgerblue',rasterized=True)
axorbit.scatter(cra2_apo[disrupt],cra2_peri[disrupt],s=1,lw=0,edgecolor='none',alpha=0.5,marker='.',color='darkred',rasterized=True)

axperihist.xaxis.set_major_formatter(plt.NullFormatter())
axperihist.yaxis.set_major_formatter(plt.NullFormatter())
axperihist.set_xlabel(r'prob.',fontsize=10)
axperihist.set_ylim([0,150])
axperihist.set_xscale(u'linear')
axperihist.set_yscale(u'linear')
axperihist.hist(cra2_peri[bound],bins=50,range=[0,150],normed=True,histtype='step',align='mid',rwidth=0,orientation='horizontal',linewidth=0.5,color='k')
axperihist.xaxis.set_major_formatter(plt.NullFormatter())
axperihist.yaxis.set_major_formatter(plt.NullFormatter())

axapohist.xaxis.set_major_formatter(plt.NullFormatter())
axapohist.yaxis.set_major_formatter(plt.NullFormatter())
axapohist.set_ylabel(r'prob.',fontsize=10)
axapohist.set_xlim([100,500])
axapohist.set_xscale(u'linear')
axapohist.set_yscale(u'linear')
axapohist.hist(cra2_apo[bound],bins=50,range=[100,500],normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',linewidth=0.5,color='k')
axapohist.xaxis.set_major_formatter(plt.NullFormatter())
axapohist.yaxis.set_major_formatter(plt.NullFormatter())


#g1.write(r'\newcommand{\peri}{$'+str(round(cra2_statsperi[2],1))+r'_{'+str(round(cra2_statsperi[1]-cra2_statsperi[2],1))+r'}'+r'^{+'+str(round(cra2_statsperi[3]-cra2_statsperi[2],1))+r'}$'+r'}'+'\n')
#g1.write(r'\newcommand{\apo}{$'+str(round(cra2_statsapo[2],1))+r'_{'+str(round(cra2_statsapo[1]-cra2_statsapo[2],1))+r'}'+r'^{+'+str(round(cra2_statsapo[3]-cra2_statsapo[2],1))+r'}$'+r'}'+'\n')
#g1.write(r'\newcommand{\vesc}{$'+str(round(cra2_statsvesc[2],1))+r'_{'+str(round(cra2_statsvesc[1]-cra2_statsvesc[2],1))+r'}'+r'^{+'+str(round(cra2_statsvesc[3]-cra2_statsvesc[2],1))+r'}$'+r'}'+'\n')

g1.close()
plotfilename='cra2_orbit.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
