import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
import scipy.special as special
import scipy.optimize as optimize
import scipy.integrate as integrate
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.99)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='8')
plt.rc('ytick',labelsize='8')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)
  
data7='/physics2/mgwalker/chains/cra2gradientpost_equal_weights.dat'
data1b='lelli_dsph.dat'
gdagger=1.2e-10
ghat=9.2e-12
g=0.0043# grav constant in galaxy units        
logupsilonstar=np.log10(2.)
siglogupsilonstar=0.25
upsilonstar=10.**logupsilonstar
sigupsilonstar=np.log(10.)*10.**logupsilonstar*siglogupsilonstar

with open(data1b) as f: # read data file
    data=f.readlines()
lelli_dsph=[]
lelli_d=[]
lelli_sigd1=[]
lelli_sigd2=[]
lelli_dhost=[]
lelli_loglum=[]
lelli_sigloglum=[]
lelli_rhalf=[]
lelli_sigrhalf=[]
lelli_ellip=[]
lelli_vdisp=[]
lelli_sigvdisp1=[]
lelli_sigvdisp2=[]
lelli_n=[]
lelli_loggbar=[]
lelli_sigloggbar1=[]
lelli_sigloggbar2=[]
lelli_gobs=[]
lelli_sigloggobs1=[]
lelli_sigloggobs2=[]
lelli_parent=[]
for line in data: # fill arrays
    p=line.split()
    lelli_dsph.append(str(p[0]))
    lelli_d.append(float(p[1]))
    lelli_sigd1.append(float(p[2]))
    lelli_sigd2.append(float(p[3]))
    lelli_dhost.append(float(p[4]))
    lelli_loglum.append(float(p[5]))
    lelli_sigloglum.append(float(p[6]))
    lelli_rhalf.append(float(p[7]))
    lelli_sigrhalf.append(float(p[8]))
    lelli_ellip.append(float(p[9]))
    lelli_vdisp.append(float(p[10]))
    lelli_sigvdisp1.append(float(p[11]))
    lelli_sigvdisp2.append(float(p[12]))
    lelli_n.append(float(p[13]))
    lelli_loggbar.append(float(p[14]))
    lelli_sigloggbar1.append(float(p[15]))
    lelli_sigloggbar2.append(float(p[16]))
    lelli_gobs.append(float(p[17]))
    lelli_sigloggobs1.append(float(p[18]))
    lelli_sigloggobs2.append(float(p[19]))
    lelli_parent.append(str(p[20]))
lelli_dsph=np.array(lelli_dsph)
lelli_d=np.array(lelli_d)
lelli_sigd1=np.array(lelli_sigd1)
lelli_sigd2=np.array(lelli_sigd2)
lelli_dhost=np.array(lelli_dhost)
lelli_loglum=np.array(lelli_loglum)
lelli_sigloglum=np.array(lelli_sigloglum)
lelli_rhalf=np.array(lelli_rhalf)
lelli_sigrhalf=np.array(lelli_sigrhalf)
lelli_ellip=np.array(lelli_ellip)
lelli_vdisp=np.array(lelli_vdisp)
lelli_sigvdisp1=np.array(lelli_sigvdisp1)
lelli_sigvdisp2=np.array(lelli_sigvdisp2)
lelli_n=np.array(lelli_n)
lelli_loggbar=np.array(lelli_loggbar)
lelli_sigloggbar1=np.array(lelli_sigloggbar1)
lelli_sigloggbar2=np.array(lelli_sigloggbar2)
lelli_gobs=np.array(lelli_gobs)
lelli_sigloggobs1=np.array(lelli_sigloggobs1)
lelli_sigloggobs2=np.array(lelli_sigloggobs2)
lelli_parent=np.array(lelli_parent)

lelli_mhost=np.zeros(len(lelli_rhalf))
for i in range(0,len(lelli_rhalf)):
    if lelli_ellip[i] > 0.:
        lelli_rhalf[i]=lelli_rhalf[i]*np.sqrt(1.-lelli_ellip[i])########convert to geometric mean radius
        lelli_sigrhalf[i]=lelli_sigrhalf[i]*np.sqrt(1.-lelli_ellip[i])
        if(lelli_parent[i]=='MW'):
            lelli_mhost[i]=1.e+12
        if(lelli_parent[i]=='M31'):
            lelli_mhost[i]=2.e+12

lelli_rhalf=3./4.*lelli_rhalf
lelli_sigrhalf=3./4.*lelli_sigrhalf
lelli_sigvdisp=(np.abs(lelli_sigvdisp1)+np.abs(lelli_sigvdisp2))/2.

lelli_luminosity=10.**lelli_loglum
lelli_sigluminosity=10.**lelli_loglum*np.log(10.)*lelli_sigloglum

lelli_gbar=g*upsilonstar*lelli_luminosity/(2.**1.5)/lelli_rhalf**2*(1000.**2)/3.09e+16
lelli_gobs=5.*lelli_vdisp**2/2./lelli_rhalf*(1000.**2)/3.09e+16
lelli_siggbar=np.sqrt((lelli_gbar/lelli_luminosity*lelli_sigluminosity)**2+(lelli_gbar/upsilonstar*sigupsilonstar)**2+(2.*lelli_gbar/lelli_rhalf*lelli_sigrhalf)**2)
lelli_siggobs=np.sqrt((2.*lelli_gobs/lelli_vdisp*lelli_sigvdisp)**2+(lelli_gobs/lelli_rhalf*lelli_sigrhalf)**2)

lelli_loggbar=np.log10(lelli_gbar)
lelli_sigloggbar=np.sqrt((lelli_siggbar/lelli_gbar/np.log(10.))**2)
lelli_loggobs=np.log10(lelli_gobs)
lelli_sigloggobs=np.sqrt((lelli_siggobs/lelli_gobs/np.log(10.))**2)

lelli_gtides=g*lelli_mhost*2.*lelli_rhalf/((lelli_dhost*1000.)**3)/((3.09e+13))*(1000.**2)

lelli_deltaloggobs=lelli_loggobs-np.log10(lelli_gbar/(1.-np.exp(-np.sqrt(lelli_gbar/gdagger))))
lelli_sigdeltaloggobs=lelli_sigloggobs
lelli_mw=np.where(lelli_parent=='MW')
lelli_m31=np.where(lelli_parent=='M31')
lelli_mwkeep=np.where((lelli_parent=='MW')&(lelli_siggobs/lelli_gobs<0.5))
lelli_m31keep=np.where((lelli_parent=='M31')&(lelli_siggobs/lelli_gobs<0.5))

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_navarro8_0.2.dat') as f:
    data=f.readlines()
navarro8_02_scatter=[]
navarro8_02_m200=[]
navarro8_02_rh=[]
navarro8_02_lum=[]
navarro8_02_vdisp=[]
navarro8_02_gbar=[]
navarro8_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    navarro8_02_scatter.append(float(p[0]))
    navarro8_02_m200.append(float(p[1]))
    navarro8_02_rh.append(float(p[2]))
    navarro8_02_lum.append(float(p[3]))
    navarro8_02_vdisp.append(float(p[4]))
    navarro8_02_gbar.append(float(p[5]))
    navarro8_02_gobs.append(float(p[6]))
navarro8_02_scatter=np.array(navarro8_02_scatter)
navarro8_02_m200=np.array(navarro8_02_m200)
navarro8_02_rh=np.array(navarro8_02_rh)
navarro8_02_lum=np.array(navarro8_02_lum)
navarro8_02_vdisp=np.array(navarro8_02_vdisp)
navarro8_02_gbar=np.array(navarro8_02_gbar)
navarro8_02_gobs=np.array(navarro8_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_navarro9_0.2.dat') as f:
    data=f.readlines()
navarro9_02_scatter=[]
navarro9_02_m200=[]
navarro9_02_rh=[]
navarro9_02_lum=[]
navarro9_02_vdisp=[]
navarro9_02_gbar=[]
navarro9_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    navarro9_02_scatter.append(float(p[0]))
    navarro9_02_m200.append(float(p[1]))
    navarro9_02_rh.append(float(p[2]))
    navarro9_02_lum.append(float(p[3]))
    navarro9_02_vdisp.append(float(p[4]))
    navarro9_02_gbar.append(float(p[5]))
    navarro9_02_gobs.append(float(p[6]))
navarro9_02_scatter=np.array(navarro9_02_scatter)
navarro9_02_m200=np.array(navarro9_02_m200)
navarro9_02_rh=np.array(navarro9_02_rh)
navarro9_02_lum=np.array(navarro9_02_lum)
navarro9_02_vdisp=np.array(navarro9_02_vdisp)
navarro9_02_gbar=np.array(navarro9_02_gbar)
navarro9_02_gobs=np.array(navarro9_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_navarro10_0.2.dat') as f:
    data=f.readlines()
navarro10_02_scatter=[]
navarro10_02_m200=[]
navarro10_02_rh=[]
navarro10_02_lum=[]
navarro10_02_vdisp=[]
navarro10_02_gbar=[]
navarro10_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    navarro10_02_scatter.append(float(p[0]))
    navarro10_02_m200.append(float(p[1]))
    navarro10_02_rh.append(float(p[2]))
    navarro10_02_lum.append(float(p[3]))
    navarro10_02_vdisp.append(float(p[4]))
    navarro10_02_gbar.append(float(p[5]))
    navarro10_02_gobs.append(float(p[6]))
navarro10_02_scatter=np.array(navarro10_02_scatter)
navarro10_02_m200=np.array(navarro10_02_m200)
navarro10_02_rh=np.array(navarro10_02_rh)
navarro10_02_lum=np.array(navarro10_02_lum)
navarro10_02_vdisp=np.array(navarro10_02_vdisp)
navarro10_02_gbar=np.array(navarro10_02_gbar)
navarro10_02_gobs=np.array(navarro10_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_navarro11_0.2.dat') as f:
    data=f.readlines()
navarro11_02_scatter=[]
navarro11_02_m200=[]
navarro11_02_rh=[]
navarro11_02_lum=[]
navarro11_02_vdisp=[]
navarro11_02_gbar=[]
navarro11_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    navarro11_02_scatter.append(float(p[0]))
    navarro11_02_m200.append(float(p[1]))
    navarro11_02_rh.append(float(p[2]))
    navarro11_02_lum.append(float(p[3]))
    navarro11_02_vdisp.append(float(p[4]))
    navarro11_02_gbar.append(float(p[5]))
    navarro11_02_gobs.append(float(p[6]))
navarro11_02_scatter=np.array(navarro11_02_scatter)
navarro11_02_m200=np.array(navarro11_02_m200)
navarro11_02_rh=np.array(navarro11_02_rh)
navarro11_02_lum=np.array(navarro11_02_lum)
navarro11_02_vdisp=np.array(navarro11_02_vdisp)
navarro11_02_gbar=np.array(navarro11_02_gbar)
navarro11_02_gobs=np.array(navarro11_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_dicintio8_0.2.dat') as f:
    data=f.readlines()
dicintio8_02_scatter=[]
dicintio8_02_m200=[]
dicintio8_02_rh=[]
dicintio8_02_lum=[]
dicintio8_02_vdisp=[]
dicintio8_02_gbar=[]
dicintio8_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    dicintio8_02_scatter.append(float(p[0]))
    dicintio8_02_m200.append(float(p[1]))
    dicintio8_02_rh.append(float(p[2]))
    dicintio8_02_lum.append(float(p[3]))
    dicintio8_02_vdisp.append(float(p[4]))
    dicintio8_02_gbar.append(float(p[5]))
    dicintio8_02_gobs.append(float(p[6]))
dicintio8_02_scatter=np.array(dicintio8_02_scatter)
dicintio8_02_m200=np.array(dicintio8_02_m200)
dicintio8_02_rh=np.array(dicintio8_02_rh)
dicintio8_02_lum=np.array(dicintio8_02_lum)
dicintio8_02_vdisp=np.array(dicintio8_02_vdisp)
dicintio8_02_gbar=np.array(dicintio8_02_gbar)
dicintio8_02_gobs=np.array(dicintio8_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_dicintio9_0.2.dat') as f:
    data=f.readlines()
dicintio9_02_scatter=[]
dicintio9_02_m200=[]
dicintio9_02_rh=[]
dicintio9_02_lum=[]
dicintio9_02_vdisp=[]
dicintio9_02_gbar=[]
dicintio9_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    dicintio9_02_scatter.append(float(p[0]))
    dicintio9_02_m200.append(float(p[1]))
    dicintio9_02_rh.append(float(p[2]))
    dicintio9_02_lum.append(float(p[3]))
    dicintio9_02_vdisp.append(float(p[4]))
    dicintio9_02_gbar.append(float(p[5]))
    dicintio9_02_gobs.append(float(p[6]))
dicintio9_02_scatter=np.array(dicintio9_02_scatter)
dicintio9_02_m200=np.array(dicintio9_02_m200)
dicintio9_02_rh=np.array(dicintio9_02_rh)
dicintio9_02_lum=np.array(dicintio9_02_lum)
dicintio9_02_vdisp=np.array(dicintio9_02_vdisp)
dicintio9_02_gbar=np.array(dicintio9_02_gbar)
dicintio9_02_gobs=np.array(dicintio9_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_dicintio10_0.2.dat') as f:
    data=f.readlines()
dicintio10_02_scatter=[]
dicintio10_02_m200=[]
dicintio10_02_rh=[]
dicintio10_02_lum=[]
dicintio10_02_vdisp=[]
dicintio10_02_gbar=[]
dicintio10_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    dicintio10_02_scatter.append(float(p[0]))
    dicintio10_02_m200.append(float(p[1]))
    dicintio10_02_rh.append(float(p[2]))
    dicintio10_02_lum.append(float(p[3]))
    dicintio10_02_vdisp.append(float(p[4]))
    dicintio10_02_gbar.append(float(p[5]))
    dicintio10_02_gobs.append(float(p[6]))
dicintio10_02_scatter=np.array(dicintio10_02_scatter)
dicintio10_02_m200=np.array(dicintio10_02_m200)
dicintio10_02_rh=np.array(dicintio10_02_rh)
dicintio10_02_lum=np.array(dicintio10_02_lum)
dicintio10_02_vdisp=np.array(dicintio10_02_vdisp)
dicintio10_02_gbar=np.array(dicintio10_02_gbar)
dicintio10_02_gobs=np.array(dicintio10_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_dicintio11_0.2.dat') as f:
    data=f.readlines()
dicintio11_02_scatter=[]
dicintio11_02_m200=[]
dicintio11_02_rh=[]
dicintio11_02_lum=[]
dicintio11_02_vdisp=[]
dicintio11_02_gbar=[]
dicintio11_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    dicintio11_02_scatter.append(float(p[0]))
    dicintio11_02_m200.append(float(p[1]))
    dicintio11_02_rh.append(float(p[2]))
    dicintio11_02_lum.append(float(p[3]))
    dicintio11_02_vdisp.append(float(p[4]))
    dicintio11_02_gbar.append(float(p[5]))
    dicintio11_02_gobs.append(float(p[6]))
dicintio11_02_scatter=np.array(dicintio11_02_scatter)
dicintio11_02_m200=np.array(dicintio11_02_m200)
dicintio11_02_rh=np.array(dicintio11_02_rh)
dicintio11_02_lum=np.array(dicintio11_02_lum)
dicintio11_02_vdisp=np.array(dicintio11_02_vdisp)
dicintio11_02_gbar=np.array(dicintio11_02_gbar)
dicintio11_02_gobs=np.array(dicintio11_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_justin8_0.2.dat') as f:
    data=f.readlines()
justin8_02_scatter=[]
justin8_02_m200=[]
justin8_02_rh=[]
justin8_02_lum=[]
justin8_02_vdisp=[]
justin8_02_gbar=[]
justin8_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    justin8_02_scatter.append(float(p[0]))
    justin8_02_m200.append(float(p[1]))
    justin8_02_rh.append(float(p[2]))
    justin8_02_lum.append(float(p[3]))
    justin8_02_vdisp.append(float(p[4]))
    justin8_02_gbar.append(float(p[5]))
    justin8_02_gobs.append(float(p[6]))
justin8_02_scatter=np.array(justin8_02_scatter)
justin8_02_m200=np.array(justin8_02_m200)
justin8_02_rh=np.array(justin8_02_rh)
justin8_02_lum=np.array(justin8_02_lum)
justin8_02_vdisp=np.array(justin8_02_vdisp)
justin8_02_gbar=np.array(justin8_02_gbar)
justin8_02_gobs=np.array(justin8_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_justin9_0.2.dat') as f:
    data=f.readlines()
justin9_02_scatter=[]
justin9_02_m200=[]
justin9_02_rh=[]
justin9_02_lum=[]
justin9_02_vdisp=[]
justin9_02_gbar=[]
justin9_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    justin9_02_scatter.append(float(p[0]))
    justin9_02_m200.append(float(p[1]))
    justin9_02_rh.append(float(p[2]))
    justin9_02_lum.append(float(p[3]))
    justin9_02_vdisp.append(float(p[4]))
    justin9_02_gbar.append(float(p[5]))
    justin9_02_gobs.append(float(p[6]))
justin9_02_scatter=np.array(justin9_02_scatter)
justin9_02_m200=np.array(justin9_02_m200)
justin9_02_rh=np.array(justin9_02_rh)
justin9_02_lum=np.array(justin9_02_lum)
justin9_02_vdisp=np.array(justin9_02_vdisp)
justin9_02_gbar=np.array(justin9_02_gbar)
justin9_02_gobs=np.array(justin9_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_justin10_0.2.dat') as f:
    data=f.readlines()
justin10_02_scatter=[]
justin10_02_m200=[]
justin10_02_rh=[]
justin10_02_lum=[]
justin10_02_vdisp=[]
justin10_02_gbar=[]
justin10_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    justin10_02_scatter.append(float(p[0]))
    justin10_02_m200.append(float(p[1]))
    justin10_02_rh.append(float(p[2]))
    justin10_02_lum.append(float(p[3]))
    justin10_02_vdisp.append(float(p[4]))
    justin10_02_gbar.append(float(p[5]))
    justin10_02_gobs.append(float(p[6]))
justin10_02_scatter=np.array(justin10_02_scatter)
justin10_02_m200=np.array(justin10_02_m200)
justin10_02_rh=np.array(justin10_02_rh)
justin10_02_lum=np.array(justin10_02_lum)
justin10_02_vdisp=np.array(justin10_02_vdisp)
justin10_02_gbar=np.array(justin10_02_gbar)
justin10_02_gobs=np.array(justin10_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_justin11_0.2.dat') as f:
    data=f.readlines()
justin11_02_scatter=[]
justin11_02_m200=[]
justin11_02_rh=[]
justin11_02_lum=[]
justin11_02_vdisp=[]
justin11_02_gbar=[]
justin11_02_gobs=[]
for line in data: # fill arrays
    p=line.split()
    justin11_02_scatter.append(float(p[0]))
    justin11_02_m200.append(float(p[1]))
    justin11_02_rh.append(float(p[2]))
    justin11_02_lum.append(float(p[3]))
    justin11_02_vdisp.append(float(p[4]))
    justin11_02_gbar.append(float(p[5]))
    justin11_02_gobs.append(float(p[6]))
justin11_02_scatter=np.array(justin11_02_scatter)
justin11_02_m200=np.array(justin11_02_m200)
justin11_02_rh=np.array(justin11_02_rh)
justin11_02_lum=np.array(justin11_02_lum)
justin11_02_vdisp=np.array(justin11_02_vdisp)
justin11_02_gbar=np.array(justin11_02_gbar)
justin11_02_gobs=np.array(justin11_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_navarro8_2.0.dat') as f:
    data=f.readlines()
navarro8_20_scatter=[]
navarro8_20_m200=[]
navarro8_20_rh=[]
navarro8_20_lum=[]
navarro8_20_vdisp=[]
navarro8_20_gbar=[]
navarro8_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    navarro8_20_scatter.append(float(p[0]))
    navarro8_20_m200.append(float(p[1]))
    navarro8_20_rh.append(float(p[2]))
    navarro8_20_lum.append(float(p[3]))
    navarro8_20_vdisp.append(float(p[4]))
    navarro8_20_gbar.append(float(p[5]))
    navarro8_20_gobs.append(float(p[6]))
navarro8_20_scatter=np.array(navarro8_20_scatter)
navarro8_20_m200=np.array(navarro8_20_m200)
navarro8_20_rh=np.array(navarro8_20_rh)
navarro8_20_lum=np.array(navarro8_20_lum)
navarro8_20_vdisp=np.array(navarro8_20_vdisp)
navarro8_20_gbar=np.array(navarro8_20_gbar)
navarro8_20_gobs=np.array(navarro8_20_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_navarro9_2.0.dat') as f:
    data=f.readlines()
navarro9_20_scatter=[]
navarro9_20_m200=[]
navarro9_20_rh=[]
navarro9_20_lum=[]
navarro9_20_vdisp=[]
navarro9_20_gbar=[]
navarro9_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    navarro9_20_scatter.append(float(p[0]))
    navarro9_20_m200.append(float(p[1]))
    navarro9_20_rh.append(float(p[2]))
    navarro9_20_lum.append(float(p[3]))
    navarro9_20_vdisp.append(float(p[4]))
    navarro9_20_gbar.append(float(p[5]))
    navarro9_20_gobs.append(float(p[6]))
navarro9_20_scatter=np.array(navarro9_20_scatter)
navarro9_20_m200=np.array(navarro9_20_m200)
navarro9_20_rh=np.array(navarro9_20_rh)
navarro9_20_lum=np.array(navarro9_20_lum)
navarro9_20_vdisp=np.array(navarro9_20_vdisp)
navarro9_20_gbar=np.array(navarro9_20_gbar)
navarro9_20_gobs=np.array(navarro9_20_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_navarro10_2.0.dat') as f:
    data=f.readlines()
navarro10_20_scatter=[]
navarro10_20_m200=[]
navarro10_20_rh=[]
navarro10_20_lum=[]
navarro10_20_vdisp=[]
navarro10_20_gbar=[]
navarro10_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    navarro10_20_scatter.append(float(p[0]))
    navarro10_20_m200.append(float(p[1]))
    navarro10_20_rh.append(float(p[2]))
    navarro10_20_lum.append(float(p[3]))
    navarro10_20_vdisp.append(float(p[4]))
    navarro10_20_gbar.append(float(p[5]))
    navarro10_20_gobs.append(float(p[6]))
navarro10_20_scatter=np.array(navarro10_20_scatter)
navarro10_20_m200=np.array(navarro10_20_m200)
navarro10_20_rh=np.array(navarro10_20_rh)
navarro10_20_lum=np.array(navarro10_20_lum)
navarro10_20_vdisp=np.array(navarro10_20_vdisp)
navarro10_20_gbar=np.array(navarro10_20_gbar)
navarro10_20_gobs=np.array(navarro10_20_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_navarro11_2.0.dat') as f:
    data=f.readlines()
navarro11_20_scatter=[]
navarro11_20_m200=[]
navarro11_20_rh=[]
navarro11_20_lum=[]
navarro11_20_vdisp=[]
navarro11_20_gbar=[]
navarro11_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    navarro11_20_scatter.append(float(p[0]))
    navarro11_20_m200.append(float(p[1]))
    navarro11_20_rh.append(float(p[2]))
    navarro11_20_lum.append(float(p[3]))
    navarro11_20_vdisp.append(float(p[4]))
    navarro11_20_gbar.append(float(p[5]))
    navarro11_20_gobs.append(float(p[6]))
navarro11_20_scatter=np.array(navarro11_20_scatter)
navarro11_20_m200=np.array(navarro11_20_m200)
navarro11_20_rh=np.array(navarro11_20_rh)
navarro11_20_lum=np.array(navarro11_20_lum)
navarro11_20_vdisp=np.array(navarro11_20_vdisp)
navarro11_20_gbar=np.array(navarro11_20_gbar)
navarro11_20_gobs=np.array(navarro11_20_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_dicintio8_2.0.dat') as f:
    data=f.readlines()
dicintio8_20_scatter=[]
dicintio8_20_m200=[]
dicintio8_20_rh=[]
dicintio8_20_lum=[]
dicintio8_20_vdisp=[]
dicintio8_20_gbar=[]
dicintio8_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    dicintio8_20_scatter.append(float(p[0]))
    dicintio8_20_m200.append(float(p[1]))
    dicintio8_20_rh.append(float(p[2]))
    dicintio8_20_lum.append(float(p[3]))
    dicintio8_20_vdisp.append(float(p[4]))
    dicintio8_20_gbar.append(float(p[5]))
    dicintio8_20_gobs.append(float(p[6]))
dicintio8_20_scatter=np.array(dicintio8_20_scatter)
dicintio8_20_m200=np.array(dicintio8_20_m200)
dicintio8_20_rh=np.array(dicintio8_20_rh)
dicintio8_20_lum=np.array(dicintio8_20_lum)
dicintio8_20_vdisp=np.array(dicintio8_20_vdisp)
dicintio8_20_gbar=np.array(dicintio8_20_gbar)
dicintio8_20_gobs=np.array(dicintio8_20_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_dicintio9_2.0.dat') as f:
    data=f.readlines()
dicintio9_20_scatter=[]
dicintio9_20_m200=[]
dicintio9_20_rh=[]
dicintio9_20_lum=[]
dicintio9_20_vdisp=[]
dicintio9_20_gbar=[]
dicintio9_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    dicintio9_20_scatter.append(float(p[0]))
    dicintio9_20_m200.append(float(p[1]))
    dicintio9_20_rh.append(float(p[2]))
    dicintio9_20_lum.append(float(p[3]))
    dicintio9_20_vdisp.append(float(p[4]))
    dicintio9_20_gbar.append(float(p[5]))
    dicintio9_20_gobs.append(float(p[6]))
dicintio9_20_scatter=np.array(dicintio9_20_scatter)
dicintio9_20_m200=np.array(dicintio9_20_m200)
dicintio9_20_rh=np.array(dicintio9_20_rh)
dicintio9_20_lum=np.array(dicintio9_20_lum)
dicintio9_20_vdisp=np.array(dicintio9_20_vdisp)
dicintio9_20_gbar=np.array(dicintio9_20_gbar)
dicintio9_20_gobs=np.array(dicintio9_20_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_dicintio10_2.0.dat') as f:
    data=f.readlines()
dicintio10_20_scatter=[]
dicintio10_20_m200=[]
dicintio10_20_rh=[]
dicintio10_20_lum=[]
dicintio10_20_vdisp=[]
dicintio10_20_gbar=[]
dicintio10_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    dicintio10_20_scatter.append(float(p[0]))
    dicintio10_20_m200.append(float(p[1]))
    dicintio10_20_rh.append(float(p[2]))
    dicintio10_20_lum.append(float(p[3]))
    dicintio10_20_vdisp.append(float(p[4]))
    dicintio10_20_gbar.append(float(p[5]))
    dicintio10_20_gobs.append(float(p[6]))
dicintio10_20_scatter=np.array(dicintio10_20_scatter)
dicintio10_20_m200=np.array(dicintio10_20_m200)
dicintio10_20_rh=np.array(dicintio10_20_rh)
dicintio10_20_lum=np.array(dicintio10_20_lum)
dicintio10_20_vdisp=np.array(dicintio10_20_vdisp)
dicintio10_20_gbar=np.array(dicintio10_20_gbar)
dicintio10_20_gobs=np.array(dicintio10_20_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_dicintio11_2.0.dat') as f:
    data=f.readlines()
dicintio11_20_scatter=[]
dicintio11_20_m200=[]
dicintio11_20_rh=[]
dicintio11_20_lum=[]
dicintio11_20_vdisp=[]
dicintio11_20_gbar=[]
dicintio11_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    dicintio11_20_scatter.append(float(p[0]))
    dicintio11_20_m200.append(float(p[1]))
    dicintio11_20_rh.append(float(p[2]))
    dicintio11_20_lum.append(float(p[3]))
    dicintio11_20_vdisp.append(float(p[4]))
    dicintio11_20_gbar.append(float(p[5]))
    dicintio11_20_gobs.append(float(p[6]))
dicintio11_20_scatter=np.array(dicintio11_20_scatter)
dicintio11_20_m200=np.array(dicintio11_20_m200)
dicintio11_20_rh=np.array(dicintio11_20_rh)
dicintio11_20_lum=np.array(dicintio11_20_lum)
dicintio11_20_vdisp=np.array(dicintio11_20_vdisp)
dicintio11_20_gbar=np.array(dicintio11_20_gbar)
dicintio11_20_gobs=np.array(dicintio11_02_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_justin8_2.0.dat') as f:
    data=f.readlines()
justin8_20_scatter=[]
justin8_20_m200=[]
justin8_20_rh=[]
justin8_20_lum=[]
justin8_20_vdisp=[]
justin8_20_gbar=[]
justin8_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    justin8_20_scatter.append(float(p[0]))
    justin8_20_m200.append(float(p[1]))
    justin8_20_rh.append(float(p[2]))
    justin8_20_lum.append(float(p[3]))
    justin8_20_vdisp.append(float(p[4]))
    justin8_20_gbar.append(float(p[5]))
    justin8_20_gobs.append(float(p[6]))
justin8_20_scatter=np.array(justin8_20_scatter)
justin8_20_m200=np.array(justin8_20_m200)
justin8_20_rh=np.array(justin8_20_rh)
justin8_20_lum=np.array(justin8_20_lum)
justin8_20_vdisp=np.array(justin8_20_vdisp)
justin8_20_gbar=np.array(justin8_20_gbar)
justin8_20_gobs=np.array(justin8_20_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_justin9_2.0.dat') as f:
    data=f.readlines()
justin9_20_scatter=[]
justin9_20_m200=[]
justin9_20_rh=[]
justin9_20_lum=[]
justin9_20_vdisp=[]
justin9_20_gbar=[]
justin9_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    justin9_20_scatter.append(float(p[0]))
    justin9_20_m200.append(float(p[1]))
    justin9_20_rh.append(float(p[2]))
    justin9_20_lum.append(float(p[3]))
    justin9_20_vdisp.append(float(p[4]))
    justin9_20_gbar.append(float(p[5]))
    justin9_20_gobs.append(float(p[6]))
justin9_20_scatter=np.array(justin9_20_scatter)
justin9_20_m200=np.array(justin9_20_m200)
justin9_20_rh=np.array(justin9_20_rh)
justin9_20_lum=np.array(justin9_20_lum)
justin9_20_vdisp=np.array(justin9_20_vdisp)
justin9_20_gbar=np.array(justin9_20_gbar)
justin9_20_gobs=np.array(justin9_20_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_justin10_2.0.dat') as f:
    data=f.readlines()
justin10_20_scatter=[]
justin10_20_m200=[]
justin10_20_rh=[]
justin10_20_lum=[]
justin10_20_vdisp=[]
justin10_20_gbar=[]
justin10_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    justin10_20_scatter.append(float(p[0]))
    justin10_20_m200.append(float(p[1]))
    justin10_20_rh.append(float(p[2]))
    justin10_20_lum.append(float(p[3]))
    justin10_20_vdisp.append(float(p[4]))
    justin10_20_gbar.append(float(p[5]))
    justin10_20_gobs.append(float(p[6]))
justin10_20_scatter=np.array(justin10_20_scatter)
justin10_20_m200=np.array(justin10_20_m200)
justin10_20_rh=np.array(justin10_20_rh)
justin10_20_lum=np.array(justin10_20_lum)
justin10_20_vdisp=np.array(justin10_20_vdisp)
justin10_20_gbar=np.array(justin10_20_gbar)
justin10_20_gobs=np.array(justin10_20_gobs)

with open('/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_justin11_2.0.dat') as f:
    data=f.readlines()
justin11_20_scatter=[]
justin11_20_m200=[]
justin11_20_rh=[]
justin11_20_lum=[]
justin11_20_vdisp=[]
justin11_20_gbar=[]
justin11_20_gobs=[]
for line in data: # fill arrays
    p=line.split()
    justin11_20_scatter.append(float(p[0]))
    justin11_20_m200.append(float(p[1]))
    justin11_20_rh.append(float(p[2]))
    justin11_20_lum.append(float(p[3]))
    justin11_20_vdisp.append(float(p[4]))
    justin11_20_gbar.append(float(p[5]))
    justin11_20_gobs.append(float(p[6]))
justin11_20_scatter=np.array(justin11_20_scatter)
justin11_20_m200=np.array(justin11_20_m200)
justin11_20_rh=np.array(justin11_20_rh)
justin11_20_lum=np.array(justin11_20_lum)
justin11_20_vdisp=np.array(justin11_20_vdisp)
justin11_20_gbar=np.array(justin11_20_gbar)
justin11_20_gobs=np.array(justin11_20_gobs)

with open(data7) as f: # read data file
    data=f.readlines()
cra2vmean=[]
cra2vvar=[]
cra2fehmean=[]
cra2fehvar=[]
cra2rslight=[]
cra2like=[]
for line in data: # fill arrays
    p=line.split()
    cra2vmean.append(float(p[4]))
    cra2vvar.append(float(p[2]))
    cra2fehmean.append(float(p[5]))
    cra2fehvar.append(float(p[3]))
    cra2rslight.append(float(p[1]))
    cra2like.append(float(p[7]))
cra2vmean=np.array(cra2vmean)
cra2vvar=np.array(cra2vvar)
cra2fehmean=np.array(cra2fehmean)
cra2fehvar=np.array(cra2fehvar)
cra2rslight=np.array(cra2rslight)
cra2like=np.array(cra2like)

cra2rslight=10.**cra2rslight
cra2rslightpc=117000.*np.tan(cra2rslight/60.*np.pi/180.)
cra2vdisp=np.sqrt(10.**cra2vvar)
cra2fehdisp=np.sqrt(10.**cra2fehvar)
cra2_fehdisp=[np.median(cra2fehdisp)]
cra2_sigfehdisp=[np.std(cra2fehdisp)]

cra2_vdisp0=np.array([np.median(cra2vdisp)])
cra2_sigvdisp0=np.array([np.std(cra2vdisp)])
cra2_feh=np.array([np.median(cra2fehmean)])
cra2_sigfeh=np.array([np.std(cra2fehmean)])
cra2_rhalf0=np.median(cra2rslightpc)
cra2_sigrhalf0=np.std(cra2rslightpc)
cra2_rhalf=cra2rslightpc
cra2_absvmag0=-8.2
cra2_sigabsvmag0=0.1
cra2_absvmag=np.random.normal(loc=cra2_absvmag0,scale=cra2_sigabsvmag0,size=len(cra2vdisp))
cra2_rho0=cra2_vdisp0**2/g/cra2_rhalf0**2
cra2_sigrho0=np.sqrt((2.*cra2_vdisp0/cra2_rhalf0**2/g*cra2_sigvdisp0)**2+(2.*cra2_vdisp0**2/g/cra2_rhalf0**3*cra2_sigrhalf0)**2)
cra2_vdisp=cra2vdisp
cra2_luminosity0=10.**((cra2_absvmag0-4.83)/(-2.5))
cra2_luminosity=10.**((cra2_absvmag-4.83)/(-2.5))
cra2_sigluminosity0=np.log(10.)/2.5*10.**((cra2_absvmag0-4.83)/(-2.5))*cra2_sigabsvmag0
cra2_mrhalf0=1./0.0043*cra2_rhalf0*cra2_vdisp0**2
cra2_mrhalf=1./0.0043*cra2_rhalf*cra2vdisp**2
cra2_sigmrhalf0=np.sqrt(2.*cra2_rhalf0/0.0043*cra2_vdisp0*(cra2_sigvdisp0**2)+((1./0.0043*(cra2_vdisp0**2))**2)*cra2_sigrhalf0**2)
cra2_mlratio=cra2_mrhalf/(cra2_luminosity)
cra2_mlratio0=cra2_mrhalf0/cra2_luminosity0
cra2_sigmlratio0=np.sqrt((cra2_sigmrhalf0**2)/(cra2_luminosity0**2)+((cra2_mrhalf0/cra2_luminosity0**2)**2)*cra2_sigluminosity0**2)
cra2_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(cra2_mrhalf))
cra2_upsilonstar=10.**cra2_logupsilonstar
cra2_gbar=g*cra2_upsilonstar*cra2_luminosity/(2.**1.5)/cra2_rhalf**2*(1000.**2)/3.09e+16
cra2_gobs=5.*cra2_vdisp**2/2./cra2_rhalf*(1000.**2)/3.09e+16
cra2_loggbar=np.log10(cra2_gbar)
cra2_loggobs=np.log10(cra2_gobs)
cra2_deltaloggobs=cra2_loggobs-np.log10(cra2_gbar/(1.-np.exp(-np.sqrt(cra2_gbar/gdagger))))

gs=plt.GridSpec(15,15) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
axgobsgbar=fig.add_subplot(gs[0:6,9:15])
axsb2=fig.add_subplot(gs[0:3,0:6])
axrv2=fig.add_subplot(gs[3:6,0:6])

axgobsgbar.set_xlabel(r'$\log_{10}[g_{\rm bar}/(\mathrm{m/s^2})]$',fontsize=11,rotation=0)
axgobsgbar.set_ylabel(r'$\log_{10}[g_{\rm obs}/(\mathrm{m/s^2})]$',fontsize=11,rotation=90)
axgobsgbar.set_xlim([-15,-8])
axgobsgbar.set_ylim([-13,-8])
axgobsgbar.set_xscale(u'linear')
axgobsgbar.set_yscale(u'linear')
axgobsgbar.scatter([np.median(np.log10(cra2_gbar))],[np.median(np.log10(cra2_gobs))],alpha=1,color='y',rasterized=False,edgecolor='none',s=25,zorder=10)
axgobsgbar.scatter(lelli_loggbar[lelli_mwkeep],lelli_loggobs[lelli_mwkeep],alpha=0.75,color='y',rasterized=True,zorder=14,s=20,edgecolor='none')
axgobsgbar.scatter(lelli_loggbar[lelli_m31keep],lelli_loggobs[lelli_m31keep],alpha=0.75,color='y',rasterized=True,zorder=14,s=20,edgecolor='none')
mondgbar=np.linspace(-20.,0.,1000)
mondgbar=10.**mondgbar
mondgobs=mondgbar/(1.-np.exp(-np.sqrt(mondgbar/gdagger)))
mondgobs2=mondgbar/(1.-np.exp(-np.sqrt(mondgbar/gdagger)))+ghat*np.exp(-np.sqrt(mondgbar*gdagger/ghat**2))
axgobsgbar.text(-14,-12.5,'Cra2',fontsize=8,color='k',zorder=40,alpha=1)
axgobsgbar.plot(np.log10(mondgbar),np.log10(mondgobs),lw=1,color='k',zorder=10)
axgobsgbar.plot(np.log10(mondgbar),np.log10(mondgobs2),lw=1,color='k',linestyle='--',zorder=10)
axgobsgbar.plot([-16,-7],[-16,-7],lw=1,color='k',linestyle=':')

alpha_cusp_rhalf1=1.49
beta_cusp_rhalf1=0.35
alpha_cusp_rhalf2=1.22
beta_cusp_rhalf2=0.33
alpha_core_rhalf1=2.91
beta_core_rhalf1=0.15
alpha_core_rhalf2=1.63
beta_core_rhalf2=0.03

alpha_cusp_sigma1=-0.88
beta_cusp_sigma1=0.24
alpha_cusp_sigma2=-0.68
beta_cusp_sigma2=0.26
alpha_core_sigma1=-2.56
beta_core_sigma1=0.05
alpha_core_sigma2=-1.39
beta_core_sigma2=0.29

alpha_cusp_mstar1=3.43
beta_cusp_mstar1=1.86
alpha_cusp_mstar2=3.57
beta_cusp_mstar2=2.06
alpha_core_mstar1=1.43
beta_core_mstar1=0.69
alpha_core_mstar2=0.82
beta_core_mstar2=0.82

def findmassratio(x,stellarmassratio,alpha,beta):
    val=stellarmassratio-(2.**alpha)*(x**beta)/(1.+x)**alpha
    return val


x0=np.median(cra2_gbar)
y0=np.median(cra2_gobs)

stellarmassratio=np.array([0.,1.,2.])
stellarmassratio=1./10.**stellarmassratio
cusp_massratio1=np.zeros(len(stellarmassratio))
cusp_massratio2=np.zeros(len(stellarmassratio))
core_massratio1=np.zeros(len(stellarmassratio))
core_massratio2=np.zeros(len(stellarmassratio))
cusp_stellarmassratio1=stellarmassratio
cusp_stellarmassratio2=stellarmassratio
core_stellarmassratio1=stellarmassratio
core_stellarmassratio2=stellarmassratio


low=1.e-10
high=1.
for i in range(0,len(stellarmassratio)):
    cusp_massratio1[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_cusp_mstar1,beta_cusp_mstar1),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
    cusp_massratio2[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_cusp_mstar2,beta_cusp_mstar2),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
    core_massratio1[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_core_mstar1,beta_core_mstar1),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
    core_massratio2[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_core_mstar2,beta_core_mstar2),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)

###uncomment these lines to examine change in HALO mass.  otherwise, if commented, examine change in STELLAR mass
cusp_massratio1=stellarmassratio#
cusp_massratio2=stellarmassratio#
core_massratio1=stellarmassratio#
core_massratio2=stellarmassratio#
cusp_stellarmassratio1=(2.**alpha_cusp_mstar1)*(cusp_massratio1**beta_cusp_mstar1)/(1.+cusp_massratio1)**alpha_cusp_mstar1#
cusp_stellarmassratio2=(2.**alpha_cusp_mstar2)*(cusp_massratio2**beta_cusp_mstar2)/(1.+cusp_massratio2)**alpha_cusp_mstar2#
core_stellarmassratio1=(2.**alpha_core_mstar1)*(core_massratio1**beta_core_mstar1)/(1.+core_massratio1)**alpha_core_mstar1#
core_stellarmassratio2=(2.**alpha_core_mstar2)*(core_massratio2**beta_core_mstar2)/(1.+core_massratio2)**alpha_core_mstar2#
#####

cusp_rhalfratio1=(2.**alpha_cusp_rhalf1)*(cusp_massratio1**beta_cusp_rhalf1)/(1.+cusp_massratio1)**alpha_cusp_rhalf1
cusp_sigmaratio1=(2.**alpha_cusp_sigma1)*(cusp_massratio1**beta_cusp_sigma1)/(1.+cusp_massratio1)**alpha_cusp_sigma1
cusp_gbarratio1=cusp_stellarmassratio1/cusp_rhalfratio1**2
cusp_gobsratio1=cusp_massratio1/cusp_rhalfratio1**2
cusp_rhalfratio2=(2.**alpha_cusp_rhalf2)*(cusp_massratio2**beta_cusp_rhalf2)/(1.+cusp_massratio2)**alpha_cusp_rhalf2
cusp_sigmaratio2=(2.**alpha_cusp_sigma2)*(cusp_massratio2**beta_cusp_sigma2)/(1.+cusp_massratio2)**alpha_cusp_sigma2
cusp_gbarratio2=cusp_stellarmassratio2/cusp_rhalfratio2**2
cusp_gobsratio2=cusp_massratio2/cusp_rhalfratio2**2
core_rhalfratio1=(2.**alpha_core_rhalf1)*(core_massratio1**beta_core_rhalf1)/(1.+core_massratio1)**alpha_core_rhalf1
core_sigmaratio1=(2.**alpha_core_sigma1)*(core_massratio1**beta_core_sigma1)/(1.+core_massratio1)**alpha_core_sigma1
core_gbarratio1=core_stellarmassratio1/core_rhalfratio1**2
core_gobsratio1=core_massratio1/core_rhalfratio1**2
core_rhalfratio2=(2.**alpha_core_rhalf2)*(core_massratio2**beta_core_rhalf2)/(1.+core_massratio2)**alpha_core_rhalf2
core_sigmaratio2=(2.**alpha_core_sigma2)*(core_massratio2**beta_core_sigma2)/(1.+core_massratio2)**alpha_core_sigma2
core_gbarratio2=core_stellarmassratio2/core_rhalfratio2**2
core_gobsratio2=core_massratio2/core_rhalfratio2**2

#initial conditions for progenitor
cusp1_gbar0=np.median(cra2_gbar)/cusp_gbarratio1
cusp1_gobs0=np.median(cra2_gobs)/cusp_gobsratio1
cusp2_gbar0=np.array([4.e-9,4.e-9,4.e-9])#np.median(cra2_gbar)/cusp_gbarratio2
cusp2_gobs0=np.array([6.e-12,6.e-12,6.e-12])#np.median(cra2_gobs)/cusp_gobsratio2
core1_gbar0=np.median(cra2_gbar)/core_gbarratio1
core1_gobs0=np.median(cra2_gobs)/core_gobsratio1
core2_gbar0=np.array([5.e-9,5.e-9,5.e-9])#np.median(cra2_gbar)/core_gbarratio2
core2_gobs0=np.array([7.e-10,7.e-10,7.e-10])#np.median(cra2_gobs)/core_gobsratio2

cusp1_stellarmass0=np.median(cra2_luminosity*upsilonstar)/cusp_stellarmassratio1
cusp1_rhalf0=np.median(cra2_rhalf)/cusp_rhalfratio1
cusp2_stellarmass0=np.array([10.**10,10.**10,10.**10])#np.median(cra2_luminosity*upsilonstar)/cusp_stellarmassratio2
cusp2_rhalf0=np.median(cra2_rhalf)/cusp_rhalfratio2
cusp2_rhalf0=np.array([10.**1.6,10.**1.6,10.**1.6])#np.median(cra2_rhalf)/cusp_rhalfratio2
core1_stellarmass0=np.median(cra2_luminosity*upsilonstar)/core_stellarmassratio1
core1_rhalf0=np.median(cra2_rhalf)/core_rhalfratio1
core2_stellarmass0=np.array([10.**8.5,10.**8.5,10.**8.5])#np.median(cra2_luminosity*upsilonstar)/core_stellarmassratio2
core2_rhalf0=np.array([10.**1.2,10.**1.2,10.**1.2])#np.median(cra2_rhalf)/core_rhalfratio2
cusp1_sigma0=np.median(cra2_vdisp)/cusp_sigmaratio1
cusp2_sigma0=np.array([10.**2.6,10.**2.6,10.**2.6])#np.median(cra2_vdisp)/cusp_sigmaratio2
core1_sigma0=np.median(cra2_vdisp)/core_sigmaratio1
core2_sigma0=np.array([10.**2.5,10.**2.5,10.**2.5])#np.median(cra2_vdisp)/core_sigmaratio2

axgobsgbar.scatter(np.log10(cusp2_gbar0[range(1,len(cusp2_gbar0))]),np.log10(cusp2_gobs0[range(1,len(cusp2_gbar0))]),marker='.',color='k',s=15,zorder=10)
axgobsgbar.scatter(np.log10(core2_gbar0[range(1,len(core2_gbar0))]),np.log10(core2_gobs0[range(1,len(core2_gbar0))]),marker='.',color='r',s=15,zorder=10)

for i in range(0,len(cusp1_gbar0)):
    x=np.linspace(1.,cusp_massratio1[i],100)
    cusp_rhalf1=2.**alpha_cusp_rhalf1*x**beta_cusp_rhalf1/(1.+x)**alpha_cusp_rhalf1
    cusp_mstar1=2.**alpha_cusp_mstar1*x**beta_cusp_mstar1/(1.+x)**alpha_cusp_mstar1
    cusp_sigma1=2.**alpha_cusp_sigma1*x**beta_cusp_sigma1/(1.+x)**alpha_cusp_sigma1
    cusp_gbar1=cusp1_gbar0[i]*cusp_mstar1/cusp_rhalf1**2
    cusp_gobs1=cusp1_gobs0[i]*x/cusp_rhalf1**2
#    axgobsgbar.plot(np.log10(cusp_gbar1),np.log10(cusp_gobs1),color='k',lw=0.5)
for i in range(1,len(cusp2_gbar0)):
    x=np.linspace(1.,cusp_massratio2[i],100)
    cusp_rhalf2=2.**alpha_cusp_rhalf2*x**beta_cusp_rhalf2/(1.+x)**alpha_cusp_rhalf2
    cusp_mstar2=2.**alpha_cusp_mstar2*x**beta_cusp_mstar2/(1.+x)**alpha_cusp_mstar2
    cusp_sigma2=2.**alpha_cusp_sigma2*x**beta_cusp_sigma2/(1.+x)**alpha_cusp_sigma2
    cusp_gbar2=cusp2_gbar0[i]*cusp_mstar2/cusp_rhalf2**2
    cusp_gobs2=cusp2_gobs0[i]*x/cusp_rhalf2**2
    axgobsgbar.plot(np.log10(cusp_gbar2),np.log10(cusp_gobs2),color='k',lw=0.5)
    axgobsgbar.scatter(np.log10(cusp_gbar2[len(cusp_gbar2)-1]),np.log10(cusp_gobs2[len(cusp_gobs2)-1]),marker='.',color='k',s=20,facecolor='none')
    if(i==len(cusp2_gbar0)-1):
        axgobsgbar.arrow(np.log10(cusp_gbar2[len(cusp_gbar2)-1]),np.log10(cusp_gobs2[len(cusp_gobs2)-1]),-0.5,-0.1,head_width=0.2,head_length=0.2,fc='k',ec='k',lw=0.5)
        axrv2.arrow(np.log10(cusp_rhalf2[len(cusp_rhalf2)-1]*cusp2_rhalf0[i]),np.log10(cusp_sigma2[len(cusp_sigma2)-1]*cusp2_sigma0[i]),-0.15,-0.1,head_width=0.1,head_length=0.1,fc='k',ec='k',lw=0.5)
        axsb2.arrow(np.log10(cusp_rhalf2[len(cusp_rhalf2)-1]*cusp2_rhalf0[i]),np.log10(cusp_mstar2[len(cusp_mstar2)-1]*cusp2_stellarmass0[i]),-0.1,-0.5,head_width=0.1,head_length=0.4,fc='k',ec='k',lw=0.5)

    axsb2.plot(np.log10(cusp2_rhalf0[i]*cusp_rhalf2),np.log10(cusp2_stellarmass0[i]*cusp_mstar2),color='k',lw=0.5)
    axsb2.scatter(np.log10(cusp_rhalf2[len(cusp_rhalf2)-1]*cusp2_rhalf0[i]),np.log10(cusp_mstar2[len(cusp_mstar2)-1]*cusp2_stellarmass0[i]),marker='.',color='k',s=10,facecolor='none')
    axrv2.plot(np.log10(cusp2_rhalf0[i]*cusp_rhalf2),np.log10(cusp2_sigma0[i]*cusp_sigma2),color='k',lw=0.5)
    axrv2.scatter(np.log10(cusp_rhalf2[len(cusp_rhalf2)-1]*cusp2_rhalf0[i]),np.log10(cusp_sigma2[len(cusp_sigma2)-1]*cusp2_sigma0[i]),marker='.',color='k',s=10,facecolor='none')

for i in range(0,len(core1_gbar0)):
    x=np.linspace(1.,core_massratio1[i],100)
    core_rhalf1=2.**alpha_core_rhalf1*x**beta_core_rhalf1/(1.+x)**alpha_core_rhalf1
    core_mstar1=2.**alpha_core_mstar1*x**beta_core_mstar1/(1.+x)**alpha_core_mstar1
    core_sigma1=2.**alpha_core_sigma1*x**beta_core_sigma1/(1.+x)**alpha_core_sigma1
    core_gbar1=core1_gbar0[i]*core_mstar1/core_rhalf1**2
    core_gobs1=core1_gobs0[i]*x/core_rhalf1**2
#    axgobsgbar.plot(np.log10(core_gbar1),np.log10(core_gobs1),color='r',lw=0.5)
#    axsb2.plot(np.log10(core1_rhalf0[i]*core_rhalf1),np.log10(core1_stellarmass0[i]*core_mstar1),color='r',lw=0.5)
#    axrv2.plot(np.log10(core1_rhalf0[i]*core_rhalf1),np.log10(core1_sigma0[i]*core_sigma1),color='r',lw=0.5)
for i in range(1,len(core2_gbar0)):
    x=np.linspace(1.,core_massratio2[i],100)
    core_rhalf2=2.**alpha_core_rhalf2*x**beta_core_rhalf2/(1.+x)**alpha_core_rhalf2
    core_mstar2=2.**alpha_core_mstar2*x**beta_core_mstar2/(1.+x)**alpha_core_mstar2
    core_sigma2=2.**alpha_core_sigma2*x**beta_core_sigma2/(1.+x)**alpha_core_sigma2
    core_gbar2=core2_gbar0[i]*core_mstar2/core_rhalf2**2
    core_gobs2=core2_gobs0[i]*x/core_rhalf2**2
    axgobsgbar.scatter(np.log10(core_gbar2[len(core_gbar2)-1]),np.log10(core_gobs2[len(core_gobs2)-1]),marker='.',color='r',s=20,facecolor='none')
    axgobsgbar.plot(np.log10(core_gbar2),np.log10(core_gobs2),color='r',lw=0.5,linestyle='-')
    if(i==len(core2_gbar0)-1):
        axgobsgbar.arrow(np.log10(core_gbar2[len(core_gbar2)-1]),np.log10(core_gobs2[len(core_gobs2)-1]),-0.2,-0.25,head_width=0.2,head_length=0.2,fc='r',ec='r',lw=0.5)
        axrv2.arrow(np.log10(core_rhalf2[len(core_rhalf2)-1]*core2_rhalf0[i]),np.log10(core_sigma2[len(core_sigma2)-1]*core2_sigma0[i]),0.0,-0.2,head_width=0.1,head_length=0.1,fc='r',ec='r',lw=0.5)
        axsb2.arrow(np.log10(core_rhalf2[len(core_rhalf2)-1]*core2_rhalf0[i]),np.log10(core_mstar2[len(core_mstar2)-1]*core2_stellarmass0[i]),0.02,-0.75,head_width=0.1,head_length=0.4,fc='r',ec='r',lw=0.5)

    axsb2.plot(np.log10(core2_rhalf0[i]*core_rhalf2),np.log10(core2_stellarmass0[i]*core_mstar2),color='r',lw=0.5,linestyle='-')
    axsb2.scatter(np.log10(core_rhalf2[len(core_rhalf2)-1]*core2_rhalf0[i]),np.log10(core_mstar2[len(core_mstar2)-1]*core2_stellarmass0[i]),marker='.',color='r',s=10,facecolor='none')
    axrv2.plot(np.log10(core2_rhalf0[i]*core_rhalf2),np.log10(core2_sigma0[i]*core_sigma2),color='r',lw=0.5,linestyle='-')
    axrv2.scatter(np.log10(core_rhalf2[len(core_rhalf2)-1]*core2_rhalf0[i]),np.log10(core_sigma2[len(core_sigma2)-1]*core2_sigma0[i]),marker='.',color='r',s=10,facecolor='none')

#axgobsgbar.scatter(justin8_02_gbar,justin8_02_gobs,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axgobsgbar.scatter(dicintio8_02_gbar,dicintio8_02_gobs,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axgobsgbar.scatter(navarro8_02_gbar,navarro8_02_gobs,color='k',s=1,marker='.',alpha=0.2,rasterized=True)
#axgobsgbar.scatter(justin9_02_gbar,justin9_02_gobs,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axgobsgbar.scatter(dicintio9_02_gbar,dicintio9_02_gobs,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axgobsgbar.scatter(navarro9_02_gbar,navarro9_02_gobs,color='k',s=1,marker='.',alpha=0.2,rasterized=True)
#axgobsgbar.scatter(justin10_02_gbar,justin10_02_gobs,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axgobsgbar.scatter(dicintio10_02_gbar,dicintio10_02_gobs,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axgobsgbar.scatter(navarro10_02_gbar,navarro10_02_gobs,color='k',s=1,marker='.',alpha=0.2,rasterized=True)
#axgobsgbar.scatter(justin11_02_gbar,justin11_02_gobs,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axgobsgbar.scatter(dicintio11_02_gbar,dicintio11_02_gobs,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axgobsgbar.scatter(navarro11_02_gbar,navarro11_02_gobs,color='k',s=1,marker='.',alpha=0.2,rasterized=True)

axgobsgbar.scatter(navarro8_02_gbar[0],navarro8_02_gobs[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axgobsgbar.scatter(navarro9_02_gbar[0],navarro9_02_gobs[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axgobsgbar.scatter(navarro10_02_gbar[0],navarro10_02_gobs[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axgobsgbar.scatter(navarro11_02_gbar[0],navarro11_02_gobs[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axgobsgbar.scatter(dicintio8_02_gbar[0],dicintio8_02_gobs[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
axgobsgbar.scatter(dicintio9_02_gbar[0],dicintio9_02_gobs[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
axgobsgbar.scatter(dicintio10_02_gbar[0],dicintio10_02_gobs[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
axgobsgbar.scatter(dicintio11_02_gbar[0],dicintio11_02_gobs[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
#axgobsgbar.scatter(justin8_02_gbar[0],justin8_02_gobs[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)
#axgobsgbar.scatter(justin9_02_gbar[0],justin9_02_gobs[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)
#axgobsgbar.scatter(justin10_02_gbar[0],justin10_02_gobs[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)
#axgobsgbar.scatter(justin11_02_gbar[0],justin11_02_gobs[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)

axsb2.xaxis.set_major_formatter(plt.NullFormatter())
axsb2.set_ylabel(r'$\log_{10}[L_{V}/L_{V_{\odot}}]$',fontsize=9,rotation=90)
axsb2.set_ylim([2.5,11])
axsb2.set_xlim([1.,4.])
axsb2.set_xscale(u'linear')
axsb2.set_yscale(u'linear')

axsb2.scatter(np.log10(np.median(cra2_rhalf)),np.log10(np.median(cra2_luminosity)),alpha=1,color='y',rasterized=False,edgecolor='none',s=25,marker='o',zorder=10)
axsb2.scatter(np.log10(lelli_rhalf[lelli_mwkeep]),np.log10(lelli_luminosity[lelli_mwkeep]),alpha=0.75,color='y',rasterized=True,zorder=14,s=20,edgecolor='none')
axsb2.scatter(np.log10(lelli_rhalf[lelli_m31keep]),np.log10(lelli_luminosity[lelli_m31keep]),alpha=0.75,color='y',rasterized=True,zorder=14,s=20,edgecolor='none')


#axsb2.scatter(justin8_02_rh,justin8_02_lum,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axsb2.scatter(dicintio8_02_rh,dicintio8_02_lum,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axsb2.scatter(navarro8_02_rh,navarro8_02_lum,color='k',s=1,marker='.',alpha=0.2,rasterized=True)
#axsb2.scatter(justin9_02_rh,justin9_02_lum,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axsb2.scatter(dicintio9_02_rh,dicintio9_02_lum,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axsb2.scatter(navarro9_02_rh,navarro9_02_lum,color='k',s=1,marker='.',alpha=0.2,rasterized=True)
#axsb2.scatter(justin10_02_rh,justin10_02_lum,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axsb2.scatter(dicintio10_02_rh,dicintio10_02_lum,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axsb2.scatter(navarro10_02_rh,navarro10_02_lum,color='k',s=1,marker='.',alpha=0.2,rasterized=True)
#axsb2.scatter(justin11_02_rh,justin11_02_lum,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axsb2.scatter(dicintio11_02_rh,dicintio11_02_lum,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axsb2.scatter(navarro11_02_rh,navarro11_02_lum,color='k',s=1,marker='.',alpha=0.2,rasterized=True)

axsb2.scatter(navarro8_02_rh[0],navarro8_02_lum[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axsb2.scatter(navarro9_02_rh[0],navarro9_02_lum[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axsb2.scatter(navarro10_02_rh[0],navarro10_02_lum[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axsb2.scatter(navarro11_02_rh[0],navarro11_02_lum[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axsb2.scatter(dicintio8_02_rh[0],dicintio8_02_lum[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
axsb2.scatter(dicintio9_02_rh[0],dicintio9_02_lum[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
axsb2.scatter(dicintio10_02_rh[0],dicintio10_02_lum[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
axsb2.scatter(dicintio11_02_rh[0],dicintio11_02_lum[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
#axsb2.scatter(justin8_02_rh[0],justin8_02_lum[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)
#axsb2.scatter(justin9_02_rh[0],justin9_02_lum[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)
#axsb2.scatter(justin10_02_rh[0],justin10_02_lum[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)
#axsb2.scatter(justin11_02_rh[0],justin11_02_lum[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)

axsb2.scatter(np.log10(cusp2_rhalf0[range(1,len(cusp2_stellarmass0))]),np.log10(cusp2_stellarmass0[range(1,len(cusp2_stellarmass0))]),marker='.',color='k',s=10,zorder=10)
axsb2.scatter(np.log10(core2_rhalf0[range(1,len(core2_stellarmass0))]),np.log10(core2_stellarmass0[range(1,len(core2_stellarmass0))]),marker='.',color='r',s=10,zorder=10)

axsb2.text(3.2,4.5,'Cra2',fontsize=7,color='k',zorder=10)
axgobsgbar.scatter([1.e-100,1.e-100],[1.e-100,1.e-90],marker='.',color='k',label='NFW (X = no scatter)',s=10)
axgobsgbar.scatter([1.e-100,1.e-100],[1.e-100,1.e-90],marker='.',color='r',label='gNFW (O = no scatter)',s=10)
#axgobsgbar.scatter([1.e-100,1.e-100],[1.e-100,1.e-90],marker='.',color='b',label='core (+)',s=10)
axgobsgbar.scatter([1.e-100,1.e-100],[1.e-100,1.e-90],marker='.',color='y',label='observed',s=25,alpha=0.75)
#axgobsgbar.plot([1.e-100,1.e-100],[1.e-100,1.e-90],marker='.',color='k',label='mass loss (NFW)',lw=1)
#axgobsgbar.plot([1.e-100,1.e-100],[1.e-100,1.e-90],marker='.',color='r',label='mass loss (core)',lw=1)
#axrv2.scatter([1.e-100,1.e-100],[1.e-100,1.e-90],marker='.',color='b',label='core (+)',s=10)

axgobsgbar.legend(loc=2,fontsize=6,handlelength=1,numpoints=1,scatterpoints=1,shadow=False,borderaxespad=0)
axsb2.xaxis.set_major_formatter(plt.NullFormatter())

axrv2.set_ylabel(r'$\log_{10}[\sigma/(\mathrm{km/s})]$',fontsize=9,rotation=90)
axrv2.set_xlabel(r'$\log_{10}[R_{\rm half}/\mathrm{pc}]$',fontsize=11,rotation=0)
axrv2.set_ylim([0,2.95])
axrv2.set_xlim([1.,4.])
axrv2.set_xscale(u'linear')
axrv2.set_yscale(u'linear')
axrv2.scatter(np.log10(np.median(cra2_rhalf)),np.log10(np.median(cra2_vdisp)),alpha=1,color='y',rasterized=False,edgecolor='none',s=25,marker='o',zorder=10)
axrv2.text(3.1,0.2,'Cra2',fontsize=7)
axrv2.scatter(np.log10(lelli_rhalf[lelli_mwkeep]),np.log10(lelli_vdisp[lelli_mwkeep]),alpha=0.75,color='y',rasterized=True,zorder=14,s=20,edgecolor='none')
axrv2.scatter(np.log10(lelli_rhalf[lelli_m31keep]),np.log10(lelli_vdisp[lelli_m31keep]),alpha=0.75,color='y',rasterized=True,zorder=14,s=20,edgecolor='none')

#axrv2.scatter(justin8_02_rh,justin8_02_vdisp,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axrv2.scatter(dicintio8_02_rh,dicintio8_02_vdisp,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axrv2.scatter(navarro8_02_rh,navarro8_02_vdisp,color='k',s=1,marker='.',alpha=0.2,rasterized=True)
#axrv2.scatter(justin9_02_rh,justin9_02_vdisp,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axrv2.scatter(dicintio9_02_rh,dicintio9_02_vdisp,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axrv2.scatter(navarro9_02_rh,navarro9_02_vdisp,color='k',s=1,marker='.',alpha=0.2,rasterized=True)
#axrv2.scatter(justin10_02_rh,justin10_02_vdisp,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axrv2.scatter(dicintio10_02_rh,dicintio10_02_vdisp,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axrv2.scatter(navarro10_02_rh,navarro10_02_vdisp,color='k',s=1,marker='.',alpha=0.2,rasterized=True)
#axrv2.scatter(justin11_02_rh,justin11_02_vdisp,color='b',s=1,marker='.',alpha=0.2,rasterized=True)
axrv2.scatter(dicintio11_02_rh,dicintio11_02_vdisp,color='r',s=1,marker='.',alpha=0.2,rasterized=True)
axrv2.scatter(navarro11_02_rh,navarro11_02_vdisp,color='k',s=1,marker='.',alpha=0.2,rasterized=True)

axrv2.scatter(navarro8_02_rh[0],navarro8_02_vdisp[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axrv2.scatter(navarro9_02_rh[0],navarro9_02_vdisp[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axrv2.scatter(navarro10_02_rh[0],navarro10_02_vdisp[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axrv2.scatter(navarro11_02_rh[0],navarro11_02_vdisp[0],color='white',alpha=1,marker='x',s=25,rasterized=True,zorder=15)
axrv2.scatter(dicintio8_02_rh[0],dicintio8_02_vdisp[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
axrv2.scatter(dicintio9_02_rh[0],dicintio9_02_vdisp[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
axrv2.scatter(dicintio10_02_rh[0],dicintio10_02_vdisp[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
axrv2.scatter(dicintio11_02_rh[0],dicintio11_02_vdisp[0],color='white',alpha=1,marker='o',s=25,rasterized=True,facecolor='none',zorder=15)
#axrv2.scatter(justin8_02_rh[0],justin8_02_vdisp[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)
#axrv2.scatter(justin9_02_rh[0],justin9_02_vdisp[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)
#axrv2.scatter(justin10_02_rh[0],justin10_02_vdisp[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)
#axrv2.scatter(justin11_02_rh[0],justin11_02_vdisp[0],color='white',alpha=1,marker='+',s=25,rasterized=True,zorder=15)

axrv2.scatter(np.log10(cusp2_rhalf0[range(1,len(cusp2_stellarmass0))]),np.log10(cusp2_sigma0[range(1,len(cusp2_stellarmass0))]),marker='.',color='k',s=10,zorder=10)
axrv2.scatter(np.log10(core2_rhalf0[range(1,len(core2_stellarmass0))]),np.log10(core2_sigma0[range(1,len(core2_stellarmass0))]),marker='.',color='r',s=10,zorder=10)

plotfilename='cra2_gobsgbar_tracks02.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
