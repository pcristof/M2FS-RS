import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import scipy.integrate as integrate
import scipy.special as special
import scipy.optimize as optimize
from scipy.integrate import quad
import random
import matplotlib.lines as lines
from matplotlib.colors import LogNorm
from matplotlib.pyplot import *
from scipy import integrate
np.set_printoptions(threshold='nan')
import sys

gs=plt.GridSpec(2,2) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
#fig.set_
ax0_0=fig.add_subplot(gs[0:6,0:6])

r_field=40.# radius of circular region of interest (ROI)
r_integration=35.#radius of thin ring in integral
y_edge=-20.#y coordinate of edge of survey footprint (assumed to be parallel with x axis)
dx=-0.001218957426914#x coordinate of centroid
dy=10.693544735717278# y coordinate of centroid
d=np.sqrt(dx**2+dy**2)#distance between centroid and center of ROI

phi=np.arccos((d**2+r_integration**2-r_field**2)/2./r_integration/d)#law of cosines to get opening angle of wedge 
eta_min1=phi+np.pi/2.-np.arctan2(dy,dx)-2.*phi#position angle of lower bound of wedge1
eta_max1=phi+np.pi/2.-np.arctan2(dy,dx)#position angle of upper bound of wedge1
eta_min2=np.arccos(np.abs(y_edge-dy)/r_integration)#position angle of lower bound of wedge2 
eta_max2=-1.*np.arccos(np.abs(y_edge-dy)/r_integration)#position angle of upper bound of wedge2

##################################
#transform position angles above into azimuthal angle that has theta=0 for +x direction, theta=pi/2 for +y direction
theta_max1=3.*np.pi/2.-eta_min1
theta_min1=3.*np.pi/2.-eta_max1
theta_max2=3.*np.pi/2.-eta_min2
theta_min2=3.*np.pi/2.-eta_max2
##################################

##################################
#ensure that theta values are between 0 and 2pi
if(theta_max1 <0.):
    theta_max1=theta_max1+2.*np.pi
if(theta_min1 <0.):
    theta_min1=theta_min1+2.*np.pi
if(theta_max2 <0.):
    theta_max2=theta_max2+2.*np.pi
if(theta_min2 <0.):
    theta_min2=theta_min2+2.*np.pi

if(theta_max1 >2.*np.pi):
    theta_max1=theta_max1-2.*np.pi
if(theta_min1 >2.*np.pi):
    theta_min1=theta_min1-2.*np.pi
if(theta_max2 >2.*np.pi):
    theta_max2=theta_max2-2.*np.pi
if(theta_min2 >2.*np.pi):
    theta_min2=theta_min2-2.*np.pi
##################################

theta_final_min=0.#overall lower limit on theta
theta_final_max=2.*np.pi#overall upper limit on theta

split=0
found=0
if(dy-y_edge < r_integration):
    theta_final_min=theta_min2
    theta_final_max=theta_max2
    
    if(r_integration+d > r_field):
        if((theta_max2 <= theta_min2) and (theta_min2 <= theta_min1) and (theta_max1 <= theta_max1)):
            theta_final_min=theta_min1
            theta_final_max=theta_max1
            found=1
        if((theta_max2 <= theta_min2) and (theta_min2 <= theta_max1) and (theta_max1 <= theta_min1)):
            theta_final_min=theta_min1
            theta_final_max=theta_max2
            found=1
        if((theta_max2 <= theta_min1) and (theta_min1 <= theta_max1) and (theta_max1 <= theta_min2)):
            theta_final_min=theta_min1
            theta_final_max=theta_min1
            found=1
        if((theta_max2 <= theta_min1) and (theta_min1 <= theta_min2) and (theta_min2 <= theta_max1)):
            theta_final_min=theta_min2
            theta_final_max=theta_max1
            found=1
        if((theta_max1 <= theta_max2) and (theta_max2 <= theta_min2) and (theta_min2 <= theta_min1)):
            theta_final_min=theta_min1
            theta_final_max=theta_max1
            found=1
        if((theta_min1 <= theta_max1) and (theta_max1 <= theta_max2) and (theta_max2 <= theta_min2)):
            theta_final_min=theta_min1
            theta_final_max=theta_max1
            found=1
        if((theta_min1 <= theta_max2) and (theta_max2 <= theta_min2) and (theta_min2 <= theta_max1)):
            theta_final_min=theta_min1
            theta_final_max=theta_max2
            found=1
        if((theta_min1 <= theta_max2) and (theta_max2 <= theta_max1) and (theta_max1 <= theta_min2)):
            theta_final_min=theta_min1
            theta_final_max=theta_max2
            found=1
        if((theta_max1 <= theta_max2) and (theta_max2 <= theta_min1) and (theta_min1 <= theta_min2)):
            theta_final_min=theta_min2
            theta_final_max=theta_max1
            found=1
        if((theta_max2 <= theta_max1) and (theta_max1 <= theta_min2) and (theta_min2 <= theta_min1)):
            found=1
        if((theta_max2 <= theta_max1) and (theta_max1 <= theta_min1) and (theta_min1 <= theta_min2)):
            found=1
        if((theta_max1 <= theta_min1) and (theta_min1 <= theta_max2) and (theta_max2 <= theta_min2)):
            thetasplit_final_min1=theta_min1
            thetasplit_final_max1=theta_max2
            thetasplit_final_min2=theta_min2
            thetasplit_final_max2=theta_max1
            split=1
            found=1


if(dy-y_edge >= r_integration):
    if(r_integration+d > r_field):
        theta_final_min=theta_min1
        theta_final_max=theta_max1

#split=0
#if((theta_min1 lt theta_max2) and (theta_max2

##################################
#now ensure that the final integration region is continuous (ie does not suffer from 2pi to 0 discontinuity)
if(theta_final_min > theta_final_max):
    theta_final_min=theta_final_min-2.*np.pi
if(thetasplit_final_min1 > thetasplit_final_max1):
    thetasplit_final_min1=thetasplit_final_min1-2.*np.pi
if(thetasplit_final_min2 > thetasplit_final_max2):
    thetasplit_final_min2=thetasplit_final_min2-2.*np.pi

##################################
#if((theta_min2 > theta_final_min) and (theta_max2 > theta_final_min)):
#    theta_final_min=theta_min2


x1=dx
y1=dy
x2=x1+r_integration*np.cos(theta_min1)
y2=y1+r_integration*np.sin(theta_min1)
x3=x1+r_integration*np.cos(theta_max1)
y3=y1+r_integration*np.sin(theta_max1)

x4=x1+r_integration*np.cos(theta_min2)
y4=y1+r_integration*np.sin(theta_min2)
x5=x1+r_integration*np.cos(theta_max2)
y5=y1+r_integration*np.sin(theta_max2)

x9=x1+10.5*r_field*np.cos(theta_final_min)
y9=y1+10.5*r_field*np.sin(theta_final_min)
x10=x1+10.5*r_field*np.cos(theta_final_max)
y10=y1+10.5*r_field*np.sin(theta_final_max)

x11=x1+10.5*r_field*np.cos(thetasplit_final_min1)
y11=y1+10.5*r_field*np.sin(thetasplit_final_min1)
x12=x1+10.5*r_field*np.cos(thetasplit_final_max1)
y12=y1+10.5*r_field*np.sin(thetasplit_final_max1)
x13=x1+10.5*r_field*np.cos(thetasplit_final_min2)
y13=y1+10.5*r_field*np.sin(thetasplit_final_min2)
x14=x1+10.5*r_field*np.cos(thetasplit_final_max2)
y14=y1+10.5*r_field*np.sin(thetasplit_final_max2)

ax0_0.set_xlim([-70,70])
ax0_0.set_ylim([-70,70])

circle1=plt.Circle((0,0),r_field,color='0.25',alpha=0.35)
circle2=plt.Circle((dx,dy),r_integration,color='r',alpha=0.35)
ax0_0.add_artist(circle1)
ax0_0.add_artist(circle2)
ax0_0.plot([-1000,1000],[y_edge,y_edge])
ax0_0.plot([x1,x2],[y1,y2],color='b')
ax0_0.plot([x1,x3],[y1,y3],color='r')
ax0_0.plot([x1,x4],[y1,y4],color='g')
ax0_0.plot([x1,x5],[y1,y5],color='m')
if(split==0):
    ax0_0.plot([x1,x9],[y1,y9],color='k',linestyle=':')
    ax0_0.plot([x1,x10],[y1,y10],color='k',linestyle='--')
if(split==1):
    ax0_0.plot([x1,x11],[y1,y11],color='b',linestyle=':')
    ax0_0.plot([x1,x12],[y1,y12],color='b',linestyle='--')
    ax0_0.plot([x1,x13],[y1,y13],color='r',linestyle=':')
    ax0_0.plot([x1,x14],[y1,y14],color='r',linestyle='--')


plotfilename='fov_truncate.pdf'
plt.savefig(plotfilename,dpi=400)
if(split==0):
    print theta_final_min,theta_final_max
if(split==1):
    print thetasplit_final_min1,thetasplit_final_max1
    print thetasplit_final_min2,thetasplit_final_max2
plt.show()
plt.close()
