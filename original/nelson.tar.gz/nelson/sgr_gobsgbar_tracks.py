import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
import scipy.optimize as optimize
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.6)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='10')
plt.rc('ytick',labelsize='10')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)
    
gdagger=1.2e-10
ghat=9.2e-12
g=0.0043# grav constant in galaxy units        
data1='mcconnachie.dat'
data1b='lelli_dsph.dat'
data4='gru1teffprior_gradientpost_equal_weights.dat'
data5='ret2_gradientpost_equal_weights.dat'
data6='tuc2teffprior_gradientpost_equal_weights.dat'
data7='/physics2/mgwalker/chains/cra2gradientpost_equal_weights.dat'

logupsilonstar=0.
siglogupsilonstar=0.25
upsilonstar=10.**logupsilonstar
sigupsilonstar=np.log(10.)*10.**logupsilonstar*siglogupsilonstar

out='cra2_gobsgbar_newcommands.tex'
g1=open(out,'w')

with open('mcgaugh_gobsgbar.dat') as f: # read data file
    data=f.readlines()[13:]
mcgaugh_gbar=[]
mcgaugh_siggbar=[]
mcgaugh_gobs=[]
mcgaugh_siggobs=[]
for line in data: # fill arrays
    p=line.split()
    mcgaugh_gbar.append(float(p[0]))
    mcgaugh_siggbar.append(float(p[1]))
    mcgaugh_gobs.append(float(p[2]))
    mcgaugh_siggobs.append(float(p[3]))
mcgaugh_gbar=np.array(mcgaugh_gbar)
mcgaugh_siggbar=np.array(mcgaugh_siggbar)
mcgaugh_gobs=np.array(mcgaugh_gobs)
mcgaugh_siggobs=np.array(mcgaugh_siggobs)

mcgaugh_deltaloggobs=mcgaugh_gobs-np.log10(10.**mcgaugh_gbar/(1.-np.exp(-np.sqrt(10.**mcgaugh_gbar/gdagger))))
mcgaugh_sigdeltaloggobs=mcgaugh_siggobs

with open(data1b) as f: # read data file
    data=f.readlines()
lelli_dsph=[]
lelli_d=[]
lelli_sigd1=[]
lelli_sigd2=[]
lelli_dhost=[]
lelli_loglum=[]
lelli_sigloglum=[]
lelli_rhalf=[]
lelli_sigrhalf=[]
lelli_ellip=[]
lelli_vdisp=[]
lelli_sigvdisp1=[]
lelli_sigvdisp2=[]
lelli_n=[]
lelli_loggbar=[]
lelli_sigloggbar1=[]
lelli_sigloggbar2=[]
lelli_gobs=[]
lelli_sigloggobs1=[]
lelli_sigloggobs2=[]
lelli_parent=[]
for line in data: # fill arrays
    p=line.split()
    lelli_dsph.append(str(p[0]))
    lelli_d.append(float(p[1]))
    lelli_sigd1.append(float(p[2]))
    lelli_sigd2.append(float(p[3]))
    lelli_dhost.append(float(p[4]))
    lelli_loglum.append(float(p[5]))
    lelli_sigloglum.append(float(p[6]))
    lelli_rhalf.append(float(p[7]))
    lelli_sigrhalf.append(float(p[8]))
    lelli_ellip.append(float(p[9]))
    lelli_vdisp.append(float(p[10]))
    lelli_sigvdisp1.append(float(p[11]))
    lelli_sigvdisp2.append(float(p[12]))
    lelli_n.append(float(p[13]))
    lelli_loggbar.append(float(p[14]))
    lelli_sigloggbar1.append(float(p[15]))
    lelli_sigloggbar2.append(float(p[16]))
    lelli_gobs.append(float(p[17]))
    lelli_sigloggobs1.append(float(p[18]))
    lelli_sigloggobs2.append(float(p[19]))
    lelli_parent.append(str(p[20]))
lelli_dsph=np.array(lelli_dsph)
lelli_d=np.array(lelli_d)
lelli_sigd1=np.array(lelli_sigd1)
lelli_sigd2=np.array(lelli_sigd2)
lelli_dhost=np.array(lelli_dhost)
lelli_loglum=np.array(lelli_loglum)
lelli_sigloglum=np.array(lelli_sigloglum)
lelli_rhalf=np.array(lelli_rhalf)
lelli_sigrhalf=np.array(lelli_sigrhalf)
lelli_ellip=np.array(lelli_ellip)
lelli_vdisp=np.array(lelli_vdisp)
lelli_sigvdisp1=np.array(lelli_sigvdisp1)
lelli_sigvdisp2=np.array(lelli_sigvdisp2)
lelli_n=np.array(lelli_n)
lelli_loggbar=np.array(lelli_loggbar)
lelli_sigloggbar1=np.array(lelli_sigloggbar1)
lelli_sigloggbar2=np.array(lelli_sigloggbar2)
lelli_gobs=np.array(lelli_gobs)
lelli_sigloggobs1=np.array(lelli_sigloggobs1)
lelli_sigloggobs2=np.array(lelli_sigloggobs2)
lelli_parent=np.array(lelli_parent)

lelli_mhost=np.zeros(len(lelli_rhalf))
for i in range(0,len(lelli_rhalf)):
    if lelli_ellip[i] > 0.:
        lelli_rhalf[i]=lelli_rhalf[i]*np.sqrt(1.-lelli_ellip[i])########convert to geometric mean radius
        lelli_sigrhalf[i]=lelli_sigrhalf[i]*np.sqrt(1.-lelli_ellip[i])
        if(lelli_parent[i]=='MW'):
            lelli_mhost[i]=1.e+12
        if(lelli_parent[i]=='M31'):
            lelli_mhost[i]=2.e+12

lelli_rhalf=3./4.*lelli_rhalf
lelli_sigrhalf=3./4.*lelli_sigrhalf
lelli_sigvdisp=(np.abs(lelli_sigvdisp1)+np.abs(lelli_sigvdisp2))/2.

lelli_luminosity=10.**lelli_loglum
lelli_sigluminosity=10.**lelli_loglum*np.log(10.)*lelli_sigloglum

lelli_gbar=g*upsilonstar*lelli_luminosity/(2.**1.5)/lelli_rhalf**2*(1000.**2)/3.09e+16
lelli_gobs=5.*lelli_vdisp**2/2./lelli_rhalf*(1000.**2)/3.09e+16
lelli_siggbar=np.sqrt((lelli_gbar/lelli_luminosity*lelli_sigluminosity)**2+(lelli_gbar/upsilonstar*sigupsilonstar)**2+(2.*lelli_gbar/lelli_rhalf*lelli_sigrhalf)**2)
lelli_siggobs=np.sqrt((2.*lelli_gobs/lelli_vdisp*lelli_sigvdisp)**2+(lelli_gobs/lelli_rhalf*lelli_sigrhalf)**2)

lelli_loggbar=np.log10(lelli_gbar)
lelli_sigloggbar=np.sqrt((lelli_siggbar/lelli_gbar/np.log(10.))**2)
lelli_loggobs=np.log10(lelli_gobs)
lelli_sigloggobs=np.sqrt((lelli_siggobs/lelli_gobs/np.log(10.))**2)

lelli_gtides=g*lelli_mhost*2.*lelli_rhalf/((lelli_dhost*1000.)**3)/((3.09e+13))*(1000.**2)

lelli_deltaloggobs=lelli_loggobs-np.log10(lelli_gbar/(1.-np.exp(-np.sqrt(lelli_gbar/gdagger))))
lelli_sigdeltaloggobs=lelli_sigloggobs

with open(data1) as f: # read data file
    data=f.readlines()

parent=[]
dsph=[]
rah=[]
ram=[]
ras=[]
chardecd=[]
decm=[]
decs=[]
glon=[]
glat=[]
distance=[]
sigdistance=[]
vsys=[]
sigvsys=[]
vmag=[]
sigvmag=[]
rhalfarcmin=[]
sigrhalfarcmin=[]
muv=[]
sigmuv=[]
ellip=[]
absvmag=[]
sigabsvmag=[]
rhalf=[]
sigrhalf=[]
vdisp=[]
sigvdisp=[]
feh=[]
sigfeh=[]
method=[]

for line in data: # fill arrays
    p=line.split()
    parent.append(str(p[0]))
    dsph.append(str(p[1]))
    rah.append(float(p[3]))
    ram.append(float(p[4]))
    ras.append(float(p[5]))
    chardecd.append(float(p[6]))
    decm.append(float(p[7]))
    decs.append(str(p[8]))
    glon.append(float(p[9]))
    glat.append(float(p[10]))
    distance.append(float(p[11]))
    sigdistance.append(float(p[12]))
    vsys.append(float(p[14]))
    sigvsys.append(float(p[15]))
    vmag.append(float(p[16]))
    sigvmag.append(float(p[17]))
    rhalfarcmin.append(float(p[19]))
    sigrhalfarcmin.append(float(p[20]))
    muv.append(float(p[22]))
    sigmuv.append(float(p[23]))
    ellip.append(float(p[25]))
    absvmag.append(float(p[26]))
    sigabsvmag.append(float(p[27]))
    rhalf.append(float(p[29]))
    sigrhalf.append(float(p[30]))
    vdisp.append(float(p[32]))
    sigvdisp.append(float(p[33]))
    feh.append(float(p[35]))
    sigfeh.append(float(p[36]))
    method.append(str(p[37]))

parent=np.array(parent)
dsph=np.array(dsph)
rah=np.array(rah)
ram=np.array(ram)
ras=np.array(ras)
chardecd=np.array(chardecd)
decm=np.array(decm)
decs=np.array(decs)
glon=np.array(glon)
glat=np.array(glat)
distance=np.array(distance)
sigdistance=np.array(sigdistance)
vsys=np.array(vsys)
sigvsys=np.array(sigvsys)
vmag=np.array(vmag)
sigvmag=np.array(sigvmag)
rhalfarcmin=np.array(rhalfarcmin)
sigrhalfarcmin=np.array(sigrhalfarcmin)
muv=np.array(muv)
sigmuv=np.array(sigmuv)
ellip=np.array(ellip)
absvmag=np.array(absvmag)
sigabsvmag=np.array(sigabsvmag)
rhalf=np.array(rhalf)
sigrhalf=np.array(sigrhalf)
vdisp=np.array(vdisp)
sigvdisp=np.array(sigvdisp)
feh=np.array(feh)
sigfeh=np.array(sigfeh)
method=np.array(method)

vdisp[8]=2.5

for i in range(0,len(rhalf)):
    if ellip[i] > 0.:
        rhalf[i]=rhalf[i]*np.sqrt(1.-ellip[i])########convert to geometric mean radius
        sigrhalf[i]=sigrhalf[i]*np.sqrt(1.-ellip[i])


with open(data4) as f: # read data file
    data=f.readlines()

gru1vmean=[]
gru1vdisp=[]
gru1vgrad=[]
gru1vtheta=[]
gru1fehmean=[]
gru1fehdisp=[]
gru1fehgrad=[]
gru1like=[]

for line in data: # fill arrays
    p=line.split()
    gru1vmean.append(float(p[0]))
    gru1vdisp.append(float(p[1]))
    gru1vgrad.append(float(p[2]))
    gru1vtheta.append(float(p[3]))
    gru1fehmean.append(float(p[4]))
    gru1fehdisp.append(float(p[5]))
    gru1fehgrad.append(float(p[6]))
    gru1like.append(float(p[7]))

gru1vmean=np.array(gru1vmean)
gru1vdisp=np.array(gru1vdisp)
gru1vgrad=np.array(gru1vgrad)
gru1vtheta=np.array(gru1vtheta)
gru1fehmean=np.array(gru1fehmean)
gru1fehdisp=np.array(gru1fehdisp)
gru1fehgrad=np.array(gru1fehgrad)
gru1like=np.array(gru1like)

gru1_vdisp0=np.array([np.median(gru1vdisp)])
gru1_sigvdisp0=np.array([np.std(gru1vdisp)])
gru1_feh=np.array([np.median(gru1fehmean)])
gru1_sigfeh=np.array([np.std(gru1fehmean)])
gru1_rhalf0=62.
gru1_sigrhalf0=30.
gru1_rhalf=np.random.normal(loc=gru1_rhalf0,scale=gru1_sigrhalf0,size=len(gru1vdisp))
#gru1_sigrhalf=np.array([1.])
gru1_absvmag0=-3.4
gru1_sigabsvmag0=0.3
gru1_absvmag=np.random.normal(loc=gru1_absvmag0,scale=gru1_sigabsvmag0,size=len(gru1vdisp))
#gru1_sigabsvmag=np.array([0.1])
gru1_rho0=gru1_vdisp0**2/g/gru1_rhalf0**2
gru1_sigrho0=np.sqrt((2.*gru1_vdisp0/gru1_rhalf0**2/g*gru1_sigvdisp0)**2+(2.*gru1_vdisp0**2/g/gru1_rhalf0**3*gru1_sigrhalf0)**2)
gru1_fehdisp=[np.median(gru1fehdisp)]
gru1_sigfehdisp=[np.std(gru1fehdisp)]


with open(data5) as f: # read data file
    data=f.readlines()

ret2vmean=[]
ret2vdisp=[]
ret2vgrad=[]
ret2vtheta=[]
ret2fehmean=[]
ret2fehdisp=[]
ret2fehgrad=[]
ret2like=[]

for line in data: # fill arrays
    p=line.split()
    ret2vmean.append(float(p[0]))
    ret2vdisp.append(float(p[1]))
    ret2vgrad.append(float(p[2]))
    ret2vtheta.append(float(p[3]))
    ret2fehmean.append(float(p[4]))
    ret2fehdisp.append(float(p[5]))
    ret2fehgrad.append(float(p[6]))
    ret2like.append(float(p[7]))

ret2vmean=np.array(ret2vmean)
ret2vdisp=np.array(ret2vdisp)
ret2vgrad=np.array(ret2vgrad)
ret2vtheta=np.array(ret2vtheta)
ret2fehmean=np.array(ret2fehmean)
ret2fehdisp=np.array(ret2fehdisp)
ret2fehgrad=np.array(ret2fehgrad)
ret2like=np.array(ret2like)

ret2_vdisp0=np.array([np.median(ret2vdisp)])
ret2_sigvdisp0=np.array([np.std(ret2vdisp)])
ret2_feh=np.array([np.median(ret2fehmean)])
ret2_sigfeh=np.array([np.std(ret2fehmean)])
ret2_rhalf0=32.
ret2_sigrhalf0=2.
ret2_rhalf=np.random.normal(loc=ret2_rhalf0,scale=ret2_sigrhalf0,size=len(ret2vdisp))
#ret2_sigrhalf=np.array([1.])
ret2_absvmag0=-2.7
ret2_sigabsvmag0=0.1
ret2_absvmag=np.random.normal(loc=ret2_absvmag0,scale=0.2,size=len(ret2vdisp))
#ret2_sigabsvmag=np.array([0.1])
ret2_rho0=ret2_vdisp0**2/g/ret2_rhalf0**2
ret2_sigrho0=np.sqrt((2.*ret2_vdisp0/ret2_rhalf0**2/g*ret2_sigvdisp0)**2+(2.*ret2_vdisp0**2/g/ret2_rhalf0**3*ret2_sigrhalf0)**2)


with open(data6) as f: # read data file
    data=f.readlines()

tuc2vmean=[]
tuc2vdisp=[]
tuc2vgrad=[]
tuc2vtheta=[]
tuc2fehmean=[]
tuc2fehdisp=[]
tuc2fehgrad=[]
tuc2like=[]

for line in data: # fill arrays
    p=line.split()
    tuc2vmean.append(float(p[0]))
    tuc2vdisp.append(float(p[1]))
    tuc2vgrad.append(float(p[2]))
    tuc2vtheta.append(float(p[3]))
    tuc2fehmean.append(float(p[4]))
    tuc2fehdisp.append(float(p[5]))
    tuc2fehgrad.append(float(p[6]))
    tuc2like.append(float(p[7]))

tuc2vmean=np.array(tuc2vmean)
tuc2vdisp=np.array(tuc2vdisp)
tuc2vgrad=np.array(tuc2vgrad)
tuc2vtheta=np.array(tuc2vtheta)
tuc2fehmean=np.array(tuc2fehmean)
tuc2fehdisp=np.array(tuc2fehdisp)
tuc2fehgrad=np.array(tuc2fehgrad)
tuc2like=np.array(tuc2like)

tuc2_vdisp0=np.array([np.median(tuc2vdisp)])
tuc2_sigvdisp0=np.array([np.std(tuc2vdisp)])
tuc2_feh=np.array([np.median(tuc2fehmean)])
tuc2_sigfeh=np.array([np.std(tuc2fehmean)])
tuc2_rhalf0=165.
tuc2_sigrhalf0=28.
tuc2_rhalf=np.random.normal(loc=tuc2_rhalf0,scale=tuc2_sigrhalf0,size=len(tuc2vdisp))
#tuc2_sigrhalf=np.array([1.])
tuc2_absvmag0=-3.8
tuc2_sigabsvmag0=0.1
tuc2_absvmag=np.random.normal(loc=tuc2_absvmag0,scale=tuc2_sigabsvmag0,size=len(tuc2vdisp))
#tuc2_sigabsvmag=np.array([0.1])
tuc2_rho0=tuc2_vdisp0**2/g/tuc2_rhalf0**2
tuc2_sigrho0=np.sqrt((2.*tuc2_vdisp0/tuc2_rhalf0**2/g*tuc2_sigvdisp0)**2+(2.*tuc2_vdisp0**2/g/tuc2_rhalf0**3*tuc2_sigrhalf0)**2)
tuc2_fehdisp=[np.median(tuc2fehdisp)]
tuc2_sigfehdisp=[np.std(tuc2fehdisp)]

with open(data7) as f: # read data file
    data=f.readlines()

cra2vmean=[]
cra2vvar=[]
cra2fehmean=[]
cra2fehvar=[]
cra2rslight=[]
cra2like=[]

for line in data: # fill arrays
    p=line.split()
    cra2vmean.append(float(p[4]))
    cra2vvar.append(float(p[2]))
    cra2fehmean.append(float(p[5]))
    cra2fehvar.append(float(p[3]))
    cra2rslight.append(float(p[1]))
    cra2like.append(float(p[7]))

cra2vmean=np.array(cra2vmean)
cra2vvar=np.array(cra2vvar)
cra2fehmean=np.array(cra2fehmean)
cra2fehvar=np.array(cra2fehvar)
cra2rslight=np.array(cra2rslight)
cra2like=np.array(cra2like)

cra2rslight=10.**cra2rslight
cra2rslightpc=117000.*np.tan(cra2rslight/60.*np.pi/180.)
cra2vdisp=np.sqrt(10.**cra2vvar)
cra2fehdisp=np.sqrt(10.**cra2fehvar)
cra2_fehdisp=[np.median(cra2fehdisp)]
cra2_sigfehdisp=[np.std(cra2fehdisp)]

cra2_vdisp0=np.array([np.median(cra2vdisp)])
cra2_sigvdisp0=np.array([np.std(cra2vdisp)])
cra2_feh=np.array([np.median(cra2fehmean)])
cra2_sigfeh=np.array([np.std(cra2fehmean)])
cra2_rhalf0=np.median(cra2rslightpc)
cra2_sigrhalf0=np.std(cra2rslightpc)
cra2_rhalf=cra2rslightpc
cra2_absvmag0=-8.2
cra2_sigabsvmag0=0.1
cra2_absvmag=np.random.normal(loc=cra2_absvmag0,scale=cra2_sigabsvmag0,size=len(cra2vdisp))
cra2_rho0=cra2_vdisp0**2/g/cra2_rhalf0**2
cra2_sigrho0=np.sqrt((2.*cra2_vdisp0/cra2_rhalf0**2/g*cra2_sigvdisp0)**2+(2.*cra2_vdisp0**2/g/cra2_rhalf0**3*cra2_sigrhalf0)**2)

luminosity=10.**((absvmag-4.83)/(-2.5))
sigluminosity=np.log(10.)/2.5*10.**((absvmag-4.83)/(-2.5))*sigabsvmag
mrhalf=1./0.0043*rhalf*vdisp**2
sigmrhalf=np.sqrt(((2.*rhalf/0.0043*vdisp)**2)*(sigvdisp**2)+((1./0.0043*(vdisp**2))**2)*sigrhalf**2)
mlratio=mrhalf/(luminosity)
sigmlratio=np.sqrt((sigmrhalf**2)/(luminosity**2)+((mrhalf/luminosity**2)**2)*sigluminosity**2)
gbar=g*upsilonstar*luminosity/(2.**1.5)/rhalf**2*(1000.**2)/3.09e+16
gobs=5.*vdisp**2/2./rhalf*(1000.**2)/3.09e+16
siggbar=np.sqrt((gbar/luminosity*sigluminosity)**2+(gbar/upsilonstar*sigupsilonstar)**2+(2.*gbar/rhalf*sigrhalf)**2)
siggobs=np.sqrt((2.*gobs/vdisp*sigvdisp)**2+(gobs/rhalf*sigrhalf)**2)
loggbar=np.log10(gbar)
sigloggbar=np.sqrt((siggbar/gbar/np.log(10.))**2)
loggobs=np.log10(gobs)
sigloggobs=np.sqrt((siggobs/gobs/np.log(10.))**2)

deltaloggobs=loggobs-np.log10(gbar/(1.-np.exp(-np.sqrt(gbar/gdagger))))
sigdeltaloggobs=sigloggobs

rho=vdisp**2/rhalf**2/g
sigrho=np.sqrt((2.*vdisp/rhalf**2/g*sigvdisp)**2+(2.*vdisp**2/g/rhalf**3*sigrhalf)**2)
mw_rhokeep=np.where((parent =='MW') & (sigrho/rho <=1.))
m31_rhokeep=np.where((parent =='M31') & (sigrho/rho <=1.))
rest_rhokeep=np.where((parent =='Rest') & (sigrho/rho <= 1.))
mw_mlkeep=np.where((parent =='MW') & (sigmlratio/mlratio <=1.))
m31_mlkeep=np.where((parent =='M31') & (sigmlratio/mlratio <=1.))
rest_mlkeep=np.where((parent =='Rest') & (sigmlratio/mlratio <= 1.))

gru1_vdisp=gru1vdisp
gru1_luminosity0=10.**((gru1_absvmag0-4.83)/(-2.5))
gru1_luminosity=10.**((gru1_absvmag-4.83)/(-2.5))
gru1_sigluminosity0=np.log(10.)/2.5*10.**((gru1_absvmag0-4.83)/(-2.5))*gru1_sigabsvmag0
gru1_mrhalf0=1./0.0043*gru1_rhalf0*gru1_vdisp0**2
gru1_mrhalf=1./0.0043*gru1_rhalf*gru1vdisp**2
gru1_sigmrhalf0=np.sqrt(2.*gru1_rhalf0/0.0043*gru1_vdisp0*(gru1_sigvdisp0**2)+((1./0.0043*(gru1_vdisp0**2))**2)*gru1_sigrhalf0**2)
gru1_mlratio=gru1_mrhalf/(gru1_luminosity)
gru1_mlratio0=gru1_mrhalf0/gru1_luminosity0
gru1_sigmlratio0=np.sqrt((gru1_sigmrhalf0**2)/(gru1_luminosity0**2)+((gru1_mrhalf0/gru1_luminosity0**2)**2)*gru1_sigluminosity0**2)
gru1_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(gru1_mrhalf))
gru1_upsilonstar=10.**gru1_logupsilonstar
gru1_gbar=g*gru1_upsilonstar*gru1_luminosity/(2.**1.5)/gru1_rhalf**2*(1000.**2)/3.09e+16
gru1_gobs=5.*gru1_vdisp**2/2./gru1_rhalf*(1000.**2)/3.09e+16
gru1_loggbar=np.log10(gru1_gbar)
gru1_loggobs=np.log10(gru1_gobs)
gru1_deltaloggobs=gru1_loggobs-np.log10(gru1_gbar/(1.-np.exp(-np.sqrt(gru1_gbar/gdagger))))


ret2_vdisp=ret2vdisp
ret2_luminosity0=10.**((ret2_absvmag0-4.83)/(-2.5))
ret2_luminosity=10.**((ret2_absvmag-4.83)/(-2.5))
ret2_sigluminosity0=np.log(10.)/2.5*10.**((ret2_absvmag0-4.83)/(-2.5))*ret2_sigabsvmag0
ret2_mrhalf0=1./0.0043*ret2_rhalf0*ret2_vdisp0**2
ret2_mrhalf=1./0.0043*ret2_rhalf*ret2vdisp**2
ret2_sigmrhalf0=np.sqrt(2.*ret2_rhalf0/0.0043*ret2_vdisp0*(ret2_sigvdisp0**2)+((1./0.0043*(ret2_vdisp0**2))**2)*ret2_sigrhalf0**2)
ret2_mlratio=ret2_mrhalf/(ret2_luminosity)
ret2_mlratio0=ret2_mrhalf0/ret2_luminosity0
ret2_sigmlratio0=np.sqrt((ret2_sigmrhalf0**2)/(ret2_luminosity0**2)+((ret2_mrhalf0/ret2_luminosity0**2)**2)*ret2_sigluminosity0**2)
ret2_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(ret2_mrhalf))
ret2_upsilonstar=10.**ret2_logupsilonstar
ret2_gbar=g*ret2_upsilonstar*ret2_luminosity/(2.**1.5)/ret2_rhalf**2*(1000.**2)/3.09e+16
ret2_gobs=5.*ret2_vdisp**2/2./ret2_rhalf*(1000.**2)/3.09e+16
ret2_loggbar=np.log10(ret2_gbar)
ret2_loggobs=np.log10(ret2_gobs)
ret2_deltaloggobs=ret2_loggobs-np.log10(ret2_gbar/(1.-np.exp(-np.sqrt(ret2_gbar/gdagger))))

tuc2_vdisp=tuc2vdisp
tuc2_luminosity0=10.**((tuc2_absvmag0-4.83)/(-2.5))
tuc2_luminosity=10.**((tuc2_absvmag-4.83)/(-2.5))
tuc2_sigluminosity0=np.log(10.)/2.5*10.**((tuc2_absvmag0-4.83)/(-2.5))*tuc2_sigabsvmag0
tuc2_mrhalf0=1./0.0043*tuc2_rhalf0*tuc2_vdisp0**2
tuc2_mrhalf=1./0.0043*tuc2_rhalf*tuc2vdisp**2
tuc2_sigmrhalf0=np.sqrt(2.*tuc2_rhalf0/0.0043*tuc2_vdisp0*(tuc2_sigvdisp0**2)+((1./0.0043*(tuc2_vdisp0**2))**2)*tuc2_sigrhalf0**2)
tuc2_mlratio=tuc2_mrhalf/(tuc2_luminosity)
tuc2_mlratio0=tuc2_mrhalf0/tuc2_luminosity0
tuc2_sigmlratio0=np.sqrt((tuc2_sigmrhalf0**2)/(tuc2_luminosity0**2)+((tuc2_mrhalf0/tuc2_luminosity0**2)**2)*tuc2_sigluminosity0**2)
tuc2_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(tuc2_mrhalf))
tuc2_upsilonstar=10.**tuc2_logupsilonstar
tuc2_gbar=g*tuc2_upsilonstar*tuc2_luminosity/(2.**1.5)/tuc2_rhalf**2*(1000.**2)/3.09e+16
tuc2_gobs=5.*tuc2_vdisp**2/2./tuc2_rhalf*(1000.**2)/3.09e+16
tuc2_loggbar=np.log10(tuc2_gbar)
tuc2_loggobs=np.log10(tuc2_gobs)
tuc2_deltaloggobs=tuc2_loggobs-np.log10(tuc2_gbar/(1.-np.exp(-np.sqrt(tuc2_gbar/gdagger))))

cra2_vdisp=cra2vdisp
cra2_luminosity0=10.**((cra2_absvmag0-4.83)/(-2.5))
cra2_luminosity=10.**((cra2_absvmag-4.83)/(-2.5))
cra2_sigluminosity0=np.log(10.)/2.5*10.**((cra2_absvmag0-4.83)/(-2.5))*cra2_sigabsvmag0
cra2_mrhalf0=1./0.0043*cra2_rhalf0*cra2_vdisp0**2
cra2_mrhalf=1./0.0043*cra2_rhalf*cra2vdisp**2
cra2_sigmrhalf0=np.sqrt(2.*cra2_rhalf0/0.0043*cra2_vdisp0*(cra2_sigvdisp0**2)+((1./0.0043*(cra2_vdisp0**2))**2)*cra2_sigrhalf0**2)
cra2_mlratio=cra2_mrhalf/(cra2_luminosity)
cra2_mlratio0=cra2_mrhalf0/cra2_luminosity0
cra2_sigmlratio0=np.sqrt((cra2_sigmrhalf0**2)/(cra2_luminosity0**2)+((cra2_mrhalf0/cra2_luminosity0**2)**2)*cra2_sigluminosity0**2)
cra2_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(cra2_mrhalf))
cra2_upsilonstar=10.**cra2_logupsilonstar
cra2_gbar=g*cra2_upsilonstar*cra2_luminosity/(2.**1.5)/cra2_rhalf**2*(1000.**2)/3.09e+16
cra2_gobs=5.*cra2_vdisp**2/2./cra2_rhalf*(1000.**2)/3.09e+16
cra2_loggbar=np.log10(cra2_gbar)
cra2_loggobs=np.log10(cra2_gobs)
cra2_deltaloggobs=cra2_loggobs-np.log10(cra2_gbar/(1.-np.exp(-np.sqrt(cra2_gbar/gdagger))))

#with open('/physics2/mgwalker/chains/cra2jeanscountsnfw.profiles') as f: # read data file
#    data=f.readlines()
#cra2nfw_rad=[]
#cra2nfw_radpc=[]
#cra2nfw_gbar=[]
#cra2nfw_gbarlo1=[]
#cra2nfw_gbarlo2=[]
#cra2nfw_gbarhi1=[]
#cra2nfw_gbarhi2=[]
#cra2nfw_gobs=[]
#cra2nfw_gobslo1=[]
#cra2nfw_gobslo2=[]
#cra2nfw_gobshi1=[]
#cra2nfw_gobshi2=[]
#for line in data: # fill arrays
#    p=line.split()
#    cra2nfw_rad.append(float(p[0]))
#    cra2nfw_radpc.append(float(p[1]))
#    cra2nfw_gbar.append(float(p[77]))
#    cra2nfw_gbarlo1.append(float(p[78]))
#    cra2nfw_gbarlo2.append(float(p[80]))
#    cra2nfw_gbarhi1.append(float(p[79]))
#    cra2nfw_gbarhi2.append(float(p[81]))
#    cra2nfw_gobs.append(float(p[82]))
#    cra2nfw_gobslo1.append(float(p[83]))
#    cra2nfw_gobslo2.append(float(p[85]))
#    cra2nfw_gobshi1.append(float(p[84]))
#    cra2nfw_gobshi2.append(float(p[86]))
#cra2nfw_rad=np.array(cra2nfw_rad)
#cra2nfw_radpc=np.array(cra2nfw_radpc)
#cra2nfw_gbar=np.array(cra2nfw_gbar)*(1000.**2)/3.09e+16
#cra2nfw_gbarlo1=np.array(cra2nfw_gbarlo1)*(1000.**2)/3.09e+16
#cra2nfw_gbarlo2=np.array(cra2nfw_gbarlo2)*(1000.**2)/3.09e+16
#cra2nfw_gbarhi1=np.array(cra2nfw_gbarhi1)*(1000.**2)/3.09e+16
#cra2nfw_gbarhi2=np.array(cra2nfw_gbarhi2)*(1000.**2)/3.09e+16
#cra2nfw_gobs=np.array(cra2nfw_gobs)*(1000.**2)/3.09e+16
#cra2nfw_gobslo1=np.array(cra2nfw_gobslo1)*(1000.**2)/3.09e+16
#cra2nfw_gobslo2=np.array(cra2nfw_gobslo2)*(1000.**2)/3.09e+16
#cra2nfw_gobshi1=np.array(cra2nfw_gobshi1)*(1000.**2)/3.09e+16
#cra2nfw_gobshi2=np.array(cra2nfw_gobshi2)*(1000.**2)/3.09e+16

gs=plt.GridSpec(10,10) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
ax2_2=fig.add_subplot(gs[0:5,1:6])

notrust=[1,15,17,18,13,2]
trust=[0,16,11,14,12,23,22,9,10,21]
mwkeep=np.where((parent=='MW')&(siggobs<gobs))
m31keep=np.where((parent=='M31')&(siggobs<gobs))
restkeep=np.where((parent=='Rest')&(siggobs<gobs))
lelli_mw=np.where(lelli_parent=='MW')
lelli_m31=np.where(lelli_parent=='M31')
lelli_mwkeep=np.where((lelli_parent=='MW')&(lelli_siggobs/lelli_gobs<0.5))
lelli_m31keep=np.where((lelli_parent=='M31')&(lelli_siggobs/lelli_gobs<0.5))
#lelli_mwkeep=np.where((lelli_parent=='MW')&(lelli_rhalf > 100.))
#lelli_m31keep=np.where((lelli_parent=='M31')&(lelli_rhalf > 100.))

ax2_2.set_xlabel(r'$\log_{10}[g_{\rm bar}/(\mathrm{m\,s^{-2}})]$',fontsize=13,rotation=0)
ax2_2.set_ylabel(r'$\log_{10}[g_{\rm obs}/(\mathrm{m\,s^{-2}})]$',fontsize=13,rotation=90)
#ax2_2.set_xlabel(r'$R_{\rm h}$ [pc]',fontsize=11,rotation=0,labelpad=5)
ax2_2.set_xlim([-15,-8])
ax2_2.set_ylim([-13,-8])
ax2_2.set_xscale(u'linear')
ax2_2.set_yscale(u'linear')
#ax2_2.errorbar(mcgaugh_gbar,mcgaugh_gobs,xerr=mcgaugh_siggbar,yerr=mcgaugh_siggobs,elinewidth=0.2,fmt='.',capsize=0,alpha=0.2,color='k',rasterized=False,mew=0.1)
ax2_2.errorbar((lelli_loggbar[lelli_mwkeep]),(lelli_loggobs[lelli_mwkeep]),xerr=lelli_sigloggbar[lelli_mwkeep],yerr=lelli_sigloggobs[lelli_mwkeep],elinewidth=0.75,fmt='.',capsize=1,alpha=0.2,color='k',rasterized=False,mew=0.5)
ax2_2.errorbar((lelli_loggbar[lelli_m31keep]),(lelli_loggobs[lelli_m31keep]),xerr=lelli_sigloggbar[lelli_m31keep],yerr=lelli_sigloggobs[lelli_m31keep],elinewidth=0.75,fmt='.',capsize=1,alpha=0.2,color='k',rasterized=False,mew=0.5)
ax2_2.errorbar(loggbar[dsph=='sgr'],loggobs[dsph=='sgr'],xerr=sigloggbar[dsph=='sgr'],yerr=sigloggobs[dsph=='sgr'],capsize=1,alpha=0.2,color='k',rasterized=False,mew=0.5)

ax2_2.errorbar([np.median(np.log10(cra2_gbar))],[np.median(np.log10(cra2_gobs))],xerr=[np.std(cra2_loggbar)],yerr=[np.std(cra2_loggobs)],elinewidth=0.75,fmt='.',capsize=1,alpha=0.2,color='k',rasterized=False,mew=0.5,markerfacecolor='k')
#ax2_2.scatter([np.median(np.log10(cra2_gbar))],[np.median(np.log10(cra2_gobs))],alpha=1,color='k',rasterized=False,edgecolor='none',s=25)
ax2_2.scatter(loggbar[dsph=='sgr'],loggobs[dsph=='sgr'],alpha=1,color='k',rasterized=False,s=25,edgecolor='none')
#ax2_2.errorbar([np.median(np.log10(ret2_gbar))],[np.median(np.log10(ret2_gobs))],xerr=[np.std(ret2_loggbar)],yerr=[np.std(ret2_loggobs)],elinewidth=0.75,fmt='.',capsize=1,alpha=1,color='b',rasterized=False,mew=0.5)
mondgbar=np.linspace(-20.,0.,1000)
mondgbar=10.**mondgbar
mondgobs=mondgbar/(1.-np.exp(-np.sqrt(mondgbar/gdagger)))
mondgobs2=mondgbar/(1.-np.exp(-np.sqrt(mondgbar/gdagger)))+ghat*np.exp(-np.sqrt(mondgbar*gdagger/ghat**2))
ax2_2.text(-12.5,-11.5,'Sgr',fontsize=7)
#ax2_2.plot(np.log10(mondgbar),np.log10(mondgobs),lw=1,color='k',label=r'$\frac{g_{\rm obs}}{g_{\rm bar}}=(1-\exp[-\sqrt{g_{\rm bar}/g_{\dagger}}])^{-1}$')
ax2_2.plot(np.log10(mondgbar),np.log10(mondgobs),lw=1,color='k')
ax2_2.plot(np.log10(mondgbar),np.log10(mondgobs2),lw=1,color='k',linestyle='--')
#use=np.where(cra2nfw_radpc<2000.)
#ax2_2.plot(np.log10(cra2nfw_gbar[use]),np.log10(cra2nfw_gobs[use]),lw=1,color='g')
ax2_2.plot([-16,-7],[-16,-7],lw=1,color='k',linestyle=':')

alpha_cusp_rhalf1=1.49
beta_cusp_rhalf1=0.35
alpha_cusp_rhalf2=1.22
beta_cusp_rhalf2=0.33
alpha_core_rhalf1=2.91
beta_core_rhalf1=0.15
alpha_core_rhalf2=1.63
beta_core_rhalf2=0.03

alpha_cusp_sigma1=-0.88
beta_cusp_sigma1=0.24
alpha_cusp_sigma2=-0.68
beta_cusp_sigma2=0.26
alpha_core_sigma1=-2.56
beta_core_sigma1=0.05
alpha_core_sigma2=-1.39
beta_core_sigma2=0.29

alpha_cusp_mstar1=3.43
beta_cusp_mstar1=1.86
alpha_cusp_mstar2=3.57
beta_cusp_mstar2=2.06
alpha_core_mstar1=1.43
beta_core_mstar1=0.69
alpha_core_mstar2=0.82
beta_core_mstar2=0.82

dra=np.where(lelli_dsph=='Draco')
x0=np.median(cra2_gbar)
y0=np.median(cra2_gobs)
#x0=lelli_gbar[dra]
#y0=lelli_gobs[dra]

def findmassratio(x,stellarmassratio,alpha,beta):
    val=stellarmassratio-(2.**alpha)*(x**beta)/(1.+x)**alpha
    return val

stellarmassratio=np.array([0.5,1.,1.5,2.])
stellarmassratio=1./10.**stellarmassratio
cusp_massratio1=np.zeros(len(stellarmassratio))
cusp_massratio2=np.zeros(len(stellarmassratio))
core_massratio1=np.zeros(len(stellarmassratio))
core_massratio2=np.zeros(len(stellarmassratio))

low=1.e-10
high=1.
for i in range(0,len(stellarmassratio)):
    cusp_massratio1[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_cusp_mstar1,beta_cusp_mstar1),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
    cusp_massratio2[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_cusp_mstar2,beta_cusp_mstar2),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
    core_massratio1[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_core_mstar1,beta_core_mstar1),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
    core_massratio2[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_core_mstar2,beta_core_mstar2),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)

cusp_rhalfratio1=(2.**alpha_cusp_rhalf1)*(cusp_massratio1**beta_cusp_rhalf1)/(1.+cusp_massratio1)**alpha_cusp_rhalf1
cusp_sigmaratio1=(2.**alpha_cusp_sigma1)*(cusp_massratio1**beta_cusp_sigma1)/(1.+cusp_massratio1)**alpha_cusp_sigma1
cusp_gbarratio1=stellarmassratio/cusp_rhalfratio1**2
cusp_gobsratio1=cusp_massratio1/cusp_rhalfratio1**2
cusp_rhalfratio2=(2.**alpha_cusp_rhalf2)*(cusp_massratio2**beta_cusp_rhalf2)/(1.+cusp_massratio2)**alpha_cusp_rhalf2
cusp_sigmaratio2=(2.**alpha_cusp_sigma2)*(cusp_massratio2**beta_cusp_sigma2)/(1.+cusp_massratio2)**alpha_cusp_sigma2
cusp_gbarratio2=stellarmassratio/cusp_rhalfratio2**2
cusp_gobsratio2=cusp_massratio2/cusp_rhalfratio2**2
core_rhalfratio1=(2.**alpha_core_rhalf1)*(core_massratio1**beta_core_rhalf1)/(1.+core_massratio1)**alpha_core_rhalf1
core_sigmaratio1=(2.**alpha_core_sigma1)*(core_massratio1**beta_core_sigma1)/(1.+core_massratio1)**alpha_core_sigma1
core_gbarratio1=stellarmassratio/core_rhalfratio1**2
core_gobsratio1=core_massratio1/core_rhalfratio1**2
core_rhalfratio2=(2.**alpha_core_rhalf2)*(core_massratio2**beta_core_rhalf2)/(1.+core_massratio2)**alpha_core_rhalf2
core_sigmaratio2=(2.**alpha_core_sigma2)*(core_massratio2**beta_core_sigma2)/(1.+core_massratio2)**alpha_core_sigma2
core_gbarratio2=stellarmassratio/core_rhalfratio2**2
core_gobsratio2=core_massratio2/core_rhalfratio2**2

#initial conditions for progenitor
#cusp1_gbar0=np.median(cra2_gbar)/cusp_gbarratio1
#cusp1_gobs0=np.median(cra2_gobs)/cusp_gobsratio1
#cusp2_gbar0=np.median(cra2_gbar)/cusp_gbarratio2
#cusp2_gobs0=np.median(cra2_gobs)/cusp_gobsratio2
#core1_gbar0=np.median(cra2_gbar)/core_gbarratio1
#core1_gobs0=np.median(cra2_gobs)/core_gobsratio1
#core2_gbar0=np.median(cra2_gbar)/core_gbarratio2
#core2_gobs0=np.median(cra2_gobs)/core_gobsratio2

cusp1_gbar0=gbar[dsph=='sgr']/cusp_gbarratio1
cusp1_gobs0=gobs[dsph=='sgr']/cusp_gobsratio1
cusp2_gbar0=gbar[dsph=='sgr']/cusp_gbarratio2
cusp2_gobs0=gobs[dsph=='sgr']/cusp_gobsratio2
core1_gbar0=gbar[dsph=='sgr']/core_gbarratio1
core1_gobs0=gobs[dsph=='sgr']/core_gobsratio1
core2_gbar0=gbar[dsph=='sgr']/core_gbarratio2
core2_gobs0=gobs[dsph=='sgr']/core_gobsratio2

cusp1_gbarfuture=gbar[dsph=='sgr']*cusp_gbarratio1
cusp1_gobsfuture=gobs[dsph=='sgr']*cusp_gobsratio1
cusp2_gbarfuture=gbar[dsph=='sgr']*cusp_gbarratio2
cusp2_gobsfuture=gobs[dsph=='sgr']*cusp_gobsratio2
core1_gbarfuture=gbar[dsph=='sgr']*core_gbarratio1
core1_gobsfuture=gobs[dsph=='sgr']*core_gobsratio1
core2_gbarfuture=gbar[dsph=='sgr']*core_gbarratio2
core2_gobsfuture=gobs[dsph=='sgr']*core_gobsratio2

ax2_2.scatter(np.log10(cusp1_gbar0),np.log10(cusp1_gobs0),marker='o',color='b',s=10,edgecolor='none')
#ax2_2.scatter(np.log10(cusp2_gbar0),np.log10(cusp2_gobs0),marker='o',color='b',s=10,edgecolor='none')
ax2_2.scatter(np.log10(core1_gbar0),np.log10(core1_gobs0),marker='o',color='r',s=10,edgecolor='none')
#ax2_2.scatter(np.log10(core2_gbar0),np.log10(core2_gobs0),marker='o',color='r',s=10,edgecolor='none')
ax2_2.scatter(np.log10(cusp1_gbarfuture),np.log10(cusp1_gobsfuture),marker='o',color='b',s=10,edgecolor='none')
#ax2_2.scatter(np.log10(cusp2_gbarfuture),np.log10(cusp2_gobsfuture),marker='o',color='b',s=10,edgecolor='none')
ax2_2.scatter(np.log10(core1_gbarfuture),np.log10(core1_gobsfuture),marker='o',color='r',s=10,edgecolor='none')
#ax2_2.scatter(np.log10(core2_gbarfuture),np.log10(core2_gobsfuture),marker='o',color='r',s=10,edgecolor='none')

for i in range(0,len(cusp1_gbar0)):
    x=np.linspace(1.,cusp_massratio1[i],100)
    cusp_rhalf1=2**alpha_cusp_rhalf1*x**beta_cusp_rhalf1/(1.+x)**alpha_cusp_rhalf1
    cusp_mstar1=2**alpha_cusp_mstar1*x**beta_cusp_mstar1/(1.+x)**alpha_cusp_mstar1
    cusp_gbar1=cusp1_gbar0[i]*cusp_mstar1/cusp_rhalf1**2
    cusp_gobs1=cusp1_gobs0[i]*x/cusp_rhalf1**2
    ax2_2.plot(np.log10(cusp_gbar1),np.log10(cusp_gobs1),color='b',lw=0.5)
for i in range(0,len(cusp2_gbar0)):
    x=np.linspace(1.,cusp_massratio2[i],100)
    cusp_rhalf2=2**alpha_cusp_rhalf2*x**beta_cusp_rhalf2/(1.+x)**alpha_cusp_rhalf2
    cusp_mstar2=2**alpha_cusp_mstar2*x**beta_cusp_mstar2/(1.+x)**alpha_cusp_mstar2
    cusp_gbar2=cusp2_gbar0[i]*cusp_mstar2/cusp_rhalf2**2
    cusp_gobs2=cusp2_gobs0[i]*x/cusp_rhalf2**2
#    ax2_2.plot(np.log10(cusp_gbar2),np.log10(cusp_gobs2),color='b',lw=0.5,linestyle='--')
for i in range(0,len(core1_gbar0)):
    x=np.linspace(1.,core_massratio1[i],100)
    core_rhalf1=2**alpha_core_rhalf1*x**beta_core_rhalf1/(1.+x)**alpha_core_rhalf1
    core_mstar1=2**alpha_core_mstar1*x**beta_core_mstar1/(1.+x)**alpha_core_mstar1
    core_gbar1=core1_gbar0[i]*core_mstar1/core_rhalf1**2
    core_gobs1=core1_gobs0[i]*x/core_rhalf1**2
    ax2_2.plot(np.log10(core_gbar1),np.log10(core_gobs1),color='r',lw=0.5)
for i in range(0,len(core2_gbar0)):
    x=np.linspace(1.,core_massratio2[i],100)
    core_rhalf2=2**alpha_core_rhalf2*x**beta_core_rhalf2/(1.+x)**alpha_core_rhalf2
    core_mstar2=2**alpha_core_mstar2*x**beta_core_mstar2/(1.+x)**alpha_core_mstar2
    core_gbar2=core2_gbar0[i]*core_mstar2/core_rhalf2**2
    core_gobs2=core2_gobs0[i]*x/core_rhalf2**2
#    ax2_2.plot(np.log10(core_gbar2),np.log10(core_gobs2),color='r',lw=0.5,linestyle='--')



for i in range(0,len(cusp1_gbar0)):
    x=np.linspace(1.,cusp_massratio1[i],100)
    cusp_rhalf1=2**alpha_cusp_rhalf1*x**beta_cusp_rhalf1/(1.+x)**alpha_cusp_rhalf1
    cusp_mstar1=2**alpha_cusp_mstar1*x**beta_cusp_mstar1/(1.+x)**alpha_cusp_mstar1
    cusp_gbar1=gbar[dsph=='sgr']*cusp_mstar1/cusp_rhalf1**2
    cusp_gobs1=gobs[dsph=='sgr']*x/cusp_rhalf1**2
    ax2_2.plot(np.log10(cusp_gbar1),np.log10(cusp_gobs1),color='b',lw=0.5)
for i in range(0,len(cusp2_gbar0)):
    x=np.linspace(1.,cusp_massratio2[i],100)
    cusp_rhalf2=2**alpha_cusp_rhalf2*x**beta_cusp_rhalf2/(1.+x)**alpha_cusp_rhalf2
    cusp_mstar2=2**alpha_cusp_mstar2*x**beta_cusp_mstar2/(1.+x)**alpha_cusp_mstar2
    cusp_gbar2=gbar[dsph=='sgr']*cusp_mstar2/cusp_rhalf2**2
    cusp_gobs2=gobs[dsph=='sgr']*x/cusp_rhalf2**2
#    ax2_2.plot(np.log10(cusp_gbar2),np.log10(cusp_gobs2),color='b',lw=0.5,linestyle='--')
for i in range(0,len(core1_gbar0)):
    x=np.linspace(1.,core_massratio1[i],100)
    core_rhalf1=2**alpha_core_rhalf1*x**beta_core_rhalf1/(1.+x)**alpha_core_rhalf1
    core_mstar1=2**alpha_core_mstar1*x**beta_core_mstar1/(1.+x)**alpha_core_mstar1
    core_gbar1=gbar[dsph=='sgr']*core_mstar1/core_rhalf1**2
    core_gobs1=gobs[dsph=='sgr']*x/core_rhalf1**2
    ax2_2.plot(np.log10(core_gbar1),np.log10(core_gobs1),color='r',lw=0.5)
for i in range(0,len(core2_gbar0)):
    x=np.linspace(1.,core_massratio2[i],100)
    core_rhalf2=2**alpha_core_rhalf2*x**beta_core_rhalf2/(1.+x)**alpha_core_rhalf2
    core_mstar2=2**alpha_core_mstar2*x**beta_core_mstar2/(1.+x)**alpha_core_mstar2
    core_gbar2=gbar[dsph=='sgr']*core_mstar2/core_rhalf2**2
    core_gobs2=gobs[dsph=='sgr']*x/core_rhalf2**2
#    ax2_2.plot(np.log10(core_gbar2),np.log10(core_gobs2),color='r',lw=0.5,linestyle='--')

ax2_2.plot([1.e-100,1.e-90],[1.e-100,1.e-100],lw=1,color='b',label='cusp')
ax2_2.plot([1.e-100,1.e-90],[1.e-100,1.e-100],lw=1,color='r',label='core')
df44_rhalf=4600.
df44_mhalf=0.71e+10
df44_mstar=1.5e+8
df44_gbar=g*df44_mstar/df44_rhalf**2*(1000.**2)/3.09e+16
df44_gobs=g*df44_mhalf/df44_rhalf**2*(1000.**2)/3.09e+16
#ax2_2.scatter([np.log10(df44_gbar)],[np.log10(df44_gobs)],marker='s',s=10,color='k')
ax2_2.legend(loc=4,fontsize=6,handlelength=1,numpoints=1,scatterpoints=1,shadow=False)


plotfilename='sgr_gobsgbar_tracks.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
