#!/usr/bin/python
import numpy as np
import matplotlib
from astropy import units as u
from astropy.coordinates import SkyCoord,Distance,ICRS
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

cra2_racenter=177.310
cra2_deccenter=-18.413

cra2_data1='/physics2/mgwalker/chains/cra2gradientpost_equal_weights.dat'
out1='cra2_grfcommands.tex'
g1=open(out1,'w')

usolar0=-11.1 #               KM/S, SOLAR MOTION WRT LSR; DEHNEN & BINNEY 98
vsolar0=12.24 #               KM/S
wsolar0=7.25 #               KM/S
sigusolar0=1.
sigvsolar0=2.
sigwsolar0=0.5

vlsr=220.# LSR velocity, km/s
llsr=np.pi/2. #direction of LSR motion in Galactic coordinates, radians
blsr=0. #radians
vlsrx=220.
vlsry=0.
vlsrz=0.



with open(cra2_data1) as f: # read data file
    data=f.readlines()

cra2_vmean=[]

for line in data: # fill arrays
    p=line.split()
    cra2_vmean.append(float(p[4]))

cra2_vmean=np.array(cra2_vmean)

cra2_distance=Distance(120,u.kpc)

cra2_coords=SkyCoord(cra2_racenter,cra2_deccenter,unit=['deg','deg'])
cra2_lcenter=cra2_coords.galactic.l.radian
cra2_bcenter=cra2_coords.galactic.b.radian

cra2_usolar=np.random.normal(loc=usolar0,scale=sigusolar0,size=len(cra2_vmean))
cra2_vsolar=np.random.normal(loc=vsolar0,scale=sigvsolar0,size=len(cra2_vmean))
cra2_wsolar=np.random.normal(loc=wsolar0,scale=sigwsolar0,size=len(cra2_vmean))

cra2_vsolarx=cra2_vsolar
cra2_vsolary=cra2_usolar
cra2_vsolarz=cra2_wsolar

cra2_x=np.sin(cra2_lcenter)*np.cos(cra2_bcenter)
cra2_y=-np.cos(cra2_bcenter)*np.cos(cra2_lcenter)
cra2_z=np.sin(cra2_bcenter)
cra2_projlsr=vlsrx*cra2_x+vlsry*cra2_y+vlsrz*cra2_z
cra2_projsolar=cra2_vsolarx*cra2_x+cra2_vsolary*cra2_y+cra2_vsolarz*cra2_z
cra2_proj=cra2_projlsr+cra2_projsolar
cra2_vgrf=cra2_vmean+cra2_proj
cra2_statsvgrf=np.percentile(cra2_vgrf,[2.5,16.,50.,84.,97.5])

g1.write(r'\newcommand{\cragalacticl}{$'+str(round(cra2_lcenter*180./np.pi,3))+'$}'+'\n')
g1.write(r'\newcommand{\cragalacticb}{$'+str(round(cra2_bcenter*180./np.pi,3))+'$}'+'\n')
g1.write(r'\newcommand{\cravgrf}{$'+str(round(cra2_statsvgrf[2],1))+r'_{'+str(round(cra2_statsvgrf[1]-cra2_statsvgrf[2],1))+r'}'+r'^{+'+str(round(cra2_statsvgrf[3]-cra2_statsvgrf[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\cravgrfexpanded}{$'+str(round(cra2_statsvgrf[2],1))+r'_{'+str(round(cra2_statsvgrf[1]-cra2_statsvgrf[2],1))+r'('+str(round(cra2_statsvgrf[0]-cra2_statsvgrf[2],1))+r')}'+r'^{+'+str(round(cra2_statsvgrf[3]-cra2_statsvgrf[2],1))+r'(+'+str(round(cra2_statsvgrf[4]-cra2_statsvgrf[2],1))+r')}$'+r'}'+'\n')

g1.close()
