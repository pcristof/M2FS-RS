import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.isotonic import IsotonicRegression
from sklearn.utils import check_random_state
from astropy.coordinates import SkyCoord
from copy import deepcopy
from scipy.stats import chi2
import mycode
from astropy.io import fits
matplotlib.use('TkAgg')

#user input
###############################
fitsfile1='hecto_n2419_all.fits'
fitsfile2='hecto_n2419_weightedmeans.fits'
infile='nelson_n2419.dat'
outfile='nelson_n2419_em.dat'
plotfilename='nelson_n2419_em.pdf'
vcut1=-200.#artificial lower Vlos limit (km/s) for members (anything with Vlos<vcut1 is automatically given Pmem=0)
vcut2=200.#artificial upper Vlos limit (km/s) for members (anything with Vlos>vcut2 is automatically given Pmem=0)
iterations=500#number of iterations of EM algorithm
###############################

def standardcoords(rarad,decrad,racenter,deccenter):
    xi=np.zeros(len(rarad))
    eta=np.zeros(len(rarad))
    for i in range(len(rarad)):
        xi[i]=np.cos(decrad[i])*np.sin(rarad[i]-racenter)/(np.sin(deccenter)*np.sin(decrad[i])+np.cos(deccenter)*np.cos(decrad[i])*np.cos(rarad[i]-racenter))*180.*60./np.pi
        eta[i]=(np.cos(deccenter)*np.sin(decrad[i])-np.sin(deccenter)*np.cos(decrad[i])*np.cos(rarad[i]-racenter))/(np.sin(deccenter)*np.sin(decrad[i])+np.cos(deccenter)*np.cos(decrad[i])*np.cos(rarad[i]-racenter))*180.*60./np.pi
    return xi,eta

def stats(x,y,v,sigv,p,oldmean,olddisp,oldkx,oldky):
    n=np.size(x)
    disp2=np.sum(p*(v-oldmean-oldkx*x-oldky*y)**2/(1.+sigv**2/olddisp**2))/np.sum(p/(1.+sigv**2/olddisp**2))
    disp=np.sqrt(disp2)
    mean=np.sum(p*(v-oldkx*x-oldky*y)/(olddisp**2+sigv**2))/np.sum(p/(olddisp**2+sigv**2))
    kx=np.sum(p*x*(v-oldmean-oldky*y)/(olddisp**2+sigv**2))/np.sum(p*x**2/(olddisp**2+sigv**2))
    ky=np.sum(p*y*(v-oldmean-oldkx*x)/(olddisp**2+sigv**2))/np.sum(p*y**2/(olddisp**2+sigv**2))
    return mean,disp,kx,ky

def stats2(x,y,v,sigv,p,oldmean,olddisp,oldkr):
    n=np.size(x)
    r=np.sqrt(x**2+y**2)
    disp2=np.sum(p*(v-oldmean-oldkr*r)**2/(1.+sigv**2/olddisp**2))/np.sum(p/(1.+sigv**2/olddisp**2))
    disp=np.sqrt(disp2)
    mean=np.sum(p*(v-oldkr*r)/(olddisp**2+sigv**2))/np.sum(p/(olddisp**2+sigv**2))
    kr=np.sum(p*r*(v-oldmean)/(olddisp**2+sigv**2))/np.sum(p*r**2/(olddisp**2+sigv**2))
    return mean,disp,kr

#read input file into arrays for each column
#
with open(infile) as f:
    header=f.readlines()[0:1]
with open(infile) as f:
    data=f.readlines()[1:]
#initialize column arrays
radeg=[]
decdeg=[]
hjd=[]
snratio=[]
v=[]
sigv=[]
skewv=[]
kurtv=[]
teff=[]
sigteff=[]
skewteff=[]
kurtteff=[]
logg=[]
siglogg=[]
skewlogg=[]
kurtlogg=[]
z=[]
sigz=[]
skewz=[]
kurtz=[]
resolution=[]
sigresolution=[]
skewresolution=[]
kurtresolution=[]
mediansky=[]
stdmediansky=[]

#append data from input file
for line in data: # fill arrays
    p=line.split()
    radeg.append(float(p[0]))
    decdeg.append(float(p[1]))
    hjd.append(float(p[2]))
    snratio.append(float(p[3]))
    v.append(float(p[4]))
    sigv.append(float(p[5]))
    skewv.append(float(p[6]))
    kurtv.append(float(p[7]))
    teff.append(float(p[8]))
    sigteff.append(float(p[9]))
    skewteff.append(float(p[10]))
    kurtteff.append(float(p[11]))
    logg.append(float(p[12]))
    siglogg.append(float(p[13]))
    skewlogg.append(float(p[14]))
    kurtlogg.append(float(p[15]))
    z.append(float(p[16]))
    sigz.append(float(p[17]))
    skewz.append(float(p[18]))
    kurtz.append(float(p[19]))
    resolution.append(float(p[20]))
    sigresolution.append(float(p[21]))
    skewresolution.append(float(p[22]))
    kurtresolution.append(float(p[23]))
    mediansky.append(float(p[24]))
    stdmediansky.append(float(p[25]))
radeg=np.array(radeg)
decdeg=np.array(decdeg)
hjd=np.array(hjd)
snratio=np.array(snratio)
v=np.array(v)
sigv=np.array(sigv)
skewv=np.array(skewv)
kurtv=np.array(kurtv)
teff=np.array(teff)
sigteff=np.array(sigteff)
skewteff=np.array(skewteff)
kurtteff=np.array(kurtteff)
logg=np.array(logg)
siglogg=np.array(siglogg)
skewlogg=np.array(skewlogg)
kurtlogg=np.array(kurtlogg)
z=np.array(z)
sigz=np.array(sigz)
skewz=np.array(skewz)
kurtz=np.array(kurtz)
resolution=np.array(resolution)
sigresolution=np.array(sigresolution)
skewresolution=np.array(skewresolution)
kurtresolution=np.array(kurtresolution)
mediansky=np.array(mediansky)
stdmediansky=np.array(stdmediansky)


obs=np.zeros(len(v),dtype='int')
good=np.full((len(v)),False)
vchi2=np.zeros(len(v),dtype='float')
pvchi2=np.zeros(len(v),dtype='float')
starid=np.zeros(len(v),dtype='int')
vmean=np.zeros(len(v),dtype='float')
sigvmean=np.zeros(len(v),dtype='float')
teffmean=np.zeros(len(v),dtype='float')
sigteffmean=np.zeros(len(v),dtype='float')
loggmean=np.zeros(len(v),dtype='float')
sigloggmean=np.zeros(len(v),dtype='float')
zmean=np.zeros(len(v),dtype='float')
sigzmean=np.zeros(len(v),dtype='float')

ra=radeg*np.pi/180.#ra in radians
dec=decdeg*np.pi/180.# dec in radians
c=SkyCoord('07h38m08.51s','+38d52m54.9s',frame='icrs')
radegcenter=c.ra.deg
decdegcenter=c.dec.deg

#take median ra,dec as fiducial center
racenter=radegcenter*np.pi/180.#fiducial center in radians
deccenter=decdegcenter*np.pi/180.#fiducial center in radians
#get standard coordinates (xi,eta) about this nominal center - (xi,eta) have units of arcmin and give angular separation from fiducial center
xi,eta=standardcoords(ra,dec,racenter,deccenter)#arcmin
r=np.sqrt(xi**2+eta**2)

goods=np.where((sigv<5.)&(np.abs(skewv)<1.)&(np.abs(kurtv)<1.))[0]
good[goods]=True

counter=0
samestar=0.5
for i in range(0,len(radeg)):
    if((good[i])&(obs[i]==0)):
        counter=counter+1
        dist=np.sqrt((xi[i]-xi)**2+(eta[i]-eta)**2)*60.
        this=np.where((dist<samestar)&(good))[0]
        starid[this]=counter
        for j in range(0,len(this)):
            obs[this[j]]=j+1
        vmean[this],sigvmean[this]=mycode.weightedmean(deepcopy(v[this]),deepcopy(sigv[this]))
        teffmean[this],sigteffmean[this]=mycode.weightedmean(teff[this],sigteff[this])
        loggmean[this],sigloggmean[this]=mycode.weightedmean(logg[this],siglogg[this])
        zmean[this],sigzmean[this]=mycode.weightedmean(z[this],sigz[this])
        vchi2[this]=np.sum((v[this]-vmean[this[0]])**2/(sigv[this]**2))
        pvchi2[this]=chi2.cdf(vchi2[this[0]],len(this)-1)

keep=np.where(obs==1)[0]
pmem=np.zeros(len(ra))+0.5#initialize Pmem = 0.5 for all stars
pnon=1.-pmem

#initialize means, dispersions and gradients of Gaussian distributions that we will fit to V, pmRA and pmDec distributions.  I just use 0 for all the gradients ('gradx' and 'grady'), the mean of the observable for all the means ('center') and the standard deviation of the observable for all the dispersions ('scale'), for both members ('mem') and nonmembers ('non')
v_center_mem=np.mean(vmean[keep])
v_center_non=np.mean(vmean[keep])
z_center_mem=np.mean(zmean[keep])
z_center_non=np.mean(zmean[keep])
logg_center_mem=np.mean(loggmean[keep])
logg_center_non=np.mean(loggmean[keep])

v_scale_mem=np.std(vmean[keep])
v_scale_non=np.std(vmean[keep])
z_scale_mem=np.std(zmean[keep])
z_scale_non=np.std(zmean[keep])
logg_scale_mem=np.std(loggmean[keep])
logg_scale_non=np.std(loggmean[keep])

v_gradx_mem=0.
v_grady_mem=0.
z_gradr_mem=0.
logg_gradx_mem=0.
logg_grady_mem=0.

v_gradx_non=0.
v_grady_non=0.
z_gradr_non=0.
logg_gradx_non=0.
logg_grady_non=0.


#perform isotonic regression to initialize member fraction as function of distance (from line that represents stream locus)
ir=IsotonicRegression()
fraction0=1.-ir.fit_transform(r[keep],pnon[keep])
fraction=np.zeros(len(v),dtype='float')
for i in range(0,len(keep)):
    fraction[keep[i]]=fraction0[i]

#now iterate the EM algorithm
for i in range(0,iterations):
    #estimate mean, dispersion, gradient in x, gradient in y for v, pmRA, pmDec, for both members and non-members (using Pmem as weights)
    v_center_mem,v_scale_mem,v_gradx_mem,v_grady_mem=stats(xi[keep],eta[keep],vmean[keep],sigvmean[keep],pmem[keep],v_center_mem,v_scale_mem,v_gradx_mem,v_grady_mem)
    v_center_non,v_scale_non,v_gradx_non,v_grady_non=stats(xi[keep],eta[keep],vmean[keep],sigvmean[keep],pnon[keep],v_center_non,v_scale_non,v_gradx_non,v_grady_non)
    z_center_mem,z_scale_mem,z_gradr_mem=stats2(xi[keep],eta[keep],zmean[keep],sigzmean[keep],pmem[keep],z_center_mem,z_scale_mem,z_gradr_mem)
    z_center_non,z_scale_non,z_gradr_non=stats2(xi[keep],eta[keep],zmean[keep],sigzmean[keep],pnon[keep],z_center_non,z_scale_non,z_gradr_non)
    logg_center_mem,logg_scale_mem,logg_gradx_mem,logg_grady_mem=stats(xi[keep],eta[keep],loggmean[keep],sigloggmean[keep],pmem[keep],logg_center_mem,logg_scale_mem,logg_gradx_mem,logg_grady_mem)
    logg_center_non,logg_scale_non,logg_gradx_non,logg_grady_non=stats(xi[keep],eta[keep],loggmean[keep],sigloggmean[keep],pnon[keep],logg_center_non,logg_scale_non,logg_gradx_non,logg_grady_non)

    #compute probability density corresponding to each observable, for both member and nonmember distributions, given the means/dispersions/gradients estimated above
    v_pm=1./(2.*np.pi*np.sqrt(v_scale_mem**2+sigvmean**2))*np.exp(-0.5*(vmean-v_center_mem-v_gradx_mem*xi-v_grady_mem*eta)**2/(v_scale_mem**2+sigvmean**2))
    v_pn=1./(2.*np.pi*np.sqrt(v_scale_non**2+sigvmean**2))*np.exp(-0.5*(vmean-v_center_non-v_gradx_non*xi-v_grady_non*eta)**2/(v_scale_non**2+sigvmean**2))
    z_pm=1./(2.*np.pi*np.sqrt(z_scale_mem**2+sigzmean**2))*np.exp(-0.5*(zmean-z_center_mem-z_gradr_mem*r)**2/(z_scale_mem**2+sigzmean**2))
    z_pn=1./(2.*np.pi*np.sqrt(z_scale_non**2+sigzmean**2))*np.exp(-0.5*(zmean-z_center_non-z_gradr_non*r)**2/(z_scale_non**2+sigzmean**2))
    logg_pm=1./(2.*np.pi*np.sqrt(logg_scale_mem**2+sigloggmean**2))*np.exp(-0.5*(loggmean-logg_center_mem-logg_gradx_mem*xi-logg_grady_mem*eta)**2/(logg_scale_mem**2+sigloggmean**2))
    logg_pn=1./(2.*np.pi*np.sqrt(logg_scale_non**2+sigloggmean**2))*np.exp(-0.5*(loggmean-logg_center_non-logg_gradx_non*xi-logg_grady_non*eta)**2/(logg_scale_non**2+sigloggmean**2))
    pm=v_pm*z_pm#product of all individual-dimension probability densities (for V, pmRA, pmDec) for members
    pn=v_pn*z_pn#product of all individual-dimension probability densities (for V, pmRA, pmDec) for nonmembers
    #update membership probabilities
    pmem=fraction*pm/(fraction*pm+(1.-fraction)*pn)

    #impose artificial membership cuts based on V
    for j in range(0,len(v)):
        if v[j]<vcut1:
            pmem[j]=0.
        if v[j]>vcut2:
            pmem[j]=0.

    pnon=1.-pmem

#perform isotonic regression to initialize member fraction as function of distance (from line that represents stream locus)
    ir=IsotonicRegression()
    fraction0=1.-ir.fit_transform(r[keep],pnon[keep])
    for j in range(0,len(keep)):
        fraction[keep[j]]=fraction0[j]

    #print output to screen
    print('Iteration ',i+1)
    print('V_center_mem, V_scale_mem, V_center_non, V_scale_non, V_gradx_mem, V_grady_mem, V_gradx_non, V_grady_non')
    print('units are km/s and km/s/arcmin')
    print(v_center_mem,v_scale_mem,v_center_non,v_scale_non,v_gradx_mem,v_grady_mem,v_gradx_non,v_grady_non)
    print('Z_center_mem, Z_scale_mem, Z_center_non, Z_scale_non, Z_gradr_mem, Z_gradr_non,')
    print('units are Angstroms and Angstroms/arcmin')
    print(z_center_mem,z_scale_mem,z_center_non,z_scale_non,z_gradr_mem,z_gradr_non)
    print('logg_center_mem, logg_scale_mem, logg_center_non, logg_scale_non, logg_gradx_mem, logg_grady_mem, logg_gradx_non, logg_grady_non')
    print('units are cgs')
    print(logg_center_mem,logg_scale_mem,logg_center_non,logg_scale_non,logg_gradx_mem,logg_grady_mem,logg_gradx_non,logg_grady_non)
    print('sum(Pmem), sum(Pnon)')
    print(np.sum(pmem[keep]),np.sum(pnon[keep]))
    print(' ')

#write output file that appends Pmem to input data
g1=open(outfile,'w')
for line in header:
    p=line.split('\n')
    g1.write('# object ID # observation '+p[0]+' # mean_vhelio [km/s] # err_mean_vhelio [km/s] # mean_Teff [K] # err_mean_Teff [K] # mean_logg # err_mean_logg # mean_Fe/H # err_mean_Fe/H # Pmember \n')

col1=fits.Column(name='id',format='A6',array=starid)
col2=fits.Column(name='obs',format='A3',array=obs)
col3=fits.Column(name='ra_deg',format='D',array=radeg)
col4=fits.Column(name='dec_deg',format='D',array=decdeg)
col5=fits.Column(name='hjd',format='D',array=hjd)
col6=fits.Column(name='sn_ratio',format='D',array=snratio)
col7=fits.Column(name='v',format='D',array=v)
col8=fits.Column(name='sig_v',format='D',array=sigv)
col9=fits.Column(name='skew_v',format='D',array=skewv)
col10=fits.Column(name='kurt_v',format='D',array=kurtv)
col11=fits.Column(name='teff',format='D',array=teff)
col12=fits.Column(name='sig_teff',format='D',array=sigteff)
col13=fits.Column(name='skew_teff',format='D',array=skewteff)
col14=fits.Column(name='kurt_teff',format='D',array=kurtteff)
col15=fits.Column(name='logg',format='D',array=logg)
col16=fits.Column(name='sig_logg',format='D',array=siglogg)
col17=fits.Column(name='skew_logg',format='D',array=skewlogg)
col18=fits.Column(name='kurt_logg',format='D',array=kurtlogg)
col19=fits.Column(name='z',format='D',array=z)
col20=fits.Column(name='sig_z',format='D',array=sigz)
col21=fits.Column(name='skew_z',format='D',array=skewz)
col22=fits.Column(name='kurt_z',format='D',array=kurtz)
col23=fits.Column(name='resolution',format='D',array=resolution)
col24=fits.Column(name='sig_resolution',format='D',array=sigresolution)
col25=fits.Column(name='skew_resolution',format='D',array=skewresolution)
col26=fits.Column(name='kurt_resolution',format='D',array=kurtresolution)
col27=fits.Column(name='mediansky',format='D',array=mediansky)
col28=fits.Column(name='std_mediansky',format='D',array=stdmediansky)
col29=fits.Column(name='v_mean',format='D',array=vmean)
col30=fits.Column(name='sig_v_mean',format='D',array=sigvmean)
col31=fits.Column(name='teff_mean',format='D',array=teffmean)
col32=fits.Column(name='sig_teff_mean',format='D',array=sigteffmean)
col33=fits.Column(name='logg_mean',format='D',array=loggmean)
col34=fits.Column(name='sig_logg_mean',format='D',array=sigloggmean)
col35=fits.Column(name='z_mean',format='D',array=zmean)
col36=fits.Column(name='sig_z_mean',format='D',array=sigzmean)
col37=fits.Column(name='v_chi2',format='D',array=vchi2)
col38=fits.Column(name='v_chi2_cdf',format='D',array=pvchi2)
col39=fits.Column(name='p_member',format='D',array=pmem)
cols=fits.ColDefs([col1,col2,col3,col4,col5,col6,col7,col8,col9,col10,col11,col12,col13,col14,col15,col16,col17,col18,col19,col20,col21,col22,col23,col24,col25,col26,col27,col28,col29,col30,col31,col32,col33,col34,col35,col36,col37,col38,col39])
hdu=fits.BinTableHDU.from_columns(cols)
hdu.writeto(fitsfile1,overwrite=True)

keep=np.where((good)&(obs==1))[0]
col1=fits.Column(name='id',format='A6',array=starid[keep])
col2=fits.Column(name='ra_deg',format='D',array=radeg[keep])
col3=fits.Column(name='dec_deg',format='D',array=decdeg[keep])
col4=fits.Column(name='v_mean',format='D',array=vmean[keep])
col5=fits.Column(name='sig_v_mean',format='D',array=sigvmean[keep])
col6=fits.Column(name='teff_mean',format='D',array=teffmean[keep])
col7=fits.Column(name='sig_teff_mean',format='D',array=sigteffmean[keep])
col8=fits.Column(name='logg_mean',format='D',array=loggmean[keep])
col9=fits.Column(name='sig_logg_mean',format='D',array=sigloggmean[keep])
col10=fits.Column(name='z_mean',format='D',array=zmean[keep])
col11=fits.Column(name='sig_z_mean',format='D',array=sigzmean[keep])
col12=fits.Column(name='v_chi2',format='D',array=vchi2[keep])
col13=fits.Column(name='v_chi2_cdf',format='D',array=pvchi2[keep])
col14=fits.Column(name='p_member',format='D',array=pmem[keep])
cols=fits.ColDefs([col1,col2,col3,col4,col5,col6,col7,col8,col9,col10,col11,col12,col13,col14])
hdu=fits.BinTableHDU.from_columns(cols)
hdu.writeto(fitsfile2,overwrite=True)

for i in range(0,len(radeg)):
    if obs[i]==1:
        this=np.where(starid==starid[i])[0]
        for j in range(0,len(this)):
#            print(str.format('{0:.7f}',round(radeg[this[j]])).zfill(7))
            string=str.format('{0:.0f}',starid[this[j]]).zfill(0)+' '+str.format('{0:.0f}',obs[this[j]],0).zfill(0)+' '+str.format('{0:.7f}',round(radeg[this[j]],7)).zfill(7)+' '+str.format('{0:.7f}',round(decdeg[this[j]],7)).zfill(7)+' '+str.format('{0:.3f}',round(hjd[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(snratio[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(v[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(sigv[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(skewv[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(kurtv[this[j]],3)).zfill(3)+' '+str.format('{0:.1f}',round(teff[this[j]],1)).zfill(1)+' '+str.format('{0:.1f}',round(sigteff[this[j]],1)).zfill(1)+' '+str.format('{0:.1f}',round(skewteff[this[j]],1)).zfill(1)+' '+str.format('{0:.1f}',round(kurtteff[this[j]],1)).zfill(1)+' '+str.format('{0:.3f}',round(logg[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(siglogg[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(skewlogg[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(kurtlogg[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(z[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(sigz[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(skewz[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(kurtz[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(resolution[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(sigresolution[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(skewresolution[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(kurtresolution[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(mediansky[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(stdmediansky[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(vmean[this[j]],2)).zfill(2)+' '+str.format('{0:.3f}',round(sigvmean[this[j]],2)).zfill(2)+' '+str.format('{0:.0f}',round(teffmean[this[j]],0)).zfill(0)+' '+str.format('{0:.0f}',round(sigteffmean[this[j]],0)).zfill(3)+' '+str.format('{0:.2f}',round(loggmean[this[j]],2)).zfill(2)+' '+str.format('{0:.2f}',round(sigloggmean[this[j]],2)).zfill(2)+' '+str.format('{0:.3f}',round(zmean[this[j]],3)).zfill(3)+' '+str.format('{0:.3f}',round(sigzmean[this[j]],3)).zfill(3)+' '+str.format('{:.4f}',round(np.log10(pmem[this[j]]),4)).zfill(4)+' \n'
            g1.write(string)
g1.close()

#gs=plt.GridSpec(7,7) # define multi-panel plot
#gs.update(wspace=0,hspace=0) # specify inter-panel spacing
#fig=plt.figure(figsize=(6,6)) # define plot size
#ax=fig.add_subplot(gs[0:6,0:6])

#plt.savefig(plotfilename,dpi=400)
#plt.show()
#plt.close()
