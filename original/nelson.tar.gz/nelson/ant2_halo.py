import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='False')
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='5')
plt.rc('ytick',labelsize='5')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

g=0.004317
h0=70.
triangle=200.
rhocrit=3.*(h0**2)/8./np.pi/6.67e-11/((3.09e13)**2)/((1.e+6)**2)*((3.09e+16)**3)/2.e+30
rhomin=triangle*rhocrit
  
rhalf=2860.
          
with open('/physics2/mgwalker/chains/ant2halopost_equal_weights.dat') as f: # read data file
    data=f.readlines()
m200=[]
c200=[]
rcore=[]
rtide=[]
deltahalo=[]
ncore=[]
rslightindex=[]
for line in data: # fill arrays
    p=line.split()
    m200.append(float(p[0]))
    c200.append(float(p[1]))
    rcore.append(float(p[2]))
    rtide.append(float(p[3]))
    deltahalo.append(float(p[4]))
    ncore.append(float(p[5]))
    rslightindex.append(float(p[6]))
m200=np.array(m200)
c200=np.array(c200)
rcore=np.array(rcore)
rtide=np.array(rtide)
deltahalo=np.array(deltahalo)
ncore=np.array(ncore)
rslightindex=np.array(rslightindex)

m200=10.**m200
c200=10.**c200
rcore=10.**rcore
rtide=10.**rtide

r200=(3./4.*m200/np.pi/rhomin)**0.33333
gc=1./(np.log(1.+c200)-c200/(1.+c200))
rshalo=r200/c200
rhoshalo=rhomin*(c200**3)*gc/3.
rc=rshalo*rcore
rt=rshalo*rtide

with open('/physics2/mgwalker/chains/ant2halo_nfwpost_equal_weights.dat') as f: # read data file
    data=f.readlines()
nfw_m200=[]
nfw_c200=[]
nfw_rcore=[]
nfw_rtide=[]
nfw_deltahalo=[]
nfw_ncore=[]
nfw_rslightindex=[]
for line in data: # fill arrays
    p=line.split()
    nfw_m200.append(float(p[0]))
    nfw_c200.append(float(p[1]))
    nfw_rcore.append(float(p[2]))
    nfw_rtide.append(float(p[3]))
    nfw_deltahalo.append(float(p[4]))
    nfw_ncore.append(float(p[5]))
    nfw_rslightindex.append(float(p[6]))
nfw_m200=np.array(nfw_m200)
nfw_c200=np.array(nfw_c200)
nfw_rcore=np.array(nfw_rcore)
nfw_rtide=np.array(nfw_rtide)
nfw_deltahalo=np.array(nfw_deltahalo)
nfw_ncore=np.array(nfw_ncore)
nfw_rslightindex=np.array(nfw_rslightindex)

nfw_m200=10.**nfw_m200
nfw_c200=10.**nfw_c200
nfw_rcore=10.**nfw_rcore
nfw_rtide=10.**nfw_rtide

nfw_r200=(3./4.*nfw_m200/np.pi/rhomin)**0.33333
nfw_gc=1./(np.log(1.+nfw_c200)-nfw_c200/(1.+nfw_c200))
nfw_rshalo=nfw_r200/nfw_c200
nfw_rhoshalo=rhomin*(nfw_c200**3)*nfw_gc/3.
nfw_rc=nfw_rshalo*nfw_rcore
nfw_rt=nfw_rshalo*nfw_rtide

with open('/physics2/mgwalker/chains/ant2halo_nfwtidepost_equal_weights.dat') as f: # read data file
    data=f.readlines()
nfwtide_m200=[]
nfwtide_c200=[]
nfwtide_rcore=[]
nfwtide_rtide=[]
nfwtide_deltahalo=[]
nfwtide_ncore=[]
nfwtide_rslightindex=[]
for line in data: # fill arrays
    p=line.split()
    nfwtide_m200.append(float(p[0]))
    nfwtide_c200.append(float(p[1]))
    nfwtide_rcore.append(float(p[2]))
    nfwtide_rtide.append(float(p[3]))
    nfwtide_deltahalo.append(float(p[4]))
    nfwtide_ncore.append(float(p[5]))
    nfwtide_rslightindex.append(float(p[6]))
nfwtide_m200=np.array(nfwtide_m200)
nfwtide_c200=np.array(nfwtide_c200)
nfwtide_rcore=np.array(nfwtide_rcore)
nfwtide_rtide=np.array(nfwtide_rtide)
nfwtide_deltahalo=np.array(nfwtide_deltahalo)
nfwtide_ncore=np.array(nfwtide_ncore)
nfwtide_rslightindex=np.array(nfwtide_rslightindex)

nfwtide_m200=10.**nfwtide_m200
nfwtide_c200=10.**nfwtide_c200
nfwtide_rcore=10.**nfwtide_rcore
nfwtide_rtide=10.**nfwtide_rtide

nfwtide_r200=(3./4.*nfwtide_m200/np.pi/rhomin)**0.33333
nfwtide_gc=1./(np.log(1.+nfwtide_c200)-nfwtide_c200/(1.+nfwtide_c200))
nfwtide_rshalo=nfwtide_r200/nfwtide_c200
nfwtide_rhoshalo=rhomin*(nfwtide_c200**3)*nfwtide_gc/3.
nfwtide_rc=nfwtide_rshalo*nfwtide_rcore
nfwtide_rt=nfwtide_rshalo*nfwtide_rtide




with open('/physics2/mgwalker/chains/ant2halo_corepost_equal_weights.dat') as f: # read data file
    data=f.readlines()
core_m200=[]
core_c200=[]
core_rcore=[]
core_rtide=[]
core_deltahalo=[]
core_ncore=[]
core_rslightindex=[]
for line in data: # fill arrays
    p=line.split()
    core_m200.append(float(p[0]))
    core_c200.append(float(p[1]))
    core_rcore.append(float(p[2]))
    core_rtide.append(float(p[3]))
    core_deltahalo.append(float(p[4]))
    core_ncore.append(float(p[5]))
    core_rslightindex.append(float(p[6]))
core_m200=np.array(core_m200)
core_c200=np.array(core_c200)
core_rcore=np.array(core_rcore)
core_rtide=np.array(core_rtide)
core_deltahalo=np.array(core_deltahalo)
core_ncore=np.array(core_ncore)
core_rslightindex=np.array(core_rslightindex)

core_m200=10.**core_m200
core_c200=10.**core_c200
core_rcore=10.**core_rcore
core_rtide=10.**core_rtide

core_r200=(3./4.*core_m200/np.pi/rhomin)**0.33333
core_gc=1./(np.log(1.+core_c200)-core_c200/(1.+core_c200))
core_rshalo=core_r200/core_c200
core_rhoshalo=rhomin*(core_c200**3)*core_gc/3.
core_rc=core_rshalo*core_rcore
core_rt=core_rshalo*core_rtide

gs=plt.GridSpec(7,7) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
#fig.set_

ax2_4=fig.add_subplot(gs[0:6,0:6])
#ax2_4.hist(np.log10(m200),color='k',bins=50,alpha=1,lw=3,normed=False,histtype='step',rwidth=0)
#ax2_4.hist(np.log10(nfw_m200),color='r',bins=50,alpha=1,lw=3,normed=False,histtype='step',rwidth=0)
#ax2_4.hist(np.log10(nfwtide_m200),color='c',bins=50,alpha=1,lw=3,normed=False,histtype='step',rwidth=0)
#ax2_4.hist(np.log10(core_m200),color='b',bins=50,alpha=1,lw=3,normed=False,histtype='step',rwidth=0)

#ax2_4.hist(np.log10(rhalf/r200),color='k',bins=50,alpha=1,lw=3,normed=False,histtype='step',rwidth=0)
ax2_4.hist(np.log10(rhalf/nfw_r200),color='r',bins=50,alpha=1,lw=3,normed=False,histtype='step',rwidth=0)
ax2_4.hist(np.log10(rhalf/nfwtide_r200),color='c',bins=50,alpha=1,lw=3,normed=False,histtype='step',rwidth=0)
ax2_4.hist(np.log10(rhalf/core_r200),color='b',bins=50,alpha=1,lw=3,normed=False,histtype='step',rwidth=0)

plotfilename='ant2_halo.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
