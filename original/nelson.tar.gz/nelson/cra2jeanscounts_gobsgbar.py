import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.5)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='6')
plt.rc('ytick',labelsize='6')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

g=0.0043# grav constant in galaxy units        
    
with open('cra2jeans_profile.vdisp') as f: # read data file
    data=f.readlines()
r=[]
sigr=[]
vmean=[]
sigvmean=[]
vdisp=[]
sigvdisp=[]
membin=[]
nbin=[]
rpc=[]
sigrpc=[]
for line in data: # fill arrays
    p=line.split()
    r.append(float(p[0]))
    sigr.append(float(p[1]))
    vmean.append(float(p[2]))
    sigvmean.append(float(p[3]))
    vdisp.append(float(p[4]))
    sigvdisp.append(float(p[5]))
    membin.append(float(p[6]))
    nbin.append(float(p[7]))
    rpc.append(float(p[8]))
    sigrpc.append(float(p[9]))

r=np.array(r)
sigr=np.array(sigr)
vmean=np.array(vmean)
sigvmean=np.array(sigvmean)
vdisp=np.array(vdisp)
sigvdisp=np.array(sigvdisp)
membin=np.array(membin)
nbin=np.array(nbin)
rpc=np.array(rpc)
sigrpc=np.array(sigrpc)

with open('cra2jeanslight_profile.vdisp') as f: # read data file
    data=f.readlines()
light_r=[]
light_sigr=[]
light_vmean=[]
light_sigvmean=[]
light_vdisp=[]
light_sigvdisp=[]
light_membin=[]
light_nbin=[]
light_rpc=[]
light_sigrpc=[]
for line in data: # fill arrays
    p=line.split()
    light_r.append(float(p[0]))
    light_sigr.append(float(p[1]))
    light_vmean.append(float(p[2]))
    light_sigvmean.append(float(p[3]))
    light_vdisp.append(float(p[4]))
    light_sigvdisp.append(float(p[5]))
    light_membin.append(float(p[6]))
    light_nbin.append(float(p[7]))
    light_rpc.append(float(p[8]))
    light_sigrpc.append(float(p[9]))

light_r=np.array(light_r)
light_sigr=np.array(light_sigr)
light_vmean=np.array(light_vmean)
light_sigvmean=np.array(light_sigvmean)
light_vdisp=np.array(light_vdisp)
light_sigvdisp=np.array(light_sigvdisp)
light_membin=np.array(light_membin)
light_nbin=np.array(light_nbin)
light_rpc=np.array(light_rpc)
light_sigrpc=np.array(light_sigrpc)

with open('/physics2/mgwalker/chains/cra2jeanscounts.profiles') as f: # read data file
    data=f.readlines()
cra2rho_rad=[]
cra2rho_radpc=[]
cra2rho_rho=[]
cra2rho_rholo1=[]
cra2rho_rholo2=[]
cra2rho_rhohi1=[]
cra2rho_rhohi2=[]
cra2rho_mass=[]
cra2rho_masslo1=[]
cra2rho_masslo2=[]
cra2rho_masshi1=[]
cra2rho_masshi2=[]
cra2rho_vdisp=[]
cra2rho_vdisplo1=[]
cra2rho_vdisplo2=[]
cra2rho_vdisphi1=[]
cra2rho_vdisphi2=[]
cra2rho_nstar=[]
cra2rho_nstarlo1=[]
cra2rho_nstarlo2=[]
cra2rho_nstarhi1=[]
cra2rho_nstarhi2=[]
cra2rho_stellarmass=[]
cra2rho_stellarmasslo1=[]
cra2rho_stellarmasslo2=[]
cra2rho_stellarmasshi1=[]
cra2rho_stellarmasshi2=[]
cra2rho_nustar=[]
cra2rho_nustarlo1=[]
cra2rho_nustarlo2=[]
cra2rho_nustarhi1=[]
cra2rho_nustarhi2=[]
cra2rho_mtot=[]
cra2rho_mtotlo1=[]
cra2rho_mtotlo2=[]
cra2rho_mtothi1=[]
cra2rho_mtothi2=[]
cra2rho_dmfraction=[]
cra2rho_dmfractionlo1=[]
cra2rho_dmfractionlo2=[]
cra2rho_dmfractionhi1=[]
cra2rho_dmfractionhi2=[]
cra2rho_dratio=[]
cra2rho_dratiolo1=[]
cra2rho_dratiolo2=[]
cra2rho_dratiohi1=[]
cra2rho_dratiohi2=[]
cra2rho_rhostar=[]
cra2rho_rhostarlo1=[]
cra2rho_rhostarlo2=[]
cra2rho_rhostarhi1=[]
cra2rho_rhostarhi2=[]
cra2rho_mstacy=[]
cra2rho_mstacylo1=[]
cra2rho_mstacylo2=[]
cra2rho_mstacyhi1=[]
cra2rho_mstacyhi2=[]
cra2rho_slopedm=[]
cra2rho_slopedmlo1=[]
cra2rho_slopedmlo2=[]
cra2rho_slopedmhi1=[]
cra2rho_slopedmhi2=[]
cra2rho_gbar=[]
cra2rho_gbarlo1=[]
cra2rho_gbarlo2=[]
cra2rho_gbarhi1=[]
cra2rho_gbarhi2=[]
cra2rho_gobs=[]
cra2rho_gobslo1=[]
cra2rho_gobslo2=[]
cra2rho_gobshi1=[]
cra2rho_gobshi2=[]

for line in data: # fill arrays
    p=line.split()
    cra2rho_rad.append(float(p[0]))
    cra2rho_radpc.append(float(p[1]))
    cra2rho_rho.append(float(p[17]))
    cra2rho_rholo1.append(float(p[18]))
    cra2rho_rholo2.append(float(p[20]))
    cra2rho_rhohi1.append(float(p[19]))
    cra2rho_rhohi2.append(float(p[21]))
    cra2rho_mass.append(float(p[22]))
    cra2rho_masslo1.append(float(p[23]))
    cra2rho_masslo2.append(float(p[25]))
    cra2rho_masshi1.append(float(p[24]))
    cra2rho_masshi2.append(float(p[26]))
    cra2rho_vdisp.append(float(p[27]))
    cra2rho_vdisplo1.append(float(p[28]))
    cra2rho_vdisplo2.append(float(p[30]))
    cra2rho_vdisphi1.append(float(p[29]))
    cra2rho_vdisphi2.append(float(p[31]))
    cra2rho_nstar.append(float(p[32]))
    cra2rho_nstarlo1.append(float(p[33]))
    cra2rho_nstarlo2.append(float(p[35]))
    cra2rho_nstarhi1.append(float(p[34]))
    cra2rho_nstarhi2.append(float(p[36]))
    cra2rho_stellarmass.append(float(p[37]))
    cra2rho_stellarmasslo1.append(float(p[38]))
    cra2rho_stellarmasslo2.append(float(p[40]))
    cra2rho_stellarmasshi1.append(float(p[39]))
    cra2rho_stellarmasshi2.append(float(p[41]))
    cra2rho_nustar.append(float(p[42]))
    cra2rho_nustarlo1.append(float(p[43]))
    cra2rho_nustarlo2.append(float(p[45]))
    cra2rho_nustarhi1.append(float(p[44]))
    cra2rho_nustarhi2.append(float(p[46]))
    cra2rho_mtot.append(float(p[47]))
    cra2rho_mtotlo1.append(float(p[48]))
    cra2rho_mtotlo2.append(float(p[50]))
    cra2rho_mtothi1.append(float(p[49]))
    cra2rho_mtothi2.append(float(p[51]))
    cra2rho_dmfraction.append(float(p[52]))
    cra2rho_dmfractionlo1.append(float(p[53]))
    cra2rho_dmfractionlo2.append(float(p[55]))
    cra2rho_dmfractionhi1.append(float(p[54]))
    cra2rho_dmfractionhi2.append(float(p[56]))
    cra2rho_dratio.append(float(p[57]))
    cra2rho_dratiolo1.append(float(p[58]))
    cra2rho_dratiolo2.append(float(p[60]))
    cra2rho_dratiohi1.append(float(p[59]))
    cra2rho_dratiohi2.append(float(p[61]))
    cra2rho_rhostar.append(float(p[62]))
    cra2rho_rhostarlo1.append(float(p[63]))
    cra2rho_rhostarlo2.append(float(p[65]))
    cra2rho_rhostarhi1.append(float(p[64]))
    cra2rho_rhostarhi2.append(float(p[66]))
    cra2rho_mstacy.append(float(p[67]))
    cra2rho_mstacylo1.append(float(p[68]))
    cra2rho_mstacylo2.append(float(p[70]))
    cra2rho_mstacyhi1.append(float(p[69]))
    cra2rho_mstacyhi2.append(float(p[71]))
    cra2rho_slopedm.append(float(p[72]))
    cra2rho_slopedmlo1.append(float(p[73]))
    cra2rho_slopedmlo2.append(float(p[75]))
    cra2rho_slopedmhi1.append(float(p[74]))
    cra2rho_slopedmhi2.append(float(p[76]))
    cra2rho_gbar.append(float(p[77]))
    cra2rho_gbarlo1.append(float(p[78]))
    cra2rho_gbarlo2.append(float(p[80]))
    cra2rho_gbarhi1.append(float(p[79]))
    cra2rho_gbarhi2.append(float(p[81]))
    cra2rho_gobs.append(float(p[82]))
    cra2rho_gobslo1.append(float(p[83]))
    cra2rho_gobslo2.append(float(p[85]))
    cra2rho_gobshi1.append(float(p[84]))
    cra2rho_gobshi2.append(float(p[86]))

cra2rho_rad=np.array(cra2rho_rad)
cra2rho_radpc=np.array(cra2rho_radpc)
cra2rho_rho=np.array(cra2rho_rho)
cra2rho_rholo1=np.array(cra2rho_rholo1)
cra2rho_rholo2=np.array(cra2rho_rholo2)
cra2rho_rhohi1=np.array(cra2rho_rhohi1)
cra2rho_rhohi2=np.array(cra2rho_rhohi2)
cra2rho_mass=np.array(cra2rho_mass)
cra2rho_masslo1=np.array(cra2rho_masslo1)
cra2rho_masslo2=np.array(cra2rho_masslo2)
cra2rho_masshi1=np.array(cra2rho_masshi1)
cra2rho_masshi2=np.array(cra2rho_masshi2)
cra2rho_vdisp=np.array(cra2rho_vdisp)
cra2rho_vdisplo1=np.array(cra2rho_vdisplo1)
cra2rho_vdisplo2=np.array(cra2rho_vdisplo2)
cra2rho_vdisphi1=np.array(cra2rho_vdisphi1)
cra2rho_vdisphi2=np.array(cra2rho_vdisphi2)
cra2rho_nstar=np.array(cra2rho_nstar)
cra2rho_nstarlo1=np.array(cra2rho_nstarlo1)
cra2rho_nstarlo2=np.array(cra2rho_nstarlo2)
cra2rho_nstarhi1=np.array(cra2rho_nstarhi1)
cra2rho_nstarhi2=np.array(cra2rho_nstarhi2)
cra2rho_stellarmass=np.array(cra2rho_stellarmass)
cra2rho_stellarmasslo1=np.array(cra2rho_stellarmasslo1)
cra2rho_stellarmasslo2=np.array(cra2rho_stellarmasslo2)
cra2rho_stellarmasshi1=np.array(cra2rho_stellarmasshi1)
cra2rho_stellarmasshi2=np.array(cra2rho_stellarmasshi2)
cra2rho_nustar=np.array(cra2rho_nustar)
cra2rho_nustarlo1=np.array(cra2rho_nustarlo1)
cra2rho_nustarlo2=np.array(cra2rho_nustarlo2)
cra2rho_nustarhi1=np.array(cra2rho_nustarhi1)
cra2rho_nustarhi2=np.array(cra2rho_nustarhi2)
cra2rho_mtot=np.array(cra2rho_mtot)
cra2rho_mtotlo1=np.array(cra2rho_mtotlo1)
cra2rho_mtotlo2=np.array(cra2rho_mtotlo2)
cra2rho_mtothi1=np.array(cra2rho_mtothi1)
cra2rho_mtothi2=np.array(cra2rho_mtothi2)
cra2rho_dmfraction=np.array(cra2rho_dmfraction)
cra2rho_dmfractionlo1=np.array(cra2rho_dmfractionlo1)
cra2rho_dmfractionlo2=np.array(cra2rho_dmfractionlo2)
cra2rho_dmfractionhi1=np.array(cra2rho_dmfractionhi1)
cra2rho_dmfractionhi2=np.array(cra2rho_dmfractionhi2)
cra2rho_dratio=np.array(cra2rho_dratio)
cra2rho_dratiolo1=np.array(cra2rho_dratiolo1)
cra2rho_dratiolo2=np.array(cra2rho_dratiolo2)
cra2rho_dratiohi1=np.array(cra2rho_dratiohi1)
cra2rho_dratiohi2=np.array(cra2rho_dratiohi2)
cra2rho_rhostar=np.array(cra2rho_rhostar)
cra2rho_rhostarlo1=np.array(cra2rho_rhostarlo1)
cra2rho_rhostarlo2=np.array(cra2rho_rhostarlo2)
cra2rho_rhostarhi1=np.array(cra2rho_rhostarhi1)
cra2rho_rhostarhi2=np.array(cra2rho_rhostarhi2)
cra2rho_mstacy=np.array(cra2rho_mstacy)
cra2rho_mstacylo1=np.array(cra2rho_mstacylo1)
cra2rho_mstacylo2=np.array(cra2rho_mstacylo2)
cra2rho_mstacyhi1=np.array(cra2rho_mstacyhi1)
cra2rho_mstacyhi2=np.array(cra2rho_mstacyhi2)
cra2rho_slopedm=np.array(cra2rho_slopedm)
cra2rho_slopedmlo1=np.array(cra2rho_slopedmlo1)
cra2rho_slopedmlo2=np.array(cra2rho_slopedmlo2)
cra2rho_slopedmhi1=np.array(cra2rho_slopedmhi1)
cra2rho_slopedmhi2=np.array(cra2rho_slopedmhi2)
cra2rho_gbar=np.array(cra2rho_gbar)
cra2rho_gbarlo1=np.array(cra2rho_gbarlo1)
cra2rho_gbarlo2=np.array(cra2rho_gbarlo2)
cra2rho_gbarhi1=np.array(cra2rho_gbarhi1)
cra2rho_gbarhi2=np.array(cra2rho_gbarhi2)
cra2rho_gobs=np.array(cra2rho_gobs)
cra2rho_gobslo1=np.array(cra2rho_gobslo1)
cra2rho_gobslo2=np.array(cra2rho_gobslo2)
cra2rho_gobshi1=np.array(cra2rho_gobshi1)
cra2rho_gobshi2=np.array(cra2rho_gobshi2)

with open('/physics2/mgwalker/chains/cra2counts.profiles') as f: # read data file
    data=f.readlines()
cra2counts_rad=[]
cra2counts_radpc=[]
cra2counts_mstacy=[]
cra2counts_mstacylo1=[]
cra2counts_mstacylo2=[]
cra2counts_mstacyhi1=[]
cra2counts_mstacyhi2=[]
cra2counts_rhostacy=[]
cra2counts_rhostacylo1=[]
cra2counts_rhostacylo2=[]
cra2counts_rhostacyhi1=[]
cra2counts_rhostacyhi2=[]
cra2counts_slopestacy=[]
cra2counts_slopestacylo1=[]
cra2counts_slopestacylo2=[]
cra2counts_slopestacyhi1=[]
cra2counts_slopestacyhi2=[]
cra2counts_slopestellarmass=[]
cra2counts_slopestellarmasslo1=[]
cra2counts_slopestellarmasslo2=[]
cra2counts_slopestellarmasshi1=[]
cra2counts_slopestellarmasshi2=[]

for line in data: # fill arrays
    p=line.split()
    cra2counts_rad.append(float(p[0]))
    cra2counts_radpc.append(float(p[1]))
    cra2counts_mstacy.append(float(p[27]))
    cra2counts_mstacylo1.append(float(p[28]))
    cra2counts_mstacylo2.append(float(p[30]))
    cra2counts_mstacyhi1.append(float(p[29]))
    cra2counts_mstacyhi2.append(float(p[31]))
    cra2counts_rhostacy.append(float(p[32]))
    cra2counts_rhostacylo1.append(float(p[33]))
    cra2counts_rhostacylo2.append(float(p[35]))
    cra2counts_rhostacyhi1.append(float(p[34]))
    cra2counts_rhostacyhi2.append(float(p[36]))
    cra2counts_slopestacy.append(float(p[37]))
    cra2counts_slopestacylo1.append(float(p[38]))
    cra2counts_slopestacylo2.append(float(p[40]))
    cra2counts_slopestacyhi1.append(float(p[39]))
    cra2counts_slopestacyhi2.append(float(p[41]))
    cra2counts_slopestellarmass.append(float(p[42]))
    cra2counts_slopestellarmasslo1.append(float(p[43]))
    cra2counts_slopestellarmasslo2.append(float(p[45]))
    cra2counts_slopestellarmasshi1.append(float(p[44]))
    cra2counts_slopestellarmasshi2.append(float(p[46]))

cra2counts_rad=np.array(cra2counts_rad)
cra2counts_radpc=np.array(cra2counts_radpc)
cra2counts_mstacy=np.array(cra2counts_mstacy)
cra2counts_mstacylo1=np.array(cra2counts_mstacylo1)
cra2counts_mstacylo2=np.array(cra2counts_mstacylo2)
cra2counts_mstacyhi1=np.array(cra2counts_mstacyhi1)
cra2counts_mstacyhi2=np.array(cra2counts_mstacyhi2)
cra2counts_rhostacy=np.array(cra2counts_rhostacy)
cra2counts_rhostacylo1=np.array(cra2counts_rhostacylo1)
cra2counts_rhostacylo2=np.array(cra2counts_rhostacylo2)
cra2counts_rhostacyhi1=np.array(cra2counts_rhostacyhi1)
cra2counts_rhostacyhi2=np.array(cra2counts_rhostacyhi2)
cra2counts_slopestacy=np.array(cra2counts_slopestacy)
cra2counts_slopestacylo1=np.array(cra2counts_slopestacylo1)
cra2counts_slopestacylo2=np.array(cra2counts_slopestacylo2)
cra2counts_slopestacyhi1=np.array(cra2counts_slopestacyhi1)
cra2counts_slopestacyhi2=np.array(cra2counts_slopestacyhi2)
cra2counts_slopestellarmass=np.array(cra2counts_slopestellarmass)
cra2counts_slopestellarmasslo1=np.array(cra2counts_slopestellarmasslo1)
cra2counts_slopestellarmasslo2=np.array(cra2counts_slopestellarmasslo2)
cra2counts_slopestellarmasshi1=np.array(cra2counts_slopestellarmasshi1)
cra2counts_slopestellarmasshi2=np.array(cra2counts_slopestellarmasshi2)

#cra2counts_m=cra2counts_mstacy
#cra2counts_mlo1=cra2counts_mstacylo1
#cra2counts_mhi1=cra2counts_mstacyhi1
#cra2counts_mlo2=cra2counts_mstacylo2
#cra2counts_mhi2=cra2counts_mstacyhi2
#cra2counts_logm=np.log10(cra2counts_mstacy)
#cra2counts_logmlo1=np.log10(cra2counts_mstacylo1)
#cra2counts_logmhi1=np.log10(cra2counts_mstacyhi1)
#cra2counts_logmlo2=np.log10(cra2counts_mstacylo2)
#cra2counts_logmhi2=np.log10(cra2counts_mstacyhi2)
#cra2counts_rad2=[]
#cra2counts_dm=[]
#cra2counts_dmlo1=[]
#cra2counts_dmhi1=[]
#cra2counts_dmlo2=[]
#cra2counts_dmhi2=[]
#cra2counts_dlogm=[]
#cra2counts_dlogmlo1=[]
#cra2counts_dlogmhi1=[]
#cra2counts_dlogmlo2=[]
#cra2counts_dlogmhi2=[]
#cra2counts_dr=[]
#cra2counts_dlogr=[]
#cra2counts_dlogrho=[]
#cra2counts_dlogrholo1=[]
#cra2counts_dlogrholo2=[]
#cra2counts_dlogrhohi1=[]
#cra2counts_dlogrhohi2=[]
#for i in range(1,len(cra2counts_rad)):
#    cra2counts_rad2.append(cra2counts_radpc[i])
#    cra2counts_dr.append(cra2counts_radpc[i]-cra2counts_radpc[i-1])
#    cra2counts_dlogr.append(np.log10(cra2counts_radpc[i])-np.log10(cra2counts_radpc[i-1]))
#    cra2counts_dm.append(cra2counts_m[i]-cra2counts_m[i-1])
#    cra2counts_dmlo1.append(cra2counts_mlo1[i]-cra2counts_mlo1[i-1])
#    cra2counts_dmlo2.append(cra2counts_mlo2[i]-cra2counts_mlo2[i-1])
#    cra2counts_dmhi1.append(cra2counts_mhi1[i]-cra2counts_mhi1[i-1])
#    cra2counts_dmhi2.append(cra2counts_mhi2[i]-cra2counts_mhi2[i-1])
#    cra2counts_dlogm.append(cra2counts_logm[i]-cra2counts_logm[i-1])
#    cra2counts_dlogmlo1.append(cra2counts_logmlo1[i]-cra2counts_logmlo1[i-1])
#    cra2counts_dlogmlo2.append(cra2counts_logmlo2[i]-cra2counts_logmlo2[i-1])
#    cra2counts_dlogmhi1.append(cra2counts_logmhi1[i]-cra2counts_logmhi1[i-1])
#    cra2counts_dlogmhi2.append(cra2counts_logmhi2[i]-cra2counts_logmhi2[i-1])
#cra2counts_rad2=np.array(cra2counts_rad2)
#cra2counts_dlogr=np.array(cra2counts_dlogr)
#cra2counts_dlogm=np.array(cra2counts_dlogm)
#cra2counts_dlogmlo1=np.array(cra2counts_dlogmlo1)
#cra2counts_dlogmlo2=np.array(cra2counts_dlogmlo2)
#cra2counts_dlogmhi1=np.array(cra2counts_dlogmhi1)
#cra2counts_dlogmhi2=np.array(cra2counts_dlogmhi2)
#cra2counts_dm=np.array(cra2counts_dm)
#cra2counts_dmlo1=np.array(cra2counts_dmlo1)
#cra2counts_dmlo2=np.array(cra2counts_dmlo2)
#cra2counts_dmhi1=np.array(cra2counts_dmhi1)
#cra2counts_dmhi2=np.array(cra2counts_dmhi2)
#
#cra2counts_rho=cra2counts_dm/cra2counts_dr/4./np.pi/cra2counts_rad2**2
#cra2counts_rholo1=cra2counts_dmlo1/cra2counts_dr/4./np.pi/cra2counts_rad2**2
#cra2counts_rholo2=cra2counts_dmlo2/cra2counts_dr/4./np.pi/cra2counts_rad2**2
#cra2counts_rhohi1=cra2counts_dmhi1/cra2counts_dr/4./np.pi/cra2counts_rad2**2
#cra2counts_rhohi2=cra2counts_dmhi2/cra2counts_dr/4./np.pi/cra2counts_rad2**2
#
#cra2counts_rad3=[]
#cra2counts_dr3=[]
#cra2counts_dlogr3=[]
#for i in range(1,len(cra2counts_rad2)):
#    cra2counts_rad3.append(cra2counts_rad2[i])
#    cra2counts_dr3.append(cra2counts_rad2[i]-cra2counts_rad2[i-1])
#    cra2counts_dlogr3.append(np.log10(cra2counts_rad2[i])-np.log10(cra2counts_rad2[i-1]))
#    cra2counts_dlogrho.append(np.log10(cra2counts_rho[i])-np.log10(cra2counts_rho[i-1]))
#    cra2counts_dlogrholo1.append(np.log10(cra2counts_rholo1[i])-np.log10(cra2counts_rholo1[i-1]))
#    cra2counts_dlogrholo2.append(np.log10(cra2counts_rholo2[i])-np.log10(cra2counts_rholo2[i-1]))
#    cra2counts_dlogrhohi1.append(np.log10(cra2counts_rhohi1[i])-np.log10(cra2counts_rhohi1[i-1]))
#    cra2counts_dlogrhohi2.append(np.log10(cra2counts_rhohi2[i])-np.log10(cra2counts_rhohi2[i-1]))
#cra2counts_dlogrho=np.array(cra2counts_dlogrho)
#cra2counts_dlogrholo1=np.array(cra2counts_dlogrholo1)
#cra2counts_dlogrholo2=np.array(cra2counts_dlogrholo2)
#cra2counts_dlogrhohi1=np.array(cra2counts_dlogrhohi1)
#cra2counts_dlogrhohi2=np.array(cra2counts_dlogrhohi2)
#cra2counts_dlogr3=np.array(cra2counts_dlogr3)
#cra2counts_dr3=np.array(cra2counts_dr3)
#cra2counts_rad3=np.array(cra2counts_rad3)
#cra2counts_dlnrhodlnr=cra2counts_dlogrho/cra2counts_dlogr3
#cra2counts_dlnrhodlnrlo1=cra2counts_dlogrholo1/cra2counts_dlogr3
#cra2counts_dlnrhodlnrlo2=cra2counts_dlogrholo2/cra2counts_dlogr3
#cra2counts_dlnrhodlnrhi1=cra2counts_dlogrhohi1/cra2counts_dlogr3
#cra2counts_dlnrhodlnrhi2=cra2counts_dlogrhohi2/cra2counts_dlogr3

with open('/physics2/mgwalker/chains/cra2jeanslight.profiles') as f: # read data file
    data=f.readlines()
cra2rholight_rad=[]
cra2rholight_radpc=[]
cra2rholight_rho=[]
cra2rholight_rholo1=[]
cra2rholight_rholo2=[]
cra2rholight_rhohi1=[]
cra2rholight_rhohi2=[]
cra2rholight_mass=[]
cra2rholight_masslo1=[]
cra2rholight_masslo2=[]
cra2rholight_masshi1=[]
cra2rholight_masshi2=[]
cra2rholight_vdisp=[]
cra2rholight_vdisplo1=[]
cra2rholight_vdisplo2=[]
cra2rholight_vdisphi1=[]
cra2rholight_vdisphi2=[]
cra2rholight_nstar=[]
cra2rholight_nstarlo1=[]
cra2rholight_nstarlo2=[]
cra2rholight_nstarhi1=[]
cra2rholight_nstarhi2=[]
cra2rholight_stellarmass=[]
cra2rholight_stellarmasslo1=[]
cra2rholight_stellarmasslo2=[]
cra2rholight_stellarmasshi1=[]
cra2rholight_stellarmasshi2=[]
cra2rholight_nustar=[]
cra2rholight_nustarlo1=[]
cra2rholight_nustarlo2=[]
cra2rholight_nustarhi1=[]
cra2rholight_nustarhi2=[]
cra2rholight_mtot=[]
cra2rholight_mtotlo1=[]
cra2rholight_mtotlo2=[]
cra2rholight_mtothi1=[]
cra2rholight_mtothi2=[]
cra2rholight_dmfraction=[]
cra2rholight_dmfractionlo1=[]
cra2rholight_dmfractionlo2=[]
cra2rholight_dmfractionhi1=[]
cra2rholight_dmfractionhi2=[]
cra2rholight_dratio=[]
cra2rholight_dratiolo1=[]
cra2rholight_dratiolo2=[]
cra2rholight_dratiohi1=[]
cra2rholight_dratiohi2=[]
cra2rholight_rhostar=[]
cra2rholight_rhostarlo1=[]
cra2rholight_rhostarlo2=[]
cra2rholight_rhostarhi1=[]
cra2rholight_rhostarhi2=[]

for line in data: # fill arrays
    p=line.split()
    cra2rholight_rad.append(float(p[0]))
    cra2rholight_radpc.append(float(p[1]))
    cra2rholight_rho.append(float(p[17]))
    cra2rholight_rholo1.append(float(p[18]))
    cra2rholight_rholo2.append(float(p[20]))
    cra2rholight_rhohi1.append(float(p[19]))
    cra2rholight_rhohi2.append(float(p[21]))
    cra2rholight_mass.append(float(p[22]))
    cra2rholight_masslo1.append(float(p[23]))
    cra2rholight_masslo2.append(float(p[25]))
    cra2rholight_masshi1.append(float(p[24]))
    cra2rholight_masshi2.append(float(p[26]))
    cra2rholight_vdisp.append(float(p[27]))
    cra2rholight_vdisplo1.append(float(p[28]))
    cra2rholight_vdisplo2.append(float(p[30]))
    cra2rholight_vdisphi1.append(float(p[29]))
    cra2rholight_vdisphi2.append(float(p[31]))
    cra2rholight_nstar.append(float(p[32]))
    cra2rholight_nstarlo1.append(float(p[33]))
    cra2rholight_nstarlo2.append(float(p[35]))
    cra2rholight_nstarhi1.append(float(p[34]))
    cra2rholight_nstarhi2.append(float(p[36]))
    cra2rholight_stellarmass.append(float(p[37]))
    cra2rholight_stellarmasslo1.append(float(p[38]))
    cra2rholight_stellarmasslo2.append(float(p[40]))
    cra2rholight_stellarmasshi1.append(float(p[39]))
    cra2rholight_stellarmasshi2.append(float(p[41]))
    cra2rholight_nustar.append(float(p[42]))
    cra2rholight_nustarlo1.append(float(p[43]))
    cra2rholight_nustarlo2.append(float(p[45]))
    cra2rholight_nustarhi1.append(float(p[44]))
    cra2rholight_nustarhi2.append(float(p[46]))
    cra2rholight_mtot.append(float(p[47]))
    cra2rholight_mtotlo1.append(float(p[48]))
    cra2rholight_mtotlo2.append(float(p[50]))
    cra2rholight_mtothi1.append(float(p[49]))
    cra2rholight_mtothi2.append(float(p[51]))
    cra2rholight_dmfraction.append(float(p[52]))
    cra2rholight_dmfractionlo1.append(float(p[53]))
    cra2rholight_dmfractionlo2.append(float(p[55]))
    cra2rholight_dmfractionhi1.append(float(p[54]))
    cra2rholight_dmfractionhi2.append(float(p[56]))
    cra2rholight_dratio.append(float(p[57]))
    cra2rholight_dratiolo1.append(float(p[58]))
    cra2rholight_dratiolo2.append(float(p[60]))
    cra2rholight_dratiohi1.append(float(p[59]))
    cra2rholight_dratiohi2.append(float(p[61]))
    cra2rholight_rhostar.append(float(p[62]))
    cra2rholight_rhostarlo1.append(float(p[63]))
    cra2rholight_rhostarlo2.append(float(p[65]))
    cra2rholight_rhostarhi1.append(float(p[64]))
    cra2rholight_rhostarhi2.append(float(p[66]))

cra2rholight_rad=np.array(cra2rholight_rad)
cra2rholight_radpc=np.array(cra2rholight_radpc)
cra2rholight_rho=np.array(cra2rholight_rho)
cra2rholight_rholo1=np.array(cra2rholight_rholo1)
cra2rholight_rholo2=np.array(cra2rholight_rholo2)
cra2rholight_rhohi1=np.array(cra2rholight_rhohi1)
cra2rholight_rhohi2=np.array(cra2rholight_rhohi2)
cra2rholight_mass=np.array(cra2rholight_mass)
cra2rholight_masslo1=np.array(cra2rholight_masslo1)
cra2rholight_masslo2=np.array(cra2rholight_masslo2)
cra2rholight_masshi1=np.array(cra2rholight_masshi1)
cra2rholight_masshi2=np.array(cra2rholight_masshi2)
cra2rholight_vdisp=np.array(cra2rholight_vdisp)
cra2rholight_vdisplo1=np.array(cra2rholight_vdisplo1)
cra2rholight_vdisplo2=np.array(cra2rholight_vdisplo2)
cra2rholight_vdisphi1=np.array(cra2rholight_vdisphi1)
cra2rholight_vdisphi2=np.array(cra2rholight_vdisphi2)
cra2rholight_nstar=np.array(cra2rholight_nstar)
cra2rholight_nstarlo1=np.array(cra2rholight_nstarlo1)
cra2rholight_nstarlo2=np.array(cra2rholight_nstarlo2)
cra2rholight_nstarhi1=np.array(cra2rholight_nstarhi1)
cra2rholight_nstarhi2=np.array(cra2rholight_nstarhi2)
cra2rholight_stellarmass=np.array(cra2rholight_stellarmass)
cra2rholight_stellarmasslo1=np.array(cra2rholight_stellarmasslo1)
cra2rholight_stellarmasslo2=np.array(cra2rholight_stellarmasslo2)
cra2rholight_stellarmasshi1=np.array(cra2rholight_stellarmasshi1)
cra2rholight_stellarmasshi2=np.array(cra2rholight_stellarmasshi2)
cra2rholight_nustar=np.array(cra2rholight_nustar)
cra2rholight_nustarlo1=np.array(cra2rholight_nustarlo1)
cra2rholight_nustarlo2=np.array(cra2rholight_nustarlo2)
cra2rholight_nustarhi1=np.array(cra2rholight_nustarhi1)
cra2rholight_nustarhi2=np.array(cra2rholight_nustarhi2)
cra2rholight_mtot=np.array(cra2rholight_mtot)
cra2rholight_mtotlo1=np.array(cra2rholight_mtotlo1)
cra2rholight_mtotlo2=np.array(cra2rholight_mtotlo2)
cra2rholight_mtothi1=np.array(cra2rholight_mtothi1)
cra2rholight_mtothi2=np.array(cra2rholight_mtothi2)
cra2rholight_dmfraction=np.array(cra2rholight_dmfraction)
cra2rholight_dmfractionlo1=np.array(cra2rholight_dmfractionlo1)
cra2rholight_dmfractionlo2=np.array(cra2rholight_dmfractionlo2)
cra2rholight_dmfractionhi1=np.array(cra2rholight_dmfractionhi1)
cra2rholight_dmfractionhi2=np.array(cra2rholight_dmfractionhi2)
cra2rholight_dratio=np.array(cra2rholight_dratio)
cra2rholight_dratiolo1=np.array(cra2rholight_dratiolo1)
cra2rholight_dratiolo2=np.array(cra2rholight_dratiolo2)
cra2rholight_dratiohi1=np.array(cra2rholight_dratiohi1)
cra2rholight_dratiohi2=np.array(cra2rholight_dratiohi2)
cra2rholight_rhostar=np.array(cra2rholight_rhostar)
cra2rholight_rhostarlo1=np.array(cra2rholight_rhostarlo1)
cra2rholight_rhostarlo2=np.array(cra2rholight_rhostarlo2)
cra2rholight_rhostarhi1=np.array(cra2rholight_rhostarhi1)
cra2rholight_rhostarhi2=np.array(cra2rholight_rhostarhi2)

with open('/physics2/mgwalker/chains/cra2gradientpost_equal_weights.dat') as f: # read data file
    data=f.readlines()

cra2vmean=[]
cra2vvar=[]
cra2fehmean=[]
cra2fehvar=[]
cra2like=[]

for line in data: # fill arrays
    p=line.split()
    cra2vmean.append(float(p[4]))
    cra2vvar.append(float(p[2]))
    cra2fehmean.append(float(p[5]))
    cra2fehvar.append(float(p[3]))
    cra2like.append(float(p[7]))

cra2vmean=np.array(cra2vmean)
cra2vvar=np.array(cra2vvar)
cra2fehmean=np.array(cra2fehmean)
cra2fehvar=np.array(cra2fehvar)
cra2like=np.array(cra2like)

cra2vdisp=np.sqrt(10.**cra2vvar)
cra2fehdisp=np.sqrt(10.**cra2fehvar)

cra2_vdisp0=np.array([np.median(cra2vdisp)])
cra2_sigvdisp0=np.array([np.std(cra2vdisp)])
cra2_feh=np.array([np.median(cra2fehmean)])
cra2_sigfeh=np.array([np.std(cra2fehmean)])
cra2_rhalf0=1066.
cra2_sigrhalf0=84.
cra2_rwolf=cra2_rhalf0*4./3.
cra2_sigrwolf=cra2_sigrhalf0*4./3.
cra2_rhalf=np.random.normal(loc=cra2_rhalf0,scale=cra2_sigrhalf0,size=len(cra2vdisp))
#cra2_sigrhalf=np.array([1.])
cra2_absvmag0=-8.2
cra2_sigabsvmag0=0.1
cra2_absvmag=np.random.normal(loc=cra2_absvmag0,scale=cra2_sigabsvmag0,size=len(cra2vdisp))
#cra2_sigabsvmag=np.array([0.1])
cra2_rho0=cra2_vdisp0**2/g/cra2_rhalf0**2
cra2_sigrho0=np.sqrt((2.*cra2_vdisp0/cra2_rhalf0**2/g*cra2_sigvdisp0)**2+(2.*cra2_vdisp0**2/g/cra2_rhalf0**3*cra2_sigrhalf0)**2)

cra2_luminosity0=10.**((cra2_absvmag0-4.83)/(-2.5))
cra2_luminosity=10.**((cra2_absvmag-4.83)/(-2.5))
cra2_sigluminosity0=np.log(10.)/2.5*10.**((cra2_absvmag0-4.83)/(-2.5))*cra2_sigabsvmag0
cra2_mrhalf0=5./2./0.0043*cra2_rhalf0*cra2_vdisp0**2
cra2_mwolf=4./0.0043*cra2_rhalf0*cra2_vdisp0**2
cra2_mrhalf=5./2./0.0043*cra2_rhalf*cra2vdisp**2
cra2_sigmrhalf0=np.sqrt(((5./2.*2.*cra2_rhalf0/0.0043*cra2_vdisp0)**2)*(cra2_sigvdisp0**2)+((5./2./0.0043*(cra2_vdisp0**2))**2)*cra2_sigrhalf0**2)
cra2_sigmwolf=np.sqrt(((4.*2.*cra2_rhalf0/0.0043*cra2_vdisp0)**2)*(cra2_sigvdisp0**2)+((4./0.0043*(cra2_vdisp0**2))**2)*cra2_sigrhalf0**2)
cra2_mlratio=cra2_mrhalf/(cra2_luminosity)
cra2_mlratio0=cra2_mrhalf0/cra2_luminosity0
cra2_sigmlratio0=np.sqrt((cra2_sigmrhalf0**2)/(cra2_luminosity0**2)+((cra2_mrhalf0/cra2_luminosity0**2)**2)*cra2_sigluminosity0**2)

with open('/physics2/mgwalker/chains/cra2jeanslight.pv') as f:
    data=f.readlines()
jeanslightvel=[]
jeanslightvelmedian1=[]
jeanslightvello11=[]
jeanslightvelhi11=[]
jeanslightvello12=[]
jeanslightvelhi12=[]
jeanslightvelmedian3=[]
jeanslightvello31=[]
jeanslightvelhi31=[]
jeanslightvello32=[]
jeanslightvelhi32=[]
jeanslightvelmedian=[]
jeanslightvello1=[]
jeanslightvelhi1=[]
jeanslightvello2=[]
jeanslightvelhi2=[]
for line in data:
    p=line.split()
    jeanslightvel.append(float(p[0]))
    jeanslightvelmedian1.append(float(p[1]))
    jeanslightvello11.append(float(p[2]))
    jeanslightvelhi11.append(float(p[3]))
    jeanslightvello12.append(float(p[4]))
    jeanslightvelhi12.append(float(p[5]))
    jeanslightvelmedian3.append(float(p[6]))
    jeanslightvello31.append(float(p[7]))
    jeanslightvelhi31.append(float(p[8]))
    jeanslightvello32.append(float(p[9]))
    jeanslightvelhi32.append(float(p[10]))
    jeanslightvelmedian.append(float(p[11]))
    jeanslightvello1.append(float(p[12]))
    jeanslightvelhi1.append(float(p[13]))
    jeanslightvello2.append(float(p[14]))
    jeanslightvelhi2.append(float(p[15]))
jeanslightvel=np.array(jeanslightvel)
jeanslightvelmedian1=np.array(jeanslightvelmedian1)
jeanslightvello11=np.array(jeanslightvello11)
jeanslightvelhi11=np.array(jeanslightvelhi11)
jeanslightvello12=np.array(jeanslightvello12)
jeanslightvelhi12=np.array(jeanslightvelhi12)
jeanslightvelmedian3=np.array(jeanslightvelmedian3)
jeanslightvello31=np.array(jeanslightvello31)
jeanslightvelhi31=np.array(jeanslightvelhi31)
jeanslightvello32=np.array(jeanslightvello32)
jeanslightvelhi32=np.array(jeanslightvelhi32)
jeanslightvelmedian=np.array(jeanslightvelmedian)
jeanslightvello1=np.array(jeanslightvello1)
jeanslightvelhi1=np.array(jeanslightvelhi1)
jeanslightvello2=np.array(jeanslightvello2)
jeanslightvelhi2=np.array(jeanslightvelhi2)

with open('/physics2/mgwalker/chains/cra2jeans.pv') as f:
    data=f.readlines()
jeansvel=[]
jeansvelmedian1=[]
jeansvello11=[]
jeansvelhi11=[]
jeansvello12=[]
jeansvelhi12=[]
jeansvelmedian3=[]
jeansvello31=[]
jeansvelhi31=[]
jeansvello32=[]
jeansvelhi32=[]
jeansvelmedian=[]
jeansvello1=[]
jeansvelhi1=[]
jeansvello2=[]
jeansvelhi2=[]
for line in data:
    p=line.split()
    jeansvel.append(float(p[0]))
    jeansvelmedian1.append(float(p[1]))
    jeansvello11.append(float(p[2]))
    jeansvelhi11.append(float(p[3]))
    jeansvello12.append(float(p[4]))
    jeansvelhi12.append(float(p[5]))
    jeansvelmedian3.append(float(p[6]))
    jeansvello31.append(float(p[7]))
    jeansvelhi31.append(float(p[8]))
    jeansvello32.append(float(p[9]))
    jeansvelhi32.append(float(p[10]))
    jeansvelmedian.append(float(p[11]))
    jeansvello1.append(float(p[12]))
    jeansvelhi1.append(float(p[13]))
    jeansvello2.append(float(p[14]))
    jeansvelhi2.append(float(p[15]))
jeansvel=np.array(jeansvel)
jeansvelmedian1=np.array(jeansvelmedian1)
jeansvello11=np.array(jeansvello11)
jeansvelhi11=np.array(jeansvelhi11)
jeansvello12=np.array(jeansvello12)
jeansvelhi12=np.array(jeansvelhi12)
jeansvelmedian3=np.array(jeansvelmedian3)
jeansvello31=np.array(jeansvello31)
jeansvelhi31=np.array(jeansvelhi31)
jeansvello32=np.array(jeansvello32)
jeansvelhi32=np.array(jeansvelhi32)
jeansvelmedian=np.array(jeansvelmedian)
jeansvello1=np.array(jeansvello1)
jeansvelhi1=np.array(jeansvelhi1)
jeansvello2=np.array(jeansvello2)
jeansvelhi2=np.array(jeansvelhi2)

with open('/physics2/mgwalker/chains/cra2jeans.specpop') as f: # read data file
    data=f.readlines()[1:]
specpop_ra=[]
specpop_dec=[]
specpop_xi=[]
specpop_eta=[]
specpop_r=[]
specpop_theta=[]
specpop_hjd=[]
specpop_v=[]
specpop_sigv=[]
specpop_skewv=[]
specpop_kurtv=[]
specpop_teff=[]
specpop_sigteff=[]
specpop_skewteff=[]
specpop_kurtteff=[]
specpop_logg=[]
specpop_siglogg=[]
specpop_skewlogg=[]
specpop_kurtlogg=[]
specpop_z=[]
specpop_sigz=[]
specpop_skewz=[]
specpop_kurtz=[]
specpop_snratio=[]
specpop_gmag=[]
specpop_siggmag=[]
specpop_rmag=[]
specpop_sigrmag=[]
specpop_imag=[]
specpop_sigimag=[]
specpop_pmem=[]
specpop_pmemlo1=[]
specpop_pmemhi1=[]
specpop_pmemlo2=[]
specpop_pmemhi2=[]
specpop_pnon=[]
specpop_pnonlo1=[]
specpop_pnonhi1=[]
specpop_pnonlo2=[]
specpop_pnonhi2=[]
for line in data: # fill arrays
    p=line.split()
    specpop_ra.append(float(p[0]))
    specpop_dec.append(float(p[1]))
    specpop_xi.append(float(p[2]))
    specpop_eta.append(float(p[3]))
    specpop_r.append(float(p[4]))
    specpop_theta.append(float(p[5]))
    specpop_hjd.append(float(p[6]))
    specpop_v.append(float(p[7]))
    specpop_sigv.append(float(p[8]))
    specpop_skewv.append(float(p[9]))
    specpop_kurtv.append(float(p[10]))
    specpop_teff.append(float(p[11]))
    specpop_sigteff.append(float(p[12]))
    specpop_skewteff.append(float(p[13]))
    specpop_kurtteff.append(float(p[14]))
    specpop_logg.append(float(p[15]))
    specpop_siglogg.append(float(p[16]))
    specpop_skewlogg.append(float(p[17]))
    specpop_kurtlogg.append(float(p[18]))
    specpop_z.append(float(p[19]))
    specpop_sigz.append(float(p[20]))
    specpop_skewz.append(float(p[21]))
    specpop_kurtz.append(float(p[22]))
    specpop_snratio.append(float(p[24]))
    specpop_gmag.append(float(p[25]))
    specpop_siggmag.append(float(p[26]))
    specpop_rmag.append(float(p[27]))
    specpop_sigrmag.append(float(p[28]))
    specpop_imag.append(float(p[29]))
    specpop_sigimag.append(float(p[30]))
    specpop_pmem.append(float(p[31]))
    specpop_pmemlo1.append(float(p[32]))
    specpop_pmemhi1.append(float(p[33]))
    specpop_pmemlo2.append(float(p[34]))
    specpop_pmemhi2.append(float(p[35]))
    specpop_pnon.append(float(p[36]))
    specpop_pnonlo1.append(float(p[37]))
    specpop_pnonhi1.append(float(p[38]))
    specpop_pnonlo2.append(float(p[39]))
    specpop_pnonhi2.append(float(p[40]))
specpop_ra=np.array(specpop_ra)
specpop_dec=np.array(specpop_dec)
specpop_xi=np.array(specpop_xi)
specpop_eta=np.array(specpop_eta)
specpop_r=np.array(specpop_r)
specpop_theta=np.array(specpop_theta)
specpop_hjd=np.array(specpop_hjd)
specpop_v=np.array(specpop_v)
specpop_sigv=np.array(specpop_sigv)
specpop_skewv=np.array(specpop_skewv)
specpop_kurtv=np.array(specpop_kurtv)
specpop_teff=np.array(specpop_teff)
specpop_sigteff=np.array(specpop_sigteff)
specpop_skewteff=np.array(specpop_skewteff)
specpop_kurtteff=np.array(specpop_kurtteff)
specpop_logg=np.array(specpop_logg)
specpop_siglogg=np.array(specpop_siglogg)
specpop_skewlogg=np.array(specpop_skewlogg)
specpop_kurtlogg=np.array(specpop_kurtlogg)
specpop_z=np.array(specpop_z)
specpop_sigz=np.array(specpop_sigz)
specpop_skewz=np.array(specpop_skewz)
specpop_kurtz=np.array(specpop_kurtz)
specpop_pmem=np.array(specpop_pmem)
specpop_snratio=np.array(specpop_snratio)
specpop_gmag=np.array(specpop_gmag)
specpop_siggmag=np.array(specpop_siggmag)
specpop_rmag=np.array(specpop_rmag)
specpop_sigrmag=np.array(specpop_sigrmag)
specpop_imag=np.array(specpop_imag)
specpop_sigimag=np.array(specpop_sigimag)
specpop_pmem=np.array(specpop_pmem)
specpop_pmemlo1=np.array(specpop_pmemlo1)
specpop_pmemhi1=np.array(specpop_pmemhi1)
specpop_pmemlo2=np.array(specpop_pmemlo2)
specpop_pmemhi2=np.array(specpop_pmemhi2)
specpop_pnon=np.array(specpop_pnon)
specpop_pnonlo1=np.array(specpop_pnonlo1)
specpop_pnonhi1=np.array(specpop_pnonhi1)
specpop_pnonlo2=np.array(specpop_pnonlo2)
specpop_pnonhi2=np.array(specpop_pnonhi2)




gs=plt.GridSpec(20,20) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size

ax3_0=fig.add_subplot(gs[0:5,0:8])
ax1_0=fig.add_subplot(gs[5:10,0:8])
ax2_0=fig.add_subplot(gs[10:15,0:8])
#ax0_0=fig.add_subplot(gs[10:15,0:8])
ax0_1=fig.add_subplot(gs[15:20,12:20])
#ax3=fig.add_subplot(gs[15:20,4:10])

cra2rho_gbar=cra2rho_stellarmass*g/cra2rho_radpc**2
cra2rho_gobs=cra2rho_mass*g/cra2rho_radpc**2

#ax0_1.xaxis.set_major_formatter(plt.NullFormatter())
ax0_1.set_ylabel(r'$\sigma_{v_{los}}$ [km/s]',fontsize=10,rotation=90)
ax0_1.set_xlabel(r'$R$ [arcmin]',fontsize=10,rotation=0,labelpad=5)
ax0_1.set_xlim([1,500])
ax0_1.set_ylim([0,9])
ax0_1.set_xscale(u'log')
ax0_1.set_yscale(u'linear')
#ax0_1.set_yticks([1,10,100])
#ax0_1.set_yticklabels([1,10,100],fontsize=10)
#ax0_1.scatter(np.median(cra2_rhalf0),np.median(cra2_vdisp0),s=10,lw=0,edgecolor='none',alpha=0.69,marker='s',color='b',rasterized=True,label='Cra 2')
#ax0_1.fill_between(cra2rho_rad,cra2rho_vdisplo2,cra2rho_vdisphi2,facecolor=(0.5,0.0,1.0),alpha=0.6,rasterized=False,edgecolor='None')
ax0_1.fill_between(cra2rho_rad,cra2rho_vdisplo2,cra2rho_vdisphi2,facecolor='indigo',alpha=0.85,rasterized=False,edgecolor='None')
ax0_1.fill_between(cra2rholight_rad,cra2rholight_vdisplo2,cra2rholight_vdisphi2,facecolor='darkred',alpha=0.6,rasterized=False,edgecolor='None')
ax0_1.errorbar(r,vdisp,xerr=sigr,yerr=sigvdisp,elinewidth=0.75,fmt='o',capsize=0,alpha=1,color='k',rasterized=False)
#ax0_1.errorbar(light_r,light_vdisp,xerr=light_sigr,yerr=light_sigvdisp,elinewidth=0.25,fmt='o',capsize=0,alpha=1,color='r',rasterized=True)
ax0_1.text(1.5,7.5,'Crater 2',fontsize=7,color='k')
#ax0_1.fill_between(cra2rho_rad,cra2rho_vdisplo2,cra2rho_vdisphi2,facecolor='0.6',alpha=0.5,rasterized=False,edgecolor='None')
#ax0_1.plot(cra2rho_rad,cra2rho_vdisp,lw=0.5,color='k')
ax0_1.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='indigo',label='DM+stars',alpha=0.7)
ax0_1.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars only')
ax0_1.legend(loc=1,fontsize=6,handlelength=1,numpoints=1,scatterpoints=1,shadow=False)
axtop=ax0_1.twiny()
shite=ax0_1.get_xlim()
distance=117000.
shite2=[]
shite2.append(shite[0])
shite2.append(shite[1])
shite2=np.array(shite2)
shite3=distance*np.tan(shite2/60.*np.pi/180.)
axtop.set_xlim(shite3)
axtop.set_xscale(u'log')
axtop.set_xlabel(r'$R$ [pc]',fontsize=10,rotation=0,labelpad=7)
#ax1_0.xaxis.set_major_formatter(plt.NullFormatter())

ax3_0.xaxis.set_major_formatter(plt.NullFormatter())
ax3_0.set_ylabel(r'd$\log M_{\rm enclosed}$/d$\log r$',fontsize=10,rotation=90)
#ax2_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
#ax3_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
ax3_0.set_xlim([10,10000])
ax3_0.set_ylim([0.01,3])
ax3_0.set_xscale(u'log')
ax3_0.set_yscale(u'linear')
#ax3_0.set_yticks([1,10,100])
#ax3_0.set_yticklabels([1,10,100],fontsize=10)
#ax3_0.scatter(np.median(cra2_rhalf0),np.median(cra2_vdisp0),s=10,lw=0,edgecolor='none',alpha=0.69,marker='s',color='b',rasterized=True,label='Cra 2')
ax3_0.fill_between(cra2rho_radpc,cra2rho_slopedmlo2,cra2rho_slopedmhi2,facecolor='navy',alpha=0.6,rasterized=False,edgecolor='None')
ax3_0.fill_between(cra2counts_radpc,cra2counts_slopestellarmasslo2,cra2counts_slopestellarmasshi2,facecolor='darkred',alpha=0.6,rasterized=False,edgecolor='None')
ax3_0.fill_between(cra2counts_radpc,cra2counts_slopestacylo2,cra2counts_slopestacyhi2,facecolor='g',alpha=0.6,rasterized=False,edgecolor='None')
#ax3_0.text(1000,2.7,'Crater 2',fontsize=7,color='k')
#ax3_0.plot(cra2rho_radpc,cra2rho_rho,lw=0.5,color='k')
ax3_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='navy',label='dark matter')
ax3_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars')
ax3_0.xaxis.set_major_formatter(plt.NullFormatter())

ax1_0.xaxis.set_major_formatter(plt.NullFormatter())
ax1_0.set_ylabel(r'$\rho$ [M$_{\odot}$/pc$^3$]',fontsize=10,rotation=90)
#ax2_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
#ax1_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
ax1_0.set_xlim([10,10000])
ax1_0.set_ylim([0.00000005,0.099])
ax1_0.set_xscale(u'log')
ax1_0.set_yscale(u'log')
#ax1_0.set_yticks([1,10,100])
#ax1_0.set_yticklabels([1,10,100],fontsize=10)
#ax1_0.scatter(np.median(cra2_rhalf0),np.median(cra2_vdisp0),s=10,lw=0,edgecolor='none',alpha=0.69,marker='s',color='b',rasterized=True,label='Cra 2')
ax1_0.fill_between(cra2rho_radpc,cra2rho_rholo2,cra2rho_rhohi2,facecolor='navy',alpha=0.6,rasterized=False,edgecolor='None',label='dark matter')
ax1_0.fill_between(cra2rho_radpc,cra2rho_rhostarlo2,cra2rho_rhostarhi2,facecolor='darkred',alpha=0.6,rasterized=False,edgecolor='None',label='stars')
ax1_0.fill_between(cra2counts_radpc,cra2counts_rhostacylo2,cra2counts_rhostacyhi2,facecolor='g',alpha=0.6,rasterized=False,edgecolor='None')
#ax1_0.plot(cra2counts_radpc,cra2counts_rhostacy,color='g',lw=2)
ax1_0.text(1000,0.01,'Crater 2',fontsize=7,color='k')
#ax1_0.plot(cra2rho_radpc,cra2rho_rho,lw=0.5,color='k')
ax1_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='navy',label='dark matter')
ax1_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars')
ax1_0.xaxis.set_major_formatter(plt.NullFormatter())

#ax2_0.xaxis.set_major_formatter(plt.NullFormatter())
ax2_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
ax2_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
ax2_0.set_xlim([10,10000])
ax2_0.set_ylim([100,7000000000])
ax2_0.set_xscale(u'log')
ax2_0.set_yscale(u'log')
#ax2_0.fill_between(cra2rho_radpc,cra2rho_masslo2,cra2rho_masshi2,facecolor='0.1',alpha=0.60,rasterized=False,edgecolor='None')
ax2_0.fill_between(cra2rho_radpc,cra2rho_masslo2,cra2rho_masshi2,facecolor='navy',alpha=0.6,rasterized=False,edgecolor='None')
ax2_0.fill_between(cra2rho_radpc,cra2rho_stellarmasslo2,cra2rho_stellarmasshi2,facecolor='darkred',alpha=0.6,rasterized=False,edgecolor='None')
#ax2_0.fill_between(cra2rho_radpc,cra2rho_mstacylo2,cra2rho_mstacyhi2,facecolor='y',alpha=0.6,rasterized=False,edgecolor='None')
ax2_0.fill_between(cra2counts_radpc,cra2counts_mstacylo2,cra2counts_mstacyhi2,facecolor='g',alpha=0.6,rasterized=False,edgecolor='None')
#ax2_0.plot(cra2counts_radpc,cra2counts_mstacy,color='g',lw=2)
ax2_0.errorbar([cra2_rhalf0],[cra2_mrhalf0],xerr=[cra2_sigrhalf0],yerr=[cra2_sigmrhalf0],elinewidth=0.5,fmt='.',capsize=0,alpha=1,color='white',rasterized=False)
ax2_0.errorbar([cra2_rwolf],[cra2_mwolf],xerr=[cra2_sigrwolf],yerr=[cra2_sigmwolf],elinewidth=0.5,fmt='.',capsize=0,alpha=1,color='white',rasterized=False)
#ax2_0.fill_between(cra2rho_radpc,cra2rho_mtotlo2,cra2rho_mtothi2,facecolor='k',alpha=0.60,rasterized=False,edgecolor='None')
#ax2_0.plot(cra2rho_radpc,cra2rho_mtot,lw=0.5,color='k')
#ax2_0.xaxis.set_major_formatter(plt.NullFormatter())
ax2_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='navy',label='dark matter')
ax2_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars')
ax2_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='g',label='gobs(gbar)')
ax2_0.legend(loc=2,fontsize=6,handlelength=1,numpoints=1,scatterpoints=1,shadow=False)

#ax0_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
#ax0_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
#ax0_0.set_xlim([10,10000])
#ax0_0.set_ylim([100,9000000000])
#ax0_0.set_xscale(u'log')
#ax0_0.set_yscale(u'log')
##ax0_0.fill_between(cra2rho_radpc,cra2rho_masslo2,cra2rho_masshi2,facecolor='0.1',alpha=0.60,rasterized=False,edgecolor='None')
#ax0_0.fill_between(cra2rho_radpc,cra2rho_masslo2,cra2rho_masshi2,facecolor='b',alpha=0.60,rasterized=False,edgecolor='None')
#ax0_0.fill_between(cra2rho_radpc,cra2rho_stellarmasslo2,cra2rho_stellarmasshi2,facecolor='r',alpha=0.60,rasterized=False,edgecolor='None')
##ax0_0.fill_between(cra2rho_radpc,cra2rho_mtotlo2,cra2rho_mtothi2,facecolor='k',alpha=0.60,rasterized=False,edgecolor='None')
#ax0_0.plot(cra2rho_radpc,cra2rho_stellarmass,lw=0.25,color='r')
##ax0_0.plot(cra2rho_radpc,cra2rho_mtot,lw=0.5,color='k')
#ax0_0.plot(cra2rho_rad,cra2rho_vdisp,lw=0.25,color='k')

plotfilename='cra2jeanscounts_profiles.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
