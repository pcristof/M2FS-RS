import numpy as np
import astropy
from astropy.io import fits
import matplotlib
import matplotlib.pyplot as plt
from astropy.nddata import NDData
from astropy.nddata import StdDevUncertainty
from astropy.nddata import CCDData
from astropy import time, coordinates as coord, units as u
from astropy.time import Time
from astropy.coordinates import SkyCoord, EarthLocation
import ccdproc
import astropy.units as u
from astropy.modeling import models
from ccdproc import Combiner
import os
import scipy
import hecto_process as hecto
matplotlib.use('TkAgg')

data_directory='/nfs/nas-0-9/mgwalker.proj/hecto_data/'
fit_directory='/nfs/nas-0-9/mgwalker.proj/hecto_chains/'
