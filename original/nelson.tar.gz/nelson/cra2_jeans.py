import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='False')
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='5')
plt.rc('ytick',labelsize='5')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)
            
cra2_data1='/physics2/mgwalker/chains/cra2jeanspost_equal_weights.dat'

out1='cra2jeans_commands.tex'
out2='cra2jeans_table.tex'
g1=open(out1,'w')
g2=open(out2,'w')

with open(cra2_data1) as f: # read data file
    data=f.readlines()

cra2_logbigsigma0=[]
cra2_logrs=[]
cra2_loganisotropy=[]
cra2_logzvar=[]
cra2_vmean=[]
cra2_zmean=[]
cra2_mualpha=[]
cra2_mudelta=[]
cra2_logbigsigmab=[]
cra2_bigsigmagrad=[]
cra2_gradtheta=[]
cra2_zgrad=[]
cra2_logrhohalo=[]
cra2_logrshalo=[]
cra2_alphahalo=[]
cra2_betahalo=[]
cra2_gammahalo=[]
cra2_logmlstar=[]
cra2_like=[]

for line in data: # fill arrays
    p=line.split()
    cra2_logbigsigma0.append(float(p[0]))
    cra2_logrs.append(float(p[1]))
    cra2_loganisotropy.append(float(p[2]))
    cra2_logzvar.append(float(p[3]))
    cra2_vmean.append(float(p[4]))
    cra2_zmean.append(float(p[5]))
    cra2_mualpha.append(float(p[6]))
    cra2_mudelta.append(float(p[7]))
    cra2_logbigsigmab.append(float(p[8]))
    cra2_bigsigmagrad.append(float(p[9]))
    cra2_gradtheta.append(float(p[10]))
    cra2_zgrad.append(float(p[11]))
    cra2_logrhohalo.append(float(p[12]))
    cra2_logrshalo.append(float(p[13]))
    cra2_alphahalo.append(float(p[14]))
    cra2_betahalo.append(float(p[15]))
    cra2_gammahalo.append(float(p[16]))
    cra2_logmlstar.append(float(p[17]))
    cra2_like.append(float(p[18]))

cra2_logbigsigma0=np.array(cra2_logbigsigma0)
cra2_logrs=np.array(cra2_logrs)
cra2_loganisotropy=np.array(cra2_loganisotropy)
cra2_logzvar=np.array(cra2_logzvar)
cra2_vmean=np.array(cra2_vmean)
cra2_zmean=np.array(cra2_zmean)
cra2_mualpha=np.array(cra2_mualpha)
cra2_mudelta=np.array(cra2_mudelta)
cra2_logbigsigmab=np.array(cra2_logbigsigmab)
cra2_bigsigmagrad=np.array(cra2_bigsigmagrad)
cra2_gradtheta=np.array(cra2_gradtheta)
cra2_zgrad=np.array(cra2_zgrad)
cra2_logrhohalo=np.array(cra2_logrhohalo)
cra2_logrshalo=np.array(cra2_logrshalo)
cra2_alphahalo=np.array(cra2_alphahalo)
cra2_betahalo=np.array(cra2_betahalo)
cra2_gammahalo=np.array(cra2_gammahalo)
cra2_logmlstar=np.array(cra2_logmlstar)
cra2_like=np.array(cra2_like)

cra2_rs=10.**cra2_logrs
cra2_fehdisp=np.sqrt(10.**cra2_logzvar)
cra2_gradtheta=cra2_gradtheta*180./np.pi
cra2_rshalo=10.**cra2_logrshalo
cra2_rhohalo=10.**cra2_logrhohalo

cra2_statslogbigsigma0=np.percentile(cra2_logbigsigma0,[2.5,16.,50.,84.,97.5])
cra2_statslogrs=np.percentile(cra2_logrs,[2.5,16.,50.,84.,97.5])
cra2_statsloganisotropy=np.percentile(cra2_loganisotropy,[2.5,16.,50.,84.,97.5])
cra2_statslogzvar=np.percentile(cra2_logzvar,[2.5,16.,50.,84.,97.5])
cra2_statsvmean=np.percentile(cra2_vmean,[2.5,16.,50.,84.,97.5])
cra2_statszmean=np.percentile(cra2_zmean,[2.5,16.,50.,84.,97.5])
cra2_statsmualpha=np.percentile(cra2_mualpha,[2.5,16.,50.,84.,97.5])
cra2_statsmudelta=np.percentile(cra2_mudelta,[2.5,16.,50.,84.,97.5])
cra2_statslogbigsigmab=np.percentile(cra2_logbigsigmab,[2.5,16.,50.,84.,97.5])
cra2_statsbigsigmagrad=np.percentile(cra2_bigsigmagrad,[2.5,16.,50.,84.,97.5])
cra2_statsgradtheta=np.percentile(cra2_gradtheta,[2.5,16.,50.,84.,97.5])
cra2_statszgrad=np.percentile(cra2_zgrad,[2.5,16.,50.,84.,97.5])
cra2_statslogrhohalo=np.percentile(cra2_logrhohalo,[2.5,16.,50.,84.,97.5])
cra2_statslogrshalo=np.percentile(cra2_logrshalo,[2.5,16.,50.,84.,97.5])
cra2_statsalphahalo=np.percentile(cra2_alphahalo,[2.5,16.,50.,84.,97.5])
cra2_statsbetahalo=np.percentile(cra2_betahalo,[2.5,16.,50.,84.,97.5])
cra2_statsgammahalo=np.percentile(cra2_gammahalo,[2.5,16.,50.,84.,97.5])
cra2_statslogmlstar=np.percentile(cra2_logmlstar,[2.5,16.,50.,84.,97.5])
cra2_statslike=np.percentile(cra2_like,[2.5,16.,50.,84.,97.5])
cra2_statsrs=np.percentile(cra2_rs,[2.5,16.,50.,84.,97.5])
cra2_statsfehdisp=np.percentile(cra2_fehdisp,[2.5,16.,50.,84.,97.5])
cra2_statsgradtheta=np.percentile(cra2_gradtheta,[2.5,16.,50.,84.,97.5])
cra2_statsrshalo=np.percentile(cra2_rshalo,[2.5,16.,50.,84.,97.5])
cra2_statsrhohalo=np.percentile(cra2_rhohalo,[2.5,16.,50.,84.,97.5])

g1.write(r'\newcommand{\jeansvmean}{$'+str(round(cra2_statsvmean[2],1))+r'_{'+str(round(cra2_statsvmean[1]-cra2_statsvmean[2],1))+r'}'+r'^{+'+str(round(cra2_statsvmean[3]-cra2_statsvmean[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogbigsigmazero}{$'+str(round(cra2_statslogbigsigma0[2],1))+r'_{'+str(round(cra2_statslogbigsigma0[1]-cra2_statslogbigsigma0[2],1))+r'}'+r'^{+'+str(round(cra2_statslogbigsigma0[3]-cra2_statslogbigsigma0[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogrs}{$'+str(round(cra2_statslogrs[2],1))+r'_{'+str(round(cra2_statslogrs[1]-cra2_statslogrs[2],1))+r'}'+r'^{+'+str(round(cra2_statslogrs[3]-cra2_statslogrs[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansloganisotropy}{$'+str(round(cra2_statsloganisotropy[2],1))+r'_{'+str(round(cra2_statsloganisotropy[1]-cra2_statsloganisotropy[2],1))+r'}'+r'^{+'+str(round(cra2_statsloganisotropy[3]-cra2_statsloganisotropy[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogzvar}{$'+str(round(cra2_statslogzvar[2],1))+r'_{'+str(round(cra2_statslogzvar[1]-cra2_statslogzvar[2],1))+r'}'+r'^{+'+str(round(cra2_statslogzvar[3]-cra2_statslogzvar[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanszmean}{$'+str(round(cra2_statszmean[2],1))+r'_{'+str(round(cra2_statszmean[1]-cra2_statszmean[2],1))+r'}'+r'^{+'+str(round(cra2_statszmean[3]-cra2_statszmean[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansmualpha}{$'+str(round(cra2_statsmualpha[2],1))+r'_{'+str(round(cra2_statsmualpha[1]-cra2_statsmualpha[2],1))+r'}'+r'^{+'+str(round(cra2_statsmualpha[3]-cra2_statsmualpha[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansmudelta}{$'+str(round(cra2_statsmudelta[2],1))+r'_{'+str(round(cra2_statsmudelta[1]-cra2_statsmudelta[2],1))+r'}'+r'^{+'+str(round(cra2_statsmudelta[3]-cra2_statsmudelta[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogbigsigmab}{$'+str(round(cra2_statslogbigsigmab[2],1))+r'_{'+str(round(cra2_statslogbigsigmab[1]-cra2_statslogbigsigmab[2],1))+r'}'+r'^{+'+str(round(cra2_statslogbigsigmab[3]-cra2_statslogbigsigmab[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansbigsigmagrad}{$'+str(round(cra2_statsbigsigmagrad[2],1))+r'_{'+str(round(cra2_statsbigsigmagrad[1]-cra2_statsbigsigmagrad[2],1))+r'}'+r'^{+'+str(round(cra2_statsbigsigmagrad[3]-cra2_statsbigsigmagrad[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansgradtheta}{$'+str(round(cra2_statsgradtheta[2],1))+r'_{'+str(round(cra2_statsgradtheta[1]-cra2_statsgradtheta[2],1))+r'}'+r'^{+'+str(round(cra2_statsgradtheta[3]-cra2_statsgradtheta[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanszgrad}{$'+str(round(cra2_statszgrad[2],1))+r'_{'+str(round(cra2_statszgrad[1]-cra2_statszgrad[2],1))+r'}'+r'^{+'+str(round(cra2_statszgrad[3]-cra2_statszgrad[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogrhohalo}{$'+str(round(cra2_statslogrhohalo[2],1))+r'_{'+str(round(cra2_statslogrhohalo[1]-cra2_statslogrhohalo[2],1))+r'}'+r'^{+'+str(round(cra2_statslogrhohalo[3]-cra2_statslogrhohalo[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogrshalo}{$'+str(round(cra2_statslogrshalo[2],1))+r'_{'+str(round(cra2_statslogrshalo[1]-cra2_statslogrshalo[2],1))+r'}'+r'^{+'+str(round(cra2_statslogrshalo[3]-cra2_statslogrshalo[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansalphahalo}{$'+str(round(cra2_statsalphahalo[2],1))+r'_{'+str(round(cra2_statsalphahalo[1]-cra2_statsalphahalo[2],1))+r'}'+r'^{+'+str(round(cra2_statsalphahalo[3]-cra2_statsalphahalo[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansbetahalo}{$'+str(round(cra2_statsbetahalo[2],1))+r'_{'+str(round(cra2_statsbetahalo[1]-cra2_statsbetahalo[2],1))+r'}'+r'^{+'+str(round(cra2_statsbetahalo[3]-cra2_statsbetahalo[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansgammahalo}{$'+str(round(cra2_statsgammahalo[2],1))+r'_{'+str(round(cra2_statsgammahalo[1]-cra2_statsgammahalo[2],1))+r'}'+r'^{+'+str(round(cra2_statsgammahalo[3]-cra2_statsgammahalo[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogmlstar}{$'+str(round(cra2_statslogmlstar[2],1))+r'_{'+str(round(cra2_statslogmlstar[1]-cra2_statslogmlstar[2],1))+r'}'+r'^{+'+str(round(cra2_statslogmlstar[3]-cra2_statslogmlstar[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansrs}{$'+str(round(cra2_statsrs[2],1))+r'_{'+str(round(cra2_statsrs[1]-cra2_statsrs[2],1))+r'}'+r'^{+'+str(round(cra2_statsrs[3]-cra2_statsrs[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansfehdisp}{$'+str(round(cra2_statsfehdisp[2],1))+r'_{'+str(round(cra2_statsfehdisp[1]-cra2_statsfehdisp[2],1))+r'}'+r'^{+'+str(round(cra2_statsfehdisp[3]-cra2_statsfehdisp[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansrshalo}{$'+str(round(cra2_statsrshalo[2],1))+r'_{'+str(round(cra2_statsrshalo[1]-cra2_statsrshalo[2],1))+r'}'+r'^{+'+str(round(cra2_statsrshalo[3]-cra2_statsrshalo[2],1))+r'}$'+r'}'+'\n')

g1.write(r'\newcommand{\jeansvmeanexpanded}{$'+str(round(cra2_statsvmean[2],1))+r'_{'+str(round(cra2_statsvmean[1]-cra2_statsvmean[2],1))+r'('+str(round(cra2_statsvmean[0]-cra2_statsvmean[2],1))+r')}'+r'^{+'+str(round(cra2_statsvmean[3]-cra2_statsvmean[2],1))+r'(+'+str(round(cra2_statsvmean[4]-cra2_statsvmean[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogbigsigmazeroexpanded}{$'+str(round(cra2_statslogbigsigma0[2],1))+r'_{'+str(round(cra2_statslogbigsigma0[1]-cra2_statslogbigsigma0[2],1))+r'('+str(round(cra2_statslogbigsigma0[0]-cra2_statslogbigsigma0[2],1))+r')}'+r'^{+'+str(round(cra2_statslogbigsigma0[3]-cra2_statslogbigsigma0[2],1))+r'(+'+str(round(cra2_statslogbigsigma0[4]-cra2_statslogbigsigma0[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogrsexpanded}{$'+str(round(cra2_statslogrs[2],1))+r'_{'+str(round(cra2_statslogrs[1]-cra2_statslogrs[2],1))+r'('+str(round(cra2_statslogrs[0]-cra2_statslogrs[2],1))+r')}'+r'^{+'+str(round(cra2_statslogrs[3]-cra2_statslogrs[2],1))+r'(+'+str(round(cra2_statslogrs[4]-cra2_statslogrs[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansloganisotropyexpanded}{$'+str(round(cra2_statsloganisotropy[2],1))+r'_{'+str(round(cra2_statsloganisotropy[1]-cra2_statsloganisotropy[2],1))+r'('+str(round(cra2_statsloganisotropy[0]-cra2_statsloganisotropy[2],1))+r')}'+r'^{+'+str(round(cra2_statsloganisotropy[3]-cra2_statsloganisotropy[2],1))+r'(+'+str(round(cra2_statsloganisotropy[4]-cra2_statsloganisotropy[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogzvarexpanded}{$'+str(round(cra2_statslogzvar[2],1))+r'_{'+str(round(cra2_statslogzvar[1]-cra2_statslogzvar[2],1))+r'('+str(round(cra2_statslogzvar[0]-cra2_statslogzvar[2],1))+r')}'+r'^{+'+str(round(cra2_statslogzvar[3]-cra2_statslogzvar[2],1))+r'(+'+str(round(cra2_statslogzvar[4]-cra2_statslogzvar[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanszmeanexpanded}{$'+str(round(cra2_statszmean[2],1))+r'_{'+str(round(cra2_statszmean[1]-cra2_statszmean[2],1))+r'('+str(round(cra2_statszmean[0]-cra2_statszmean[2],1))+r')}'+r'^{+'+str(round(cra2_statszmean[3]-cra2_statszmean[2],1))+r'(+'+str(round(cra2_statszmean[4]-cra2_statszmean[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansmualphaexpanded}{$'+str(round(cra2_statsmualpha[2],1))+r'_{'+str(round(cra2_statsmualpha[1]-cra2_statsmualpha[2],1))+r'('+str(round(cra2_statsmualpha[0]-cra2_statsmualpha[2],1))+r')}'+r'^{+'+str(round(cra2_statsmualpha[3]-cra2_statsmualpha[2],1))+r'(+'+str(round(cra2_statsmualpha[4]-cra2_statsmualpha[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansmudeltaexpanded}{$'+str(round(cra2_statsmudelta[2],1))+r'_{'+str(round(cra2_statsmudelta[1]-cra2_statsmudelta[2],1))+r'('+str(round(cra2_statsmudelta[0]-cra2_statsmudelta[2],1))+r')}'+r'^{+'+str(round(cra2_statsmudelta[3]-cra2_statsmudelta[2],1))+r'(+'+str(round(cra2_statsmudelta[4]-cra2_statsmudelta[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogbigsigmabexpanded}{$'+str(round(cra2_statslogbigsigmab[2],1))+r'_{'+str(round(cra2_statslogbigsigmab[1]-cra2_statslogbigsigmab[2],1))+r'('+str(round(cra2_statslogbigsigmab[0]-cra2_statslogbigsigmab[2],1))+r')}'+r'^{+'+str(round(cra2_statslogbigsigmab[3]-cra2_statslogbigsigmab[2],1))+r'(+'+str(round(cra2_statslogbigsigmab[4]-cra2_statslogbigsigmab[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansbigsigmagradexpanded}{$'+str(round(cra2_statsbigsigmagrad[2],1))+r'_{'+str(round(cra2_statsbigsigmagrad[1]-cra2_statsbigsigmagrad[2],1))+r'('+str(round(cra2_statsbigsigmagrad[0]-cra2_statsbigsigmagrad[2],1))+r')}'+r'^{+'+str(round(cra2_statsbigsigmagrad[3]-cra2_statsbigsigmagrad[2],1))+r'(+'+str(round(cra2_statsbigsigmagrad[4]-cra2_statsbigsigmagrad[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansgradthetaexpanded}{$'+str(round(cra2_statsgradtheta[2],1))+r'_{'+str(round(cra2_statsgradtheta[1]-cra2_statsgradtheta[2],1))+r'('+str(round(cra2_statsgradtheta[0]-cra2_statsgradtheta[2],1))+r')}'+r'^{+'+str(round(cra2_statsgradtheta[3]-cra2_statsgradtheta[2],1))+r'(+'+str(round(cra2_statsgradtheta[4]-cra2_statsgradtheta[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanszgradexpanded}{$'+str(round(cra2_statszgrad[2],1))+r'_{'+str(round(cra2_statszgrad[1]-cra2_statszgrad[2],1))+r'('+str(round(cra2_statszgrad[0]-cra2_statszgrad[2],1))+r')}'+r'^{+'+str(round(cra2_statszgrad[3]-cra2_statszgrad[2],1))+r'(+'+str(round(cra2_statszgrad[4]-cra2_statszgrad[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogrhohaloexpanded}{$'+str(round(cra2_statslogrhohalo[2],1))+r'_{'+str(round(cra2_statslogrhohalo[1]-cra2_statslogrhohalo[2],1))+r'('+str(round(cra2_statslogrhohalo[0]-cra2_statslogrhohalo[2],1))+r')}'+r'^{+'+str(round(cra2_statslogrhohalo[3]-cra2_statslogrhohalo[2],1))+r'(+'+str(round(cra2_statslogrhohalo[4]-cra2_statslogrhohalo[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogrshaloexpanded}{$'+str(round(cra2_statslogrshalo[2],1))+r'_{'+str(round(cra2_statslogrshalo[1]-cra2_statslogrshalo[2],1))+r'('+str(round(cra2_statslogrshalo[0]-cra2_statslogrshalo[2],1))+r')}'+r'^{+'+str(round(cra2_statslogrshalo[3]-cra2_statslogrshalo[2],1))+r'(+'+str(round(cra2_statslogrshalo[4]-cra2_statslogrshalo[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansalphahaloexpanded}{$'+str(round(cra2_statsalphahalo[2],1))+r'_{'+str(round(cra2_statsalphahalo[1]-cra2_statsalphahalo[2],1))+r'('+str(round(cra2_statsalphahalo[0]-cra2_statsalphahalo[2],1))+r')}'+r'^{+'+str(round(cra2_statsalphahalo[3]-cra2_statsalphahalo[2],1))+r'(+'+str(round(cra2_statsalphahalo[4]-cra2_statsalphahalo[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansbetahaloexpanded}{$'+str(round(cra2_statsbetahalo[2],1))+r'_{'+str(round(cra2_statsbetahalo[1]-cra2_statsbetahalo[2],1))+r'('+str(round(cra2_statsbetahalo[0]-cra2_statsbetahalo[2],1))+r')}'+r'^{+'+str(round(cra2_statsbetahalo[3]-cra2_statsbetahalo[2],1))+r'(+'+str(round(cra2_statsbetahalo[4]-cra2_statsbetahalo[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansgammahaloexpanded}{$'+str(round(cra2_statsgammahalo[2],1))+r'_{'+str(round(cra2_statsgammahalo[1]-cra2_statsgammahalo[2],1))+r'('+str(round(cra2_statsgammahalo[0]-cra2_statsgammahalo[2],1))+r')}'+r'^{+'+str(round(cra2_statsgammahalo[3]-cra2_statsgammahalo[2],1))+r'(+'+str(round(cra2_statsgammahalo[4]-cra2_statsgammahalo[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeanslogmlstarexpanded}{$'+str(round(cra2_statslogmlstar[2],1))+r'_{'+str(round(cra2_statslogmlstar[1]-cra2_statslogmlstar[2],1))+r'('+str(round(cra2_statslogmlstar[0]-cra2_statslogmlstar[2],1))+r')}'+r'^{+'+str(round(cra2_statslogmlstar[3]-cra2_statslogmlstar[2],1))+r'(+'+str(round(cra2_statslogmlstar[4]-cra2_statslogmlstar[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansrsexpanded}{$'+str(round(cra2_statsrs[2],1))+r'_{'+str(round(cra2_statsrs[1]-cra2_statsrs[2],1))+r'('+str(round(cra2_statsrs[0]-cra2_statsrs[2],1))+r')}'+r'^{+'+str(round(cra2_statsrs[3]-cra2_statsrs[2],1))+r'(+'+str(round(cra2_statsrs[4]-cra2_statsrs[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansfehdispexpanded}{$'+str(round(cra2_statsfehdisp[2],1))+r'_{'+str(round(cra2_statsfehdisp[1]-cra2_statsfehdisp[2],1))+r'('+str(round(cra2_statsfehdisp[0]-cra2_statsfehdisp[2],1))+r')}'+r'^{+'+str(round(cra2_statsfehdisp[3]-cra2_statsfehdisp[2],1))+r'(+'+str(round(cra2_statsfehdisp[4]-cra2_statsfehdisp[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansrshaloexpanded}{$'+str(round(cra2_statsrshalo[2],1))+r'_{'+str(round(cra2_statsrshalo[1]-cra2_statsrshalo[2],1))+r'('+str(round(cra2_statsrshalo[0]-cra2_statsrshalo[2],1))+r')}'+r'^{+'+str(round(cra2_statsrshalo[3]-cra2_statsrshalo[2],1))+r'(+'+str(round(cra2_statsrshalo[4]-cra2_statsrshalo[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\jeansrhohaloexpanded}{$'+str(round(cra2_statsrhohalo[2],1))+r'_{'+str(round(cra2_statsrhohalo[1]-cra2_statsrhohalo[2],1))+r'('+str(round(cra2_statsrhohalo[0]-cra2_statsrhohalo[2],1))+r')}'+r'^{+'+str(round(cra2_statsrhohalo[3]-cra2_statsrhohalo[2],1))+r'(+'+str(round(cra2_statsrhohalo[4]-cra2_statsrhohalo[2],1))+r')}$'+r'}'+'\n')

g2.write(r'\begin{table*}'+'\n')
g2.write(r'\scriptsize'+'\n')
g2.write(r'\centering'+'\n')
g2.write(r'\caption{\scriptsize Summary of probability distribution functions for chemodynamical parameters---Jeans model}'+'\n')
g2.write(r'\begin{tabular}{@{}lllllllllll@{}}'+'\n')
g2.write(r'\hline'+'\n')
g2.write(r'parameter & prior & posterior & description\\'+'\n')
#g2.write(r'&  & (red sample) & (blue sample) &\\'+'\n')
#g2.write(r'&  & (red sample) &\\'+'\n')
g2.write(r'\hline'+'\n')
g2.write(r'\smallskip'+'\n')
#g2.write(r'$\langle v_{\rm los}\rangle$ [km s$^{-1}$] & uniform between -500 and +500 & \vmeanexpanded & \vmeantwoexpanded '+r'& mean velocity at center' +r'\\'+'\n')
g2.write(r'$\langle v_{\rm los}\rangle$ [km s$^{-1}$] & uniform between -500 and +500 & \jeansvmeanexpanded '+r'& mean velocity at center (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\mu_{\alpha}$ [mas/century] & uniform between -1000 and +1000 & \jeansmualphaexpanded '+r'& R.A. proper motion (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
#g2.write(r'$\theta_{v_{\rm los}}$ [$\degr$] & uniform between -180 and +180 & \mudeltaexpanded & \mudeltatwoexpanded '+r'& direction of maximum velocity pm' +r'\\'+'\n')
g2.write(r'$\mu_{\delta}$ [mas/century] & uniform between -1000 and +1000 & \jeansmudeltaexpanded '+r'& Dec. proper motion (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\langle \feh\rangle $ [dex] & uniform between -5 and +1 & \jeanszmeanexpanded '+r'& mean metallicity at center (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
#g2.write(r'$\sigma_{\feh}$ & uniform between 0 and +2 & \fehdispexpanded & \fehdisptwoexpanded '+r'& metallicity dispersion' +r'\\'+'\n')
g2.write(r'$\log_{10}[\sigma^2_{\feh}]$ & uniform between -5 and +2 & \jeanslogzvarexpanded '+r'& metallicity dispersion (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
#g2.write(r'$k_{\feh}$ [dex arcmin$^{-1}$] & uniform between -1 and +1 & \zgradexpanded & \fehgradtwoexpanded '+r'& magnitude of metallicity gradient' +r'\\'+'\n')
g2.write(r'$k_{\feh}$ [dex arcmin$^{-1}$] & uniform between -1 and +1 & \jeanszgradexpanded '+r'& magnitude of metallicity gradient (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\log_{10}[\Sigma_{0,1}/(\mathrm{arcmin}^{-3})]$ & uniform between -10 and +10 & \jeanslogbigsigmazeroexpanded '+r'& 2D stellar density scale (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\log_{10}[R_{\rm h}/(\mathrm{arcmin})]$ & uniform between -1 and +4 & \jeanslogrsexpanded '+r'& 2D halflight radius (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\log_{10}[\Sigma_{0,2}/(\mathrm{arcmin}^{-2})]$ & uniform between -10 and +10 & \jeanslogbigsigmabexpanded '+r'& 2D stellar density (foreground)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$k_2 [\mathrm{arcmin}^{-1}]$ & uniform between 0 and +0.1 & \jeansbigsigmagradexpanded '+r'& gradient in 2D stellar density (foreground)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\theta_2$ [deg.] & uniform between -180 and +180 & \jeansgradthetaexpanded '+r'& direction of gradient in 2D stellar density (foreground)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')

g2.write(r'$\log_{10}(1-\beta_v)$ & uniform between -1 and +1 & \jeansloganisotropyexpanded '+r'& velocity dispersion anisotropy (Cra2))' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\log_{10}[\rho_s/(M_{\odot}\mathrm{pc}^{-3})]$ & uniform between -4 and +4 & \jeanslogrhohaloexpanded '+r'& DM scale density (Cra2))' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\log_{10}[r_s/\mathrm{pc})]$ & uniform between 0 and +5 & \jeanslogrshaloexpanded '+r'& DM scale density (Cra2))' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\alpha$ & uniform between 0.5 and 3 & \jeansalphahaloexpanded '+r'& DM halo shape parameter (Cra2))' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\beta$ & uniform between 3.5 and 10 & \jeansbetahaloexpanded '+r'& DM halo shape parameter (Cra2))' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\gamma$ & uniform between 0 and 1.5 & \jeansgammahaloexpanded '+r'& DM halo shape parameter (Cra2))' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\log_{10}[\Upsilon_*/(M_{\odot}L_{\odot}^{-1})]$ & uniform between -1 and +1 & \jeanslogmlstarexpanded '+r'& stellar M/L ratio (Cra2))' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')



g2.write(r'\smallskip'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\sigma_{\feh}$ [dex] && \jeansfehdispexpanded '+r'& metallicity dispersion (Cra2)' +r'\\'+'\n')
g2.write(r'$R_{\rm h}$ [arcmin] && \jeansrsexpanded '+r'& 2D halflight radius (Cra2)' +r'\\'+'\n')

g2.write(r'\hline'+'\n')
g2.write(r'\end{tabular}'+'\n')
g2.write(r'\\'+'\n')
g2.write(r'\label{tab:cra2_gradient}'+'\n')
g2.write(r'\end{table*}'+'\n')



g1.close()
g2.close()
