import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
import scipy.special as special
import scipy.optimize as optimize
import scipy.integrate as integrate
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.99)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='8')
plt.rc('ytick',labelsize='8')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

def func(x,params):
    alphar=params[0]
    betar=params[1]
    sigmar=params[2]
    alphav=params[3]
    betav=params[4]
    sigmav=params[5]
    alphabigr=params[6]
    betabigr=params[7]
    sigmabigr=params[8]
    lum=params[9]
    rmax=params[10]

    func=1./np.sqrt(2.*np.pi*sigmar**2)/np.sqrt(2.*np.pi*sigmav**2)*np.exp(-1./2./sigmar**2*(rmax-(alphar*x+betar))**2-1./2./sigmav**2*(x-(alphav*lum+betav))**2)
    return func

def func2(params):
    alphar=params[0]
    betar=params[1]
    sigmar=params[2]
    alphav=params[3]
    betav=params[4]
    sigmav=params[5]
    alphabigr=params[6]
    betabigr=params[7]
    sigmabigr=params[8]
    lum=params[9]
    rmax=params[10]

    func2=1./np.sqrt(2.*np.pi*sigmar**2*sigmav**2*(alphar**2/sigmar**2+1./sigmav**2))/np.exp((betar+alphar*(betav+alphav*lum)-rmax)**2/(2.*(sigmar**2+alphar**2*sigmav**2)))
    return func2

def func3(x,params):
    alphar=params[0]
    betar=params[1]
    sigmar=params[2]
    alphav=params[3]
    betav=params[4]
    sigmav=params[5]
    alphabigr=params[6]
    betabigr=params[7]
    sigmabigr=params[8]
    lum=params[9]
    rmax=params[10]
    bigr=params[11]

    func3=1./np.sqrt(2.*np.pi*sigmabigr**2)*np.exp(-1./2./sigmabigr**2*(bigr-(alphabigr*x+betabigr))**2)
    return func3

def func4(params):
    alphar=params[0]
    betar=params[1]
    sigmar=params[2]
    alphav=params[3]
    betav=params[4]
    sigmav=params[5]
    alphabigr=params[6]
    betabigr=params[7]
    sigmabigr=params[8]
    lum=params[9]
    rmax=params[10]
    bigr=params[11]
    func4=1./np.sqrt(alphabigr**2)
    return func4

alphar=0.7
betar=0.2
sigmar=0.3
alphav=0.9
betav=0.1
sigmav=0.44
alphabigr=3.9
betabigr=1.33
sigmabigr=0.56
lum=4.7
rmax=1.4
bigr=5.4

params=np.array([alphar,betar,sigmar,alphav,betav,sigmav,alphabigr,betabigr,sigmabigr,lum,rmax,bigr])
min0=-7.
max0=7.
val0=integrate.quad(func,min0,max0,args=(params))
print val0,func2(params),val0[0]/func2(params)
val0=integrate.quad(func3,min0,max0,args=(params))
print val0,func4(params)

plotfilename='test.pdf'
#plt.savefig(plotfilename,dpi=400)
#plt.show()
#plt.close()
