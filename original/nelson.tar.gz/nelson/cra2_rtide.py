import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
from scipy import optimize

np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='False')
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='10')
plt.rc('ytick',labelsize='10')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)
            
with open('/physics2/mgwalker/chains/cra2jeanscountsnfwpost_equal_weights.dat') as f: # read data file
    data=f.readlines()
nfw_m200=[]
nfw_c200=[]
for line in data: # fill arrays
    p=line.split()
    nfw_m200.append(float(p[12]))
    nfw_c200.append(float(p[13]))
nfw_m200=np.array(nfw_m200)
nfw_c200=np.array(nfw_c200)

with open('/physics2/mgwalker/chains/cra2jeanscountspost_equal_weights.dat') as f: # read data file
    data=f.readlines()
alphabetagamma_m200=[]
alphabetagamma_c200=[]
for line in data: # fill arrays
    p=line.split()
    alphabetagamma_m200.append(float(p[12]))
    alphabetagamma_c200.append(float(p[13]))
alphabetagamma_m200=np.array(alphabetagamma_m200)
alphabetagamma_c200=np.array(alphabetagamma_c200)

h0=72.
triangle=200.
rhocrit=3.*(h0**2)/8./np.pi/6.67e-11/((3.09e+13)**2)/((1.e+6)**2)*((3.09e+16)**3)/2.e+30 #MSUN/PC^3
rhomin=triangle*rhocrit   #DENSITY AT VIRIAL RADIUS

nfw_m200=10.**nfw_m200
nfw_c200=10.**nfw_c200
nfw_r200=(3.*nfw_m200/4./np.pi/rhomin)**(1./3.)
nfw_rs=nfw_r200/nfw_c200
nfw_mscale=nfw_m200*(np.log(2.)-0.5)/(np.log(1.+nfw_c200)-nfw_c200/(1.+nfw_c200))
nfw_rhos=nfw_mscale/4./np.pi/(nfw_rs**3)/(np.log(2.)-0.5)

distance=119000.
g=0.0043
vmw=np.linspace(100.,300.,11)
mmw=distance*vmw**2/g
rhomw=mmw/(4./3.*np.pi*distance**3)

def findrtide(x,rhos,rs,rhomw):
    rad=10.**x
    mass=4.*np.pi*rhos*(rs**3)*(np.log(1.+rad/rs)-rad/rs/(1.+rad/rs))
    rho=mass/(4./3.*np.pi*rad**3)
    val=rho-rhomw
    return val

med=[]
lo1=[]
hi1=[]
lo2=[]
hi2=[]
for j in range(0,len(vmw)):
    arr1=np.zeros(len(nfw_rhos))
    for i in range(0,len(nfw_rhos)):
        low=1.
        high=10.
        arr1[i]=optimize.brentq(findrtide,low,high,args=(nfw_rhos[i],nfw_rs[i],rhomw[j]),xtol=2.e-12,rtol=1e-6,maxiter=100,full_output=False,disp=True)
        print j,i,arr1[i]
    med.append(np.percentile(arr1,50))    
    hi1.append(np.percentile(arr1,84))
    lo1.append(np.percentile(arr1,16))
    hi2.append(np.percentile(arr1,97.5))
    lo2.append(np.percentile(arr1,2.5))
med=np.array(med)
hi1=np.array(hi1)
lo1=np.array(lo1)
hi2=np.array(hi2)
lo2=np.array(lo2)

gs=plt.GridSpec(7,7) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
ax=fig.add_subplot(gs[0:4,0:4])

ax.set_xlim([100,300])
ax.set_ylim([3,4.5])
ax.set_xlabel(r'$V_{\rm circ,MW}(\rm 120kpc)$ [km/s]')
ax.set_ylabel(r'$\log_{10}[r_{\rm tide,Cra2}/\mathrm{pc}]$')
ax.fill_between(vmw,lo1,hi1,color='r',alpha=0.3)
ax.plot(vmw,med,color='k')

plotfilename='cra2_rtide.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
