#THIS IS THE VERSION I MADE FOR NELSON.  MY VERSION (WHICH CALLS LIBRARY FUNCTIONS) IS 'nelson_oldformat.py'
import numpy as np
from astropy.io import fits
import hecto_process as hecto

with open('fits_filenames') as f:#'fits_filenames' is a file in working directory that lists names of fits files in old format.  Two columns: first column is name of sky-subtracted frame, second column is associated variance frame.  new multi-extension fits file has suffix '*_new.fits' and is written to same directory as old fits files

    data=f.readlines()
fitsfile=[]
var_fitsfile=[]
for line in data:
    p=line.split()
    fitsfile.append(p[0])
    var_fitsfile.append(p[1])
fitsfile=np.array(fitsfile)
var_fitsfile=np.array(var_fitsfile)

def oldformat_getwav(hdul):#for older hecto frames, interprets iraf headers to get wavelength solutions for each aperture
    import numpy as np
    import re

    class wavobject:
        def __init__(self,wav=None,wavcal=None):
            self.wav=wav
            self.wavcal=wavcal

    skysub=hdul[0].data
    pixels=len(skysub[0])
    header=hdul[0].header
    combined=''
    for line in header:
        if 'WAT2' in line:
            if len(header[line])==67:
                combined=combined+header[line]+' '#had to add this by hand because last space is getting dropped from string if blank space
            else:
                combined=combined+header[line]
    combined2=combined.split('spec')
    del combined2[0:2]#remove first two items, which do not correspond to apertures
    apwav=[]
    apwavcal=[]
    for ap in range(0,len(combined2)):
        removequote=re.sub('\"','',combined2[ap])
        linefields=removequote.split()
        del linefields[1]#remove '=' to match what we get for linefields in old IDL code
        coefficients=len(linefields)-12   
        order0=np.long(linefields[13])
        aperture=np.long(linefields[0])
        coeff=np.zeros(coefficients)
        for k in range(0,coefficients):
            coeff[k]=np.float(linefields[k+12])
        func=np.long(coeff[0])
        order=np.long(coeff[1])
        xmin=coeff[2]
        xmax=coeff[3]
        wav=[]
        wavcal=[]
        x=np.arange(pixels,dtype='float')+1.
        for jj in range(0,len(x)):
            if x[jj] > xmin and x[jj] < xmax:
                n=(2.*x[jj]-(xmax+xmin))/(xmax-xmin) # defined by IRAF
                s=(x[jj]-xmin)/(xmax-xmin)*np.float(order) # defined by IRAF
                j=np.long(s)                                # defined by IRAF
                a=np.float(j+1)-s                          # defined by IRAF
                b=s-np.float(j)                            # defined by IRAF
                z=np.zeros(4)
                if coeff[0]==3:
                    z[0]=a**3.        # defined by IRAF
                    z[1]=1.+3.*a*(1.+a*b) # defined by IRAF
                    z[2]=1.+3.*b*(1.+a*b) # defined by IRAF
                    z[3]=b**3.             # defined by IRAF
                    summ=0.
                    for ii in range(0,4):
                        summ=summ+coeff[ii+j+4]*z[ii]
                if coeff[0]==1:
                    z[0]=1.
                    z[1]=n
                    z[2]=2.*n*z[1]-1.*z[0]
                    z[3]=2.*n*z[2]-1.*z[1]
                    summ=1.*coeff[4]*z[0]+1.*coeff[5]*z[1]+1.*coeff[6]*z[2]+1.*coeff[7]*z[3]
                wav.append(summ)
                wavcal.append(1)
            if x[jj] <= xmin or x[jj] >= xmax:
                wav.append(0.)
                wavcal.append(0)
        wav=np.array(wav)
        wavcal=np.array(wavcal)
        apwav.append(wav)
        apwavcal.append(wavcal)
    apwav=np.array(apwav)
    apwavcal=np.array(apwavcal)

    return wavobject(wav=apwav,wavcal=apwavcal)

def oldformat_getplugmap(hdul):#for older hecto frames, interprets iraf headers to get wavelength solutions for each aperture
    from astropy.io import fits
    import numpy as np
    import re
    from astropy import time, coordinates as coord, units as u
    from astropy.coordinates import SkyCoord, EarthLocation

    header=hdul[0].header
    aperture=[]
    radeg=[]
    decdeg=[]
    objtype=[]
    expid=[]
    icode=[]
    rcode=[]
    xfocal=[]
    yfocal=[]
    for line in header:
        if 'APID' in line:
            aperture.append(np.long(line.split('APID')[1]))
            apinfo=header[line].split()
            obj,ra,dec,t,r,x,y=apinfo
            c=SkyCoord(ra+dec,unit=(u.hourangle,u.deg))
            radeg.append(c.ra.degree)
            decdeg.append(c.dec.degree)
            expid.append(obj)
            rcode.append(r)
            xfocal.append(x)
            yfocal.append(y)
            objtype0='TARGET'
            if 'sky' in obj: objtype0='SKY'
            if 'unused' in obj: objtype0='UNUSED'
            if 'reject' in obj: objtype0='REJECTED'
            if 'SKY' in obj: objtype0='SKY'
            if 'UNUSED' in obj: objtype0='UNUSED'
            if 'REJECT' in obj: objtype0='REJECTED'
            if objtype0=='SKY': 
                icode.append(-1)
            if objtype0=='TARGET': 
                icode.append(1)
            if objtype0=='UNUSED':
                icode.append(0)
            objtype.append(objtype0)

    icode=np.array(icode,dtype='int')
    objtype=np.array(objtype)
    expid=np.array(expid)
    radeg=np.array(radeg)
    decdeg=np.array(decdeg)
    aperture=np.array(aperture)
    rcode=np.array(rcode)
    xfocal=np.array(xfocal)
    yfocal=np.array(yfocal)

    bcode=objtype#redundancy seems to be built in at CfA for some reason
    rmag=np.zeros(len(aperture))
    rapmag=np.zeros(len(aperture))
    frames=np.zeros(len(aperture),dtype='int')
    mag=np.zeros((len(aperture),5))

    cols=fits.ColDefs([fits.Column(name='EXPID',format='A100',array=expid),fits.Column(name='OBJTYPE',format='A6',array=objtype),fits.Column(name='RA',format='D',array=radeg),fits.Column(name='DEC',format='D',array=decdeg),fits.Column(name='FIBERID',format='D',array=aperture),fits.Column(name='RMAG',format='D',array=rmag),fits.Column(name='RAPMAG',format='D',array=rapmag),fits.Column(name='ICODE',format='D',array=icode),fits.Column(name='RCODE',format='D',array=rcode),fits.Column(name='BCODE',format='A6',array=bcode),fits.Column(name='MAG',format='5D',array=mag),fits.Column(name='XFOCAL',format='D',array=xfocal),fits.Column(name='YFOCAL',format='D',array=yfocal),fits.Column(name='FRAMES',format='B',array=frames)])

    plugmap_table_hdu=fits.FITS_rec.from_columns(cols)
    return plugmap_table_hdu


for i in range(0,len(fitsfile)):
    hdul=fits.open(fitsfile[i])#sky-subbed spectra frame
    data=hdul[0].data
    hdr=fits.Header(hdul[0].header)
    wavobject=oldformat_getwav(hdul)

    plugmap_table_hdu=oldformat_getplugmap(hdul)
    hdul.close()

    hdul=fits.open(var_fitsfile[i])#variance frame (nelson's nomenclature adds 's' before filename of data frame
    var=hdul[0].data
    var_hdr=fits.Header(hdul[0].header)
    var_wavobject=oldformat_getwav(hdul)
    hdul.close()

    for j in range(0,len(wavobject.wav)):
        diff=np.where(wavobject.wav[j]!=var_wavobject.wav[j])[0]
        if len(diff)>0:
            print('ERROR: wavelengths of skysub and variance are different!!!!')
            np.pause()

    ivar=1./var
    mask_or=1-wavobject.wavcal#only masked pixels are those where wavelength solution does not apply
    mask_and=1-wavobject.wavcal#only masked pixels are those where wavelength solution does not apply (same as mask_or)
    sky=data-data#don't have these in old format
    summed=data-data#don't have these in old format

    primary_hdu=fits.PrimaryHDU(wavobject.wav,header=hdr)
    new_hdul=fits.HDUList([primary_hdu])
    new_hdul.append(fits.ImageHDU(data))
    new_hdul.append(fits.ImageHDU(ivar))
    new_hdul.append(fits.ImageHDU(mask_and))
    new_hdul.append(fits.ImageHDU(mask_or))
    new_hdul.append(fits.BinTableHDU(plugmap_table_hdu))
    new_hdul.append(fits.ImageHDU(sky))
    new_hdul.append(fits.ImageHDU(summed))

    newfits=fitsfile[i].split('.fits')[0]+'_new.fits'
    new_hdul.writeto(newfits,overwrite=True)
