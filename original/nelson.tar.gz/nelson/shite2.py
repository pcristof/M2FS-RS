import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='False')
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='9')
plt.rc('ytick',labelsize='9')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)
            
cra2_dmodulus=20.3
luminosity=10.**((-8.2-4.83)/(-2.5))
distance=117500.
rhalf=1066.
racenter0=177.310*np.pi/180.
deccenter0=-18.413*np.pi/180.
maxsigv=10.
samestar=0.5#arcsec
rmax=175.
ymin=-90.

#cra2_data3='cra2_all.tab'
cra2_data2='age12fehm170.iso'
cra2_data1='cra2_members.res'
cra2_data4='cra2_ellipsehalf.res'

hdulist=fits.open('crater2_rad3deg.fits')
tbdata=hdulist[1].data
atlas_radeg=tbdata.field('RA')
atlas_decdeg=tbdata.field('DEC')
atlas_gmag=tbdata.field('MAG_G')
atlas_rmag=tbdata.field('MAG_R')
atlas_imag=tbdata.field('MAG_I')
atlas_gclass=tbdata.field('CLASSIFICATION_G')
atlas_rclass=tbdata.field('CLASSIFICATION_R')
atlas_iclass=tbdata.field('CLASSIFICATION_I')
atlas_ebv=tbdata.field('EBV')

atlas_ra=atlas_radeg*np.pi/180.
atlas_dec=atlas_decdeg*np.pi/180.
atlas_racenter=np.zeros(len(atlas_radeg))+racenter0
atlas_deccenter=np.zeros(len(atlas_radeg))+deccenter0
atlas_xi,atlas_eta=mycode2.etaxiarr(atlas_ra,atlas_dec,atlas_racenter,atlas_deccenter)
atlas_r=np.sqrt(atlas_xi**2+atlas_eta**2)
atlas_sigr=np.zeros(len(atlas_radeg))+0.0001
atlas_mag=atlas_gmag
atlas_col=atlas_gmag-atlas_imag

atlas_center=np.where((atlas_r <= 60.) & (atlas_gclass == -1) & (atlas_iclass == -1))

with open('cra2_rgb.tab') as g: # read data file
    data=g.readlines()[2:]
rgb_rah=[]
rgb_ram=[]
rgb_ras=[]
rgb_chardecd=[]
rgb_decm=[]
rgb_decs=[]
rgb_gmag=[]
rgb_rmag=[]
rgb_imag=[]
rgb_gclass=[]
rgb_rclass=[]
rgb_iclass=[]
for line in data: # fill arrays
    p=line.split()
    rgb_rah.append(long(p[1]))
    rgb_ram.append(long(p[2]))
    rgb_ras.append(float(p[3]))
    rgb_chardecd.append(str(p[4]))
    rgb_decm.append(long(p[5]))
    rgb_decs.append(float(p[6]))
    rgb_gmag.append(float(p[8]))
    rgb_rmag.append(float(p[9]))
    rgb_imag.append(float(p[10]))
    rgb_gclass.append(float(p[11]))
    rgb_rclass.append(float(p[12]))
    rgb_iclass.append(float(p[13]))
rgb_rah=np.array(rgb_rah)
rgb_ram=np.array(rgb_ram)
rgb_ras=np.array(rgb_ras)
rgb_chardecd=np.array(rgb_chardecd)
rgb_decm=np.array(rgb_decm)
rgb_decs=np.array(rgb_decs)
rgb_gmag=np.array(rgb_gmag)
rgb_rmag=np.array(rgb_rmag)
rgb_imag=np.array(rgb_imag)
rgb_gclass=np.array(rgb_gclass)
rgb_rclass=np.array(rgb_rclass)
rgb_iclass=np.array(rgb_iclass)
rgb_ra,rgb_dec=mycode2.radecradiansarr(rgb_rah,rgb_ram,rgb_ras,rgb_chardecd,rgb_decm,rgb_decs)
rgb_radeg=rgb_ra*180./np.pi
rgb_decdeg=rgb_dec*180./np.pi

rgb_racenter=np.zeros(len(rgb_radeg))+racenter0
rgb_deccenter=np.zeros(len(rgb_radeg))+deccenter0
rgb_xi,rgb_eta=mycode2.etaxiarr(rgb_ra,rgb_dec,rgb_racenter,rgb_deccenter)
rgb_r=np.sqrt(rgb_xi**2+rgb_eta**2)
rgb_theta=np.arctan2(rgb_eta,rgb_xi)
rgb_sigr=np.zeros(len(rgb_radeg))+0.0001
rgb_col=rgb_gmag-rgb_imag
rgb_sigcol=rgb_col-rgb_col-999.
rgb_siggmag=rgb_gmag-rgb_gmag-999.
rgb_sigrmag=rgb_gmag-rgb_gmag-999.
rgb_sigimag=rgb_gmag-rgb_gmag-999.
rgb_mag=rgb_imag
rgb_sigmag=rgb_mag-rgb_mag-999.
rgb_center=np.where((rgb_r <= 60.) & (rgb_gclass == -1) & (rgb_iclass == -1))

with open(cra2_data2) as g: # read data file
    data=g.readlines()[2:]
cra2_iso_g=[]
cra2_iso_r=[]
cra2_iso_i=[]
for line in data: # fill arrays
    p=line.split()
    cra2_iso_g.append(float(p[6]))
    cra2_iso_r.append(float(p[7]))
    cra2_iso_i.append(float(p[8]))

cra2_iso_g=np.array(cra2_iso_g)
cra2_iso_r=np.array(cra2_iso_r)
cra2_iso_i=np.array(cra2_iso_i)

with open(cra2_data4) as g: # read data file
    data=g.readlines()

cra2_ellipse_x=[]
cra2_ellipse_y=[]

for line in data: # fill arrays
    p=line.split()
    cra2_ellipse_x.append(float(p[0]))
    cra2_ellipse_y.append(float(p[1]))

cra2_ellipse_x=np.array(cra2_ellipse_x)
cra2_ellipse_y=np.array(cra2_ellipse_y)

with open(cra2_data1) as f: # read data file
    data=f.readlines()[0:]
cra2_radeg=[]
cra2_decdeg=[]
cra2_xi=[]
cra2_eta=[]
cra2_r=[]
cra2_hjd=[]
cra2_v=[]
cra2_sigv=[]
cra2_skewv=[]
cra2_kurtv=[]
cra2_teff=[]
cra2_sigteff=[]
cra2_skewteff=[]
cra2_kurtteff=[]
cra2_logg=[]
cra2_siglogg=[]
cra2_skewlogg=[]
cra2_kurtlogg=[]
cra2_z=[]
cra2_sigz=[]
cra2_skewz=[]
cra2_kurtz=[]
cra2_gmag=[]
cra2_rmag=[]
cra2_imag=[]
cra2_pmem=[]
cra2_snratio=[]

for line in data: # fill arrays
    p=line.split()
    cra2_radeg.append(float(p[0]))
    cra2_decdeg.append(float(p[1]))
    cra2_xi.append(float(p[2]))
    cra2_eta.append(float(p[3]))
    cra2_r.append(float(p[4]))
    cra2_hjd.append(float(p[5]))
    cra2_v.append(float(p[6]))
    cra2_sigv.append(float(p[7]))
    cra2_skewv.append(float(p[8]))
    cra2_kurtv.append(float(p[9]))
    cra2_teff.append(float(p[10]))
    cra2_sigteff.append(float(p[11]))
    cra2_skewteff.append(float(p[12]))
    cra2_kurtteff.append(float(p[13]))
    cra2_logg.append(float(p[14]))
    cra2_siglogg.append(float(p[15]))
    cra2_skewlogg.append(float(p[16]))
    cra2_kurtlogg.append(float(p[17]))
    cra2_z.append(float(p[18]))
    cra2_sigz.append(float(p[19]))
    cra2_skewz.append(float(p[20]))
    cra2_kurtz.append(float(p[21]))
    cra2_gmag.append(float(p[22]))
    cra2_rmag.append(float(p[23]))
    cra2_imag.append(float(p[24]))
    cra2_pmem.append(float(p[25]))
    cra2_snratio.append(float(p[26]))
cra2_radeg=np.array(cra2_radeg)
cra2_decdeg=np.array(cra2_decdeg)
cra2_xi=np.array(cra2_xi)
cra2_eta=np.array(cra2_eta)
cra2_r=np.array(cra2_r)
cra2_hjd=np.array(cra2_hjd)
cra2_v=np.array(cra2_v)
cra2_sigv=np.array(cra2_sigv)
cra2_skewv=np.array(cra2_skewv)
cra2_kurtv=np.array(cra2_kurtv)
cra2_teff=np.array(cra2_teff)
cra2_sigteff=np.array(cra2_sigteff)
cra2_skewteff=np.array(cra2_skewteff)
cra2_kurtteff=np.array(cra2_kurtteff)
cra2_logg=np.array(cra2_logg)
cra2_siglogg=np.array(cra2_siglogg)
cra2_skewlogg=np.array(cra2_skewlogg)
cra2_kurtlogg=np.array(cra2_kurtlogg)
cra2_z=np.array(cra2_z)
cra2_sigz=np.array(cra2_sigz)
cra2_skewz=np.array(cra2_skewz)
cra2_kurtz=np.array(cra2_kurtz)
cra2_gmag=np.array(cra2_gmag)
cra2_rmag=np.array(cra2_rmag)
cra2_imag=np.array(cra2_imag)
cra2_pmem=np.array(cra2_pmem)
cra2_snratio=np.array(cra2_snratio)

rgb_spec=np.zeros(len(rgb_ra))
rgb_hjd=np.zeros(len(rgb_ra))
rgb_v=np.zeros(len(rgb_ra))
rgb_sigv=np.zeros(len(rgb_ra))
rgb_skewv=np.zeros(len(rgb_ra))
rgb_kurtv=np.zeros(len(rgb_ra))
rgb_teff=np.zeros(len(rgb_ra))
rgb_sigteff=np.zeros(len(rgb_ra))
rgb_skewteff=np.zeros(len(rgb_ra))
rgb_kurtteff=np.zeros(len(rgb_ra))
rgb_logg=np.zeros(len(rgb_ra))
rgb_siglogg=np.zeros(len(rgb_ra))
rgb_skewlogg=np.zeros(len(rgb_ra))
rgb_kurtlogg=np.zeros(len(rgb_ra))
rgb_z=np.zeros(len(rgb_ra))
rgb_sigz=np.zeros(len(rgb_ra))
rgb_skewz=np.zeros(len(rgb_ra))
rgb_kurtz=np.zeros(len(rgb_ra))
rgb_pmem=np.zeros(len(rgb_ra))
rgb_snratio=np.zeros(len(rgb_ra))

for i in range(0,len(rgb_ra)):
    dist=np.sqrt((rgb_xi[i]-cra2_xi)**2+(rgb_eta[i]-cra2_eta)**2)*60.
    this=np.where(dist==np.min(dist))
    if ((np.min(dist) <= samestar) and(cra2_sigv[this] <= maxsigv)):
        rgb_hjd[i]=cra2_hjd[this]
        rgb_v[i]=cra2_v[this]
        rgb_sigv[i]=cra2_sigv[this]
        rgb_skewv[i]=cra2_skewv[this]
        rgb_kurtv[i]=cra2_kurtv[this]
        rgb_teff[i]=cra2_teff[this]
        rgb_sigteff[i]=cra2_sigteff[this]
        rgb_skewteff[i]=cra2_skewteff[this]
        rgb_kurtteff[i]=cra2_kurtteff[this]
        rgb_logg[i]=cra2_logg[this]
        rgb_siglogg[i]=cra2_siglogg[this]
        rgb_skewlogg[i]=cra2_skewlogg[this]
        rgb_kurtlogg[i]=cra2_kurtlogg[this]
        rgb_z[i]=cra2_z[this]
        rgb_sigz[i]=cra2_sigz[this]
        rgb_skewz[i]=cra2_skewz[this]
        rgb_kurtz[i]=cra2_kurtz[this]
        rgb_pmem[i]=cra2_pmem[this]
        rgb_snratio[i]=cra2_snratio[this]
        rgb_spec[i]=1

piss=0
for i in range(0,len(cra2_radeg)):
    dist=np.sqrt((cra2_xi[i]-rgb_xi)**2+(cra2_eta[i]-rgb_eta)**2)*60.
    this=np.where(dist==np.min(dist))
    if ((np.min(dist) > samestar)):
        print cra2_radeg[i],cra2_decdeg[i],cra2_v[i],cra2_sigv[i],cra2_z[i],cra2_logg[i],cra2_pmem[i]
        print ' '
        piss=piss+1

print piss



