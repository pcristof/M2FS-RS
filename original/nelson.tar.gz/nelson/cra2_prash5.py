import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
from scipy.stats import kde
import random
import scipy.optimize as optimize
#from galpy.potential import MWPotential2014
#from galpy.potential import NFWPotential
#from galpy.orbit import Orbit
#from galpy.potential import vesc
from astropy import units
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=1)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='10')
plt.rc('ytick',labelsize='10')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

with open('cra2_prash_nodisk_cra2.dat') as f:
    data=f.readlines()
nodisk_scatter2=[]
nodisk_ncra2=[]
nodisk_ncra2lo=[]
nodisk_ncra2hi=[]
nodisk_cra2ratio=[]
nodisk_cra2ratiolo=[]
nodisk_cra2ratiohi=[]
nodisk_cra2apo=[]
nodisk_cra2apolo=[]
nodisk_cra2apohi=[]
nodisk_cra2peri=[]
nodisk_cra2perilo=[]
nodisk_cra2perihi=[]
nodisk_cra2apoperi=[]
nodisk_cra2apoperilo=[]
nodisk_cra2apoperihi=[]
for line in data: # fill arrays
    p=line.split()
    nodisk_scatter2.append(float(p[0]))
    nodisk_ncra2.append(float(p[1]))
    nodisk_ncra2lo.append(float(p[2]))
    nodisk_ncra2hi.append(float(p[3]))
    nodisk_cra2ratio.append(float(p[4]))
    nodisk_cra2ratiolo.append(float(p[5]))
    nodisk_cra2ratiohi.append(float(p[6]))
    nodisk_cra2apo.append(float(p[7]))
    nodisk_cra2apolo.append(float(p[8]))
    nodisk_cra2apohi.append(float(p[9]))
    nodisk_cra2peri.append(float(p[10]))
    nodisk_cra2perilo.append(float(p[11]))
    nodisk_cra2perihi.append(float(p[12]))
    nodisk_cra2apoperi.append(float(p[13]))
    nodisk_cra2apoperilo.append(float(p[14]))
    nodisk_cra2apoperihi.append(float(p[15]))
nodisk_scatter2=np.array(nodisk_scatter2)
nodisk_ncra2=np.array(nodisk_ncra2)
nodisk_ncra2lo=np.array(nodisk_ncra2lo)
nodisk_ncra2hi=np.array(nodisk_ncra2hi)
nodisk_cra2ratio=np.array(nodisk_cra2ratio)
nodisk_cra2ratiolo=np.array(nodisk_cra2ratiolo)
nodisk_cra2ratiohi=np.array(nodisk_cra2ratiohi)
nodisk_cra2apo=np.array(nodisk_cra2apo)
nodisk_cra2apolo=np.array(nodisk_cra2apolo)
nodisk_cra2apohi=np.array(nodisk_cra2apohi)
nodisk_cra2peri=np.array(nodisk_cra2peri)
nodisk_cra2perilo=np.array(nodisk_cra2perilo)
nodisk_cra2perihi=np.array(nodisk_cra2perihi)
nodisk_cra2apoperi=np.array(nodisk_cra2apoperi)
nodisk_cra2apoperilo=np.array(nodisk_cra2apoperilo)
nodisk_cra2apoperihi=np.array(nodisk_cra2apoperihi)

with open('cra2_prash_nodisk_gal.dat') as f:
    data=f.readlines()
nodisk_scatter=[]
nodisk_ngal=[]
nodisk_ngallo=[]
nodisk_ngalhi=[]
nodisk_galratio=[]
nodisk_galratiolo=[]
nodisk_galratiohi=[]
nodisk_galapo=[]
nodisk_galapolo=[]
nodisk_galapohi=[]
nodisk_galperi=[]
nodisk_galperilo=[]
nodisk_galperihi=[]
nodisk_galapoperi=[]
nodisk_galapoperilo=[]
nodisk_galapoperihi=[]
for line in data: # fill arrays
    p=line.split()
    nodisk_scatter.append(float(p[0]))
    nodisk_ngal.append(float(p[1]))
    nodisk_ngallo.append(float(p[2]))
    nodisk_ngalhi.append(float(p[3]))
    nodisk_galratio.append(float(p[4]))
    nodisk_galratiolo.append(float(p[5]))
    nodisk_galratiohi.append(float(p[6]))
    nodisk_galapo.append(float(p[7]))
    nodisk_galapolo.append(float(p[8]))
    nodisk_galapohi.append(float(p[9]))
    nodisk_galperi.append(float(p[10]))
    nodisk_galperilo.append(float(p[11]))
    nodisk_galperihi.append(float(p[12]))
    nodisk_galapoperi.append(float(p[13]))
    nodisk_galapoperilo.append(float(p[14]))
    nodisk_galapoperihi.append(float(p[15]))
nodisk_scatter=np.array(nodisk_scatter)
nodisk_ngal=np.array(nodisk_ngal)
nodisk_ngallo=np.array(nodisk_ngallo)
nodisk_ngalhi=np.array(nodisk_ngalhi)
nodisk_galratio=np.array(nodisk_galratio)
nodisk_galratiolo=np.array(nodisk_galratiolo)
nodisk_galratiohi=np.array(nodisk_galratiohi)
nodisk_galapo=np.array(nodisk_galapo)
nodisk_galapolo=np.array(nodisk_galapolo)
nodisk_galapohi=np.array(nodisk_galapohi)
nodisk_galperi=np.array(nodisk_galperi)
nodisk_galperilo=np.array(nodisk_galperilo)
nodisk_galperihi=np.array(nodisk_galperihi)
nodisk_galapoperi=np.array(nodisk_galapoperi)
nodisk_galapoperilo=np.array(nodisk_galapoperilo)
nodisk_galapoperihi=np.array(nodisk_galapoperihi)

with open('cra2_prash_disk_cra2.dat') as f:
    data=f.readlines()
disk_scatter2=[]
disk_ncra2=[]
disk_ncra2lo=[]
disk_ncra2hi=[]
disk_cra2ratio=[]
disk_cra2ratiolo=[]
disk_cra2ratiohi=[]
disk_cra2apo=[]
disk_cra2apolo=[]
disk_cra2apohi=[]
disk_cra2peri=[]
disk_cra2perilo=[]
disk_cra2perihi=[]
disk_cra2apoperi=[]
disk_cra2apoperilo=[]
disk_cra2apoperihi=[]
for line in data: # fill arrays
    p=line.split()
    disk_scatter2.append(float(p[0]))
    disk_ncra2.append(float(p[1]))
    disk_ncra2lo.append(float(p[2]))
    disk_ncra2hi.append(float(p[3]))
    disk_cra2ratio.append(float(p[4]))
    disk_cra2ratiolo.append(float(p[5]))
    disk_cra2ratiohi.append(float(p[6]))
    disk_cra2apo.append(float(p[7]))
    disk_cra2apolo.append(float(p[8]))
    disk_cra2apohi.append(float(p[9]))
    disk_cra2peri.append(float(p[10]))
    disk_cra2perilo.append(float(p[11]))
    disk_cra2perihi.append(float(p[12]))
    disk_cra2apoperi.append(float(p[13]))
    disk_cra2apoperilo.append(float(p[14]))
    disk_cra2apoperihi.append(float(p[15]))
disk_scatter2=np.array(disk_scatter2)
disk_ncra2=np.array(disk_ncra2)
disk_ncra2lo=np.array(disk_ncra2lo)
disk_ncra2hi=np.array(disk_ncra2hi)
disk_cra2ratio=np.array(disk_cra2ratio)
disk_cra2ratiolo=np.array(disk_cra2ratiolo)
disk_cra2ratiohi=np.array(disk_cra2ratiohi)
disk_cra2apo=np.array(disk_cra2apo)
disk_cra2apolo=np.array(disk_cra2apolo)
disk_cra2apohi=np.array(disk_cra2apohi)
disk_cra2peri=np.array(disk_cra2peri)
disk_cra2perilo=np.array(disk_cra2perilo)
disk_cra2perihi=np.array(disk_cra2perihi)
disk_cra2apoperi=np.array(disk_cra2apoperi)
disk_cra2apoperilo=np.array(disk_cra2apoperilo)
disk_cra2apoperihi=np.array(disk_cra2apoperihi)

with open('cra2_prash_disk_gal.dat') as f:
    data=f.readlines()
disk_scatter=[]
disk_ngal=[]
disk_ngallo=[]
disk_ngalhi=[]
disk_galratio=[]
disk_galratiolo=[]
disk_galratiohi=[]
disk_galapo=[]
disk_galapolo=[]
disk_galapohi=[]
disk_galperi=[]
disk_galperilo=[]
disk_galperihi=[]
disk_galapoperi=[]
disk_galapoperilo=[]
disk_galapoperihi=[]
for line in data: # fill arrays
    p=line.split()
    disk_scatter.append(float(p[0]))
    disk_ngal.append(float(p[1]))
    disk_ngallo.append(float(p[2]))
    disk_ngalhi.append(float(p[3]))
    disk_galratio.append(float(p[4]))
    disk_galratiolo.append(float(p[5]))
    disk_galratiohi.append(float(p[6]))
    disk_galapo.append(float(p[7]))
    disk_galapolo.append(float(p[8]))
    disk_galapohi.append(float(p[9]))
    disk_galperi.append(float(p[10]))
    disk_galperilo.append(float(p[11]))
    disk_galperihi.append(float(p[12]))
    disk_galapoperi.append(float(p[13]))
    disk_galapoperilo.append(float(p[14]))
    disk_galapoperihi.append(float(p[15]))
disk_scatter=np.array(disk_scatter)
disk_ngal=np.array(disk_ngal)
disk_ngallo=np.array(disk_ngallo)
disk_ngalhi=np.array(disk_ngalhi)
disk_galratio=np.array(disk_galratio)
disk_galratiolo=np.array(disk_galratiolo)
disk_galratiohi=np.array(disk_galratiohi)
disk_galapo=np.array(disk_galapo)
disk_galapolo=np.array(disk_galapolo)
disk_galapohi=np.array(disk_galapohi)
disk_galperi=np.array(disk_galperi)
disk_galperilo=np.array(disk_galperilo)
disk_galperihi=np.array(disk_galperihi)
disk_galapoperi=np.array(disk_galapoperi)
disk_galapoperilo=np.array(disk_galapoperilo)
disk_galapoperihi=np.array(disk_galapoperihi)




gs=plt.GridSpec(12,12) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
axprash=fig.add_subplot(gs[0:3,0:5])
axtide=fig.add_subplot(gs[6:9,0:5])
axperi2=fig.add_subplot(gs[0:3,7:12])
axperi=fig.add_subplot(gs[3:6,0:5])
axapo=fig.add_subplot(gs[3:6,7:12])
axapoperi=fig.add_subplot(gs[9:12,7:12])

axprash.set_yscale('log')
axprash.set_xscale('linear')
axprash.set_xlim([0.2,1.85])
axprash.set_ylim([0.5,900])
axprash.set_ylabel(r'$N_{\rm satellites}$',rotation=90,fontsize=11)
axprash.xaxis.set_major_formatter(plt.NullFormatter())
##axprash.fill_between(scatter,ngallo,ngalhi,color='b',alpha=0.1)
axprash.plot(nodisk_scatter,nodisk_ngal,color='b',linestyle='--')
axprash.fill_between(nodisk_scatter2,nodisk_ncra2lo,nodisk_ncra2hi,color='b',alpha=0.1)
axprash.plot(nodisk_scatter2,nodisk_ncra2,color='b')
axprash.plot(disk_scatter,disk_ngal,color='r',linestyle='--')
axprash.fill_between(disk_scatter2,disk_ncra2lo,disk_ncra2hi,color='r',alpha=0.1)                     
axprash.plot(disk_scatter2,disk_ncra2,color='r')
#axprash.plot(scatter,ncra2lo,color='r',linestyle=':')
#axprash.plot(scatter,ncra2hi,color='r',linestyle=':')
#axprash.plot(scatter,ngallo,color='b',linestyle=':')
#axprash.plot(scatter,ngalhi,color='b',linestyle=':')
axprash.plot([-10,-9],[1,1],color='b',label=r'no disk')
axprash.plot([-10,-9],[1,1],color='r',label=r'disk')
axprash.plot([-10,-9],[1,1],color='k',linestyle='--',label=r'$M_*>10^5M_{\odot}$')
axprash.plot([-10,-9],[1,1],color='k',linestyle='-',label=r'$M_*>10^5M_{\odot},M_{\rm vir}<10^7M_{\odot}$')
axprash.xaxis.set_major_formatter(plt.NullFormatter())
axprash.legend(loc=2,fontsize=5,handlelength=4.75,scatterpoints=1,borderaxespad=0,shadow=False)

axtide.set_yscale('linear')
axtide.set_xscale('linear')
axtide.set_xlim([0.2,1.85])
axtide.set_ylim([-2.5,-0.1])
axtide.set_xticks([0.5,1.0,1.5])
axtide.set_xticklabels(['0.5','1.0','1.5'])
axtide.set_xlabel(r'scatter in SMHM [dex]',fontsize=11)
axtide.set_ylabel(r'$\log_{10}[M_{\rm vir}/M_{\rm peak}]$',fontsize=11,rotation=90)
axtide.plot(nodisk_scatter,nodisk_galratio,color='b',linestyle='--')
axtide.fill_between(nodisk_scatter2,nodisk_cra2ratiolo,nodisk_cra2ratiohi,color='b',alpha=0.1)
axtide.plot(nodisk_scatter2,nodisk_cra2ratio,color='b')
axtide.plot(disk_scatter,disk_galratio,color='r',linestyle='--')
axtide.fill_between(disk_scatter2,disk_cra2ratiolo,disk_cra2ratiohi,color='r',alpha=0.1)
axtide.plot(disk_scatter2,disk_cra2ratio,color='r')
#axtide.plot(scatter,cra2ratiolo,color='r',linestyle=':')
#axtide.plot(scatter,cra2ratiohi,color='r',linestyle=':')
#axtide.plot(scatter,galratiolo,color='b',linestyle=':')
#axtide.plot(scatter,galratiohi,color='b',linestyle=':')
axtide.plot([1,1.3],[-12.5,-12.5],color='k',linestyle='--',label=r'$M_*>10^5M_{\odot}$')
axtide.plot([1,1.3],[-12,-12],color='k',label=r'$M_*>10^5M_{\odot},\n M_{\rm halo}<10^7M_{\odot}$')
#axtide.legend(loc=4,fontsize=5,handlelength=3,scatterpoints=1,borderaxespad=0)

axperi2.set_yscale('linear')
axperi2.set_xscale('linear')
axperi2.set_xlim([0.2,1.85])
axperi2.set_ylim([11,100])
axperi2.set_ylabel(r'$r_{\rm peri}$ [kpc]',fontsize=11,rotation=90)
axperi2.xaxis.set_major_formatter(plt.NullFormatter())
axperi2.plot(nodisk_scatter,nodisk_galperi,color='b',linestyle='--')
axperi2.plot(nodisk_scatter2,nodisk_cra2peri,color='b')
axperi2.plot(disk_scatter,disk_galperi,color='r',linestyle='--')
axperi2.plot(disk_scatter2,disk_cra2peri,color='r')
#axperi2.plot(scatter,cra2perilo,color='r',linestyle=':')
#axperi2.plot(scatter,cra2perihi,color='r',linestyle=':')
#axperi2.plot(scatter,galperilo,color='b',linestyle=':')
#axperi2.plot(scatter,galperihi,color='b',linestyle=':')
axperi2.xaxis.set_major_formatter(plt.NullFormatter())

axperi.set_yscale('linear')
axperi.set_xscale('linear')
axperi.set_xlim([0.2,1.85])
axperi.set_ylim([11,100])
axperi.set_ylabel(r'$r_{\rm peri}$ [kpc]',fontsize=11,rotation=90)
axperi.set_yticks([25,50,75])
axperi.set_yticklabels(['25','50','75'])
axperi.xaxis.set_major_formatter(plt.NullFormatter())
axperi.plot(nodisk_scatter,nodisk_galperi,color='b',linestyle='--')
axperi.fill_between(nodisk_scatter2,nodisk_cra2perilo,nodisk_cra2perihi,color='b',alpha=0.1)
axperi.plot(nodisk_scatter2,nodisk_cra2peri,color='b')
axperi.plot(disk_scatter,disk_galperi,color='r',linestyle='--')
axperi.fill_between(disk_scatter2,disk_cra2perilo,disk_cra2perihi,color='r',alpha=0.1)
axperi.plot(disk_scatter2,disk_cra2peri,color='r')
#axperi.plot(scatter,cra2perilo,color='r',linestyle=':')
#axperi.plot(scatter,cra2perihi,color='r',linestyle=':')
#axperi.plot(scatter,galperilo,color='b',linestyle=':')
#axperi.plot(scatter,galperihi,color='b',linestyle=':')
axperi.xaxis.set_major_formatter(plt.NullFormatter())

axapo.set_yscale('linear')
axapo.set_xscale('linear')
axapo.set_xlim([0.2,1.85])
axapo.set_ylim([100,259])
axapo.set_xticks([0.5,1.0,1.5])
axapo.set_xticklabels(['0.5','1.0','1.5'])
axapo.set_xlabel(r'scatter in SMHM [dex]',fontsize=11)
axapo.set_ylabel(r'$r_{\rm apo}$ [kpc]',fontsize=11,rotation=90)
axapo.plot(nodisk_scatter,nodisk_galapo,color='b',linestyle='--')
axapo.plot(nodisk_scatter2,nodisk_cra2apo,color='b')
axapo.plot(disk_scatter,disk_galapo,color='r',linestyle='--')
axapo.plot(disk_scatter2,disk_cra2apo,color='r')
#axapo.plot(scatter,cra2apolo,color='r',linestyle=':')
#axapo.plot(scatter,cra2apohi,color='r',linestyle=':')
#axapo.plot(scatter,galapolo,color='b',linestyle=':')
#axapo.plot(scatter,galapohi,color='b',linestyle=':')

axapoperi.set_yscale('linear')
axapoperi.set_xscale('linear')
axapoperi.set_xlim([0.2,1.85])
axapoperi.set_ylim([0,1])
axapoperi.set_xticks([0.5,1.0,1.5])
axapoperi.set_xticklabels(['0.5','1.0','1.5'])
axapoperi.set_xlabel(r'scatter in SMHM [dex]',fontsize=11)
axapoperi.set_ylabel(r'$r_{\rm peri}/r_{\rm apo}$',fontsize=11,rotation=90)
axapoperi.plot(nodisk_scatter,nodisk_galapoperi,color='b',linestyle='--')
axapoperi.plot(nodisk_scatter2,nodisk_cra2apoperi,color='b')
axapoperi.plot(disk_scatter,disk_galapoperi,color='r',linestyle='--')
axapoperi.plot(disk_scatter2,disk_cra2apoperi,color='r')
#axapoperi.plot(scatter,cra2apolo,color='r',linestyle=':')
#axapoperi.plot(scatter,cra2apohi,color='r',linestyle=':')
#axapoperi.plot(scatter,galapolo,color='b',linestyle=':')
#axapoperi.plot(scatter,galapohi,color='b',linestyle=':')

#plotfilename='cra2_prash3disk.pdf'
plotfilename='cra2_prash5.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
