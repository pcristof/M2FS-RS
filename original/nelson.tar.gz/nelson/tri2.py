import numpy as np
import astropy
from astropy.io import fits
import matplotlib
import matplotlib.pyplot as plt
from astropy.nddata import NDData
from astropy.nddata import StdDevUncertainty
from astropy.nddata import CCDData
from astropy.coordinates import SkyCoord, EarthLocation
import ccdproc
import astropy.units as u
from astropy.modeling import models
from ccdproc import Combiner
import os
import scipy
import time
import hecto_process as hecto
import mycode
matplotlib.use('TkAgg')

shite=fits.open('nelson_tri2.fits')
hjd=shite[1].data['hjd']-2.45e6
hjd1=np.where(hjd<7682)[0]
hjd2=np.where((hjd>7682.)&(hjd<7685))[0]
hjd3=np.where((hjd>7685.)&(hjd<7686))[0]
hjd4=np.where((hjd>7686.)&(hjd<7690))[0]
hjd5=np.where(hjd>7690.)[0]
ra=shite[1].data['ra_deg']
dec=shite[1].data['dec_deg']

same=1.
obs=np.zeros(len(ra))
nobs=np.zeros(len(ra))
for i in range(0,len(ra)):
    if obs[i]==0:
        dist=np.sqrt((ra[i]-ra)**2+(dec[i]-dec)**2)*3600.
        this=np.where(dist<same)[0]
        if len(this)>0:
            for j in range(0,len(this)):
                obs[this[j]]=j+1
                nobs[this[j]]=len(this)

#plt.scatter(ra[hjd1],dec[hjd1],s=3)
#plt.scatter(ra[hjd2],dec[hjd2],s=3)
#plt.scatter(ra[hjd3],dec[hjd3],s=3)
plt.scatter(ra[hjd4],dec[hjd4],s=3)
plt.scatter(ra[hjd5],dec[hjd5],s=3)
plt.show()
plt.close()

