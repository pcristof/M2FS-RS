import numpy as np
import astropy
from astropy.io import fits
import matplotlib
import matplotlib.pyplot as plt
from astropy.nddata import NDData
from astropy.nddata import StdDevUncertainty
from astropy.nddata import CCDData
import ccdproc
import dustmaps.sfd
import astropy.units as u
from astropy.modeling import models
from ccdproc import Combiner
import os
from os import path
import scipy
import m2fs_process as m2fs
import mycode
import crossmatcher
matplotlib.use('TkAgg')
import dill as pickle
#matplotlib.use('pdf')

shite=fits.open('nelson_all_ian.fits')

v1,v2=shite[1].data['vlos'],shite[1].data['teffprior_vlos']
sigv1,sigv2=shite[1].data['vlos_error'],shite[1].data['teffprior_vlos_error']
skewv1,skewv2=shite[1].data['vlos_skew'],shite[1].data['teffprior_vlos_skew']
kurtv1,kurtv2=shite[1].data['vlos_kurtosis'],shite[1].data['teffprior_vlos_kurtosis']

teff1,teff2=shite[1].data['teff'],shite[1].data['teffprior_teff']
sigteff1,sigteff2=shite[1].data['teff_error'],shite[1].data['teffprior_teff_error']
skewteff1,skewteff2=shite[1].data['teff_skew'],shite[1].data['teffprior_teff_skew']
kurtteff1,kurtteff2=shite[1].data['teff_kurtosis'],shite[1].data['teffprior_teff_kurtosis']

logg1,logg2=shite[1].data['logg'],shite[1].data['teffprior_logg']
siglogg1,siglogg2=shite[1].data['logg_error'],shite[1].data['teffprior_logg_error']
skewlogg1,skewlogg2=shite[1].data['logg_skew'],shite[1].data['teffprior_logg_skew']
kurtlogg1,kurtlogg2=shite[1].data['logg_kurtosis'],shite[1].data['teffprior_logg_kurtosis']

z1,z2=shite[1].data['z'],shite[1].data['teffprior_z']
sigz1,sigz2=shite[1].data['z_error'],shite[1].data['teffprior_z_error']
skewz1,skewz2=shite[1].data['z_skew'],shite[1].data['teffprior_z_skew']
kurtz1,kurtz2=shite[1].data['z_kurtosis'],shite[1].data['teffprior_z_kurtosis']

alpha1,alpha2=shite[1].data['alpha'],shite[1].data['teffprior_alpha']
sigalpha1,sigalpha2=shite[1].data['alpha_error'],shite[1].data['teffprior_alpha_error']
skewalpha1,skewalpha2=shite[1].data['alpha_skew'],shite[1].data['teffprior_alpha_skew']
kurtalpha1,kurtalpha2=shite[1].data['alpha_kurtosis'],shite[1].data['teffprior_alpha_kurtosis']

keep=np.where((sigv1<5.)&(np.abs(skewv1)<1.)&(np.abs(kurtv1)<1.))[0]

plt.scatter(v1[keep],(v1[keep]-v2[keep])/np.sqrt(sigv1[keep]**2+sigv2[keep]**2),s=1,alpha=0.3,color='k',rasterized=True)
plt.xlim([-500,500])
plt.ylim([-5,5])
plt.plot([-10000,10000],[0,0],linestyle='--',color='k')
plt.ylabel(r'$(v_{\rm flatprior} - v_{\rm Teffprior})/(\sigma)$')
plt.xlabel(r'$v_{\rm flatprior}$ [km/s]')
plt.savefig('vnorm_compare.pdf',dpi=200)
plt.show()
plt.close()

plt.scatter(v1[keep],v1[keep]-v2[keep],s=1,alpha=0.3,color='k',rasterized=True)
plt.xlim([-500,500])
plt.ylim([-5,5])
plt.plot([-10000,10000],[0,0],linestyle='--',color='k')
plt.ylabel(r'$v_{\rm flatprior} - v_{\rm Teffprior}$ [km/s]')
plt.xlabel(r'$v_{\rm flatprior}$ [km/s]')
plt.savefig('v_compare.pdf',dpi=200)
plt.show()
plt.close()

plt.scatter(logg1[keep],logg1[keep]-logg2[keep],s=1,alpha=0.3,color='k',rasterized=True)
plt.xlim([0,5])
plt.ylim([-4,4])
plt.plot([-10000,10000],[0,0],linestyle='--',color='k')
plt.ylabel(r'logg$_{\rm flatprior}$ - logg$_{\rm Teffprior}$')
plt.xlabel(r'logg$_{\rm flatprior}$')
plt.savefig('logg_compare.pdf',dpi=200)
plt.show()
plt.close()

plt.scatter(z1[keep],z1[keep]-z2[keep],s=1,alpha=0.3,color='k',rasterized=True)
plt.xlim([-5,1])
plt.ylim([-5,5])
plt.plot([-10000,10000],[0,0],linestyle='--',color='k')
plt.ylabel(r'[Fe/H]$_{\rm flatprior}$ - [Fe/H]$_{\rm Teffprior}$')
plt.xlabel(r'[Fe/H]$_{\rm flatprior}$')
plt.savefig('z_compare.pdf',dpi=200)
plt.show()
plt.close()

plt.scatter(teff1[keep],teff1[keep]-teff2[keep],s=1,alpha=0.3,color='k',rasterized=True)
plt.xlim([4000,8000])
plt.ylim([-1000,1000])
plt.plot([-10000,10000],[0,0],linestyle='--',color='k')
plt.ylabel(r'$T_{{\rm eff}_{\rm flatprior}} - T_{{\rm eff}_{\rm Teffprior}}$ [K]')
plt.xlabel(r'$T_{{\rm eff}_{\rm flatprior}}$ [K]')
plt.savefig('teff_compare.pdf',dpi=200)
plt.show()
plt.close()

plt.scatter(z1[keep],alpha1[keep]-alpha2[keep],s=1,alpha=0.3,color='k',rasterized=True)
plt.xlim([-5,1])
plt.ylim([-2,2])
plt.plot([-10000,10000],[0,0],linestyle='--',color='k')
plt.ylabel(r'[Mg/Fe]$_{\rm flatprior}}$ - [Mg/Fe]$_{\rm Teffprior}}$')
plt.xlabel(r'[Fe/H]$_{\rm flatprior}}$')
plt.savefig('mg_compare.pdf',dpi=200)
plt.show()
plt.close()

plt.scatter(sigteff1[keep],sigteff2[keep],s=1,alpha=0.3,color='k',rasterized=True)
plt.plot([0,10000],[0,10000],linestyle='--',color='k')
plt.xlim([0,2000])
plt.ylim([0,2000])
plt.xlabel('Teff error (flat prior) [K]')
plt.ylabel('Teff error (Teff prior) [K]')
plt.savefig('sigteff_compare.pdf',dpi=200)
plt.show()
plt.close()

plt.scatter(sigz1[keep],sigz2[keep],s=1,alpha=0.3,color='k',rasterized=True)
plt.plot([0,10000],[0,10000],linestyle='--',color='k')
plt.xlim([0,1])
plt.ylim([0,1])
plt.xlabel('[Fe/H] error (flat prior)')
plt.ylabel('[Fe/H] error (Teff prior)')
plt.savefig('sigz_compare.pdf',dpi=200)
plt.show()
plt.close() 

plt.scatter(sigalpha1[keep],sigalpha2[keep],s=1,alpha=0.3,color='k',rasterized=True)
plt.plot([0,10000],[0,10000],linestyle='--',color='k')
plt.xlim([0,1])
plt.ylim([0,1])
plt.xlabel('[Mg/Fe] error (flat prior)')
plt.ylabel('[Mg/Fe] error (Teff prior)')
plt.savefig('sigmg_compare.pdf',dpi=200)
plt.show()
plt.close() 

plt.scatter(sigv1[keep],sigv2[keep],s=1,alpha=0.3,color='k',rasterized=True)
plt.plot([0,10000],[0,10000],linestyle='--',color='k')
plt.xlim([0,5])
plt.ylim([0,5])
plt.xlabel('velocity error (flat prior) [km/s]')
plt.ylabel('velocity error (Teff prior) [km/s]')
plt.savefig('sigv_compare.pdf',dpi=200)
plt.show()
plt.close() 

plt.scatter(siglogg1[keep],siglogg2[keep],s=1,alpha=0.3,color='k',rasterized=True)
plt.plot([0,10000],[0,10000],linestyle='--',color='k')
plt.xlim([0,3])
plt.ylim([0,3])
plt.xlabel('logg error (flat prior) [km/s]')
plt.ylabel('logg error (Teff prior) [km/s]')
plt.savefig('siglogg_compare.pdf',dpi=200)
plt.show()
plt.close() 

