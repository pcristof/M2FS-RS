import numpy as np
from astropy.io import fits
import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('TkAgg')
#matplotlib.use('pdf')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')

gal='kgo13'
poop=fits.open('nelson_all_ian.fits')
keep=np.where((poop[1].data['vlos_error']<5.)&(poop[1].data['vlos_error']>0.)&(np.abs(poop[1].data['vlos_skew'])<=1.)&(np.abs(poop[1].data['vlos_kurtosis'])<=1.))[0]
keep0=np.where(poop[1].data['object']==gal)[0]
keep2=np.where((poop[1].data['vlos_error']<5.)&(poop[1].data['vlos_error']>0.)&(np.abs(poop[1].data['vlos_skew'])<=1.)&(np.abs(poop[1].data['vlos_kurtosis'])<=1.)&(poop[1].data['object']==gal))[0]
#plt.scatter(poop[1].data['vlos'],poop[1].data['z'],s=1,alpha=0.2,rasterized=True)
plt.scatter(poop[1].data['vlos'][keep],poop[1].data['z'][keep],s=1,color='k',rasterized=True,alpha=0.2)
plt.xlim([-500,500])
plt.xlabel('Vlos [km/s]')
plt.ylabel('[Fe/H]')
#plt.scatter(poop[1].data['sn_ratio'][keep],poop[1].data['chi2'][keep]/poop[1].data['n'][keep],s=1,alpha=0.2,color='k',rasterized=True)
#plt.scatter(poop[1].data['sn_ratio'][keep],poop[1].data['chi2_modified'][keep]/poop[1].data['n'][keep],s=1,alpha=0.2,color='r',rasterized=True)
#plt.scatter([9999],[99999],label='original',color='k',rasterized=True)
#plt.scatter([9999],[99999],label='modified',color='r',rasterized=True)
#plt.xlim([0.1,100])
#plt.ylim([0.1,100])
#plt.xscale('log')
#plt.yscale('log')
#plt.xlabel('median S/N/pix')
#plt.ylabel(r'$\chi^2/N_{\rm pix}$')
#plt.legend(loc=4)
plt.savefig(fname='hecto_catalog.pdf',dpi=200)
plt.show()
plt.close()

obs=np.zeros(len(keep))
for i in range(0,len(keep)):
    if obs[i]==0:
        dist=np.sqrt((poop[1].data['ra_deg'][keep][i]-poop[1].data['ra_deg'][keep])**2+(poop[1].data['dec_deg'][keep][i]-poop[1].data['dec_deg'][keep])**2)*3600.
        this=np.where(dist<0.5)[0]
        for j in range(0,len(this)):
            obs[this[j]]=j+1
stars=np.where(obs==1)[0]
print(len(keep0),len(keep),len(stars))

        
