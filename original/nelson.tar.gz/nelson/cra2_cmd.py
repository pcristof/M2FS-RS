import numpy as np 
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='9')
plt.rc('ytick',labelsize='9')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)
            
cra2_dmodulus=20.3
racenter0=177.310*np.pi/180.
deccenter0=-18.413*np.pi/180.
maxsigv=10.

#cra2_data3='cra2_all.tab'
cra2_data2='age12fehm170.iso'
cra2_data3='age12fehm200.iso'
cra2_data5='age15fehm200.iso'
cra2_data1='/physics2/mgwalker/chains/cra2gradient.pop'
cra2_data4='cra2_ellipsehalf.res'

hdulist=fits.open('crater2_rad3deg.fits')
tbdata=hdulist[1].data
atlas_radeg=tbdata.field('RA')
atlas_decdeg=tbdata.field('DEC')
atlas_gmag=tbdata.field('MAG_G')
atlas_rmag=tbdata.field('MAG_R')
atlas_imag=tbdata.field('MAG_I')
atlas_gclass=tbdata.field('CLASSIFICATION_G')
atlas_rclass=tbdata.field('CLASSIFICATION_R')
atlas_iclass=tbdata.field('CLASSIFICATION_I')
atlas_ebv=tbdata.field('EBV')

atlas_ra=atlas_radeg*np.pi/180.
atlas_dec=atlas_decdeg*np.pi/180.
atlas_racenter=np.zeros(len(atlas_radeg))+racenter0
atlas_deccenter=np.zeros(len(atlas_radeg))+deccenter0
atlas_xi,atlas_eta=mycode2.etaxiarr(atlas_ra,atlas_dec,atlas_racenter,atlas_deccenter)
atlas_r=np.sqrt(atlas_xi**2+atlas_eta**2)
atlas_sigr=np.zeros(len(atlas_radeg))+0.0001
atlas_mag=atlas_gmag
atlas_col=atlas_gmag-atlas_imag

atlas_center=np.where((atlas_r <= 60.) & (atlas_gclass == -1) & (atlas_iclass == -1))

with open('cra2_rgb.tab') as g: # read data file
    data=g.readlines()[2:]
rgb_rah=[]
rgb_ram=[]
rgb_ras=[]
rgb_chardecd=[]
rgb_decm=[]
rgb_decs=[]
rgb_gmag=[]
rgb_rmag=[]
rgb_imag=[]
rgb_gclass=[]
rgb_rclass=[]
rgb_iclass=[]
for line in data: # fill arrays
    p=line.split()
    rgb_rah.append(long(p[1]))
    rgb_ram.append(long(p[2]))
    rgb_ras.append(float(p[3]))
    rgb_chardecd.append(str(p[4]))
    rgb_decm.append(long(p[5]))
    rgb_decs.append(float(p[6]))
    rgb_gmag.append(float(p[8]))
    rgb_rmag.append(float(p[9]))
    rgb_imag.append(float(p[10]))
    rgb_gclass.append(float(p[11]))
    rgb_rclass.append(float(p[12]))
    rgb_iclass.append(float(p[13]))
rgb_rah=np.array(rgb_rah)
rgb_ram=np.array(rgb_ram)
rgb_ras=np.array(rgb_ras)
rgb_chardecd=np.array(rgb_chardecd)
rgb_decm=np.array(rgb_decm)
rgb_decs=np.array(rgb_decs)
rgb_gmag=np.array(rgb_gmag)
rgb_rmag=np.array(rgb_rmag)
rgb_imag=np.array(rgb_imag)
rgb_gclass=np.array(rgb_gclass)
rgb_rclass=np.array(rgb_rclass)
rgb_iclass=np.array(rgb_iclass)
rgb_ra,rgb_dec=mycode2.radecradiansarr(rgb_rah,rgb_ram,rgb_ras,rgb_chardecd,rgb_decm,rgb_decs)
rgb_radeg=rgb_ra*180./np.pi
rgb_decdeg=rgb_dec*180./np.pi

rgb_racenter=np.zeros(len(rgb_radeg))+racenter0
rgb_deccenter=np.zeros(len(rgb_radeg))+deccenter0
rgb_xi,rgb_eta=mycode2.etaxiarr(rgb_ra,rgb_dec,rgb_racenter,rgb_deccenter)
rgb_r=np.sqrt(rgb_xi**2+rgb_eta**2)
rgb_sigr=np.zeros(len(rgb_radeg))+0.0001
rgb_col=rgb_gmag-rgb_imag
rgb_mag=rgb_imag
rgb_center=np.where((rgb_r <= 60.) & (rgb_gclass == -1) & (rgb_iclass == -1))

with open(cra2_data2) as g: # read data file
    data=g.readlines()[2:]
cra2_iso170_g=[]
cra2_iso170_r=[]
cra2_iso170_i=[]
for line in data: # fill arrays
    p=line.split()
    cra2_iso170_g.append(float(p[6]))
    cra2_iso170_r.append(float(p[7]))
    cra2_iso170_i.append(float(p[8]))

cra2_iso170_g=np.array(cra2_iso170_g)
cra2_iso170_r=np.array(cra2_iso170_r)
cra2_iso170_i=np.array(cra2_iso170_i)

with open(cra2_data3) as g: # read data file
    data=g.readlines()[2:]
cra2_iso200_g=[]
cra2_iso200_r=[]
cra2_iso200_i=[]
for line in data: # fill arrays
    p=line.split()
    cra2_iso200_g.append(float(p[6]))
    cra2_iso200_r.append(float(p[7]))
    cra2_iso200_i.append(float(p[8]))

cra2_iso200_g=np.array(cra2_iso200_g)
cra2_iso200_r=np.array(cra2_iso200_r)
cra2_iso200_i=np.array(cra2_iso200_i)

with open(cra2_data5) as g: # read data file
    data=g.readlines()[2:]
cra2_iso200age15_g=[]
cra2_iso200age15_r=[]
cra2_iso200age15_i=[]
for line in data: # fill arrays
    p=line.split()
    cra2_iso200age15_g.append(float(p[6]))
    cra2_iso200age15_r.append(float(p[7]))
    cra2_iso200age15_i.append(float(p[8]))

cra2_iso200age15_g=np.array(cra2_iso200age15_g)
cra2_iso200age15_r=np.array(cra2_iso200age15_r)
cra2_iso200age15_i=np.array(cra2_iso200age15_i)

with open(cra2_data4) as g: # read data file
    data=g.readlines()

cra2_ellipse_x=[]
cra2_ellipse_y=[]

for line in data: # fill arrays
    p=line.split()
    cra2_ellipse_x.append(float(p[0]))
    cra2_ellipse_y.append(float(p[1]))

cra2_ellipse_x=np.array(cra2_ellipse_x)
cra2_ellipse_y=np.array(cra2_ellipse_y)

with open('nelson_cra2.dat') as f: # read data file
    data=f.readlines()[1:]
xi=[]
eta=[]
hjd=[]
v=[]
sigv=[]
skewv=[]
kurtv=[]
gmag=[]
rmag=[]
imag=[]
for line in data: # fill arrays
    p=line.split()
    xi.append(float(p[2]))
    eta.append(float(p[3]))
    hjd.append(float(p[5]))
    v.append(float(p[6]))
    sigv.append(float(p[7]))
    skewv.append(float(p[8]))
    kurtv.append(float(p[9]))
    gmag.append(float(p[22]))
    rmag.append(float(p[23]))
    imag.append(float(p[24]))
xi=np.array(xi)
eta=np.array(eta)
hjd=np.array(hjd)
v=np.array(v)
sigv=np.array(sigv)
skewv=np.array(skewv)
kurtv=np.array(kurtv)
gmag=np.array(gmag)
rmag=np.array(rmag)
imag=np.array(imag)
col=gmag-imag
mag=imag
r=np.sqrt(xi**2+eta**2)
with open(cra2_data1) as f: # read data file
    data=f.readlines()[1:]
cra2_ra=[]
cra2_dec=[]
cra2_xi=[]
cra2_eta=[]
cra2_r=[]
cra2_theta=[]
cra2_hjd=[]
cra2_v=[]
cra2_sigv=[]
cra2_skewv=[]
cra2_kurtv=[]
cra2_teff=[]
cra2_sigteff=[]
cra2_skewteff=[]
cra2_kurtteff=[]
cra2_logg=[]
cra2_siglogg=[]
cra2_skewlogg=[]
cra2_kurtlogg=[]
cra2_z=[]
cra2_sigz=[]
cra2_skewz=[]
cra2_kurtz=[]
cra2_snratio=[]
cra2_gmag=[]
cra2_siggmag=[]
cra2_rmag=[]
cra2_sigrmag=[]
cra2_imag=[]
cra2_sigimag=[]
cra2_pmem=[]
cra2_pmemlo1=[]
cra2_pmemhi1=[]
cra2_pmemlo2=[]
cra2_pmemhi2=[]
cra2_pnon=[]
cra2_pnonlo1=[]
cra2_pnonhi1=[]
cra2_pnonlo2=[]
cra2_pnonhi2=[]

for line in data: # fill arrays
    p=line.split()
    cra2_ra.append(float(p[0]))
    cra2_dec.append(float(p[1]))
    cra2_xi.append(float(p[2]))
    cra2_eta.append(float(p[3]))
    cra2_r.append(float(p[4]))
    cra2_theta.append(float(p[5]))
    cra2_hjd.append(float(p[6]))
    cra2_v.append(float(p[7]))
    cra2_sigv.append(float(p[8]))
    cra2_skewv.append(float(p[9]))
    cra2_kurtv.append(float(p[10]))
    cra2_teff.append(float(p[11]))
    cra2_sigteff.append(float(p[12]))
    cra2_skewteff.append(float(p[13]))
    cra2_kurtteff.append(float(p[14]))
    cra2_logg.append(float(p[15]))
    cra2_siglogg.append(float(p[16]))
    cra2_skewlogg.append(float(p[17]))
    cra2_kurtlogg.append(float(p[18]))
    cra2_z.append(float(p[19]))
    cra2_sigz.append(float(p[20]))
    cra2_skewz.append(float(p[21]))
    cra2_kurtz.append(float(p[22]))
    cra2_snratio.append(float(p[24]))
    cra2_gmag.append(float(p[25]))
    cra2_siggmag.append(float(p[26]))
    cra2_rmag.append(float(p[27]))
    cra2_sigrmag.append(float(p[28]))
    cra2_imag.append(float(p[29]))
    cra2_sigimag.append(float(p[30]))
    cra2_pmem.append(float(p[31]))
    cra2_pmemlo1.append(float(p[32]))
    cra2_pmemhi1.append(float(p[33]))
    cra2_pmemlo2.append(float(p[34]))
    cra2_pmemhi2.append(float(p[35]))
    cra2_pnon.append(float(p[36]))
    cra2_pnonlo1.append(float(p[37]))
    cra2_pnonhi1.append(float(p[38]))
    cra2_pnonlo2.append(float(p[39]))
    cra2_pnonhi2.append(float(p[40]))

cra2_ra=np.array(cra2_ra)
cra2_dec=np.array(cra2_dec)
cra2_xi=np.array(cra2_xi)
cra2_eta=np.array(cra2_eta)
cra2_r=np.array(cra2_r)
cra2_theta=np.array(cra2_theta)
cra2_hjd=np.array(cra2_hjd)
cra2_v=np.array(cra2_v)
cra2_sigv=np.array(cra2_sigv)
cra2_skewv=np.array(cra2_skewv)
cra2_kurtv=np.array(cra2_kurtv)
cra2_teff=np.array(cra2_teff)
cra2_sigteff=np.array(cra2_sigteff)
cra2_skewteff=np.array(cra2_skewteff)
cra2_kurtteff=np.array(cra2_kurtteff)
cra2_logg=np.array(cra2_logg)
cra2_siglogg=np.array(cra2_siglogg)
cra2_skewlogg=np.array(cra2_skewlogg)
cra2_kurtlogg=np.array(cra2_kurtlogg)
cra2_z=np.array(cra2_z)
cra2_sigz=np.array(cra2_sigz)
cra2_skewz=np.array(cra2_skewz)
cra2_kurtz=np.array(cra2_kurtz)
cra2_pmem=np.array(cra2_pmem)
cra2_snratio=np.array(cra2_snratio)
cra2_gmag=np.array(cra2_gmag)
cra2_siggmag=np.array(cra2_siggmag)
cra2_rmag=np.array(cra2_rmag)
cra2_sigrmag=np.array(cra2_sigrmag)
cra2_imag=np.array(cra2_imag)
cra2_sigimag=np.array(cra2_sigimag)
cra2_pmem=np.array(cra2_pmem)
cra2_pmemlo1=np.array(cra2_pmemlo1)
cra2_pmemhi1=np.array(cra2_pmemhi1)
cra2_pmemlo2=np.array(cra2_pmemlo2)
cra2_pmemhi2=np.array(cra2_pmemhi2)
cra2_pnon=np.array(cra2_pnon)
cra2_pnonlo1=np.array(cra2_pnonlo1)
cra2_pnonhi1=np.array(cra2_pnonhi1)
cra2_pnonlo2=np.array(cra2_pnonlo2)
cra2_pnonhi2=np.array(cra2_pnonhi2)
    
cra2_mag=cra2_imag
cra2_col=cra2_gmag-cra2_imag
cra2_sigr=cra2_r-cra2_r+0.000001

cra2_vmem=[70.,110.]
cra2_loggmem=[0.5,3.2]
cra2_zmem=[-4.,-0.5]
cra2_teffmem=[4000,7500]
cra2_rmem=[0.,85.]
cra2_magmem=[21.5,18]
cra2_colmem=[0.4,0.75]

hjd1=np.where(np.abs(cra2_hjd-2457505.6) < 1.)
hjd2=np.where(np.abs(cra2_hjd-2457508.6) < 1.)
hjd3=np.where(np.abs(cra2_hjd-2457519.6) < 1.)

#cra2_keep=np.where((cra2_sigv < maxsigv) & (cra2_skewv >= -1.) & (cra2_skewv <= 1.) & (cra2_kurtv >= -1) & (cra2_kurtv <= 1))
cra2_keep=np.where((cra2_sigv < maxsigv))#) & (cra2_skewv >= -1.) & (cra2_skewv <= 1.) & (cra2_kurtv >= -1) & (cra2_kurtv <= 1))
#cra2_mem=np.where((cra2_sigv < maxsigv) & (cra2_skewv > -1.) & (cra2_skewv < 1.) & (cra2_kurtv > -1.) & (cra2_kurtv < 1.) & (cra2_pmem > 0.9))

cra2_mem=np.where(cra2_pmem > 0.5)
cra2_good=np.where(cra2_sigv <= maxsigv)
bad=np.where((np.abs(kurtv) >1.))
badskew=np.where((np.abs(skewv) >1.))
cra2_center=np.where((cra2_r < 15.))

cra2_memrhalf1=np.where((cra2_pmem > 0.5) & (cra2_r < 31.2))
cra2_rhalf1=np.where(cra2_r < 31.2)
cra2_memrhalf2=np.where((cra2_pmem > 0.5) & (cra2_r >= 31.2))
cra2_rhalf2=np.where(cra2_r >= 31.2)
badrhalf1=np.where((np.abs(kurtv) > 1.) & (r < 31.2))
badskewrhalf1=np.where((np.abs(skewv) > 1.) & (r < 31.2))
badrhalf2=np.where((np.abs(kurtv) > 1.) & (r >= 31.2))
badskewrhalf2=np.where((np.abs(skewv) > 1.) & (r >= 31.2))


cra2_mem1=np.where((cra2_pmem > 0.5) & (np.abs(cra2_hjd-2457505.6)<1.))
cra2_good1=np.where((np.abs(cra2_hjd-2457505.6) <1.))
bad1=np.where((np.abs(hjd-2457505.6) <1.) & (np.abs(kurtv)>1.))
badskew1=np.where((np.abs(hjd-2457505.6) <1.) & (np.abs(skewv)>1.))
cra2_mem2=np.where((cra2_pmem > 0.5) & (np.abs(cra2_hjd-2457508.6)<1.))
cra2_good2=np.where((np.abs(cra2_hjd-2457508.6) <1.))
bad2=np.where((np.abs(hjd-2457508.6) <1.) & (np.abs(kurtv)>1.))
badskew2=np.where((np.abs(hjd-2457508.6) <1.) & (np.abs(skewv)>1.))
cra2_mem3=np.where((cra2_pmem > 0.5) & (np.abs(cra2_hjd-2457519.6)<1.))
cra2_good3=np.where((np.abs(cra2_hjd-2457519.6) <1.))
bad3=np.where((np.abs(hjd-2457519.6) <1.) & (np.abs(kurtv)>1.))
badskew3=np.where((np.abs(hjd-2457519.6) <1.) & (np.abs(skewv)>1.))

gs=plt.GridSpec(2,10) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
#fig.set_
ax0_0=fig.add_subplot(gs[0,0:4])
#ax0_1=fig.add_subplot(gs[0,1])

collim=[0,2]
collim2=[0.05,1.95]
collim3=[0.,1.95]
collim4=[0.05,2.]
maglim=[21.25,15.75]
rticks1=[90,60,30,0,-30]
rticks2=[-30,-15,0,15,30]

ax0_0.set_xlabel(r'$g-i$ [mag]',fontsize=10,rotation=0,labelpad=5)
ax0_0.set_ylabel(r'$i$ [mag]',fontsize=10,rotation=90,labelpad=1)
ax0_0.set_xlim(collim)
ax0_0.set_ylim(maglim)
ax0_0.set_xscale(u'linear')
ax0_0.set_yscale(u'linear')
#ax0_0.set_xticks(rticks1)
#ax0_0.set_yticks(rticks2)
ax0_0.scatter(atlas_col[atlas_center],atlas_mag[atlas_center],s=1,lw=0,edgecolor='none',alpha=0.69,marker='o',color='0.5',rasterized=True)
ax0_0.scatter(col[bad],mag[bad],s=7,lw=0.5,edgecolor='k',alpha=0.99,marker='x',color='k',rasterized=False)
ax0_0.scatter(col[badskew],mag[badskew],s=7,lw=0.5,edgecolor='k',alpha=0.99,marker='x',color='k',rasterized=False)
ax0_0.scatter(cra2_col[cra2_good],cra2_mag[cra2_good],s=5,lw=0.5,edgecolor='k',alpha=0.99,marker='o',color='k',rasterized=False)
ax0_0.scatter(cra2_col[cra2_mem],cra2_mag[cra2_mem],s=5,lw=0.5,edgecolor='r',alpha=0.99,marker='o',color='r',rasterized=False)
#ax0_0.scatter(rgb_col,rgb_mag,s=3,lw=0.5,edgecolor='g',alpha=0.99,marker='o',color='g',rasterized=True)
ax0_0.plot(cra2_iso170_g-cra2_iso170_i,cra2_iso170_i+cra2_dmodulus,color='r',label='[Fe/H]$=-1.7$',rasterized=False)
#ax0_0.plot(cra2_iso200_g-cra2_iso200_i,cra2_iso200_i+cra2_dmodulus,color='b',label='[Fe/H]$=-2.0$')
#ax0_0.plot(cra2_iso200age15_g-cra2_iso200age15_i,cra2_iso200age15_i+cra2_dmodulus,color='g',label='[Fe/H]=-2.0,age=9Gyr')
ax0_0.legend(loc=4,fontsize=7,handlelength=1,numpoints=1,scatterpoints=1,shadow=False)
ax0_0.text(0.1,16.5,'Cra 2',fontsize=12)

plotfilename='cra2_cmd.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
