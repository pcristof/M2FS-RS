import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
from scipy.stats import kde
import random
import mycode2
import scipy.optimize as optimize
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.8)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='10')
plt.rc('ytick',labelsize='10')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)
    
gdagger=1.2e-10
ghat=9.2e-12
g=0.0043# grav constant in galaxy units        
data1='mcconnachie.dat'
data1b='lelli_dsph.dat'
data4='gru1teffprior_gradientpost_equal_weights.dat'
data5='ret2_gradientpost_equal_weights.dat'
data6='tuc2teffprior_gradientpost_equal_weights.dat'
data7='/physics2/mgwalker/chains/cra2gradientpost_equal_weights.dat'

h=0.7
h0=100.*h
triangle=200.
rhocrit=3.*(h0**2)/8./np.pi/6.67e-11/((3.09e+13)**2)/((1.e+6)**2)*((3.09e+16)**3)/2.e+30 #MSUN/PC^3
rhomin=triangle*rhocrit

logm200=np.array([8.,13.])
m200=10.**logm200
logc200=0.905-0.101*np.log10(m200/(1.e+12/h))
c200=10.**logc200
r200=(m200/(4./3.*np.pi*rhomin))**(0.333333)
rs=r200/c200
rhos=m200/(4.*np.pi*(rs**3)*(np.log(1.+c200)-c200/(1.+c200)))
mscale=4.*np.pi*(rs**3)*rhos*(np.log(2.)-0.5)
navarro_rh=0.2*rs
navarro_rd=navarro_rh/1.678

behroozi_epsilon0=-1.777#-0.146+0.133
behroozi_epsilona=-0.006#-0.361+0.113
behroozi_epsilonz=-0.000#-0.104+0.003
behroozi_epsilona2=-0.119#-0.012+0.061
behroozi_m10=11.514#-0.009+0.053
behroozi_m1a=-1.793#-0.330+0.315
behroozi_m1z=-0.251#-0.125+0.012
behroozi_alpha0=-1.412#-0.105+0.020
behroozi_alphaa=0.731#-0.296+0.344
behroozi_delta0=3.508#-0.369+0.087
behroozi_deltaa=2.608#-1.261+2.446
behroozi_deltaz=-0.043#-0.071+0.958
behroozi_gamma0=0.316#-0.012+0.076
behroozi_gammaa=1.319#-0.505+0.584
behroozi_gammaz=0.279#-0.081+0.256

behroozi_z=0.1
behroozi_a=1./(1.+behroozi_z)
behroozi_nu=np.exp(-4.*behroozi_a**2)
behroozi_logepsilon=behroozi_epsilon0+(behroozi_epsilona*(behroozi_a-1.)+behroozi_epsilonz*behroozi_z)*behroozi_nu+behroozi_epsilona2*(behroozi_a-1.)
behroozi_logm1=behroozi_m10+(behroozi_m1a*(behroozi_a-1.)+behroozi_m1z*behroozi_z)*behroozi_nu
behroozi_alpha=behroozi_alpha0+(behroozi_alphaa*(behroozi_a-1.))*behroozi_nu
behroozi_delta=behroozi_delta0+(behroozi_deltaa*(behroozi_a-1.)+behroozi_deltaz*behroozi_z)*behroozi_nu
behroozi_gamma=behroozi_gamma0+(behroozi_gammaa*(behroozi_a-1.)+behroozi_gammaz*behroozi_z)*behroozi_nu

behroozi_x=np.log10(m200/10.**(behroozi_logm1))
behroozi_x0=0.
behroozi_fx=-np.log10(10.**(behroozi_alpha*behroozi_x)+1.)+behroozi_delta*(np.log10(1.+np.exp(behroozi_x)))**(behroozi_gamma)/(1.+np.exp(10.**(-1.*behroozi_x)))
behroozi_f0=-np.log10(10.**(behroozi_alpha*behroozi_x0)+1.)+behroozi_delta*(np.log10(1.+np.exp(behroozi_x0)))**(behroozi_gamma)/(1.+np.exp(10.**(-1.*behroozi_x0)))
behroozi_logmstar=np.log10((10.**behroozi_logepsilon)*(10.**behroozi_logm1))+behroozi_fx-behroozi_f0

behroozi_mu0=-0.020#-0.096+0.168
behroozi_mua=0.081#-0.036+0.078
behroozi_kappa0=0.045#-0.051+0.110
behroozi_kappaa=-0.155#-0.133+0.133
behroozi_xi0=0.218#-0.033+0.011
behroozi_xia=-0.023#-0.068+0.052
behroozi_sigmaz=0.061#-0.008+0.017
behroozi_mu=behroozi_mu0+behroozi_mua*(behroozi_a-1.)
behroozi_kappa=behroozi_kappa0+behroozi_kappaa*(behroozi_a-1.)
behroozi_xi=behroozi_xi0+behroozi_xia*(behroozi_a-1.)
behroozi_sigma=0.070+behroozi_sigmaz*(behroozi_z-0.1)
behroozi_logmbias=behroozi_mu

logupsilonstar=np.log10(2.)
siglogupsilonstar=0.25
upsilonstar=10.**logupsilonstar
sigupsilonstar=np.log(10.)*10.**logupsilonstar*siglogupsilonstar

out='cra2_gobsgbar_newcommands.tex'
g1=open(out,'w')

with open('/physics2/mgwalker/chains/cra2jeanscountsnfwpost_equal_weights.dat') as f: # read data file
    data=f.readlines()[1:]
cra2jeanscountsnfw_m200=[]
cra2jeanscountsnfw_c200=[]
cra2jeanscountsnfw_mlstar=[]
for line in data: # fill arrays
    p=line.split()
    cra2jeanscountsnfw_m200.append(float(p[12]))
    cra2jeanscountsnfw_c200.append(float(p[13]))
    cra2jeanscountsnfw_mlstar.append(float(p[14]))
cra2jeanscountsnfw_m200=np.array(cra2jeanscountsnfw_m200)
cra2jeanscountsnfw_c200=np.array(cra2jeanscountsnfw_c200)
cra2jeanscountsnfw_mlstar=np.array(cra2jeanscountsnfw_mlstar)

with open('mcgaugh_gobsgbar.dat') as f: # read data file
    data=f.readlines()[13:]
mcgaugh_gbar=[]
mcgaugh_siggbar=[]
mcgaugh_gobs=[]
mcgaugh_siggobs=[]
for line in data: # fill arrays
    p=line.split()
    mcgaugh_gbar.append(float(p[0]))
    mcgaugh_siggbar.append(float(p[1]))
    mcgaugh_gobs.append(float(p[2]))
    mcgaugh_siggobs.append(float(p[3]))
mcgaugh_gbar=np.array(mcgaugh_gbar)
mcgaugh_siggbar=np.array(mcgaugh_siggbar)
mcgaugh_gobs=np.array(mcgaugh_gobs)
mcgaugh_siggobs=np.array(mcgaugh_siggobs)

mcgaugh_deltaloggobs=mcgaugh_gobs-np.log10(10.**mcgaugh_gbar/(1.-np.exp(-np.sqrt(10.**mcgaugh_gbar/gdagger))))
mcgaugh_sigdeltaloggobs=mcgaugh_siggobs

with open(data1b) as f: # read data file
    data=f.readlines()
lelli_dsph=[]
lelli_d=[]
lelli_sigd1=[]
lelli_sigd2=[]
lelli_dhost=[]
lelli_loglum=[]
lelli_sigloglum=[]
lelli_rhalf=[]
lelli_sigrhalf=[]
lelli_ellip=[]
lelli_vdisp=[]
lelli_sigvdisp1=[]
lelli_sigvdisp2=[]
lelli_n=[]
lelli_loggbar=[]
lelli_sigloggbar1=[]
lelli_sigloggbar2=[]
lelli_gobs=[]
lelli_sigloggobs1=[]
lelli_sigloggobs2=[]
lelli_resolved=[]
lelli_parent=[]
for line in data: # fill arrays
    p=line.split()
    lelli_dsph.append(str(p[0]))
    lelli_d.append(float(p[1]))
    lelli_sigd1.append(float(p[2]))
    lelli_sigd2.append(float(p[3]))
    lelli_dhost.append(float(p[4]))
    lelli_loglum.append(float(p[5]))
    lelli_sigloglum.append(float(p[6]))
    lelli_rhalf.append(float(p[7]))
    lelli_sigrhalf.append(float(p[8]))
    lelli_ellip.append(float(p[9]))
    lelli_vdisp.append(float(p[10]))
    lelli_sigvdisp1.append(float(p[11]))
    lelli_sigvdisp2.append(float(p[12]))
    lelli_n.append(float(p[13]))
    lelli_loggbar.append(float(p[14]))
    lelli_sigloggbar1.append(float(p[15]))
    lelli_sigloggbar2.append(float(p[16]))
    lelli_gobs.append(float(p[17]))
    lelli_sigloggobs1.append(float(p[18]))
    lelli_sigloggobs2.append(float(p[19]))
    lelli_resolved.append(float(p[20]))
    lelli_parent.append(str(p[21]))
lelli_dsph=np.array(lelli_dsph)
lelli_d=np.array(lelli_d)
lelli_sigd1=np.array(lelli_sigd1)
lelli_sigd2=np.array(lelli_sigd2)
lelli_dhost=np.array(lelli_dhost)
lelli_loglum=np.array(lelli_loglum)
lelli_sigloglum=np.array(lelli_sigloglum)
lelli_rhalf=np.array(lelli_rhalf)
lelli_sigrhalf=np.array(lelli_sigrhalf)
lelli_ellip=np.array(lelli_ellip)
lelli_vdisp=np.array(lelli_vdisp)
lelli_sigvdisp1=np.array(lelli_sigvdisp1)
lelli_sigvdisp2=np.array(lelli_sigvdisp2)
lelli_n=np.array(lelli_n)
lelli_loggbar=np.array(lelli_loggbar)
lelli_sigloggbar1=np.array(lelli_sigloggbar1)
lelli_sigloggbar2=np.array(lelli_sigloggbar2)
lelli_gobs=np.array(lelli_gobs)
lelli_sigloggobs1=np.array(lelli_sigloggobs1)
lelli_sigloggobs2=np.array(lelli_sigloggobs2)
lelli_resolved=np.array(lelli_resolved)
lelli_parent=np.array(lelli_parent)

lelli_mhost=np.zeros(len(lelli_rhalf))
for i in range(0,len(lelli_rhalf)):
    if lelli_ellip[i] > 0.:
        lelli_rhalf[i]=lelli_rhalf[i]*np.sqrt(1.-lelli_ellip[i])########convert to geometric mean radius
        lelli_sigrhalf[i]=lelli_sigrhalf[i]*np.sqrt(1.-lelli_ellip[i])
        if(lelli_parent[i]=='MW'):
            lelli_mhost[i]=1.e+12
        if(lelli_parent[i]=='M31'):
            lelli_mhost[i]=2.e+12

lelli_rhalf=3./4.*lelli_rhalf
lelli_sigrhalf=3./4.*lelli_sigrhalf
lelli_sigvdisp=(np.abs(lelli_sigvdisp1)+np.abs(lelli_sigvdisp2))/2.

lelli_luminosity=10.**lelli_loglum
lelli_sigluminosity=10.**lelli_loglum*np.log(10.)*lelli_sigloglum
lelli_mrhalf=5./2./0.0043*lelli_rhalf*lelli_vdisp**2

lelli_mbar=upsilonstar*lelli_luminosity
lelli_gbar=g*upsilonstar*lelli_luminosity/(2.**1.5)/lelli_rhalf**2*(1000.**2)/3.09e+16
lelli_gobs=5.*lelli_vdisp**2/2./lelli_rhalf*(1000.**2)/3.09e+16
lelli_siggbar=np.sqrt((lelli_gbar/lelli_luminosity*lelli_sigluminosity)**2+(lelli_gbar/upsilonstar*sigupsilonstar)**2+(2.*lelli_gbar/lelli_rhalf*lelli_sigrhalf)**2)
lelli_siggobs=np.sqrt((2.*lelli_gobs/lelli_vdisp*lelli_sigvdisp)**2+(lelli_gobs/lelli_rhalf*lelli_sigrhalf)**2)

lelli_loggbar=np.log10(lelli_gbar)
lelli_sigloggbar=np.sqrt((lelli_siggbar/lelli_gbar/np.log(10.))**2)
lelli_loggobs=np.log10(lelli_gobs)
lelli_sigloggobs=np.sqrt((lelli_siggobs/lelli_gobs/np.log(10.))**2)

lelli_gtides=g*lelli_mhost*2.*lelli_rhalf/((lelli_dhost*1000.)**3)/((3.09e+13))*(1000.**2)

lelli_deltaloggobs=lelli_loggobs-np.log10(lelli_gbar/(1.-np.exp(-np.sqrt(lelli_gbar/gdagger))))
lelli_sigdeltaloggobs=lelli_sigloggobs

with open(data1) as f: # read data file
    data=f.readlines()

parent=[]
dsph=[]
rah=[]
ram=[]
ras=[]
chardecd=[]
decm=[]
decs=[]
glon=[]
glat=[]
distance=[]
sigdistance=[]
vsys=[]
sigvsys=[]
vmag=[]
sigvmag=[]
rhalfarcmin=[]
sigrhalfarcmin=[]
muv=[]
sigmuv=[]
ellip=[]
absvmag=[]
sigabsvmag=[]
rhalf=[]
sigrhalf=[]
vdisp=[]
sigvdisp=[]
feh=[]
sigfeh=[]
method=[]

for line in data: # fill arrays
    p=line.split()
    parent.append(str(p[0]))
    dsph.append(str(p[1]))
    rah.append(float(p[3]))
    ram.append(float(p[4]))
    ras.append(float(p[5]))
    chardecd.append(float(p[6]))
    decm.append(float(p[7]))
    decs.append(str(p[8]))
    glon.append(float(p[9]))
    glat.append(float(p[10]))
    distance.append(float(p[11]))
    sigdistance.append(float(p[12]))
    vsys.append(float(p[14]))
    sigvsys.append(float(p[15]))
    vmag.append(float(p[16]))
    sigvmag.append(float(p[17]))
    rhalfarcmin.append(float(p[19]))
    sigrhalfarcmin.append(float(p[20]))
    muv.append(float(p[22]))
    sigmuv.append(float(p[23]))
    ellip.append(float(p[25]))
    absvmag.append(float(p[26]))
    sigabsvmag.append(float(p[27]))
    rhalf.append(float(p[29]))
    sigrhalf.append(float(p[30]))
    vdisp.append(float(p[32]))
    sigvdisp.append(float(p[33]))
    feh.append(float(p[35]))
    sigfeh.append(float(p[36]))
    method.append(str(p[37]))

parent=np.array(parent)
dsph=np.array(dsph)
rah=np.array(rah)
ram=np.array(ram)
ras=np.array(ras)
chardecd=np.array(chardecd)
decm=np.array(decm)
decs=np.array(decs)
glon=np.array(glon)
glat=np.array(glat)
distance=np.array(distance)
sigdistance=np.array(sigdistance)
vsys=np.array(vsys)
sigvsys=np.array(sigvsys)
vmag=np.array(vmag)
sigvmag=np.array(sigvmag)
rhalfarcmin=np.array(rhalfarcmin)
sigrhalfarcmin=np.array(sigrhalfarcmin)
muv=np.array(muv)
sigmuv=np.array(sigmuv)
ellip=np.array(ellip)
absvmag=np.array(absvmag)
sigabsvmag=np.array(sigabsvmag)
rhalf=np.array(rhalf)
sigrhalf=np.array(sigrhalf)
vdisp=np.array(vdisp)
sigvdisp=np.array(sigvdisp)
feh=np.array(feh)
sigfeh=np.array(sigfeh)
method=np.array(method)

vdisp[8]=2.5

for i in range(0,len(rhalf)):
    if ellip[i] > 0.:
        rhalf[i]=rhalf[i]*np.sqrt(1.-ellip[i])########convert to geometric mean radius
        sigrhalf[i]=sigrhalf[i]*np.sqrt(1.-ellip[i])


with open(data4) as f: # read data file
    data=f.readlines()

gru1vmean=[]
gru1vdisp=[]
gru1vgrad=[]
gru1vtheta=[]
gru1fehmean=[]
gru1fehdisp=[]
gru1fehgrad=[]
gru1like=[]

for line in data: # fill arrays
    p=line.split()
    gru1vmean.append(float(p[0]))
    gru1vdisp.append(float(p[1]))
    gru1vgrad.append(float(p[2]))
    gru1vtheta.append(float(p[3]))
    gru1fehmean.append(float(p[4]))
    gru1fehdisp.append(float(p[5]))
    gru1fehgrad.append(float(p[6]))
    gru1like.append(float(p[7]))

gru1vmean=np.array(gru1vmean)
gru1vdisp=np.array(gru1vdisp)
gru1vgrad=np.array(gru1vgrad)
gru1vtheta=np.array(gru1vtheta)
gru1fehmean=np.array(gru1fehmean)
gru1fehdisp=np.array(gru1fehdisp)
gru1fehgrad=np.array(gru1fehgrad)
gru1like=np.array(gru1like)

gru1_vdisp0=np.array([np.median(gru1vdisp)])
gru1_sigvdisp0=np.array([np.std(gru1vdisp)])
gru1_feh=np.array([np.median(gru1fehmean)])
gru1_sigfeh=np.array([np.std(gru1fehmean)])
gru1_rhalf0=62.
gru1_sigrhalf0=30.
gru1_rhalf=np.random.normal(loc=gru1_rhalf0,scale=gru1_sigrhalf0,size=len(gru1vdisp))
#gru1_sigrhalf=np.array([1.])
gru1_absvmag0=-3.4
gru1_sigabsvmag0=0.3
gru1_absvmag=np.random.normal(loc=gru1_absvmag0,scale=gru1_sigabsvmag0,size=len(gru1vdisp))
#gru1_sigabsvmag=np.array([0.1])
gru1_rho0=gru1_vdisp0**2/g/gru1_rhalf0**2
gru1_sigrho0=np.sqrt((2.*gru1_vdisp0/gru1_rhalf0**2/g*gru1_sigvdisp0)**2+(2.*gru1_vdisp0**2/g/gru1_rhalf0**3*gru1_sigrhalf0)**2)
gru1_fehdisp=[np.median(gru1fehdisp)]
gru1_sigfehdisp=[np.std(gru1fehdisp)]


with open(data5) as f: # read data file
    data=f.readlines()

ret2vmean=[]
ret2vdisp=[]
ret2vgrad=[]
ret2vtheta=[]
ret2fehmean=[]
ret2fehdisp=[]
ret2fehgrad=[]
ret2like=[]

for line in data: # fill arrays
    p=line.split()
    ret2vmean.append(float(p[0]))
    ret2vdisp.append(float(p[1]))
    ret2vgrad.append(float(p[2]))
    ret2vtheta.append(float(p[3]))
    ret2fehmean.append(float(p[4]))
    ret2fehdisp.append(float(p[5]))
    ret2fehgrad.append(float(p[6]))
    ret2like.append(float(p[7]))

ret2vmean=np.array(ret2vmean)
ret2vdisp=np.array(ret2vdisp)
ret2vgrad=np.array(ret2vgrad)
ret2vtheta=np.array(ret2vtheta)
ret2fehmean=np.array(ret2fehmean)
ret2fehdisp=np.array(ret2fehdisp)
ret2fehgrad=np.array(ret2fehgrad)
ret2like=np.array(ret2like)

ret2_vdisp0=np.array([np.median(ret2vdisp)])
ret2_sigvdisp0=np.array([np.std(ret2vdisp)])
ret2_feh=np.array([np.median(ret2fehmean)])
ret2_sigfeh=np.array([np.std(ret2fehmean)])
ret2_rhalf0=32.
ret2_sigrhalf0=2.
ret2_rhalf=np.random.normal(loc=ret2_rhalf0,scale=ret2_sigrhalf0,size=len(ret2vdisp))
#ret2_sigrhalf=np.array([1.])
ret2_absvmag0=-2.7
ret2_sigabsvmag0=0.1
ret2_absvmag=np.random.normal(loc=ret2_absvmag0,scale=0.2,size=len(ret2vdisp))
#ret2_sigabsvmag=np.array([0.1])
ret2_rho0=ret2_vdisp0**2/g/ret2_rhalf0**2
ret2_sigrho0=np.sqrt((2.*ret2_vdisp0/ret2_rhalf0**2/g*ret2_sigvdisp0)**2+(2.*ret2_vdisp0**2/g/ret2_rhalf0**3*ret2_sigrhalf0)**2)


with open(data6) as f: # read data file
    data=f.readlines()

tuc2vmean=[]
tuc2vdisp=[]
tuc2vgrad=[]
tuc2vtheta=[]
tuc2fehmean=[]
tuc2fehdisp=[]
tuc2fehgrad=[]
tuc2like=[]

for line in data: # fill arrays
    p=line.split()
    tuc2vmean.append(float(p[0]))
    tuc2vdisp.append(float(p[1]))
    tuc2vgrad.append(float(p[2]))
    tuc2vtheta.append(float(p[3]))
    tuc2fehmean.append(float(p[4]))
    tuc2fehdisp.append(float(p[5]))
    tuc2fehgrad.append(float(p[6]))
    tuc2like.append(float(p[7]))

tuc2vmean=np.array(tuc2vmean)
tuc2vdisp=np.array(tuc2vdisp)
tuc2vgrad=np.array(tuc2vgrad)
tuc2vtheta=np.array(tuc2vtheta)
tuc2fehmean=np.array(tuc2fehmean)
tuc2fehdisp=np.array(tuc2fehdisp)
tuc2fehgrad=np.array(tuc2fehgrad)
tuc2like=np.array(tuc2like)

tuc2_vdisp0=np.array([np.median(tuc2vdisp)])
tuc2_sigvdisp0=np.array([np.std(tuc2vdisp)])
tuc2_feh=np.array([np.median(tuc2fehmean)])
tuc2_sigfeh=np.array([np.std(tuc2fehmean)])
tuc2_rhalf0=165.
tuc2_sigrhalf0=28.
tuc2_rhalf=np.random.normal(loc=tuc2_rhalf0,scale=tuc2_sigrhalf0,size=len(tuc2vdisp))
#tuc2_sigrhalf=np.array([1.])
tuc2_absvmag0=-3.8
tuc2_sigabsvmag0=0.1
tuc2_absvmag=np.random.normal(loc=tuc2_absvmag0,scale=tuc2_sigabsvmag0,size=len(tuc2vdisp))
#tuc2_sigabsvmag=np.array([0.1])
tuc2_rho0=tuc2_vdisp0**2/g/tuc2_rhalf0**2
tuc2_sigrho0=np.sqrt((2.*tuc2_vdisp0/tuc2_rhalf0**2/g*tuc2_sigvdisp0)**2+(2.*tuc2_vdisp0**2/g/tuc2_rhalf0**3*tuc2_sigrhalf0)**2)
tuc2_fehdisp=[np.median(tuc2fehdisp)]
tuc2_sigfehdisp=[np.std(tuc2fehdisp)]

with open(data7) as f: # read data file
    data=f.readlines()
cra2vmean=[]
cra2vvar=[]
cra2fehmean=[]
cra2fehvar=[]
cra2rslight=[]
cra2like=[]
for line in data: # fill arrays
    p=line.split()
    cra2vmean.append(float(p[4]))
    cra2vvar.append(float(p[2]))
    cra2fehmean.append(float(p[5]))
    cra2fehvar.append(float(p[3]))
    cra2rslight.append(float(p[1]))
    cra2like.append(float(p[7]))
cra2vmean=np.array(cra2vmean)
cra2vvar=np.array(cra2vvar)
cra2fehmean=np.array(cra2fehmean)
cra2fehvar=np.array(cra2fehvar)
cra2rslight=np.array(cra2rslight)
cra2like=np.array(cra2like)

cra2rslight=10.**cra2rslight
cra2rslightpc=117000.*np.tan(cra2rslight/60.*np.pi/180.)
cra2vdisp=np.sqrt(10.**cra2vvar)
cra2fehdisp=np.sqrt(10.**cra2fehvar)
cra2_fehdisp=[np.median(cra2fehdisp)]
cra2_sigfehdisp=[np.std(cra2fehdisp)]

cra2_vdisp0=np.array([np.median(cra2vdisp)])
cra2_sigvdisp0=np.array([np.std(cra2vdisp)])
cra2_feh=np.array([np.median(cra2fehmean)])
cra2_sigfeh=np.array([np.std(cra2fehmean)])
cra2_rhalf0=np.median(cra2rslightpc)
cra2_sigrhalf0=np.std(cra2rslightpc)
cra2_rhalf=cra2rslightpc
cra2_absvmag0=-8.2
cra2_sigabsvmag0=0.1
cra2_absvmag=np.random.normal(loc=cra2_absvmag0,scale=cra2_sigabsvmag0,size=len(cra2vdisp))
cra2_rho0=cra2_vdisp0**2/g/cra2_rhalf0**2
cra2_sigrho0=np.sqrt((2.*cra2_vdisp0/cra2_rhalf0**2/g*cra2_sigvdisp0)**2+(2.*cra2_vdisp0**2/g/cra2_rhalf0**3*cra2_sigrhalf0)**2)

luminosity=10.**((absvmag-4.83)/(-2.5))
sigluminosity=np.log(10.)/2.5*10.**((absvmag-4.83)/(-2.5))*sigabsvmag
mrhalf=5./2./0.0043*rhalf*vdisp**2
sigmrhalf=np.sqrt(((5./2.*2.*rhalf/0.0043*vdisp)**2)*(sigvdisp**2)+((5./2./0.0043*(vdisp**2))**2)*sigrhalf**2)
mlratio=mrhalf/(luminosity)
sigmlratio=np.sqrt((sigmrhalf**2)/(luminosity**2)+((mrhalf/luminosity**2)**2)*sigluminosity**2)
gbar=g*upsilonstar*luminosity/(2.**1.5)/rhalf**2*(1000.**2)/3.09e+16
gobs=5.*vdisp**2/2./rhalf*(1000.**2)/3.09e+16
siggbar=np.sqrt((gbar/luminosity*sigluminosity)**2+(gbar/upsilonstar*sigupsilonstar)**2+(2.*gbar/rhalf*sigrhalf)**2)
siggobs=np.sqrt((2.*gobs/vdisp*sigvdisp)**2+(gobs/rhalf*sigrhalf)**2)
loggbar=np.log10(gbar)
sigloggbar=np.sqrt((siggbar/gbar/np.log(10.))**2)
loggobs=np.log10(gobs)
sigloggobs=np.sqrt((siggobs/gobs/np.log(10.))**2)

deltaloggobs=loggobs-np.log10(gbar/(1.-np.exp(-np.sqrt(gbar/gdagger))))
sigdeltaloggobs=sigloggobs

rho=vdisp**2/rhalf**2/g
sigrho=np.sqrt((2.*vdisp/rhalf**2/g*sigvdisp)**2+(2.*vdisp**2/g/rhalf**3*sigrhalf)**2)
mw_rhokeep=np.where((parent =='MW') & (sigrho/rho <=1.))
m31_rhokeep=np.where((parent =='M31') & (sigrho/rho <=1.))
rest_rhokeep=np.where((parent =='Rest') & (sigrho/rho <= 1.))
mw_mlkeep=np.where((parent =='MW') & (sigmlratio/mlratio <=1.))
m31_mlkeep=np.where((parent =='M31') & (sigmlratio/mlratio <=1.))
rest_mlkeep=np.where((parent =='Rest') & (sigmlratio/mlratio <= 1.))

gru1_vdisp=gru1vdisp
gru1_luminosity0=10.**((gru1_absvmag0-4.83)/(-2.5))
gru1_luminosity=10.**((gru1_absvmag-4.83)/(-2.5))
gru1_sigluminosity0=np.log(10.)/2.5*10.**((gru1_absvmag0-4.83)/(-2.5))*gru1_sigabsvmag0
gru1_mrhalf0=5./2./0.0043*gru1_rhalf0*gru1_vdisp0**2
gru1_mrhalf=5./2./0.0043*gru1_rhalf*gru1vdisp**2
gru1_sigmrhalf0=np.sqrt(5./2.*2.*gru1_rhalf0/0.0043*gru1_vdisp0*(gru1_sigvdisp0**2)+((5./2./0.0043*(gru1_vdisp0**2))**2)*gru1_sigrhalf0**2)
gru1_mlratio=gru1_mrhalf/(gru1_luminosity)
gru1_mlratio0=gru1_mrhalf0/gru1_luminosity0
gru1_sigmlratio0=np.sqrt((gru1_sigmrhalf0**2)/(gru1_luminosity0**2)+((gru1_mrhalf0/gru1_luminosity0**2)**2)*gru1_sigluminosity0**2)
gru1_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(gru1_mrhalf))
gru1_upsilonstar=10.**gru1_logupsilonstar
gru1_gbar=g*gru1_upsilonstar*gru1_luminosity/(2.**1.5)/gru1_rhalf**2*(1000.**2)/3.09e+16
gru1_gobs=5.*gru1_vdisp**2/2./gru1_rhalf*(1000.**2)/3.09e+16
gru1_loggbar=np.log10(gru1_gbar)
gru1_loggobs=np.log10(gru1_gobs)
gru1_deltaloggobs=gru1_loggobs-np.log10(gru1_gbar/(1.-np.exp(-np.sqrt(gru1_gbar/gdagger))))


ret2_vdisp=ret2vdisp
ret2_luminosity0=10.**((ret2_absvmag0-4.83)/(-2.5))
ret2_luminosity=10.**((ret2_absvmag-4.83)/(-2.5))
ret2_sigluminosity0=np.log(10.)/2.5*10.**((ret2_absvmag0-4.83)/(-2.5))*ret2_sigabsvmag0
ret2_mrhalf0=5./2./0.0043*ret2_rhalf0*ret2_vdisp0**2
ret2_mrhalf=5./2./0.0043*ret2_rhalf*ret2vdisp**2
ret2_sigmrhalf0=np.sqrt(5./2.*2.*ret2_rhalf0/0.0043*ret2_vdisp0*(ret2_sigvdisp0**2)+((5./2./0.0043*(ret2_vdisp0**2))**2)*ret2_sigrhalf0**2)
ret2_mlratio=ret2_mrhalf/(ret2_luminosity)
ret2_mlratio0=ret2_mrhalf0/ret2_luminosity0
ret2_sigmlratio0=np.sqrt((ret2_sigmrhalf0**2)/(ret2_luminosity0**2)+((ret2_mrhalf0/ret2_luminosity0**2)**2)*ret2_sigluminosity0**2)
ret2_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(ret2_mrhalf))
ret2_upsilonstar=10.**ret2_logupsilonstar
ret2_gbar=g*ret2_upsilonstar*ret2_luminosity/(2.**1.5)/ret2_rhalf**2*(1000.**2)/3.09e+16
ret2_gobs=5.*ret2_vdisp**2/2./ret2_rhalf*(1000.**2)/3.09e+16
ret2_loggbar=np.log10(ret2_gbar)
ret2_loggobs=np.log10(ret2_gobs)
ret2_deltaloggobs=ret2_loggobs-np.log10(ret2_gbar/(1.-np.exp(-np.sqrt(ret2_gbar/gdagger))))

tuc2_vdisp=tuc2vdisp
tuc2_luminosity0=10.**((tuc2_absvmag0-4.83)/(-2.5))
tuc2_luminosity=10.**((tuc2_absvmag-4.83)/(-2.5))
tuc2_sigluminosity0=np.log(10.)/2.5*10.**((tuc2_absvmag0-4.83)/(-2.5))*tuc2_sigabsvmag0
tuc2_mrhalf0=5./2./0.0043*tuc2_rhalf0*tuc2_vdisp0**2
tuc2_mrhalf=5./2./0.0043*tuc2_rhalf*tuc2vdisp**2
tuc2_sigmrhalf0=np.sqrt(5./2.*2.*tuc2_rhalf0/0.0043*tuc2_vdisp0*(tuc2_sigvdisp0**2)+((5./2./0.0043*(tuc2_vdisp0**2))**2)*tuc2_sigrhalf0**2)
tuc2_mlratio=tuc2_mrhalf/(tuc2_luminosity)
tuc2_mlratio0=tuc2_mrhalf0/tuc2_luminosity0
tuc2_sigmlratio0=np.sqrt((tuc2_sigmrhalf0**2)/(tuc2_luminosity0**2)+((tuc2_mrhalf0/tuc2_luminosity0**2)**2)*tuc2_sigluminosity0**2)
tuc2_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(tuc2_mrhalf))
tuc2_upsilonstar=10.**tuc2_logupsilonstar
tuc2_gbar=g*tuc2_upsilonstar*tuc2_luminosity/(2.**1.5)/tuc2_rhalf**2*(1000.**2)/3.09e+16
tuc2_gobs=5.*tuc2_vdisp**2/2./tuc2_rhalf*(1000.**2)/3.09e+16
tuc2_loggbar=np.log10(tuc2_gbar)
tuc2_loggobs=np.log10(tuc2_gobs)
tuc2_deltaloggobs=tuc2_loggobs-np.log10(tuc2_gbar/(1.-np.exp(-np.sqrt(tuc2_gbar/gdagger))))

df44_rhalf=4600.
df44_mhalf=0.71e+10
df44_mstar=1.5e+8
df44_gbar=g*df44_mstar/df44_rhalf**2*(1000.**2)/3.09e+16
df44_gobs=g*df44_mhalf/df44_rhalf**2*(1000.**2)/3.09e+16
df44_mbar=df44_mstar

cra2_vdisp=cra2vdisp
cra2_luminosity0=10.**((cra2_absvmag0-4.83)/(-2.5))
cra2_luminosity=10.**((cra2_absvmag-4.83)/(-2.5))
cra2_sigluminosity0=np.log(10.)/2.5*10.**((cra2_absvmag0-4.83)/(-2.5))*cra2_sigabsvmag0
cra2_mrhalf0=5./2./0.0043*cra2_rhalf0*cra2_vdisp0**2
cra2_mrhalf=5./2./0.0043*cra2_rhalf*cra2vdisp**2
cra2_sigmrhalf0=np.sqrt(5./2.*2.*cra2_rhalf0/0.0043*cra2_vdisp0*(cra2_sigvdisp0**2)+((5./2./0.0043*(cra2_vdisp0**2))**2)*cra2_sigrhalf0**2)
cra2_mlratio=cra2_mrhalf/(cra2_luminosity)
cra2_mlratio0=cra2_mrhalf0/cra2_luminosity0
cra2_sigmlratio0=np.sqrt((cra2_sigmrhalf0**2)/(cra2_luminosity0**2)+((cra2_mrhalf0/cra2_luminosity0**2)**2)*cra2_sigluminosity0**2)
cra2_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(cra2_mrhalf))
cra2_upsilonstar=10.**cra2_logupsilonstar
cra2_gbar=g*cra2_upsilonstar*cra2_luminosity/(2.**1.5)/cra2_rhalf**2*(1000.**2)/3.09e+16
cra2_gobs=5.*cra2_vdisp**2/2./cra2_rhalf*(1000.**2)/3.09e+16
cra2_mbar0=cra2_luminosity0*upsilonstar
cra2_loggbar=np.log10(cra2_gbar)
cra2_loggobs=np.log10(cra2_gobs)
cra2_deltaloggobs=cra2_loggobs-np.log10(cra2_gbar/(1.-np.exp(-np.sqrt(cra2_gbar/gdagger))))

#with open('/physics2/mgwalker/chains/cra2jeanscountsnfw.profiles') as f: # read data file
#    data=f.readlines()
#cra2nfw_rad=[]
#cra2nfw_radpc=[]
#cra2nfw_gbar=[]
#cra2nfw_gbarlo1=[]
#cra2nfw_gbarlo2=[]
#cra2nfw_gbarhi1=[]
#cra2nfw_gbarhi2=[]
#cra2nfw_gobs=[]
#cra2nfw_gobslo1=[]
#cra2nfw_gobslo2=[]
#cra2nfw_gobshi1=[]
#cra2nfw_gobshi2=[]
#for line in data: # fill arrays
#    p=line.split()
#    cra2nfw_rad.append(float(p[0]))
#    cra2nfw_radpc.append(float(p[1]))
#    cra2nfw_gbar.append(float(p[77]))
#    cra2nfw_gbarlo1.append(float(p[78]))
#    cra2nfw_gbarlo2.append(float(p[80]))
#    cra2nfw_gbarhi1.append(float(p[79]))
#    cra2nfw_gbarhi2.append(float(p[81]))
#    cra2nfw_gobs.append(float(p[82]))
#    cra2nfw_gobslo1.append(float(p[83]))
#    cra2nfw_gobslo2.append(float(p[85]))
#    cra2nfw_gobshi1.append(float(p[84]))
#    cra2nfw_gobshi2.append(float(p[86]))
#cra2nfw_rad=np.array(cra2nfw_rad)
#cra2nfw_radpc=np.array(cra2nfw_radpc)
#cra2nfw_gbar=np.array(cra2nfw_gbar)*(1000.**2)/3.09e+16
#cra2nfw_gbarlo1=np.array(cra2nfw_gbarlo1)*(1000.**2)/3.09e+16
#cra2nfw_gbarlo2=np.array(cra2nfw_gbarlo2)*(1000.**2)/3.09e+16
#cra2nfw_gbarhi1=np.array(cra2nfw_gbarhi1)*(1000.**2)/3.09e+16
#cra2nfw_gbarhi2=np.array(cra2nfw_gbarhi2)*(1000.**2)/3.09e+16
#cra2nfw_gobs=np.array(cra2nfw_gobs)*(1000.**2)/3.09e+16
#cra2nfw_gobslo1=np.array(cra2nfw_gobslo1)*(1000.**2)/3.09e+16
#cra2nfw_gobslo2=np.array(cra2nfw_gobslo2)*(1000.**2)/3.09e+16
#cra2nfw_gobshi1=np.array(cra2nfw_gobshi1)*(1000.**2)/3.09e+16
#cra2nfw_gobshi2=np.array(cra2nfw_gobshi2)*(1000.**2)/3.09e+16

with open('/nfs/nas-0-9/mgwalker.proj/catalogues_matt_crater2/sim6_hr_disk.csv') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()[1:]
sim0_mvir=[]
sim0_rvir=[]
sim0_rs=[]
sim0_a_peak=[]
sim0_mvir_peak=[]
sim0_rvir_peak=[]
sim0_rs_peak=[]
sim0_a_acc=[]
sim0_r_min=[]
sim0_r_max=[]
sim0_x_min=[]
sim0_x_max=[]
sim0_x=[]
sim0_y=[]
sim0_z=[]
sim0_vx=[]
sim0_vy=[]
sim0_vz=[]
sim0_mstar_fid=[]
sim0_mstar_sca=[]
sim0_mstar_ho=[]
for line in data: # fill arrays
    p=line.split()
    sim0_mvir.append(float(p[0]))
    sim0_rvir.append(float(p[1]))
    sim0_rs.append(float(p[2]))
    sim0_a_peak.append(float(p[3]))
    sim0_mvir_peak.append(float(p[4]))
    sim0_rvir_peak.append(float(p[5]))
    sim0_rs_peak.append(float(p[6]))
    sim0_a_acc.append(float(p[7]))
    sim0_r_min.append(float(p[8]))
    sim0_r_max.append(float(p[9]))
    sim0_x_min.append(float(p[10]))
    sim0_x_max.append(float(p[11]))
    sim0_x.append(float(p[12]))
    sim0_y.append(float(p[13]))
    sim0_z.append(float(p[14]))
    sim0_vx.append(float(p[15]))
    sim0_vy.append(float(p[16]))
    sim0_vz.append(float(p[17]))
    sim0_mstar_fid.append(float(p[18]))
    sim0_mstar_sca.append(float(p[19]))
    sim0_mstar_ho.append(float(p[20]))
sim0_mvir=np.array(sim0_mvir)
sim0_rvir=np.array(sim0_rvir)
sim0_rs=np.array(sim0_rs)
sim0_a_peak=np.array(sim0_a_peak)
sim0_mvir_peak=np.array(sim0_mvir_peak)
sim0_rvir_peak=np.array(sim0_rvir_peak)
sim0_rs_peak=np.array(sim0_rs_peak)
sim0_a_acc=np.array(sim0_a_acc)
sim0_r_min=np.array(sim0_r_min)
sim0_r_max=np.array(sim0_r_max)
sim0_x_min=np.array(sim0_x_min)
sim0_x_max=np.array(sim0_x_max)
sim0_x=np.array(sim0_x)
sim0_y=np.array(sim0_y)
sim0_z=np.array(sim0_z)
sim0_vx=np.array(sim0_vx)
sim0_vy=np.array(sim0_vy)
sim0_vz=np.array(sim0_vz)
sim0_mstar_fid=np.array(sim0_mstar_fid)
sim0_mstar_sca=np.array(sim0_mstar_sca)
sim0_mstar_ho=np.array(sim0_mstar_ho)

##########assign stellar masses
sim0_mstar=sim0_mstar_sca
m1=5.e+9
gamma=-0.26
sigma=0.2+gamma*(np.log10(sim0_mvir_peak/m1))
alpha=[]
for i in range(0,len(sim0_mvir)):
    if(np.log10(sim0_mvir_peak[i])>=8.4):
        alpha.append(2.4)
    if(np.log10(sim0_mvir_peak[i])<8.4):
        alpha.append(0.64)
alpha=np.array(alpha)

#alpha=1.92
#dev=np.random.normal(0.,sigma,np.size(kauket_mvir))
#sim0_logmstar=np.log10(5.e+9/10.**(11.5*alpha))+alpha*np.log10(kauket_mvir_peak)+dev
#sim0_mstar=10.**kauket_logmstar

sim0_gal2=np.where((sim0_mstar > 1.e+2)&(sim0_mstar <1.e+3))
sim0_gal3=np.where((sim0_mstar > 1.e+3)&(sim0_mstar <1.e+4))
sim0_gal4=np.where((sim0_mstar > 1.e+4)&(sim0_mstar <1.e+5))
sim0_gal5=np.where((sim0_mstar > 1.e+5))
sim0_distance=np.sqrt(sim0_x**2+sim0_y**2+sim0_z**2)
sim0_cvir=sim0_rvir/sim0_rs
sim0_cra2=np.where((sim0_mstar > 1.e+5) & (sim0_mvir < 2.e+7))

gs=plt.GridSpec(12,12) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
axm200=fig.add_subplot(gs[0:3,0:5])
axepsilon=fig.add_subplot(gs[3:6,0:5])
ax1_2=fig.add_subplot(gs[0:3,7:12])
ax2_2=fig.add_subplot(gs[3:6,7:12])
#axmvirhist=fig.add_subplot(gs[2:7,7:9])
#axepsilonhist=fig.add_subplot(gs[7:12,7:9])
#axchist=fig.add_subplot(gs[0:2,0:7])

notrust=[1,15,17,18,13,2]
trust=[0,16,11,14,12,23,22,9,10,21]
mwkeep=np.where((parent=='MW')&(siggobs<gobs))
m31keep=np.where((parent=='M31')&(siggobs<gobs))
restkeep=np.where((parent=='Rest')&(siggobs<gobs))
lelli_mw=np.where(lelli_parent=='MW')
lelli_m31=np.where(lelli_parent=='M31')
lelli_mwkeep=np.where((lelli_parent=='MW')&(lelli_siggobs/lelli_gobs<0.5))
lelli_m31keep=np.where((lelli_parent=='M31')&(lelli_siggobs/lelli_gobs<0.5))
#lelli_mwkeep=np.where((lelli_parent=='MW')&(lelli_rhalf > 100.))
#lelli_m31keep=np.where((lelli_parent=='M31')&(lelli_rhalf > 100.))

def findm200(x,c200,rhalf0,mrhalf0,rhocrit):
    m200=10.**x
    r200=(m200/(4./3.)/np.pi/200./rhocrit)**0.3333
    rs=r200/c200
    rhos=m200/4./np.pi/(rs**3)/(np.log(1.+c200)-c200/(1.+c200))
    mrhalf=4.*np.pi*rhos*(rs**3)*(np.log(1.+rhalf0/rs)-rhalf0/rs/(1.+rhalf0/rs))
    val=mrhalf-mrhalf0
    return val

maccio0_logm200=np.linspace(5.,15.,100)
maccio0_z=0.
maccio0_a=0.520+(0.905-0.520)*np.exp(-0.617*(maccio0_z**1.21))
maccio0_b=-0.101+0.026*maccio0_z
maccio0_logc200=maccio0_a+maccio0_b*np.log10(10.**maccio0_logm200/(1.e+12/h))# from dutton/maccio0 2014

maccio1_logm200=np.linspace(5.,15.,100)
maccio1_z=1.
maccio1_a=0.520+(0.905-0.520)*np.exp(-0.617*(maccio1_z**1.21))
maccio1_b=-0.101+0.026*maccio1_z
maccio1_logc200=maccio1_a+maccio1_b*np.log10(10.**maccio1_logm200/(1.e+12/h))# from dutton/maccio0 2014

maccio2_logm200=np.linspace(5.,15.,100)
maccio2_z=2.
maccio2_a=0.520+(0.905-0.520)*np.exp(-0.617*(maccio2_z**1.21))
maccio2_b=-0.101+0.026*maccio2_z
maccio2_logc200=maccio2_a+maccio2_b*np.log10(10.**maccio2_logm200/(1.e+12/h))# from dutton/maccio0 2014
    
maccio3_logm200=np.linspace(5.,15.,100)
maccio3_z=3.
maccio3_a=0.520+(0.905-0.520)*np.exp(-0.617*(maccio3_z**1.21))
maccio3_b=-0.101+0.026*maccio3_z
maccio3_logc200=maccio3_a+maccio3_b*np.log10(10.**maccio3_logm200/(1.e+12/h))# from dutton/maccio0 2014
    
maccio4_logm200=np.linspace(5.,15.,100)
maccio4_z=4.
maccio4_a=0.520+(0.905-0.520)*np.exp(-0.617*(maccio4_z**1.21))
maccio4_b=-0.101+0.026*maccio4_z
maccio4_logc200=maccio4_a+maccio4_b*np.log10(10.**maccio4_logm200/(1.e+12/h))# from dutton/maccio0 2014

maccio5_logm200=np.linspace(5.,15.,100)
maccio5_z=5.
maccio5_a=0.520+(0.905-0.520)*np.exp(-0.617*(maccio5_z**1.21))
maccio5_b=-0.101+0.026*maccio5_z
maccio5_logc200=maccio5_a+maccio5_b*np.log10(10.**maccio5_logm200/(1.e+12/h))# from dutton/maccio0 2014
    
maccio6_logm200=np.linspace(5.,15.,100)
maccio6_z=6.
maccio6_a=0.520+(0.905-0.520)*np.exp(-0.617*(maccio6_z**1.21))
maccio6_b=-0.101+0.026*maccio6_z
maccio6_logc200=maccio6_a+maccio6_b*np.log10(10.**maccio6_logm200/(1.e+12/h))# from dutton/maccio0 2014
    
cra2jeanscountsnfw_mlstar=cra2jeanscountsnfw_mlstar-cra2jeanscountsnfw_mlstar+np.log10(2.)
cra2_mstar=cra2_luminosity0*10.**cra2jeanscountsnfw_mlstar
cra2_epsilon=np.log10(cra2_mstar/10.**cra2jeanscountsnfw_m200)
k1=kde.gaussian_kde([cra2jeanscountsnfw_c200,cra2jeanscountsnfw_m200])
k2=kde.gaussian_kde([cra2jeanscountsnfw_c200,cra2_epsilon])
nbins=50
x1,y1=np.mgrid[np.min(cra2jeanscountsnfw_c200):np.max(cra2jeanscountsnfw_c200):nbins*1j,np.min(cra2jeanscountsnfw_m200):np.max(cra2jeanscountsnfw_m200):nbins*1j]
z1=k1(np.vstack([x1.flatten(),y1.flatten()]))
x2,y2=np.mgrid[np.min(cra2jeanscountsnfw_c200):np.max(cra2jeanscountsnfw_c200):nbins*1j,np.min(cra2_epsilon):np.max(cra2_epsilon):nbins*1j]
z2=k2(np.vstack([x2.flatten(),y2.flatten()]))

#axm200.xaxis.set_major_formatter(plt.NullFormatter())
axm200.set_ylabel(r'$\log_{10}[M_{\rm vir}/M_{\odot}]$',fontsize=11,rotation=90)
#axm200.set_xlabel(r'$\log_{10}[c_{200}]$',fontsize=12,rotation=90)
#axm200.set_xlabel(r'$R_{\rm h}$ [pc]',fontsize=11,rotation=0,labelpad=5)
axm200.set_ylim([6.01,11.9])
axm200.set_xlim([0,2])
axm200.set_xscale(u'linear')
axm200.set_yscale(u'linear')
axm200.xaxis.set_major_formatter(plt.NullFormatter())
axm200.pcolormesh(x1,y1,z1.reshape(x1.shape),cmap='binary',zorder=0.25)
axm200.plot(maccio0_logc200,maccio0_logm200,color='k',lw=0.5,alpha=1,linestyle='--',zorder=0.5,rasterized=True)
axm200.plot(maccio1_logc200,maccio1_logm200,color='k',lw=0.5,alpha=1,linestyle='--',zorder=0.5,rasterized=True)
axm200.plot(maccio2_logc200,maccio2_logm200,color='k',lw=0.5,alpha=1,linestyle='--',zorder=0.5,rasterized=True)
axm200.plot(maccio3_logc200,maccio3_logm200,color='k',lw=0.5,alpha=1,linestyle='--',zorder=0.5,rasterized=True)
axm200.plot(maccio4_logc200,maccio4_logm200,color='k',lw=0.5,alpha=1,linestyle='--',zorder=0.5,rasterized=True)
axm200.plot(maccio5_logc200,maccio5_logm200,color='k',lw=0.5,alpha=1,linestyle='--',zorder=0.5,rasterized=True)
axm200.plot(maccio6_logc200,maccio6_logm200,color='k',lw=0.5,alpha=1,linestyle='--',zorder=0.5,rasterized=True)
axm200.scatter(np.log10(sim0_cvir),np.log10(sim0_mvir),marker='o',color='k',s=1,alpha=0.3,rasterized=True,zorder=0.7)
axm200.scatter(np.log10(sim0_cvir[sim0_gal2]),np.log10(sim0_mvir[sim0_gal2]),marker='o',color='r',s=5,alpha=0.5,rasterized=True,zorder=110)
axm200.scatter(np.log10(sim0_cvir[sim0_gal3]),np.log10(sim0_mvir[sim0_gal3]),marker='o',color='g',s=5,alpha=0.5,rasterized=True,zorder=110)
axm200.scatter(np.log10(sim0_cvir[sim0_gal4]),np.log10(sim0_mvir[sim0_gal4]),marker='o',color='b',s=5,alpha=0.5,rasterized=True,zorder=110)
axm200.scatter(np.log10(sim0_cvir[sim0_gal5]),np.log10(sim0_mvir[sim0_gal5]),marker='o',color='m',s=5,alpha=0.5,rasterized=True,zorder=110)
#axm200.scatter(cra2jeanscountsnfw_c200,cra2jeanscountsnfw_m200,marker='o',color='g',s=1,alpha=0.35,rasterized=True)

#axepsilon.xaxis.set_major_formatter(plt.NullFormatter())
axepsilon.set_xlabel(r'$\log_{10}[r_{\rm vir}/r_s]$',fontsize=11,rotation=0)
axepsilon.set_ylabel(r'$\log_{10}[M_*/M_{\rm vir}]$',fontsize=12,rotation=90)
#axepsilon.set_xlabel(r'$R_{\rm h}$ [pc]',fontsize=11,rotation=0,labelpad=5)
axepsilon.set_ylim([-4.99,-0.01])
axepsilon.set_xlim([0,2])
axepsilon.set_xscale(u'linear')
axepsilon.set_yscale(u'linear')
axepsilon.plot([-1.,2.],np.log10([0.16,0.16]),lw=0.5,linestyle=':',zorder=0.5,alpha=1,color='k',rasterized=True)
#axepsilon.xaxis.set_major_formatter(plt.NullFormatter())
axepsilon.pcolormesh(x2,y2,z2.reshape(x2.shape),cmap='binary',zorder=0.25)
axepsilon.scatter(np.log10(sim0_cvir),np.log10(sim0_mstar/sim0_mvir),marker='o',color='k',s=1,alpha=0.3,rasterized=True,zorder=0.7)
axepsilon.scatter(np.log10(sim0_cvir[sim0_gal2]),np.log10(sim0_mstar[sim0_gal2]/sim0_mvir[sim0_gal2]),marker='o',color='r',s=5,alpha=0.5,rasterized=True,zorder=110)
axepsilon.scatter(np.log10(sim0_cvir[sim0_gal3]),np.log10(sim0_mstar[sim0_gal3]/sim0_mvir[sim0_gal3]),marker='o',color='g',s=5,alpha=0.5,rasterized=True,zorder=110)
axepsilon.scatter(np.log10(sim0_cvir[sim0_gal4]),np.log10(sim0_mstar[sim0_gal4]/sim0_mvir[sim0_gal4]),marker='o',color='b',s=5,alpha=0.5,rasterized=True,zorder=110)
axepsilon.scatter(np.log10(sim0_cvir[sim0_gal5]),np.log10(sim0_mstar[sim0_gal5]/sim0_mvir[sim0_gal5]),marker='o',color='m',s=5,alpha=0.5,rasterized=True,zorder=110)
#axepsilon.scatter(cra2jeanscountsnfw_c200,np.log10(cra2_luminosity0*10.**cra2jeanscountsnfw_mlstar/10.**cra2jeanscountsnfw_m200),marker='o',color='g',s=1,alpha=0.35,rasterized=True)

#axchist.yaxis.set_major_formatter(plt.NullFormatter())
#axchist.set_ylabel(r'prob.',fontsize=11,rotation=90)
#axchist.set_xlim([0,2])
#axchist.set_xscale(u'linear')
#axchist.set_yscale(u'linear')
#axchist.xaxis.set_major_formatter(plt.NullFormatter())
#axchist.hist(np.log10(sim0_cvir),bins=50,range=[0,2],orientation='vertical',color='k',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axchist.hist(np.log10(sim0_cvir[sim0_gal]),bins=50,range=[0,2],orientation='vertical',color='r',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axchist.yaxis.set_major_formatter(plt.NullFormatter())
#
#axmvirhist.yaxis.set_major_formatter(plt.NullFormatter())
#axmvirhist.set_xlim([0,2])
#axmvirhist.set_xscale(u'linear')
#axmvirhist.set_yscale(u'linear')
#axmvirhist.xaxis.set_major_formatter(plt.NullFormatter())
#axmvirhist.hist(np.log10(sim0_mvir),bins=50,range=[6.1,11.9],orientation='horizontal',color='k',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axmvirhist.hist(np.log10(sim0_mvir[sim0_gal2]),bins=50,range=[6.1,11.9],orientation='horizontal',color='r',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axmvirhist.hist(np.log10(sim0_mvir[sim0_gal3]),bins=50,range=[6.1,11.9],orientation='horizontal',color='g',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axmvirhist.hist(np.log10(sim0_mvir[sim0_gal4]),bins=50,range=[6.1,11.9],orientation='horizontal',color='b',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axmvirhist.hist(np.log10(sim0_mvir[sim0_gal5]),bins=50,range=[6.1,11.9],orientation='horizontal',color='m',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axmvirhist.yaxis.set_major_formatter(plt.NullFormatter())
#
#axepsilonhist.yaxis.set_major_formatter(plt.NullFormatter())
#axepsilonhist.set_xlabel(r' prob.',fontsize=11,rotation=0)
#axepsilonhist.set_xlim([0,2])
#axepsilonhist.set_xscale(u'linear')
#axepsilonhist.set_yscale(u'linear')
#axepsilonhist.xaxis.set_major_formatter(plt.NullFormatter())
#axepsilonhist.hist(np.log10(sim0_mstar/sim0_mvir),bins=50,range=[-5,0],orientation='horizontal',color='k',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axepsilonhist.hist(np.log10(sim0_mstar[sim0_gal2]/sim0_mvir[sim0_gal2]),bins=50,range=[-5,0],orientation='horizontal',color='r',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axepsilonhist.hist(np.log10(sim0_mstar[sim0_gal3]/sim0_mvir[sim0_gal3]),bins=50,range=[-5,0],orientation='horizontal',color='g',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axepsilonhist.hist(np.log10(sim0_mstar[sim0_gal4]/sim0_mvir[sim0_gal4]),bins=50,range=[-5,0],orientation='horizontal',color='b',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axepsilonhist.hist(np.log10(sim0_mstar[sim0_gal5]/sim0_mvir[sim0_gal5]),bins=50,range=[-5,0],orientation='horizontal',color='m',normed=True,histtype='step',align='mid',rwidth=0,linewidth=0.5)
#axepsilonhist.yaxis.set_major_formatter(plt.NullFormatter())
#axepsilonhist.plot([-1.,100.],np.log10([0.16,0.16]),lw=0.5,linestyle=':',zorder=0.5,alpha=1,color='k',rasterized=True)


logc200=np.linspace(0.,2.,500)
c200=10.**logc200
for i in range(0,len(lelli_dsph)):
    m200=np.zeros(len(c200))
    logm200=np.zeros(len(c200))
    for j in range(0,len(c200)):
        low=-10.
        high=17.
        logm200[j]=optimize.brentq(findm200,low,high,args=(c200[j],lelli_rhalf[i],lelli_mrhalf[i],rhocrit),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
        
    m200=10.**logm200
    r200=(m200/(4./3.)/np.pi/200./rhocrit)**0.3333
    rs=r200/10.**logc200
    logrratio=np.log10(lelli_rhalf[i]/rs)
    logrratio2=np.log10(lelli_rhalf[i]/r200)
    logepsilon=np.log10(lelli_mbar[i]/10.**logm200)
    if(lelli_siggobs[i]<0.5*lelli_gobs[i]):
        if(lelli_parent[i]=='MW'):
            axm200.plot(logc200,logm200,color='b',alpha=0.6,rasterized=True,lw=1)
            axepsilon.plot(logc200,logepsilon,color='b',alpha=0.6,rasterized=True,lw=1)
        if(lelli_parent[i]=='M31'):
            axm200.plot(logc200,logm200,color='r',alpha=0.6,rasterized=True,lw=1)
            axepsilon.plot(logc200,logepsilon,color='r',alpha=0.6,rasterized=True,lw=1)
#            axrratio.plot(logc200,logrratio,color='r',alpha=0.6,rasterized=True,lw=1)

m200=np.zeros(len(c200))
logm200=np.zeros(len(c200))
dfm200=np.zeros(len(c200))
dflogm200=np.zeros(len(c200))
for j in range(0,len(c200)):
    low=-10.
    high=17.
    logm200[j]=optimize.brentq(findm200,low,high,args=(c200[j],cra2_rhalf0,cra2_mrhalf0,rhocrit),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
    dflogm200[j]=optimize.brentq(findm200,low,high,args=(c200[j],df44_rhalf,df44_mhalf,rhocrit),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
m200=10.**logm200
dfm200=10.**dflogm200
r200=(m200/(4./3.)/np.pi/200./rhocrit)**0.3333
dfr200=(dfm200/(4./3.)/np.pi/200./rhocrit)**0.3333
rs=r200/10.**logc200
dfrs=dfr200/10.**logc200
logrratio=np.log10(cra2_rhalf0/rs)
logrratio2=np.log10(cra2_rhalf0/r200)
logepsilon=np.log10(cra2_mbar0/10.**logm200)
dflogrratio=np.log10(df44_rhalf/dfrs)
dflogrratio2=np.log10(df44_rhalf/dfr200)
dflogepsilon=np.log10(df44_mbar/10.**dflogm200)
kravtsov=np.log10(0.015)
kravtsovlo=np.log10(0.015)-0.2
kravtsovhi=np.log10(0.015)+0.2
axm200.plot(logc200,logm200,color='b',alpha=0.9,lw=3,rasterized=True)
#axm200.plot(logc200,dflogm200,color='g',alpha=0.9,lw=3,rasterized=True)
axm200.text(6.9,0.75,'Cra2',fontsize=8,color='k')
axm200.plot([0],[0],color='b',lw=1,label='MW dSph',rasterized=True)
axm200.plot([0],[0],color='r',lw=1,label='M31 dSph',rasterized=True)
axm200.plot([0],[0],color='b',lw=3,label='Cra2',rasterized=True)
axepsilon.plot(logc200,logepsilon,color='b',alpha=0.9,rasterized=True,lw=3)
#axepsilon.plot(logc200,dflogepsilon,color='g',alpha=0.9,rasterized=True,lw=3)
#axrratio2.plot(logc200,dflogrratio2,color='g',alpha=0.9,rasterized=True,lw=3)
axm200.legend(loc=1,fontsize=4.5,handlelength=1,numpoints=1,scatterpoints=1,shadow=False,borderaxespad=0)
#axrratio2.plot([0,2],[kravtsov,kravtsov],color='k',alpha=1,rasterized=True,lw=1,linestyle=':')

ax1_2.set_xlim([0.5,2.7])
ax1_2.set_ylim([-2.75,0])
ax1_2.set_ylabel(r'$\log_{10}[M_{\rm vir}/M_{\rm peak}]$')
ax1_2.xaxis.set_major_formatter(plt.NullFormatter())
ax1_2.scatter(np.log10(sim0_distance),np.log10(sim0_mvir/sim0_mvir_peak),marker='o',color='k',s=1,alpha=0.3,rasterized=True,zorder=0.7)
ax1_2.scatter(np.log10(sim0_distance[sim0_gal2]),np.log10(sim0_mvir[sim0_gal2]/sim0_mvir_peak[sim0_gal2]),marker='o',color='r',s=5,alpha=0.5,rasterized=True)
ax1_2.scatter(np.log10(sim0_distance[sim0_gal3]),np.log10(sim0_mvir[sim0_gal3]/sim0_mvir_peak[sim0_gal3]),marker='o',color='g',s=5,alpha=0.5,rasterized=True)
ax1_2.scatter(np.log10(sim0_distance[sim0_gal4]),np.log10(sim0_mvir[sim0_gal4]/sim0_mvir_peak[sim0_gal4]),marker='o',color='b',s=5,alpha=0.5,rasterized=True)
ax1_2.scatter(np.log10(sim0_distance[sim0_gal5]),np.log10(sim0_mvir[sim0_gal5]/sim0_mvir_peak[sim0_gal5]),marker='o',color='m',s=5,alpha=0.5,rasterized=True)
#ax1_2.scatter(np.log10(scylla_distance/1000.),np.log10(scylla_mvir/scylla_mpeak),marker='o',color='k',s=1,alpha=0.3,rasterized=True)
#ax1_2.scatter(np.log10(scylla_distance[scylla_gal]/1000.),np.log10(scylla_mvir[scylla_gal]/scylla_mpeak[scylla_gal]),marker='o',color='r',s=5,alpha=1,rasterized=True)
#ax1_2.scatter(np.log10(hall_distance/1000.),np.log10(hall_mvir/hall_mpeak),marker='o',color='k',s=1,alpha=0.3,rasterized=True)
#ax1_2.scatter(np.log10(hall_distance[hall_gal]/1000.),np.log10(hall_mvir[hall_gal]/hall_mpeak[hall_gal]),marker='o',color='r',s=5,alpha=1,rasterized=True)

ax2_2.set_xlim([0.5,2.7])
ax2_2.set_ylim([6,11.9])
ax2_2.set_xlabel(r'$\log_{10}[D/\mathrm{kpc}]$')
ax2_2.set_ylabel(r'$\log_{10}[M_{\rm vir}/M_{\odot}]$')
ax2_2.scatter(np.log10(sim0_distance),np.log10(sim0_mvir),marker='o',color='k',s=1,alpha=0.3,rasterized=True,label=r'$M_*<10^2M_{\odot}$',zorder=0.7)
ax2_2.scatter(np.log10(sim0_distance[sim0_gal2]),np.log10(sim0_mvir[sim0_gal2]),marker='o',color='r',s=5,alpha=0.5,rasterized=True,label=r'$10^2\leq M_*/M_{\odot}\leq 10^3$')
ax2_2.scatter(np.log10(sim0_distance[sim0_gal3]),np.log10(sim0_mvir[sim0_gal3]),marker='o',color='g',s=5,alpha=0.5,rasterized=True,label=r'$10^3\leq M_*/M_{\odot}\leq 10^4$')
ax2_2.scatter(np.log10(sim0_distance[sim0_gal4]),np.log10(sim0_mvir[sim0_gal4]),marker='o',color='b',s=5,alpha=0.5,rasterized=True,label=r'$10^4\leq M_*/M_{\odot}\leq 10^5$')
ax2_2.scatter(np.log10(sim0_distance[sim0_gal5]),np.log10(sim0_mvir[sim0_gal5]),marker='o',color='m',s=5,alpha=0.5,rasterized=True,label=r'$M_*>10^5M_{\odot}$')
#ax2_2.scatter(np.log10(scylla_distance/1000.),np.log10(scylla_mvir),marker='o',color='k',s=1,alpha=0.3,rasterized=True)
#ax2_2.scatter(np.log10(scylla_distance[scylla_gal]/1000.),np.log10(scylla_mvir[scylla_gal]),marker='o',color='r',s=5,alpha=1,rasterized=True)
#ax2_2.scatter(np.log10(hall_distance/1000.),np.log10(hall_mvir),marker='o',color='k',s=1,alpha=0.3,rasterized=True)
#ax2_2.scatter(np.log10(hall_distance[hall_gal]/1000.),np.log10(hall_mvir[hall_gal]),marker='o',color='r',s=5,alpha=1,rasterized=True)
ax2_2.legend(loc=2,fontsize=4,scatterpoints=1,borderaxespad=0)


plotfilename='cra2_prash.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
