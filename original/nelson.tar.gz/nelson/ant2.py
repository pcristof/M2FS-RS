import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='False')
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='5')
plt.rc('ytick',labelsize='5')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

radegcenter=143.8868
decdegcenter=-36.7673
racenter0=radegcenter*np.pi/180.
deccenter0=decdegcenter*np.pi/180.
vmin=275.
vmax=310.
zmin=-4.
zmax=0.
loggmin=-1.
loggmax=5.8
out1='ant2.dat'
g1=open(out1,'w')

with open('ant2_torrealba18.dat') as f: # read data file
    data=f.readlines()
radeg=[]
decdeg=[]
v=[]
sigv=[]
logg=[]
siglogg=[]
z=[]
sigz=[]
for line in data: # fill arrays
    p=line.split()
    radeg.append(float(p[2]))
    decdeg.append(float(p[3]))
    v.append(float(p[4]))
    sigv.append(float(p[5]))
    logg.append(float(p[8]))
    siglogg.append(float(p[9]))
    z.append(float(p[6]))
    sigz.append(float(p[7]))
radeg=np.array(radeg)
decdeg=np.array(decdeg)
v=np.array(v)
sigv=np.array(sigv)
logg=np.array(logg)
siglogg=np.array(siglogg)
z=np.array(z)
sigz=np.array(sigz)

ra=radeg*np.pi/180.
dec=decdeg*np.pi/180.
racenter=np.zeros(len(radeg))+racenter0
deccenter=np.zeros(len(decdeg))+deccenter0
xi,eta=mycode2.etaxiarr(ra,dec,racenter,deccenter)
r=np.sqrt(xi**2+eta**2)

pmem=np.zeros(len(radeg))
mem=(np.where((v>vmin)&(v<vmax)&(z>zmin)&(z<zmax)&(logg>loggmin)&(logg<loggmax)))[0]
for i in range(0,len(mem)):
    pmem[mem[i]]=1.
for i in range(0,len(radeg)):
    string=str(round(radeg[i],7))+' '+str(round(decdeg[i],7))+' '+str(round(xi[i],3))+' '+str(round(eta[i],3))+' '+str(round(r[i],3))+' '+str(round(v[i],3))+' '+str(round(sigv[i],3))+' '+str(round(z[i],3))+' '+str(round(sigz[i],3))+' '+str(round(pmem[i],4))+' \n'
    g1.write(string)
g1.close()
