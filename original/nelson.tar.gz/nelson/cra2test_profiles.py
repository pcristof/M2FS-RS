import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.5)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='6')
plt.rc('ytick',labelsize='6')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)
    
with open('/physics2/mgwalker/chains/cra2test.pr') as f: # read data file
    data=f.readlines()
cra2rho_rad=[]
cra2rho_radpc=[]
cra2rho_rho=[]
cra2rho_rholo1=[]
cra2rho_rholo2=[]
cra2rho_rhohi1=[]
cra2rho_rhohi2=[]
cra2rho_mass=[]
cra2rho_masslo1=[]
cra2rho_masslo2=[]
cra2rho_masshi1=[]
cra2rho_masshi2=[]
cra2rho_vdisp=[]
cra2rho_vdisplo1=[]
cra2rho_vdisplo2=[]
cra2rho_vdisphi1=[]
cra2rho_vdisphi2=[]
cra2rho_nstar=[]
cra2rho_nstarlo1=[]
cra2rho_nstarlo2=[]
cra2rho_nstarhi1=[]
cra2rho_nstarhi2=[]
cra2rho_stellarmass=[]
cra2rho_stellarmasslo1=[]
cra2rho_stellarmasslo2=[]
cra2rho_stellarmasshi1=[]
cra2rho_stellarmasshi2=[]
cra2rho_nustar=[]
cra2rho_nustarlo1=[]
cra2rho_nustarlo2=[]
cra2rho_nustarhi1=[]
cra2rho_nustarhi2=[]
cra2rho_mtot=[]
cra2rho_mtotlo1=[]
cra2rho_mtotlo2=[]
cra2rho_mtothi1=[]
cra2rho_mtothi2=[]
cra2rho_dmfraction=[]
cra2rho_dmfractionlo1=[]
cra2rho_dmfractionlo2=[]
cra2rho_dmfractionhi1=[]
cra2rho_dmfractionhi2=[]
cra2rho_dratio=[]
cra2rho_dratiolo1=[]
cra2rho_dratiolo2=[]
cra2rho_dratiohi1=[]
cra2rho_dratiohi2=[]
cra2rho_rhostar=[]
cra2rho_rhostarlo1=[]
cra2rho_rhostarlo2=[]
cra2rho_rhostarhi1=[]
cra2rho_rhostarhi2=[]

for line in data: # fill arrays
    p=line.split()
    cra2rho_rad.append(float(p[0]))
    cra2rho_radpc.append(float(p[1]))
    cra2rho_rho.append(float(p[17]))
    cra2rho_rholo1.append(float(p[18]))
    cra2rho_rholo2.append(float(p[20]))
    cra2rho_rhohi1.append(float(p[19]))
    cra2rho_rhohi2.append(float(p[21]))
    cra2rho_mass.append(float(p[22]))
    cra2rho_masslo1.append(float(p[23]))
    cra2rho_masslo2.append(float(p[25]))
    cra2rho_masshi1.append(float(p[24]))
    cra2rho_masshi2.append(float(p[26]))
    cra2rho_vdisp.append(float(p[27]))
    cra2rho_vdisplo1.append(float(p[28]))
    cra2rho_vdisplo2.append(float(p[30]))
    cra2rho_vdisphi1.append(float(p[29]))
    cra2rho_vdisphi2.append(float(p[31]))
    cra2rho_nstar.append(float(p[32]))
    cra2rho_nstarlo1.append(float(p[33]))
    cra2rho_nstarlo2.append(float(p[35]))
    cra2rho_nstarhi1.append(float(p[34]))
    cra2rho_nstarhi2.append(float(p[36]))
    cra2rho_stellarmass.append(float(p[37]))
    cra2rho_stellarmasslo1.append(float(p[38]))
    cra2rho_stellarmasslo2.append(float(p[40]))
    cra2rho_stellarmasshi1.append(float(p[39]))
    cra2rho_stellarmasshi2.append(float(p[41]))
    cra2rho_nustar.append(float(p[42]))
    cra2rho_nustarlo1.append(float(p[43]))
    cra2rho_nustarlo2.append(float(p[45]))
    cra2rho_nustarhi1.append(float(p[44]))
    cra2rho_nustarhi2.append(float(p[46]))
    cra2rho_mtot.append(float(p[47]))
    cra2rho_mtotlo1.append(float(p[48]))
    cra2rho_mtotlo2.append(float(p[50]))
    cra2rho_mtothi1.append(float(p[49]))
    cra2rho_mtothi2.append(float(p[51]))
    cra2rho_dmfraction.append(float(p[52]))
    cra2rho_dmfractionlo1.append(float(p[53]))
    cra2rho_dmfractionlo2.append(float(p[55]))
    cra2rho_dmfractionhi1.append(float(p[54]))
    cra2rho_dmfractionhi2.append(float(p[56]))
    cra2rho_dratio.append(float(p[57]))
    cra2rho_dratiolo1.append(float(p[58]))
    cra2rho_dratiolo2.append(float(p[60]))
    cra2rho_dratiohi1.append(float(p[59]))
    cra2rho_dratiohi2.append(float(p[61]))
    cra2rho_rhostar.append(float(p[62]))
    cra2rho_rhostarlo1.append(float(p[63]))
    cra2rho_rhostarlo2.append(float(p[65]))
    cra2rho_rhostarhi1.append(float(p[64]))
    cra2rho_rhostarhi2.append(float(p[66]))

cra2rho_rad=np.array(cra2rho_rad)
cra2rho_radpc=np.array(cra2rho_radpc)
cra2rho_rho=np.array(cra2rho_rho)
cra2rho_rholo1=np.array(cra2rho_rholo1)
cra2rho_rholo2=np.array(cra2rho_rholo2)
cra2rho_rhohi1=np.array(cra2rho_rhohi1)
cra2rho_rhohi2=np.array(cra2rho_rhohi2)
cra2rho_mass=np.array(cra2rho_mass)
cra2rho_masslo1=np.array(cra2rho_masslo1)
cra2rho_masslo2=np.array(cra2rho_masslo2)
cra2rho_masshi1=np.array(cra2rho_masshi1)
cra2rho_masshi2=np.array(cra2rho_masshi2)
cra2rho_vdisp=np.array(cra2rho_vdisp)
cra2rho_vdisplo1=np.array(cra2rho_vdisplo1)
cra2rho_vdisplo2=np.array(cra2rho_vdisplo2)
cra2rho_vdisphi1=np.array(cra2rho_vdisphi1)
cra2rho_vdisphi2=np.array(cra2rho_vdisphi2)
cra2rho_nstar=np.array(cra2rho_nstar)
cra2rho_nstarlo1=np.array(cra2rho_nstarlo1)
cra2rho_nstarlo2=np.array(cra2rho_nstarlo2)
cra2rho_nstarhi1=np.array(cra2rho_nstarhi1)
cra2rho_nstarhi2=np.array(cra2rho_nstarhi2)
cra2rho_stellarmass=np.array(cra2rho_stellarmass)
cra2rho_stellarmasslo1=np.array(cra2rho_stellarmasslo1)
cra2rho_stellarmasslo2=np.array(cra2rho_stellarmasslo2)
cra2rho_stellarmasshi1=np.array(cra2rho_stellarmasshi1)
cra2rho_stellarmasshi2=np.array(cra2rho_stellarmasshi2)
cra2rho_nustar=np.array(cra2rho_nustar)
cra2rho_nustarlo1=np.array(cra2rho_nustarlo1)
cra2rho_nustarlo2=np.array(cra2rho_nustarlo2)
cra2rho_nustarhi1=np.array(cra2rho_nustarhi1)
cra2rho_nustarhi2=np.array(cra2rho_nustarhi2)
cra2rho_mtot=np.array(cra2rho_mtot)
cra2rho_mtotlo1=np.array(cra2rho_mtotlo1)
cra2rho_mtotlo2=np.array(cra2rho_mtotlo2)
cra2rho_mtothi1=np.array(cra2rho_mtothi1)
cra2rho_mtothi2=np.array(cra2rho_mtothi2)
cra2rho_dmfraction=np.array(cra2rho_dmfraction)
cra2rho_dmfractionlo1=np.array(cra2rho_dmfractionlo1)
cra2rho_dmfractionlo2=np.array(cra2rho_dmfractionlo2)
cra2rho_dmfractionhi1=np.array(cra2rho_dmfractionhi1)
cra2rho_dmfractionhi2=np.array(cra2rho_dmfractionhi2)
cra2rho_dratio=np.array(cra2rho_dratio)
cra2rho_dratiolo1=np.array(cra2rho_dratiolo1)
cra2rho_dratiolo2=np.array(cra2rho_dratiolo2)
cra2rho_dratiohi1=np.array(cra2rho_dratiohi1)
cra2rho_dratiohi2=np.array(cra2rho_dratiohi2)
cra2rho_rhostar=np.array(cra2rho_rhostar)
cra2rho_rhostarlo1=np.array(cra2rho_rhostarlo1)
cra2rho_rhostarlo2=np.array(cra2rho_rhostarlo2)
cra2rho_rhostarhi1=np.array(cra2rho_rhostarhi1)
cra2rho_rhostarhi2=np.array(cra2rho_rhostarhi2)

gs=plt.GridSpec(20,20) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size

ax1_0=fig.add_subplot(gs[0:5,0:8])
ax2_0=fig.add_subplot(gs[5:10,0:8])
#ax0_0=fig.add_subplot(gs[10:15,0:8])
ax0_1=fig.add_subplot(gs[15:20,12:20])

#ax0_1.xaxis.set_major_formatter(plt.NullFormatter())
ax0_1.set_ylabel(r'$\sigma_{v_{los}}$ [km/s]',fontsize=10,rotation=90)
ax0_1.set_xlabel(r'$R$ [arcmin]',fontsize=10,rotation=0,labelpad=5)
ax0_1.set_xlim([1,500])
ax0_1.set_ylim([0,9])
ax0_1.set_xscale(u'log')
ax0_1.set_yscale(u'linear')
#ax0_1.set_yticks([1,10,100])
#ax0_1.set_yticklabels([1,10,100],fontsize=10)
#ax0_1.scatter(np.median(cra2_rhalf0),np.median(cra2_vdisp0),s=10,lw=0,edgecolor='none',alpha=0.99,marker='s',color='b',rasterized=True,label='Cra 2')
ax0_1.fill_between(cra2rho_rad,cra2rho_vdisplo1,cra2rho_vdisphi1,facecolor='0.25',alpha=0.5,rasterized=False,edgecolor='None')
#ax0_1.fill_between(cra2rho_rad,cra2rho_vdisplo2,cra2rho_vdisphi2,facecolor='0.6',alpha=0.5,rasterized=False,edgecolor='None')
#ax0_1.plot(cra2rho_rad,cra2rho_vdisp,lw=0.5,color='k')
axtop=ax0_1.twiny()
shite=ax0_1.get_xlim()
distance=117000.
shite2=[]
shite2.append(shite[0])
shite2.append(shite[1])
shite2=np.array(shite2)
shite3=distance*np.tan(shite2/60.*np.pi/180.)
axtop.set_xlim(shite3)
axtop.set_xscale(u'log')
axtop.set_xlabel(r'$R$ [pc]',fontsize=10,rotation=0,labelpad=7)
#ax1_0.xaxis.set_major_formatter(plt.NullFormatter())

ax1_0.xaxis.set_major_formatter(plt.NullFormatter())
ax1_0.set_ylabel(r'$\rho$ [M$_{\odot}$/pc$^3$]',fontsize=10,rotation=90)
#ax2_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
#ax1_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
ax1_0.set_xlim([10,10000])
ax1_0.set_ylim([0.00000005,0.1])
ax1_0.set_xscale(u'log')
ax1_0.set_yscale(u'log')
#ax1_0.set_yticks([1,10,100])
#ax1_0.set_yticklabels([1,10,100],fontsize=10)
#ax1_0.scatter(np.median(cra2_rhalf0),np.median(cra2_vdisp0),s=10,lw=0,edgecolor='none',alpha=0.99,marker='s',color='b',rasterized=True,label='Cra 2')
ax1_0.fill_between(cra2rho_radpc,cra2rho_rholo1,cra2rho_rhohi1,facecolor='b',alpha=0.60,rasterized=False,edgecolor='None',label='dark matter')
ax1_0.fill_between(cra2rho_radpc,cra2rho_rhostarlo1,cra2rho_rhostarhi1,facecolor='r',alpha=0.60,rasterized=False,edgecolor='None',label='stars')
#ax1_0.plot(cra2rho_radpc,cra2rho_rho,lw=0.5,color='k')
ax1_0.plot([1,10],[1.e-25,1.e-25],lw=0.25,color='b',label='dark matter')
ax1_0.plot([1,10],[1.e-25,1.e-25],lw=0.25,color='r',label='stars')
ax1_0.xaxis.set_major_formatter(plt.NullFormatter())
ax1_0.legend(loc=3,fontsize=7,handlelength=1,numpoints=1,scatterpoints=1,shadow=False)

#ax2_0.xaxis.set_major_formatter(plt.NullFormatter())
ax2_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
ax2_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
ax2_0.set_xlim([10,10000])
ax2_0.set_ylim([100,7000000000])
ax2_0.set_xscale(u'log')
ax2_0.set_yscale(u'log')
#ax2_0.fill_between(cra2rho_radpc,cra2rho_masslo1,cra2rho_masshi1,facecolor='0.1',alpha=0.60,rasterized=False,edgecolor='None')
ax2_0.fill_between(cra2rho_radpc,cra2rho_masslo2,cra2rho_masshi2,facecolor='b',alpha=0.60,rasterized=False,edgecolor='None')
ax2_0.fill_between(cra2rho_radpc,cra2rho_stellarmasslo1,cra2rho_stellarmasshi1,facecolor='r',alpha=0.60,rasterized=False,edgecolor='None')
#ax2_0.fill_between(cra2rho_radpc,cra2rho_mtotlo1,cra2rho_mtothi1,facecolor='k',alpha=0.60,rasterized=False,edgecolor='None')
#ax2_0.plot(cra2rho_radpc,cra2rho_mtot,lw=0.5,color='k')
#ax2_0.xaxis.set_major_formatter(plt.NullFormatter())

#ax0_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
#ax0_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
#ax0_0.set_xlim([10,10000])
#ax0_0.set_ylim([100,9000000000])
#ax0_0.set_xscale(u'log')
#ax0_0.set_yscale(u'log')
##ax0_0.fill_between(cra2rho_radpc,cra2rho_masslo1,cra2rho_masshi1,facecolor='0.1',alpha=0.60,rasterized=False,edgecolor='None')
#ax0_0.fill_between(cra2rho_radpc,cra2rho_masslo2,cra2rho_masshi2,facecolor='b',alpha=0.60,rasterized=False,edgecolor='None')
#ax0_0.fill_between(cra2rho_radpc,cra2rho_stellarmasslo1,cra2rho_stellarmasshi1,facecolor='r',alpha=0.60,rasterized=False,edgecolor='None')
##ax0_0.fill_between(cra2rho_radpc,cra2rho_mtotlo1,cra2rho_mtothi1,facecolor='k',alpha=0.60,rasterized=False,edgecolor='None')
#ax0_0.plot(cra2rho_radpc,cra2rho_stellarmass,lw=0.25,color='r')
##ax0_0.plot(cra2rho_radpc,cra2rho_mtot,lw=0.5,color='k')
#ax0_0.plot(cra2rho_rad,cra2rho_vdisp,lw=0.25,color='k')


plotfilename='cra2test_profiles.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
