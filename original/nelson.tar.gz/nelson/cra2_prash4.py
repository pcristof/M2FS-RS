import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
from scipy.stats import kde
import random
import scipy.optimize as optimize
#from galpy.potential import MWPotential2014
#from galpy.potential import NFWPotential
#from galpy.orbit import Orbit
#from galpy.potential import vesc
from astropy import units
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=1)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='10')
plt.rc('ytick',labelsize='10')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

with open('/physics2/mgwalker/chains/prash2diskpost_equal_weights.dat') as f:
    data=f.readlines()
prash_m11_disk=[]
prash_alpha_disk=[]
prash_sigma8_disk=[]
for line in data: # fill arrays
    p=line.split()
    prash_m11_disk.append(float(p[0]))
    prash_alpha_disk.append(float(p[1]))
    prash_sigma8_disk.append(float(p[2]))
prash_m11_disk=np.array(prash_m11_disk)
prash_alpha_disk=np.array(prash_alpha_disk)
prash_sigma8_disk=np.array(prash_sigma8_disk)
prash_alpha_disk=np.tan(prash_alpha_disk)

sort=np.argsort(prash_sigma8_disk)
prash_m11_disk=prash_m11_disk[sort]
prash_alpha_disk=prash_alpha_disk[sort]
prash_sigma8_disk=prash_sigma8_disk[sort]

disk_bins=20
disk_perbin=np.long(np.float(len(prash_m11_disk))/np.float(disk_bins))
disk_bin=[]
for i in range(0,len(prash_m11_disk)):
    shite=np.long(np.float(i)/np.float(disk_perbin))+1
    if(shite>disk_bins):
        shite=disk_bins
    disk_bin.append(shite)
disk_bin=np.array(disk_bin)

with open('/physics2/mgwalker/chains/prash2nodiskpost_equal_weights.dat') as f:
    data=f.readlines()
prash_m11_nodisk=[]
prash_alpha_nodisk=[]
prash_sigma8_nodisk=[]
for line in data: # fill arrays
    p=line.split()
    prash_m11_nodisk.append(float(p[0]))
    prash_alpha_nodisk.append(float(p[1]))
    prash_sigma8_nodisk.append(float(p[2]))
prash_m11_nodisk=np.array(prash_m11_nodisk)
prash_alpha_nodisk=np.array(prash_alpha_nodisk)
prash_sigma8_nodisk=np.array(prash_sigma8_nodisk)
prash_alpha_nodisk=np.tan(prash_alpha_nodisk)

sort=np.argsort(prash_sigma8_nodisk)
prash_m11_nodisk=prash_m11_nodisk[sort]
prash_alpha_nodisk=prash_alpha_nodisk[sort]
prash_sigma8_nodisk=prash_sigma8_nodisk[sort]

nodisk_bins=20
nodisk_perbin=np.long(np.float(len(prash_m11_nodisk))/np.float(nodisk_bins))
nodisk_bin=[]
for i in range(0,len(prash_m11_nodisk)):
    shite=np.long(np.float(i)/np.float(nodisk_perbin))+1
    if(shite>nodisk_bins):
        shite=nodisk_bins
    nodisk_bin.append(shite)
nodisk_bin=np.array(nodisk_bin)

#with open('sim6_hr_disk.csv') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
with open('/nfs/nas-0-9/mgwalker.proj/catalogues_matt_crater2/sim6_hr.csv') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()[1:]
sim0_mvir=[]
sim0_rvir=[]
sim0_rs=[]
sim0_a_peak=[]
sim0_mvir_peak=[]
sim0_rvir_peak=[]
sim0_rs_peak=[]
sim0_a_acc=[]
sim0_r_min=[]
sim0_r_max=[]
sim0_x_min=[]
sim0_x_max=[]
sim0_x=[]
sim0_y=[]
sim0_z=[]
sim0_vx=[]
sim0_vy=[]
sim0_vz=[]
sim0_mstar_fid=[]
sim0_mstar_sca=[]
sim0_mstar_ho=[]
for line in data: # fill arrays
    p=line.split()
    sim0_mvir.append(float(p[0]))
    sim0_rvir.append(float(p[1]))
    sim0_rs.append(float(p[2]))
    sim0_a_peak.append(float(p[3]))
    sim0_mvir_peak.append(float(p[4]))
    sim0_rvir_peak.append(float(p[5]))
    sim0_rs_peak.append(float(p[6]))
    sim0_a_acc.append(float(p[7]))
    sim0_r_min.append(float(p[8]))
    sim0_r_max.append(float(p[9]))
    sim0_x_min.append(float(p[10]))
    sim0_x_max.append(float(p[11]))
    sim0_x.append(float(p[12]))
    sim0_y.append(float(p[13]))
    sim0_z.append(float(p[14]))
    sim0_vx.append(float(p[15]))
    sim0_vy.append(float(p[16]))
    sim0_vz.append(float(p[17]))
    sim0_mstar_fid.append(float(p[18]))
    sim0_mstar_sca.append(float(p[19]))
    sim0_mstar_ho.append(float(p[20]))
sim0_mvir=np.array(sim0_mvir)
sim0_rvir=np.array(sim0_rvir)
sim0_rs=np.array(sim0_rs)
sim0_a_peak=np.array(sim0_a_peak)
sim0_mvir_peak=np.array(sim0_mvir_peak)
sim0_rvir_peak=np.array(sim0_rvir_peak)
sim0_rs_peak=np.array(sim0_rs_peak)
sim0_a_acc=np.array(sim0_a_acc)
sim0_r_min=np.array(sim0_r_min)
sim0_r_max=np.array(sim0_r_max)
sim0_x_min=np.array(sim0_x_min)
sim0_x_max=np.array(sim0_x_max)
sim0_x=np.array(sim0_x)
sim0_y=np.array(sim0_y)
sim0_z=np.array(sim0_z)
sim0_vx=np.array(sim0_vx)
sim0_vy=np.array(sim0_vy)
sim0_vz=np.array(sim0_vz)
sim0_mstar_fid=np.array(sim0_mstar_fid)
sim0_mstar_sca=np.array(sim0_mstar_sca)
sim0_mstar_ho=np.array(sim0_mstar_ho)

sim0_distance=np.sqrt(sim0_x**2+sim0_y**2+sim0_z**2)
sim0_mstar0=sim0_mstar_sca

with open('/nfs/nas-0-9/mgwalker.proj/catalogues_matt_crater2/sim6_hr_disk.csv') as f: # read data f#with open('ELVIS_Halo_Catalogs/HiResCatalogs/iScylla_HiRes.txt') as f: # read data file
    data=f.readlines()[1:]
simdisk_mvir=[]
simdisk_rvir=[]
simdisk_rs=[]
simdisk_a_peak=[]
simdisk_mvir_peak=[]
simdisk_rvir_peak=[]
simdisk_rs_peak=[]
simdisk_a_acc=[]
simdisk_r_min=[]
simdisk_r_max=[]
simdisk_x_min=[]
simdisk_x_max=[]
simdisk_x=[]
simdisk_y=[]
simdisk_z=[]
simdisk_vx=[]
simdisk_vy=[]
simdisk_vz=[]
simdisk_mstar_fid=[]
simdisk_mstar_sca=[]
simdisk_mstar_ho=[]
for line in data: # fill arrays
    p=line.split()
    simdisk_mvir.append(float(p[0]))
    simdisk_rvir.append(float(p[1]))
    simdisk_rs.append(float(p[2]))
    simdisk_a_peak.append(float(p[3]))
    simdisk_mvir_peak.append(float(p[4]))
    simdisk_rvir_peak.append(float(p[5]))
    simdisk_rs_peak.append(float(p[6]))
    simdisk_a_acc.append(float(p[7]))
    simdisk_r_min.append(float(p[8]))
    simdisk_r_max.append(float(p[9]))
    simdisk_x_min.append(float(p[10]))
    simdisk_x_max.append(float(p[11]))
    simdisk_x.append(float(p[12]))
    simdisk_y.append(float(p[13]))
    simdisk_z.append(float(p[14]))
    simdisk_vx.append(float(p[15]))
    simdisk_vy.append(float(p[16]))
    simdisk_vz.append(float(p[17]))
    simdisk_mstar_fid.append(float(p[18]))
    simdisk_mstar_sca.append(float(p[19]))
    simdisk_mstar_ho.append(float(p[20]))
simdisk_mvir=np.array(simdisk_mvir)
simdisk_rvir=np.array(simdisk_rvir)
simdisk_rs=np.array(simdisk_rs)
simdisk_a_peak=np.array(simdisk_a_peak)
simdisk_mvir_peak=np.array(simdisk_mvir_peak)
simdisk_rvir_peak=np.array(simdisk_rvir_peak)
simdisk_rs_peak=np.array(simdisk_rs_peak)
simdisk_a_acc=np.array(simdisk_a_acc)
simdisk_r_min=np.array(simdisk_r_min)
simdisk_r_max=np.array(simdisk_r_max)
simdisk_x_min=np.array(simdisk_x_min)
simdisk_x_max=np.array(simdisk_x_max)
simdisk_x=np.array(simdisk_x)
simdisk_y=np.array(simdisk_y)
simdisk_z=np.array(simdisk_z)
simdisk_vx=np.array(simdisk_vx)
simdisk_vy=np.array(simdisk_vy)
simdisk_vz=np.array(simdisk_vz)
simdisk_mstar_fid=np.array(simdisk_mstar_fid)
simdisk_mstar_sca=np.array(simdisk_mstar_sca)
simdisk_mstar_ho=np.array(simdisk_mstar_ho)

simdisk_distance=np.sqrt(simdisk_x**2+simdisk_y**2+simdisk_z**2)
simdisk_mstar0=simdisk_mstar_sca

scatter=[]
ncra2=[]
ngal=[]
cra2ratio=[]
galratio=[]
ncra2lo=[]
ncra2hi=[]
ngallo=[]
ngalhi=[]
cra2ratiolo=[]
cra2ratiohi=[]
galratiolo=[]
galratiohi=[]
cra2apo=[]
cra2apolo=[]
cra2apohi=[]
galapo=[]
galapolo=[]
galapohi=[]
cra2peri=[]
cra2perilo=[]
cra2perihi=[]
galperi=[]
galperilo=[]
galperihi=[]
cra2apoperi=[]
galapoperi=[]

disk_scatter=[]
disk_ncra2=[]
disk_ngal=[]
disk_cra2ratio=[]
disk_galratio=[]
disk_ncra2lo=[]
disk_ncra2hi=[]
disk_ngallo=[]
disk_ngalhi=[]
disk_cra2ratiolo=[]
disk_cra2ratiohi=[]
disk_galratiolo=[]
disk_galratiohi=[]
disk_cra2apo=[]
disk_cra2apolo=[]
disk_cra2apohi=[]
disk_galapo=[]
disk_galapolo=[]
disk_galapohi=[]
disk_cra2peri=[]
disk_cra2perilo=[]
disk_cra2perihi=[]
disk_galperi=[]
disk_galperilo=[]
disk_galperihi=[]
disk_cra2apoperi=[]
disk_galapoperi=[]


#for i in range(10,12):
for i in range(1,nodisk_bins):
    print(i)
    ncra2_0=[]
    ngal_0=[]
    cra2ratio_0=[]
    galratio_0=[]
    cra2apo_0=[]
    cra2peri_0=[]
    galapo_0=[]
    galperi_0=[]
    cra2apoperi_0=[]
    galapoperi_0=[]
    
    for k in range(0,len(prash_m11_nodisk)):
        if(nodisk_bin[k]==i):
#for i in range(8500,9001):
            nodisk_prash_logmstar=[]
            for j in range(0,len(sim0_mvir)):
                if(sim0_mvir_peak[j] > 1.e+11):
                    sigma=0.2
                if(sim0_mvir_peak[j] <= 1.e+11):
                    sigma=(0.2-prash_sigma8_nodisk[k])/3.*(np.log10(sim0_mvir_peak[j])-8.)+prash_sigma8_nodisk[k]
                dev=np.random.normal(0.,sigma)
#        print j,dev
                nodisk_prash_logmstar.append(np.min([prash_m11_nodisk[k]+prash_alpha_nodisk[k]*np.log10(sim0_mvir_peak[j]/1.e+11)+dev,0.15*sim0_mvir_peak[j]]))
            nodisk_prash_logmstar=np.array(nodisk_prash_logmstar)
            nodisk_prash_mstar=10.**nodisk_prash_logmstar
            nodisk_prash_lum=nodisk_prash_mstar/2.
            nodisk_prash_absvmag=4.83-2.5*np.log10(nodisk_prash_lum)
            cra2=np.where((nodisk_prash_mstar>1.e+5)&(sim0_mvir<1.e+7)&(sim0_distance<300.))
            gal=np.where((nodisk_prash_mstar>1.e+5)&(sim0_distance<300.))
            ncra2_0.append(np.size(cra2))
            ngal_0.append(np.size(gal))
            cra2ratio_0.append(np.median(np.log10(sim0_mvir[cra2]/sim0_mvir_peak[cra2])))
            galratio_0.append(np.median(np.log10(sim0_mvir[gal]/sim0_mvir_peak[gal])))
            cra2apo_0.append(np.median(sim0_r_max[cra2]))
            cra2peri_0.append(np.median(sim0_r_min[cra2]))
            cra2apoperi_0.append(np.median(sim0_r_min[cra2]/sim0_r_max[cra2]))
            galapo_0.append(np.median(sim0_r_max[gal]))
            galperi_0.append(np.median(sim0_r_min[gal]))
            galapoperi_0.append(np.median(sim0_r_min[gal]/sim0_r_max[gal]))

    ncra2_0=np.array(ncra2_0)
    ngal_0=np.array(ngal_0)
    cra2ratio_0=np.array(cra2ratio_0)
    galratio_0=np.array(galratio_0)
    cra2apo_0=np.array(cra2apo_0)
    cra2peri_0=np.array(cra2peri_0)
    cra2apoperi_0=np.array(cra2apoperi_0)
    galapo_0=np.array(galapo_0)
    galperi_0=np.array(galperi_0)
    galapoperi_0=np.array(galapoperi_0)
    scatter.append(np.median(prash_sigma8_nodisk[nodisk_bin==i]))
#    print(ncra2_0,ngal_0)
    ncra2.append(np.median(ncra2_0))
    ngal.append(np.median(ngal_0))    
    shite=np.where(cra2ratio_0==cra2ratio_0)

    if(np.size(shite)>0):
        cra2ratio.append(np.median(cra2ratio_0[shite]))
        cra2ratiolo.append(np.percentile(cra2ratio_0[shite],16))
        cra2ratiohi.append(np.percentile(cra2ratio_0[shite],84))
        cra2apo.append(np.median(cra2apo_0[shite]))
        cra2apoperi.append(np.median(cra2apoperi_0[shite]))
        cra2apolo.append(np.percentile(cra2apo_0[shite],16))
        cra2apohi.append(np.percentile(cra2apo_0[shite],84))
        cra2peri.append(np.median(cra2peri_0[shite]))
        cra2perilo.append(np.percentile(cra2peri_0[shite],16))
        cra2perihi.append(np.percentile(cra2peri_0[shite],84))
    if(np.size(shite)==0):
        cra2ratio.append('nan')
        cra2ratiolo.append('nan')
        cra2ratiohi.append('nan')
        cra2apo.append('nan')
        cra2apoperi.append('nan')
        cra2apolo.append('nan')
        cra2apohi.append('nan')
        cra2peri.append('nan')
        cra2perilo.append('nan')
        cra2perihi.append('nan')
    shite=np.where(galratio_0==galratio_0)
    if(np.size(shite)>0):
        galratio.append(np.median(galratio_0[shite]))
        galratiolo.append(np.percentile(galratio_0[shite],16))
        galratiohi.append(np.percentile(galratio_0[shite],84))
        galapo.append(np.median(galapo_0[shite]))
        galapoperi.append(np.median(galapoperi_0[shite]))
        galapolo.append(np.percentile(galapo_0[shite],16))
        galapohi.append(np.percentile(galapo_0[shite],84))
        galperi.append(np.median(galperi_0[shite]))
        galperilo.append(np.percentile(galperi_0[shite],16))
        galperihi.append(np.percentile(galperi_0[shite],84))
    if(np.size(shite)==0):
        galratio.append('nan')
        galratiolo.append('nan')
        galratiohi.append('nan')
        galapo.append('nan')
        galapoperi.append('nan')
        galapolo.append('nan')
        galapohi.append('nan')
        galperi.append('nan')
        galperilo.append('nan')
        galperihi.append('nan')

    ncra2lo.append(np.percentile(ncra2_0[shite],16))
    ncra2hi.append(np.percentile(ncra2_0[shite],84))
    ngallo.append(np.percentile(ngal_0,16))
    ngalhi.append(np.percentile(ngal_0,84))
ncra2=np.array(ncra2)
ngal=np.array(ngal)
scatter=np.array(scatter)
cra2ratio=np.array(cra2ratio)
galratio=np.array(galratio)
cra2apo=np.array(cra2apo)
cra2peri=np.array(cra2peri)
cra2apoperi=np.array(cra2apoperi)
galapo=np.array(galapo)
galperi=np.array(galperi)
galapoperi=np.array(galapoperi)
ncra2lo=np.array(ncra2lo)
ncra2hi=np.array(ncra2hi)
ngallo=np.array(ngallo)
ngalhi=np.array(ngalhi)
cra2ratiolo=np.array(cra2ratiolo)
cra2ratiohi=np.array(cra2ratiohi)
cra2apolo=np.array(cra2apolo)
cra2apohi=np.array(cra2apohi)
cra2perilo=np.array(cra2perilo)
cra2perihi=np.array(cra2perihi)
galratiolo=np.array(galratiolo)
galratiohi=np.array(galratiohi)
galapolo=np.array(galapolo)
galapohi=np.array(galapohi)
galperilo=np.array(galperilo)
galperihi=np.array(galperihi)




#for i in range(10,12):
for i in range(1,disk_bins):
    print(i)
    disk_ncra2_0=[]
    disk_ngal_0=[]
    disk_cra2ratio_0=[]
    disk_galratio_0=[]
    disk_cra2apo_0=[]
    disk_cra2peri_0=[]
    disk_galapo_0=[]
    disk_galperi_0=[]
    disk_cra2apoperi_0=[]
    disk_galapoperi_0=[]

    for k in range(0,len(prash_m11_disk)):
        if(disk_bin[k]==i):
#for i in range(8500,9001):
            disk_prash_logmstar=[]
            for j in range(0,len(simdisk_mvir)):
                if(simdisk_mvir_peak[j] > 1.e+11):
                    sigma=0.2
                if(simdisk_mvir_peak[j] <= 1.e+11):
                    sigma=(0.2-prash_sigma8_disk[k])/3.*(np.log10(simdisk_mvir_peak[j])-8.)+prash_sigma8_disk[k]
                dev=np.random.normal(0.,sigma)
#        print j,dev
                disk_prash_logmstar.append(np.min([prash_m11_disk[k]+prash_alpha_disk[k]*np.log10(simdisk_mvir_peak[j]/1.e+11)+dev,0.15*simdisk_mvir_peak[j]]))

            disk_prash_logmstar=np.array(disk_prash_logmstar)
            disk_prash_mstar=10.**disk_prash_logmstar
            disk_prash_lum=disk_prash_mstar/2.
            disk_prash_absvmag=4.83-2.5*np.log10(disk_prash_lum)
            disk_cra2=np.where((disk_prash_mstar>1.e+5)&(simdisk_mvir<1.e+7)&(simdisk_distance<300.))
            disk_gal=np.where((disk_prash_mstar>1.e+5)&(simdisk_distance<300.))
            disk_ncra2_0.append(np.size(disk_cra2))
            disk_ngal_0.append(np.size(disk_gal))
            disk_cra2ratio_0.append(np.median(np.log10(simdisk_mvir[disk_cra2]/simdisk_mvir_peak[disk_cra2])))
            disk_galratio_0.append(np.median(np.log10(simdisk_mvir[disk_gal]/simdisk_mvir_peak[disk_gal])))
            disk_cra2apo_0.append(np.median(simdisk_r_max[disk_cra2]))
            disk_cra2peri_0.append(np.median(simdisk_r_min[disk_cra2]))
            disk_cra2apoperi_0.append(np.median(simdisk_r_min[disk_cra2]/simdisk_r_max[disk_cra2]))
            disk_galapo_0.append(np.median(simdisk_r_max[disk_gal]))
            disk_galperi_0.append(np.median(simdisk_r_min[disk_gal]))
            disk_galapoperi_0.append(np.median(simdisk_r_min[disk_gal]/simdisk_r_max[disk_gal]))
            
    disk_ncra2_0=np.array(disk_ncra2_0)
    disk_ngal_0=np.array(disk_ngal_0)
    disk_cra2ratio_0=np.array(disk_cra2ratio_0)
    disk_galratio_0=np.array(disk_galratio_0)
    disk_cra2apo_0=np.array(disk_cra2apo_0)
    disk_cra2peri_0=np.array(disk_cra2peri_0)
    disk_cra2apoperi_0=np.array(disk_cra2apoperi_0)
    disk_galapo_0=np.array(disk_galapo_0)
    disk_galperi_0=np.array(disk_galperi_0)
    disk_galapoperi_0=np.array(disk_galapoperi_0)
    disk_scatter.append(np.median(prash_sigma8_disk[disk_bin==i]))
#    print(ncra2_0,ngal_0)
    disk_ncra2.append(np.median(disk_ncra2_0))
    disk_ngal.append(np.median(disk_ngal_0))    

    disk_shite=np.where(disk_cra2ratio_0==disk_cra2ratio_0)
    if(np.size(disk_shite)>0):
        disk_cra2ratio.append(np.median(disk_cra2ratio_0[disk_shite]))
        disk_cra2ratiolo.append(np.percentile(disk_cra2ratio_0[disk_shite],16))
        disk_cra2ratiohi.append(np.percentile(disk_cra2ratio_0[disk_shite],84))
        disk_cra2apo.append(np.median(disk_cra2apo_0[disk_shite]))
        disk_cra2apoperi.append(np.median(disk_cra2apoperi_0[disk_shite]))
        disk_cra2apolo.append(np.percentile(disk_cra2apo_0[disk_shite],16))
        disk_cra2apohi.append(np.percentile(disk_cra2apo_0[disk_shite],84))
        disk_cra2peri.append(np.median(disk_cra2peri_0[disk_shite]))
        disk_cra2perilo.append(np.percentile(disk_cra2peri_0[disk_shite],16))
        disk_cra2perihi.append(np.percentile(disk_cra2peri_0[disk_shite],84))
    if(np.size(disk_shite)==0):
        disk_cra2ratio.append('nan')
        disk_cra2ratiolo.append('nan')
        disk_cra2ratiohi.append('nan')
        disk_cra2apo.append('nan')
        disk_cra2apoperi.append('nan')
        disk_cra2apolo.append('nan')
        disk_cra2apohi.append('nan')
        disk_cra2peri.append('nan')
        disk_cra2perilo.append('nan')
        disk_cra2perihi.append('nan')
    disk_shite=np.where(disk_galratio_0==disk_galratio_0)
    if(np.size(disk_shite)>0):
        disk_galratio.append(np.median(disk_galratio_0[disk_shite]))
        disk_galratiolo.append(np.percentile(disk_galratio_0[disk_shite],16))
        disk_galratiohi.append(np.percentile(disk_galratio_0[disk_shite],84))
        disk_galapo.append(np.median(disk_galapo_0[disk_shite]))
        disk_galapoperi.append(np.median(disk_galapoperi_0[disk_shite]))
        disk_galapolo.append(np.percentile(disk_galapo_0[disk_shite],16))
        disk_galapohi.append(np.percentile(disk_galapo_0[disk_shite],84))
        disk_galperi.append(np.median(disk_galperi_0[disk_shite]))
        disk_galperilo.append(np.percentile(disk_galperi_0[disk_shite],16))
        disk_galperihi.append(np.percentile(disk_galperi_0[disk_shite],84))
    if(np.size(disk_shite)==0):
        disk_galratio.append('nan')
        disk_galratiolo.append('nan')
        disk_galratiohi.append('nan')
        disk_galapo.append('nan')
        disk_galapoperi.append('nan')
        disk_galapolo.append('nan')
        disk_galapohi.append('nan')
        disk_galperi.append('nan')
        disk_galperilo.append('nan')
        disk_galperihi.append('nan')

    disk_ncra2lo.append(np.percentile(disk_ncra2_0[disk_shite],16))
    disk_ncra2hi.append(np.percentile(disk_ncra2_0[disk_shite],84))
    disk_ngallo.append(np.percentile(disk_ngal_0,16))
    disk_ngalhi.append(np.percentile(disk_ngal_0,84))

diskncra2=np.array(disk_ncra2)
diskngal=np.array(disk_ngal)
diskscatter=np.array(disk_scatter)
diskcra2ratio=np.array(disk_cra2ratio)
diskgalratio=np.array(disk_galratio)
diskcra2apo=np.array(disk_cra2apo)
diskcra2peri=np.array(disk_cra2peri)
diskcra2apoperi=np.array(disk_cra2apoperi)
diskgalapo=np.array(disk_galapo)
diskgalperi=np.array(disk_galperi)
diskgalapoperi=np.array(disk_galapoperi)
diskncra2lo=np.array(disk_ncra2lo)
diskncra2hi=np.array(disk_ncra2hi)
diskngallo=np.array(disk_ngallo)
diskngalhi=np.array(disk_ngalhi)
diskcra2ratiolo=np.array(disk_cra2ratiolo)
diskcra2ratiohi=np.array(disk_cra2ratiohi)
diskcra2apolo=np.array(disk_cra2apolo)
diskcra2apohi=np.array(disk_cra2apohi)
diskcra2perilo=np.array(disk_cra2perilo)
diskcra2perihi=np.array(disk_cra2perihi)
diskgalratiolo=np.array(disk_galratiolo)
diskgalratiohi=np.array(disk_galratiohi)
diskgalapolo=np.array(disk_galapolo)
diskgalapohi=np.array(disk_galapohi)
diskgalperilo=np.array(disk_galperilo)
diskgalperihi=np.array(disk_galperihi)




gs=plt.GridSpec(12,12) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
axprash=fig.add_subplot(gs[0:3,0:5])
axtide=fig.add_subplot(gs[6:9,0:5])
axperi2=fig.add_subplot(gs[0:3,7:12])
axperi=fig.add_subplot(gs[3:6,0:5])
axapo=fig.add_subplot(gs[3:6,7:12])
axapoperi=fig.add_subplot(gs[9:12,7:12])

axprash.set_yscale('log')
axprash.set_xscale('linear')
axprash.set_xlim([0.2,2.])
axprash.set_ylim([0.5,900])
axprash.set_ylabel(r'$N_{\rm satellites}$',rotation=90,fontsize=11)
axprash.xaxis.set_major_formatter(plt.NullFormatter())
##axprash.fill_between(scatter,ngallo,ngalhi,color='b',alpha=0.4)
axprash.plot(scatter,ngal,color='b',linestyle='--')
#axprash.fill_between(scatter,ncra2lo,ncra2hi,color='b',alpha=0.4)
axprash.plot(scatter,ncra2,color='b')
axprash.plot(disk_scatter,disk_ngal,color='r',linestyle='--')
#axprash.fill_between(disk_scatter,disk_ncra2lo,disk_ncra2hi,color='r',alpha=0.4)                     
axprash.plot(disk_scatter,disk_ncra2,color='r')
#axprash.plot(scatter,ncra2lo,color='r',linestyle=':')
#axprash.plot(scatter,ncra2hi,color='r',linestyle=':')
#axprash.plot(scatter,ngallo,color='b',linestyle=':')
#axprash.plot(scatter,ngalhi,color='b',linestyle=':')
axprash.plot([-10,-9],[1,1],color='b',label=r'no disk')
axprash.plot([-10,-9],[1,1],color='r',label=r'disk')
axprash.plot([-10,-9],[1,1],color='k',linestyle='--',label=r'$M_*>10^5M_{\odot}$')
axprash.plot([-10,-9],[1,1],color='k',linestyle='-',label=r'$M_*>10^5M_{\odot},M_{\rm vir}<10^7M_{\odot}$')
axprash.xaxis.set_major_formatter(plt.NullFormatter())
axprash.legend(loc=2,fontsize=5,handlelength=4.75,scatterpoints=1,borderaxespad=0,shadow=False)

axtide.set_yscale('linear')
axtide.set_xscale('linear')
axtide.set_xlim([0.2,2.])
axtide.set_ylim([-3,-0.1])
axtide.set_xticks([0.5,1.0,1.5,2.0])
axtide.set_xticklabels(['0.5','1.0','1.5','2.0'])
axtide.set_xlabel(r'$\sigma_8$ [dex]',fontsize=11)
axtide.set_ylabel(r'$\log_{10}[M_{\rm vir}/M_{\rm peak}]$',fontsize=11,rotation=90)
axtide.plot(scatter,galratio,color='b',linestyle='--')
#axtide.fill_between(scatter,cra2ratiolo,cra2ratiohi,color='b',alpha=0.4)
axtide.plot(scatter,cra2ratio,color='b')
axtide.plot(disk_scatter,disk_galratio,color='r',linestyle='--')
#axtide.fill_between(disk_scatter,disk_cra2ratiolo,disk_cra2ratiohi,color='r',alpha=0.4)
axtide.plot(disk_scatter,disk_cra2ratio,color='r')
#axtide.plot(scatter,cra2ratiolo,color='r',linestyle=':')
#axtide.plot(scatter,cra2ratiohi,color='r',linestyle=':')
#axtide.plot(scatter,galratiolo,color='b',linestyle=':')
#axtide.plot(scatter,galratiohi,color='b',linestyle=':')
axtide.plot([1,1.3],[-12.5,-12.5],color='k',linestyle='--',label=r'$M_*>10^5M_{\odot}$')
axtide.plot([1,1.3],[-12,-12],color='k',label=r'$M_*>10^5M_{\odot},\n M_{\rm halo}<10^7M_{\odot}$')
#axtide.legend(loc=4,fontsize=5,handlelength=3,scatterpoints=1,borderaxespad=0)

axperi2.set_yscale('linear')
axperi2.set_xscale('linear')
axperi2.set_xlim([0.2,2.])
axperi2.set_ylim([11,100])
axperi2.set_ylabel(r'$r_{\rm peri}$ [kpc]',fontsize=11,rotation=90)
axperi2.xaxis.set_major_formatter(plt.NullFormatter())
axperi2.plot(scatter,galperi,color='b',linestyle='--')
axperi2.plot(scatter,cra2peri,color='b')
axperi2.plot(disk_scatter,disk_galperi,color='r',linestyle='--')
axperi2.plot(disk_scatter,disk_cra2peri,color='r')
#axperi2.plot(scatter,cra2perilo,color='r',linestyle=':')
#axperi2.plot(scatter,cra2perihi,color='r',linestyle=':')
#axperi2.plot(scatter,galperilo,color='b',linestyle=':')
#axperi2.plot(scatter,galperihi,color='b',linestyle=':')
axperi2.xaxis.set_major_formatter(plt.NullFormatter())

axperi.set_yscale('linear')
axperi.set_xscale('linear')
axperi.set_xlim([0.2,2.])
axperi.set_ylim([11,100])
axperi.set_ylabel(r'$r_{\rm peri}$ [kpc]',fontsize=11,rotation=90)
axperi.set_yticks([25,50,75])
axperi.set_yticklabels(['25','50','75'])
axperi.xaxis.set_major_formatter(plt.NullFormatter())
axperi.plot(scatter,galperi,color='b',linestyle='--')
axperi.plot(scatter,cra2peri,color='b')
axperi.plot(disk_scatter,disk_galperi,color='r',linestyle='--')
axperi.plot(disk_scatter,disk_cra2peri,color='r')
#axperi.plot(scatter,cra2perilo,color='r',linestyle=':')
#axperi.plot(scatter,cra2perihi,color='r',linestyle=':')
#axperi.plot(scatter,galperilo,color='b',linestyle=':')
#axperi.plot(scatter,galperihi,color='b',linestyle=':')
axperi.xaxis.set_major_formatter(plt.NullFormatter())

axapo.set_yscale('linear')
axapo.set_xscale('linear')
axapo.set_xlim([0.2,2.])
axapo.set_ylim([100,259])
axapo.set_xticks([0.5,1.0,1.5,2.0])
axapo.set_xticklabels(['0.5','1.0','1.5','2.0'])
axapo.set_xlabel(r'$\sigma_8$ [dex]',fontsize=11)
axapo.set_ylabel(r'$r_{\rm apo}$ [kpc]',fontsize=11,rotation=90)
axapo.plot(scatter,galapo,color='b',linestyle='--')
axapo.plot(scatter,cra2apo,color='b')
axapo.plot(disk_scatter,disk_galapo,color='r',linestyle='--')
axapo.plot(disk_scatter,disk_cra2apo,color='r')
#axapo.plot(scatter,cra2apolo,color='r',linestyle=':')
#axapo.plot(scatter,cra2apohi,color='r',linestyle=':')
#axapo.plot(scatter,galapolo,color='b',linestyle=':')
#axapo.plot(scatter,galapohi,color='b',linestyle=':')

axapoperi.set_yscale('linear')
axapoperi.set_xscale('linear')
axapoperi.set_xlim([0.2,2.])
axapoperi.set_ylim([0,1])
axapoperi.set_xticks([0.5,1.0,1.5,2.0])
axapoperi.set_xticklabels(['0.5','1.0','1.5','2.0'])
axapoperi.set_xlabel(r'$\sigma_8$ [dex]',fontsize=11)
axapoperi.set_ylabel(r'$r_{\rm peri}/r_{\rm apo}$',fontsize=11,rotation=90)
axapoperi.plot(scatter,galapoperi,color='b',linestyle='--')
axapoperi.plot(scatter,cra2apoperi,color='b')
axapoperi.plot(disk_scatter,disk_galapoperi,color='r',linestyle='--')
axapoperi.plot(disk_scatter,disk_cra2apoperi,color='r')
#axapoperi.plot(scatter,cra2apolo,color='r',linestyle=':')
#axapoperi.plot(scatter,cra2apohi,color='r',linestyle=':')
#axapoperi.plot(scatter,galapolo,color='b',linestyle=':')
#axapoperi.plot(scatter,galapohi,color='b',linestyle=':')

#plotfilename='cra2_prash3disk.pdf'
plotfilename='cra2_prash4.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
