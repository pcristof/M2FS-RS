import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
import scipy.special as special
import scipy.optimize as optimize
import scipy.integrate as integrate
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.99)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=1)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='8')
plt.rc('ytick',labelsize='8')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)
  
fbar=0.1#do not let halos have larger fration of Mbar/Mhalo  
gdagger=1.2e-10
ghat=9.2e-12
g=0.0043# grav constant in galaxy units        
data1='/nfs/nas-0-9/mgwalker.proj/nelson/mcconnachie.dat'
data1b='/nfs/nas-0-9/mgwalker.proj/nelson/lelli_dsph.dat'
data4='/nfs/nas-0-9/mgwalker.proj/nelson/gru1teffprior_gradientpost_equal_weights.dat'
data5='/nfs/nas-0-9/mgwalker.proj/nelson/ret2_gradientpost_equal_weights.dat'
data6='/nfs/nas-0-9/mgwalker.proj/nelson/tuc2teffprior_gradientpost_equal_weights.dat'
data7='/physics2/mgwalker/chains/cra2gradientpost_equal_weights.dat'


logm200_0=np.array([8.])
smhm_scatter=2.0#dex
out='/nfs/nas-0-9/mgwalker.proj/nelson/cra2_gobsgbar_dicintio8_2.0.dat'
g1=open(out,'w')

h=0.7
h0=100.*h
triangle=200.
rhocrit=3.*(h0**2)/8./np.pi/6.67e-11/((3.09e+13)**2)/((1.e+6)**2)*((3.09e+16)**3)/2.e+30 #MSUN/PC^3
rhomin=triangle*rhocrit
realizations=5000
logc200=np.zeros(len(logm200_0))
logm200=np.zeros((len(logm200_0),realizations))
logc200=np.zeros((len(logm200_0),realizations))
logc200_dev=np.zeros((len(logm200_0),realizations))
for i in range(0,len(logm200_0)):
    logm200[i,:]=logm200_0[i]
    logc200_scatter=0.11# from dutton/maccio 2014
    logc200_dev[i,:]=np.random.normal(loc=0.,scale=logc200_scatter,size=realizations)
    logc200_dev[i,0]=0.#reserve first realization for zero-scatter case
    logc200[i,:]=0.905-0.101*np.log10(10.**logm200[i]/(1.e+12/h))+logc200_dev[i,:]# from dutton/maccio 2014
    
m200=10.**logm200
c200=10.**logc200
r200=(m200/(4./3.*np.pi*rhomin))**(0.333333)
rs=r200/c200
navarro_rs=rs
rhos=m200/(4.*np.pi*(rs**3)*(np.log(1.+c200)-c200/(1.+c200)))
mscale=4.*np.pi*(rs**3)*rhos*(np.log(2.)-0.5)
navarro_rh=np.zeros((len(logm200_0),realizations))
rh_dev=np.zeros((len(logm200_0),realizations))
for i in range(0,len(logm200_0)):
    rh_scatter=0.25
    rh_dev[i,:]=np.random.normal(loc=0.,scale=rh_scatter,size=realizations)
    rh_dev[i,0]=0.#reserve first realization for zero-scatter case
    navarro_rh[i,:]=navarro_rs[i,:]*(10.**(-0.7+rh_dev[i,:]))
    for j in range(0,realizations):
        if(navarro_rh[i,j]>navarro_rs[i,j]):
               navarro_rh[i,j]=navarro_rs[i,j]
navarro_rd=navarro_rh/1.678

behroozi_epsilon0=-1.777#-0.146+0.133
behroozi_epsilona=-0.006#-0.361+0.113
behroozi_epsilonz=-0.000#-0.104+0.003
behroozi_epsilona2=-0.119#-0.012+0.061
behroozi_m10=11.514#-0.009+0.053
behroozi_m1a=-1.793#-0.330+0.315
behroozi_m1z=-0.251#-0.125+0.012
behroozi_alpha0=-1.412#-0.105+0.020
behroozi_alphaa=0.731#-0.296+0.344
behroozi_delta0=3.508#-0.369+0.087
behroozi_deltaa=2.608#-1.261+2.446
behroozi_deltaz=-0.043#-0.071+0.958
behroozi_gamma0=0.316#-0.012+0.076
behroozi_gammaa=1.319#-0.505+0.584
behroozi_gammaz=0.279#-0.081+0.256

garrisonkimmel_alpha=0.14*smhm_scatter**2+0.14*smhm_scatter+1.79

behroozi_z=0.1
behroozi_a=1./(1.+behroozi_z)
behroozi_nu=np.exp(-4.*behroozi_a**2)
behroozi_logepsilon=behroozi_epsilon0+(behroozi_epsilona*(behroozi_a-1.)+behroozi_epsilonz*behroozi_z)*behroozi_nu+behroozi_epsilona2*(behroozi_a-1.)
behroozi_logm1=behroozi_m10+(behroozi_m1a*(behroozi_a-1.)+behroozi_m1z*behroozi_z)*behroozi_nu
behroozi_alpha=behroozi_alpha0+(behroozi_alphaa*(behroozi_a-1.))*behroozi_nu
behroozi_delta=behroozi_delta0+(behroozi_deltaa*(behroozi_a-1.)+behroozi_deltaz*behroozi_z)*behroozi_nu
behroozi_gamma=behroozi_gamma0+(behroozi_gammaa*(behroozi_a-1.)+behroozi_gammaz*behroozi_z)*behroozi_nu

behroozi_x=np.log10(m200/10.**(behroozi_logm1))
behroozi_x0=0.
behroozi_fx=-np.log10(10.**(behroozi_alpha*behroozi_x)+1.)+behroozi_delta*(np.log10(1.+np.exp(behroozi_x)))**(behroozi_gamma)/(1.+np.exp(10.**(-1.*behroozi_x)))
behroozi_f0=-np.log10(10.**(behroozi_alpha*behroozi_x0)+1.)+behroozi_delta*(np.log10(1.+np.exp(behroozi_x0)))**(behroozi_gamma)/(1.+np.exp(10.**(-1.*behroozi_x0)))

behroozi_logmstar1=np.log10(10.**behroozi_logepsilon*10.**behroozi_logm1)
garrisonkimmel_logk=behroozi_logmstar1-garrisonkimmel_alpha*behroozi_logm1
garrisonkimmel_k=10.**garrisonkimmel_logk

behroozi_dev=np.zeros((len(m200),realizations))
behroozi_logmstar=np.zeros((len(m200),realizations))
garrisonkimmel_logmstar=np.zeros((len(m200),realizations))
for i in range(0,len(m200)):
    behroozi_dev[i,:]=np.random.normal(loc=0.,scale=smhm_scatter,size=realizations)
    behroozi_dev[i,0]=0.#reserve first iteration for zero-scatter case
    behroozi_logmstar[i,:]=np.log10((10.**behroozi_logepsilon)*(10.**behroozi_logm1))+behroozi_fx[i]-behroozi_f0+behroozi_dev[i,:]
    garrisonkimmel_logmstar[i,:]=garrisonkimmel_logk+garrisonkimmel_alpha*np.log10(m200[i,:])+behroozi_dev[i,:]
#    for j in range(0,realizations):
#        if(10.**behroozi_logmstar[i,j]>fbar*m200[i,j]):
#            behroozi_logmstar[i,j]=np.log10(fbar*m200[i,j])
#        if(10.**garrisonkimmel_logmstar[i,j]>fbar*m200[i,j]):
#            garrisonkimmel_logmstar[i,j]=np.log10(fbar*m200[i,j])

behroozi_mu0=-0.020#-0.096+0.168
behroozi_mua=0.081#-0.036+0.078
behroozi_kappa0=0.045#-0.051+0.110
behroozi_kappaa=-0.155#-0.133+0.133
behroozi_xi0=0.218#-0.033+0.011
behroozi_xia=-0.023#-0.068+0.052
behroozi_sigmaz=0.061#-0.008+0.017
behroozi_mu=behroozi_mu0+behroozi_mua*(behroozi_a-1.)
behroozi_kappa=behroozi_kappa0+behroozi_kappaa*(behroozi_a-1.)
behroozi_xi=behroozi_xi0+behroozi_xia*(behroozi_a-1.)
behroozi_sigma=0.070+behroozi_sigmaz*(behroozi_z-0.1)
behroozi_logmbias=behroozi_mu

logupsilonstar=np.log10(2.)
siglogupsilonstar=0.25
upsilonstar=10.**logupsilonstar
sigupsilonstar=np.log(10.)*10.**logupsilonstar*siglogupsilonstar

with open('/nfs/nas-0-9/mgwalker.proj/nelson/mcgaugh_gobsgbar.dat') as f: # read data file
    data=f.readlines()[13:]
mcgaugh_gbar=[]
mcgaugh_siggbar=[]
mcgaugh_gobs=[]
mcgaugh_siggobs=[]
for line in data: # fill arrays
    p=line.split()
    mcgaugh_gbar.append(float(p[0]))
    mcgaugh_siggbar.append(float(p[1]))
    mcgaugh_gobs.append(float(p[2]))
    mcgaugh_siggobs.append(float(p[3]))
mcgaugh_gbar=np.array(mcgaugh_gbar)
mcgaugh_siggbar=np.array(mcgaugh_siggbar)
mcgaugh_gobs=np.array(mcgaugh_gobs)
mcgaugh_siggobs=np.array(mcgaugh_siggobs)

mcgaugh_deltaloggobs=mcgaugh_gobs-np.log10(10.**mcgaugh_gbar/(1.-np.exp(-np.sqrt(10.**mcgaugh_gbar/gdagger))))
mcgaugh_sigdeltaloggobs=mcgaugh_siggobs

with open(data1b) as f: # read data file
    data=f.readlines()
lelli_dsph=[]
lelli_d=[]
lelli_sigd1=[]
lelli_sigd2=[]
lelli_dhost=[]
lelli_loglum=[]
lelli_sigloglum=[]
lelli_rhalf=[]
lelli_sigrhalf=[]
lelli_ellip=[]
lelli_vdisp=[]
lelli_sigvdisp1=[]
lelli_sigvdisp2=[]
lelli_n=[]
lelli_loggbar=[]
lelli_sigloggbar1=[]
lelli_sigloggbar2=[]
lelli_gobs=[]
lelli_sigloggobs1=[]
lelli_sigloggobs2=[]
lelli_parent=[]
for line in data: # fill arrays
    p=line.split()
    lelli_dsph.append(str(p[0]))
    lelli_d.append(float(p[1]))
    lelli_sigd1.append(float(p[2]))
    lelli_sigd2.append(float(p[3]))
    lelli_dhost.append(float(p[4]))
    lelli_loglum.append(float(p[5]))
    lelli_sigloglum.append(float(p[6]))
    lelli_rhalf.append(float(p[7]))
    lelli_sigrhalf.append(float(p[8]))
    lelli_ellip.append(float(p[9]))
    lelli_vdisp.append(float(p[10]))
    lelli_sigvdisp1.append(float(p[11]))
    lelli_sigvdisp2.append(float(p[12]))
    lelli_n.append(float(p[13]))
    lelli_loggbar.append(float(p[14]))
    lelli_sigloggbar1.append(float(p[15]))
    lelli_sigloggbar2.append(float(p[16]))
    lelli_gobs.append(float(p[17]))
    lelli_sigloggobs1.append(float(p[18]))
    lelli_sigloggobs2.append(float(p[19]))
    lelli_parent.append(str(p[20]))
lelli_dsph=np.array(lelli_dsph)
lelli_d=np.array(lelli_d)
lelli_sigd1=np.array(lelli_sigd1)
lelli_sigd2=np.array(lelli_sigd2)
lelli_dhost=np.array(lelli_dhost)
lelli_loglum=np.array(lelli_loglum)
lelli_sigloglum=np.array(lelli_sigloglum)
lelli_rhalf=np.array(lelli_rhalf)
lelli_sigrhalf=np.array(lelli_sigrhalf)
lelli_ellip=np.array(lelli_ellip)
lelli_vdisp=np.array(lelli_vdisp)
lelli_sigvdisp1=np.array(lelli_sigvdisp1)
lelli_sigvdisp2=np.array(lelli_sigvdisp2)
lelli_n=np.array(lelli_n)
lelli_loggbar=np.array(lelli_loggbar)
lelli_sigloggbar1=np.array(lelli_sigloggbar1)
lelli_sigloggbar2=np.array(lelli_sigloggbar2)
lelli_gobs=np.array(lelli_gobs)
lelli_sigloggobs1=np.array(lelli_sigloggobs1)
lelli_sigloggobs2=np.array(lelli_sigloggobs2)
lelli_parent=np.array(lelli_parent)

lelli_mhost=np.zeros(len(lelli_rhalf))
for i in range(0,len(lelli_rhalf)):
    if lelli_ellip[i] > 0.:
        lelli_rhalf[i]=lelli_rhalf[i]*np.sqrt(1.-lelli_ellip[i])########convert to geometric mean radius
        lelli_sigrhalf[i]=lelli_sigrhalf[i]*np.sqrt(1.-lelli_ellip[i])
        if(lelli_parent[i]=='MW'):
            lelli_mhost[i]=1.e+12
        if(lelli_parent[i]=='M31'):
            lelli_mhost[i]=2.e+12

lelli_rhalf=3./4.*lelli_rhalf
lelli_sigrhalf=3./4.*lelli_sigrhalf
lelli_sigvdisp=(np.abs(lelli_sigvdisp1)+np.abs(lelli_sigvdisp2))/2.

lelli_luminosity=10.**lelli_loglum
lelli_sigluminosity=10.**lelli_loglum*np.log(10.)*lelli_sigloglum

lelli_gbar=g*upsilonstar*lelli_luminosity/(2.**1.5)/lelli_rhalf**2*(1000.**2)/3.09e+16
lelli_gobs=5.*lelli_vdisp**2/2./lelli_rhalf*(1000.**2)/3.09e+16
lelli_siggbar=np.sqrt((lelli_gbar/lelli_luminosity*lelli_sigluminosity)**2+(lelli_gbar/upsilonstar*sigupsilonstar)**2+(2.*lelli_gbar/lelli_rhalf*lelli_sigrhalf)**2)
lelli_siggobs=np.sqrt((2.*lelli_gobs/lelli_vdisp*lelli_sigvdisp)**2+(lelli_gobs/lelli_rhalf*lelli_sigrhalf)**2)

lelli_loggbar=np.log10(lelli_gbar)
lelli_sigloggbar=np.sqrt((lelli_siggbar/lelli_gbar/np.log(10.))**2)
lelli_loggobs=np.log10(lelli_gobs)
lelli_sigloggobs=np.sqrt((lelli_siggobs/lelli_gobs/np.log(10.))**2)

lelli_gtides=g*lelli_mhost*2.*lelli_rhalf/((lelli_dhost*1000.)**3)/((3.09e+13))*(1000.**2)

lelli_deltaloggobs=lelli_loggobs-np.log10(lelli_gbar/(1.-np.exp(-np.sqrt(lelli_gbar/gdagger))))
lelli_sigdeltaloggobs=lelli_sigloggobs

with open(data1) as f: # read data file
    data=f.readlines()

parent=[]
dsph=[]
rah=[]
ram=[]
ras=[]
chardecd=[]
decm=[]
decs=[]
glon=[]
glat=[]
distance=[]
sigdistance=[]
vsys=[]
sigvsys=[]
vmag=[]
sigvmag=[]
rhalfarcmin=[]
sigrhalfarcmin=[]
muv=[]
sigmuv=[]
ellip=[]
absvmag=[]
sigabsvmag=[]
rhalf=[]
sigrhalf=[]
vdisp=[]
sigvdisp=[]
feh=[]
sigfeh=[]
method=[]

for line in data: # fill arrays
    p=line.split()
    parent.append(str(p[0]))
    dsph.append(str(p[1]))
    rah.append(float(p[3]))
    ram.append(float(p[4]))
    ras.append(float(p[5]))
    chardecd.append(float(p[6]))
    decm.append(float(p[7]))
    decs.append(str(p[8]))
    glon.append(float(p[9]))
    glat.append(float(p[10]))
    distance.append(float(p[11]))
    sigdistance.append(float(p[12]))
    vsys.append(float(p[14]))
    sigvsys.append(float(p[15]))
    vmag.append(float(p[16]))
    sigvmag.append(float(p[17]))
    rhalfarcmin.append(float(p[19]))
    sigrhalfarcmin.append(float(p[20]))
    muv.append(float(p[22]))
    sigmuv.append(float(p[23]))
    ellip.append(float(p[25]))
    absvmag.append(float(p[26]))
    sigabsvmag.append(float(p[27]))
    rhalf.append(float(p[29]))
    sigrhalf.append(float(p[30]))
    vdisp.append(float(p[32]))
    sigvdisp.append(float(p[33]))
    feh.append(float(p[35]))
    sigfeh.append(float(p[36]))
    method.append(str(p[37]))

parent=np.array(parent)
dsph=np.array(dsph)
rah=np.array(rah)
ram=np.array(ram)
ras=np.array(ras)
chardecd=np.array(chardecd)
decm=np.array(decm)
decs=np.array(decs)
glon=np.array(glon)
glat=np.array(glat)
distance=np.array(distance)
sigdistance=np.array(sigdistance)
vsys=np.array(vsys)
sigvsys=np.array(sigvsys)
vmag=np.array(vmag)
sigvmag=np.array(sigvmag)
rhalfarcmin=np.array(rhalfarcmin)
sigrhalfarcmin=np.array(sigrhalfarcmin)
muv=np.array(muv)
sigmuv=np.array(sigmuv)
ellip=np.array(ellip)
absvmag=np.array(absvmag)
sigabsvmag=np.array(sigabsvmag)
rhalf=np.array(rhalf)
sigrhalf=np.array(sigrhalf)
vdisp=np.array(vdisp)
sigvdisp=np.array(sigvdisp)
feh=np.array(feh)
sigfeh=np.array(sigfeh)
method=np.array(method)

vdisp[8]=2.5

for i in range(0,len(rhalf)):
    if ellip[i] > 0.:
        rhalf[i]=rhalf[i]*np.sqrt(1.-ellip[i])########convert to geometric mean radius
        sigrhalf[i]=sigrhalf[i]*np.sqrt(1.-ellip[i])


with open(data4) as f: # read data file
    data=f.readlines()

gru1vmean=[]
gru1vdisp=[]
gru1vgrad=[]
gru1vtheta=[]
gru1fehmean=[]
gru1fehdisp=[]
gru1fehgrad=[]
gru1like=[]

for line in data: # fill arrays
    p=line.split()
    gru1vmean.append(float(p[0]))
    gru1vdisp.append(float(p[1]))
    gru1vgrad.append(float(p[2]))
    gru1vtheta.append(float(p[3]))
    gru1fehmean.append(float(p[4]))
    gru1fehdisp.append(float(p[5]))
    gru1fehgrad.append(float(p[6]))
    gru1like.append(float(p[7]))

gru1vmean=np.array(gru1vmean)
gru1vdisp=np.array(gru1vdisp)
gru1vgrad=np.array(gru1vgrad)
gru1vtheta=np.array(gru1vtheta)
gru1fehmean=np.array(gru1fehmean)
gru1fehdisp=np.array(gru1fehdisp)
gru1fehgrad=np.array(gru1fehgrad)
gru1like=np.array(gru1like)

gru1_vdisp0=np.array([np.median(gru1vdisp)])
gru1_sigvdisp0=np.array([np.std(gru1vdisp)])
gru1_feh=np.array([np.median(gru1fehmean)])
gru1_sigfeh=np.array([np.std(gru1fehmean)])
gru1_rhalf0=62.
gru1_sigrhalf0=30.
gru1_rhalf=np.random.normal(loc=gru1_rhalf0,scale=gru1_sigrhalf0,size=len(gru1vdisp))
#gru1_sigrhalf=np.array([1.])
gru1_absvmag0=-3.4
gru1_sigabsvmag0=0.3
gru1_absvmag=np.random.normal(loc=gru1_absvmag0,scale=gru1_sigabsvmag0,size=len(gru1vdisp))
#gru1_sigabsvmag=np.array([0.1])
gru1_rho0=gru1_vdisp0**2/g/gru1_rhalf0**2
gru1_sigrho0=np.sqrt((2.*gru1_vdisp0/gru1_rhalf0**2/g*gru1_sigvdisp0)**2+(2.*gru1_vdisp0**2/g/gru1_rhalf0**3*gru1_sigrhalf0)**2)
gru1_fehdisp=[np.median(gru1fehdisp)]
gru1_sigfehdisp=[np.std(gru1fehdisp)]


with open(data5) as f: # read data file
    data=f.readlines()

ret2vmean=[]
ret2vdisp=[]
ret2vgrad=[]
ret2vtheta=[]
ret2fehmean=[]
ret2fehdisp=[]
ret2fehgrad=[]
ret2like=[]

for line in data: # fill arrays
    p=line.split()
    ret2vmean.append(float(p[0]))
    ret2vdisp.append(float(p[1]))
    ret2vgrad.append(float(p[2]))
    ret2vtheta.append(float(p[3]))
    ret2fehmean.append(float(p[4]))
    ret2fehdisp.append(float(p[5]))
    ret2fehgrad.append(float(p[6]))
    ret2like.append(float(p[7]))

ret2vmean=np.array(ret2vmean)
ret2vdisp=np.array(ret2vdisp)
ret2vgrad=np.array(ret2vgrad)
ret2vtheta=np.array(ret2vtheta)
ret2fehmean=np.array(ret2fehmean)
ret2fehdisp=np.array(ret2fehdisp)
ret2fehgrad=np.array(ret2fehgrad)
ret2like=np.array(ret2like)

ret2_vdisp0=np.array([np.median(ret2vdisp)])
ret2_sigvdisp0=np.array([np.std(ret2vdisp)])
ret2_feh=np.array([np.median(ret2fehmean)])
ret2_sigfeh=np.array([np.std(ret2fehmean)])
ret2_rhalf0=32.
ret2_sigrhalf0=2.
ret2_rhalf=np.random.normal(loc=ret2_rhalf0,scale=ret2_sigrhalf0,size=len(ret2vdisp))
#ret2_sigrhalf=np.array([1.])
ret2_absvmag0=-2.7
ret2_sigabsvmag0=0.1
ret2_absvmag=np.random.normal(loc=ret2_absvmag0,scale=0.2,size=len(ret2vdisp))
#ret2_sigabsvmag=np.array([0.1])
ret2_rho0=ret2_vdisp0**2/g/ret2_rhalf0**2
ret2_sigrho0=np.sqrt((2.*ret2_vdisp0/ret2_rhalf0**2/g*ret2_sigvdisp0)**2+(2.*ret2_vdisp0**2/g/ret2_rhalf0**3*ret2_sigrhalf0)**2)


with open(data6) as f: # read data file
    data=f.readlines()

tuc2vmean=[]
tuc2vdisp=[]
tuc2vgrad=[]
tuc2vtheta=[]
tuc2fehmean=[]
tuc2fehdisp=[]
tuc2fehgrad=[]
tuc2like=[]

for line in data: # fill arrays
    p=line.split()
    tuc2vmean.append(float(p[0]))
    tuc2vdisp.append(float(p[1]))
    tuc2vgrad.append(float(p[2]))
    tuc2vtheta.append(float(p[3]))
    tuc2fehmean.append(float(p[4]))
    tuc2fehdisp.append(float(p[5]))
    tuc2fehgrad.append(float(p[6]))
    tuc2like.append(float(p[7]))

tuc2vmean=np.array(tuc2vmean)
tuc2vdisp=np.array(tuc2vdisp)
tuc2vgrad=np.array(tuc2vgrad)
tuc2vtheta=np.array(tuc2vtheta)
tuc2fehmean=np.array(tuc2fehmean)
tuc2fehdisp=np.array(tuc2fehdisp)
tuc2fehgrad=np.array(tuc2fehgrad)
tuc2like=np.array(tuc2like)

tuc2_vdisp0=np.array([np.median(tuc2vdisp)])
tuc2_sigvdisp0=np.array([np.std(tuc2vdisp)])
tuc2_feh=np.array([np.median(tuc2fehmean)])
tuc2_sigfeh=np.array([np.std(tuc2fehmean)])
tuc2_rhalf0=165.
tuc2_sigrhalf0=28.
tuc2_rhalf=np.random.normal(loc=tuc2_rhalf0,scale=tuc2_sigrhalf0,size=len(tuc2vdisp))
#tuc2_sigrhalf=np.array([1.])
tuc2_absvmag0=-3.8
tuc2_sigabsvmag0=0.1
tuc2_absvmag=np.random.normal(loc=tuc2_absvmag0,scale=tuc2_sigabsvmag0,size=len(tuc2vdisp))
#tuc2_sigabsvmag=np.array([0.1])
tuc2_rho0=tuc2_vdisp0**2/g/tuc2_rhalf0**2
tuc2_sigrho0=np.sqrt((2.*tuc2_vdisp0/tuc2_rhalf0**2/g*tuc2_sigvdisp0)**2+(2.*tuc2_vdisp0**2/g/tuc2_rhalf0**3*tuc2_sigrhalf0)**2)
tuc2_fehdisp=[np.median(tuc2fehdisp)]
tuc2_sigfehdisp=[np.std(tuc2fehdisp)]

with open(data7) as f: # read data file
    data=f.readlines()

cra2vmean=[]
cra2vvar=[]
cra2fehmean=[]
cra2fehvar=[]
cra2rslight=[]
cra2like=[]

for line in data: # fill arrays
    p=line.split()
    cra2vmean.append(float(p[4]))
    cra2vvar.append(float(p[2]))
    cra2fehmean.append(float(p[5]))
    cra2fehvar.append(float(p[3]))
    cra2rslight.append(float(p[1]))
    cra2like.append(float(p[7]))

cra2vmean=np.array(cra2vmean)
cra2vvar=np.array(cra2vvar)
cra2fehmean=np.array(cra2fehmean)
cra2fehvar=np.array(cra2fehvar)
cra2rslight=np.array(cra2rslight)
cra2like=np.array(cra2like)

cra2rslight=10.**cra2rslight
cra2rslightpc=117000.*np.tan(cra2rslight/60.*np.pi/180.)
cra2vdisp=np.sqrt(10.**cra2vvar)
cra2fehdisp=np.sqrt(10.**cra2fehvar)
cra2_fehdisp=[np.median(cra2fehdisp)]
cra2_sigfehdisp=[np.std(cra2fehdisp)]

cra2_vdisp0=np.array([np.median(cra2vdisp)])
cra2_sigvdisp0=np.array([np.std(cra2vdisp)])
cra2_feh=np.array([np.median(cra2fehmean)])
cra2_sigfeh=np.array([np.std(cra2fehmean)])
cra2_rhalf0=np.median(cra2rslightpc)
cra2_sigrhalf0=np.std(cra2rslightpc)
cra2_rhalf=cra2rslightpc
cra2_absvmag0=-8.2
cra2_sigabsvmag0=0.1
cra2_absvmag=np.random.normal(loc=cra2_absvmag0,scale=cra2_sigabsvmag0,size=len(cra2vdisp))
cra2_rho0=cra2_vdisp0**2/g/cra2_rhalf0**2
cra2_sigrho0=np.sqrt((2.*cra2_vdisp0/cra2_rhalf0**2/g*cra2_sigvdisp0)**2+(2.*cra2_vdisp0**2/g/cra2_rhalf0**3*cra2_sigrhalf0)**2)

luminosity=10.**((absvmag-4.83)/(-2.5))
sigluminosity=np.log(10.)/2.5*10.**((absvmag-4.83)/(-2.5))*sigabsvmag
mrhalf=1./0.0043*rhalf*vdisp**2
sigmrhalf=np.sqrt(((2.*rhalf/0.0043*vdisp)**2)*(sigvdisp**2)+((1./0.0043*(vdisp**2))**2)*sigrhalf**2)
mlratio=mrhalf/(luminosity)
sigmlratio=np.sqrt((sigmrhalf**2)/(luminosity**2)+((mrhalf/luminosity**2)**2)*sigluminosity**2)
gbar=g*upsilonstar*luminosity/(2.**1.5)/rhalf**2*(1000.**2)/3.09e+16
gobs=5.*vdisp**2/2./rhalf*(1000.**2)/3.09e+16
siggbar=np.sqrt((gbar/luminosity*sigluminosity)**2+(gbar/upsilonstar*sigupsilonstar)**2+(2.*gbar/rhalf*sigrhalf)**2)
siggobs=np.sqrt((2.*gobs/vdisp*sigvdisp)**2+(gobs/rhalf*sigrhalf)**2)
loggbar=np.log10(gbar)
sigloggbar=np.sqrt((siggbar/gbar/np.log(10.))**2)
loggobs=np.log10(gobs)
sigloggobs=np.sqrt((siggobs/gobs/np.log(10.))**2)

deltaloggobs=loggobs-np.log10(gbar/(1.-np.exp(-np.sqrt(gbar/gdagger))))
sigdeltaloggobs=sigloggobs

rho=vdisp**2/rhalf**2/g
sigrho=np.sqrt((2.*vdisp/rhalf**2/g*sigvdisp)**2+(2.*vdisp**2/g/rhalf**3*sigrhalf)**2)
mw_rhokeep=np.where((parent =='MW') & (sigrho/rho <=1.))
m31_rhokeep=np.where((parent =='M31') & (sigrho/rho <=1.))
rest_rhokeep=np.where((parent =='Rest') & (sigrho/rho <= 1.))
mw_mlkeep=np.where((parent =='MW') & (sigmlratio/mlratio <=1.))
m31_mlkeep=np.where((parent =='M31') & (sigmlratio/mlratio <=1.))
rest_mlkeep=np.where((parent =='Rest') & (sigmlratio/mlratio <= 1.))

gru1_vdisp=gru1vdisp
gru1_luminosity0=10.**((gru1_absvmag0-4.83)/(-2.5))
gru1_luminosity=10.**((gru1_absvmag-4.83)/(-2.5))
gru1_sigluminosity0=np.log(10.)/2.5*10.**((gru1_absvmag0-4.83)/(-2.5))*gru1_sigabsvmag0
gru1_mrhalf0=1./0.0043*gru1_rhalf0*gru1_vdisp0**2
gru1_mrhalf=1./0.0043*gru1_rhalf*gru1vdisp**2
gru1_sigmrhalf0=np.sqrt(2.*gru1_rhalf0/0.0043*gru1_vdisp0*(gru1_sigvdisp0**2)+((1./0.0043*(gru1_vdisp0**2))**2)*gru1_sigrhalf0**2)
gru1_mlratio=gru1_mrhalf/(gru1_luminosity)
gru1_mlratio0=gru1_mrhalf0/gru1_luminosity0
gru1_sigmlratio0=np.sqrt((gru1_sigmrhalf0**2)/(gru1_luminosity0**2)+((gru1_mrhalf0/gru1_luminosity0**2)**2)*gru1_sigluminosity0**2)
gru1_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(gru1_mrhalf))
gru1_upsilonstar=10.**gru1_logupsilonstar
gru1_gbar=g*gru1_upsilonstar*gru1_luminosity/(2.**1.5)/gru1_rhalf**2*(1000.**2)/3.09e+16
gru1_gobs=5.*gru1_vdisp**2/2./gru1_rhalf*(1000.**2)/3.09e+16
gru1_loggbar=np.log10(gru1_gbar)
gru1_loggobs=np.log10(gru1_gobs)
gru1_deltaloggobs=gru1_loggobs-np.log10(gru1_gbar/(1.-np.exp(-np.sqrt(gru1_gbar/gdagger))))


ret2_vdisp=ret2vdisp
ret2_luminosity0=10.**((ret2_absvmag0-4.83)/(-2.5))
ret2_luminosity=10.**((ret2_absvmag-4.83)/(-2.5))
ret2_sigluminosity0=np.log(10.)/2.5*10.**((ret2_absvmag0-4.83)/(-2.5))*ret2_sigabsvmag0
ret2_mrhalf0=1./0.0043*ret2_rhalf0*ret2_vdisp0**2
ret2_mrhalf=1./0.0043*ret2_rhalf*ret2vdisp**2
ret2_sigmrhalf0=np.sqrt(2.*ret2_rhalf0/0.0043*ret2_vdisp0*(ret2_sigvdisp0**2)+((1./0.0043*(ret2_vdisp0**2))**2)*ret2_sigrhalf0**2)
ret2_mlratio=ret2_mrhalf/(ret2_luminosity)
ret2_mlratio0=ret2_mrhalf0/ret2_luminosity0
ret2_sigmlratio0=np.sqrt((ret2_sigmrhalf0**2)/(ret2_luminosity0**2)+((ret2_mrhalf0/ret2_luminosity0**2)**2)*ret2_sigluminosity0**2)
ret2_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(ret2_mrhalf))
ret2_upsilonstar=10.**ret2_logupsilonstar
ret2_gbar=g*ret2_upsilonstar*ret2_luminosity/(2.**1.5)/ret2_rhalf**2*(1000.**2)/3.09e+16
ret2_gobs=5.*ret2_vdisp**2/2./ret2_rhalf*(1000.**2)/3.09e+16
ret2_loggbar=np.log10(ret2_gbar)
ret2_loggobs=np.log10(ret2_gobs)
ret2_deltaloggobs=ret2_loggobs-np.log10(ret2_gbar/(1.-np.exp(-np.sqrt(ret2_gbar/gdagger))))

tuc2_vdisp=tuc2vdisp
tuc2_luminosity0=10.**((tuc2_absvmag0-4.83)/(-2.5))
tuc2_luminosity=10.**((tuc2_absvmag-4.83)/(-2.5))
tuc2_sigluminosity0=np.log(10.)/2.5*10.**((tuc2_absvmag0-4.83)/(-2.5))*tuc2_sigabsvmag0
tuc2_mrhalf0=1./0.0043*tuc2_rhalf0*tuc2_vdisp0**2
tuc2_mrhalf=1./0.0043*tuc2_rhalf*tuc2vdisp**2
tuc2_sigmrhalf0=np.sqrt(2.*tuc2_rhalf0/0.0043*tuc2_vdisp0*(tuc2_sigvdisp0**2)+((1./0.0043*(tuc2_vdisp0**2))**2)*tuc2_sigrhalf0**2)
tuc2_mlratio=tuc2_mrhalf/(tuc2_luminosity)
tuc2_mlratio0=tuc2_mrhalf0/tuc2_luminosity0
tuc2_sigmlratio0=np.sqrt((tuc2_sigmrhalf0**2)/(tuc2_luminosity0**2)+((tuc2_mrhalf0/tuc2_luminosity0**2)**2)*tuc2_sigluminosity0**2)
tuc2_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(tuc2_mrhalf))
tuc2_upsilonstar=10.**tuc2_logupsilonstar
tuc2_gbar=g*tuc2_upsilonstar*tuc2_luminosity/(2.**1.5)/tuc2_rhalf**2*(1000.**2)/3.09e+16
tuc2_gobs=5.*tuc2_vdisp**2/2./tuc2_rhalf*(1000.**2)/3.09e+16
tuc2_loggbar=np.log10(tuc2_gbar)
tuc2_loggobs=np.log10(tuc2_gobs)
tuc2_deltaloggobs=tuc2_loggobs-np.log10(tuc2_gbar/(1.-np.exp(-np.sqrt(tuc2_gbar/gdagger))))

cra2_vdisp=cra2vdisp
cra2_luminosity0=10.**((cra2_absvmag0-4.83)/(-2.5))
cra2_luminosity=10.**((cra2_absvmag-4.83)/(-2.5))
cra2_sigluminosity0=np.log(10.)/2.5*10.**((cra2_absvmag0-4.83)/(-2.5))*cra2_sigabsvmag0
cra2_mrhalf0=1./0.0043*cra2_rhalf0*cra2_vdisp0**2
cra2_mrhalf=1./0.0043*cra2_rhalf*cra2vdisp**2
cra2_sigmrhalf0=np.sqrt(2.*cra2_rhalf0/0.0043*cra2_vdisp0*(cra2_sigvdisp0**2)+((1./0.0043*(cra2_vdisp0**2))**2)*cra2_sigrhalf0**2)
cra2_mlratio=cra2_mrhalf/(cra2_luminosity)
cra2_mlratio0=cra2_mrhalf0/cra2_luminosity0
cra2_sigmlratio0=np.sqrt((cra2_sigmrhalf0**2)/(cra2_luminosity0**2)+((cra2_mrhalf0/cra2_luminosity0**2)**2)*cra2_sigluminosity0**2)
cra2_logupsilonstar=np.random.normal(loc=0,scale=0.25,size=np.size(cra2_mrhalf))
cra2_upsilonstar=10.**cra2_logupsilonstar
cra2_gbar=g*cra2_upsilonstar*cra2_luminosity/(2.**1.5)/cra2_rhalf**2*(1000.**2)/3.09e+16
cra2_gobs=5.*cra2_vdisp**2/2./cra2_rhalf*(1000.**2)/3.09e+16
cra2_loggbar=np.log10(cra2_gbar)
cra2_loggobs=np.log10(cra2_gobs)
cra2_deltaloggobs=cra2_loggobs-np.log10(cra2_gbar/(1.-np.exp(-np.sqrt(cra2_gbar/gdagger))))

#with open('/physics2/mgwalker/chains/cra2jeanscountsnfw.profiles') as f: # read data file
#    data=f.readlines()
#cra2nfw_rad=[]
#cra2nfw_radpc=[]
#cra2nfw_gbar=[]
#cra2nfw_gbarlo1=[]
#cra2nfw_gbarlo2=[]
#cra2nfw_gbarhi1=[]
#cra2nfw_gbarhi2=[]
#cra2nfw_gobs=[]
#cra2nfw_gobslo1=[]
#cra2nfw_gobslo2=[]
#cra2nfw_gobshi1=[]
#cra2nfw_gobshi2=[]
#for line in data: # fill arrays
#    p=line.split()
#    cra2nfw_rad.append(float(p[0]))
#    cra2nfw_radpc.append(float(p[1]))
#    cra2nfw_gbar.append(float(p[77]))
#    cra2nfw_gbarlo1.append(float(p[78]))
#    cra2nfw_gbarlo2.append(float(p[80]))
#    cra2nfw_gbarhi1.append(float(p[79]))
#    cra2nfw_gbarhi2.append(float(p[81]))
#    cra2nfw_gobs.append(float(p[82]))
#    cra2nfw_gobslo1.append(float(p[83]))
#    cra2nfw_gobslo2.append(float(p[85]))
#    cra2nfw_gobshi1.append(float(p[84]))
#    cra2nfw_gobshi2.append(float(p[86]))
#cra2nfw_rad=np.array(cra2nfw_rad)
#cra2nfw_radpc=np.array(cra2nfw_radpc)
#cra2nfw_gbar=np.array(cra2nfw_gbar)*(1000.**2)/3.09e+16
#cra2nfw_gbarlo1=np.array(cra2nfw_gbarlo1)*(1000.**2)/3.09e+16
#cra2nfw_gbarlo2=np.array(cra2nfw_gbarlo2)*(1000.**2)/3.09e+16
#cra2nfw_gbarhi1=np.array(cra2nfw_gbarhi1)*(1000.**2)/3.09e+16
#cra2nfw_gbarhi2=np.array(cra2nfw_gbarhi2)*(1000.**2)/3.09e+16
#cra2nfw_gobs=np.array(cra2nfw_gobs)*(1000.**2)/3.09e+16
#cra2nfw_gobslo1=np.array(cra2nfw_gobslo1)*(1000.**2)/3.09e+16
#cra2nfw_gobslo2=np.array(cra2nfw_gobslo2)*(1000.**2)/3.09e+16
#cra2nfw_gobshi1=np.array(cra2nfw_gobshi1)*(1000.**2)/3.09e+16
#cra2nfw_gobshi2=np.array(cra2nfw_gobshi2)*(1000.**2)/3.09e+16

notrust=[1,15,17,18,13,2]
trust=[0,16,11,14,12,23,22,9,10,21]
mwkeep=np.where((parent=='MW')&(siggobs<gobs))
m31keep=np.where((parent=='M31')&(siggobs<gobs))
restkeep=np.where((parent=='Rest')&(siggobs<gobs))
lelli_mw=np.where(lelli_parent=='MW')
lelli_m31=np.where(lelli_parent=='M31')
lelli_mwkeep=np.where((lelli_parent=='MW')&(lelli_siggobs/lelli_gobs<0.5))
lelli_m31keep=np.where((lelli_parent=='M31')&(lelli_siggobs/lelli_gobs<0.5))
#lelli_mwkeep=np.where((lelli_parent=='MW')&(lelli_rhalf > 100.))
#lelli_m31keep=np.where((lelli_parent=='M31')&(lelli_rhalf > 100.))

alpha_cusp_rhalf1=1.49
beta_cusp_rhalf1=0.35
alpha_cusp_rhalf2=1.22
beta_cusp_rhalf2=0.33
alpha_core_rhalf1=2.91
beta_core_rhalf1=0.15
alpha_core_rhalf2=1.63
beta_core_rhalf2=0.03

alpha_cusp_sigma1=-0.88
beta_cusp_sigma1=0.24
alpha_cusp_sigma2=-0.68
beta_cusp_sigma2=0.26
alpha_core_sigma1=-2.56
beta_core_sigma1=0.05
alpha_core_sigma2=-1.39
beta_core_sigma2=0.29

alpha_cusp_mstar1=3.43
beta_cusp_mstar1=1.86
alpha_cusp_mstar2=3.57
beta_cusp_mstar2=2.06
alpha_core_mstar1=1.43
beta_core_mstar1=0.69
alpha_core_mstar2=0.82
beta_core_mstar2=0.82

dra=np.where(lelli_dsph=='Draco')
x0=np.median(cra2_gbar)
y0=np.median(cra2_gobs)
#x0=lelli_gbar[dra]
#y0=lelli_gobs[dra]

def alphabetagamma_lweightedvdisp(x,params):
    pi=params[1]
    g=params[2]
    rslight=params[14]
    rshalo=params[34]
    mscale=params[35]
    xvirialhalo=params[51]

    bigs=x*rslight/rshalo
    params[99]=bigs

    vdisp2=0.
    if(bigs>=xvirialhalo):
        vdisp2=0.
    if((bigs+1.)>=xvirialhalo):
        min0=bigs
        max0=xvirialhalo
        val0=integrate.quad(alphabetagamma_jeans,min0,max0,args=(params))
        vdisp2=2.*g*mscale*(val0[0])#=sigma^2(X)*Sigma(X)/nu0
    if((bigs+1.)<xvirialhalo):
        min0=bigs
        max0=bigs+1.
        val0=integrate.quad(alphabetagamma_jeans,min0,max0,args=(params))
        vdisp2=2.*g*mscale*(val0[0])#=sigma^2(X)*Sigma(X)/nu0
    alphabetagamma_lweightedvdisp=vdisp2*x#=sigma^2*Sigma(X)*X/nu0
    return alphabetagamma_lweightedvdisp

def justin_lweightedvdisp(x,params):
    pi=params[1]
    g=params[2]
    rslight=params[14]
    rshalo=params[34]
    mscale=params[35]
    xvirialhalo=params[51]

    bigs=x*rslight/rshalo
    params[99]=bigs

    vdisp2=0.
    if(bigs>=xvirialhalo):
        vdisp2=0.
    if((bigs+1.)>=xvirialhalo):
        min0=bigs
        max0=xvirialhalo
        val0=integrate.quad(justin_jeans,min0,max0,args=(params))
        vdisp2=2.*g*mscale*(val0[0])#=sigma^2(X)*Sigma(X)/nu0
    if((bigs+1.)<xvirialhalo):
        min0=bigs
        max0=bigs+1.
        val0=integrate.quad(justin_jeans,min0,max0,args=(params))
        vdisp2=2.*g*mscale*(val0[0])#=sigma^2(X)*Sigma(X)/nu0
    justin_lweightedvdisp=vdisp2*x#=sigma^2*Sigma(X)*X/nu0
    return justin_lweightedvdisp

def alphabetagamma_jeans(x,params):
    pi=params[1]
    alphalight=params[11]
    betalight=params[12]
    gammalight=params[13]
    rslight=params[14]
    nu0=params[15]
    nscale=params[16]
    lscale=params[17]
    alphahalo=params[31]
    betahalo=params[32]
    gammahalo=params[33]
    rshalo=params[34]
    mscalehalo=params[35]
    rhomin=params[36]
    bigs=params[99]
    mlstar=params[43]
    
    r=x*rshalo/rslight
    stellarnu=1./(r**gammalight)/(1.+r**alphalight)**((betalight-gammalight)/alphalight)#nu1(r)/nu1(0)
    
    darkmass=alphabetagamma_enclosed(x,alphahalo,betahalo,gammahalo)
    nstars=alphabetagamma_enclosed(r,alphalight,betalight,gammalight)
    totalmass=darkmass+mlstar/mscalehalo*(nstars*lscale)
    u=x/bigs
    kernel=np.sqrt(1.-1./u**2)
    alphabetagamma_jeans=kernel*stellarnu*totalmass/x
    return alphabetagamma_jeans

def justin_jeans(x,params):
    pi=params[1]
    alphalight=params[11]
    betalight=params[12]
    gammalight=params[13]
    rslight=params[14]
    nu0=params[15]
    nscale=params[16]
    lscale=params[17]
#    alphahalo=params[31]
#    betahalo=params[32]
#    gammahalo=params[33]
    rshalo=params[34]
    mscalehalo=params[35]
    rhomin=params[36]
    bigs=params[99]
    mlstar=params[43]
    rcore=params[99]
    
    r=x*rshalo/rslight
    stellarnu=1./(r**gammalight)/(1.+r**alphalight)**((betalight-gammalight)/alphalight)#nu1(r)/nu1(0)
    
    darkmass=justin_enclosed(x,rshalo,rcore)
    nstars=alphabetagamma_enclosed(r,alphalight,betalight,gammalight)
    totalmass=darkmass+mlstar/mscalehalo*(nstars*lscale)
    u=x/bigs
    kernel=np.sqrt(1.-1./u**2)
    justin_jeans=kernel*stellarnu*totalmass/x
    return justin_jeans

def alphabetagamma_enclosed(x,alpha,beta,gamma):
    a=(3.-gamma)/alpha
    b=(beta-gamma)/alpha
    c=(3.-gamma+alpha)/alpha
    z1=-x**alpha
    z2=-1.
    hf1=special.hyp2f1(a,b,c,z1)
    hf2=special.hyp2f1(a,b,c,z2)
    alphabetagamma_enclosed=(x**(3.-gamma))*hf1/hf2
    return alphabetagamma_enclosed

def justin_enclosed(x,rs,rc):
    justin_enclosed=(np.log(1.+x)-x/(1.+x))/(np.log(2.)-0.5)*np.tanh(x*rs/rc)/np.tanh(rs/rc)
    return justin_enclosed

def findmassratio(x,stellarmassratio,alpha,beta):
    val=stellarmassratio-(2.**alpha)*(x**beta)/(1.+x)**alpha
    return val

stellarmassratio=np.array([0.,1.,2.,3.])
stellarmassratio=1./10.**stellarmassratio
cusp_massratio1=np.zeros(len(stellarmassratio))
cusp_massratio2=np.zeros(len(stellarmassratio))
core_massratio1=np.zeros(len(stellarmassratio))
core_massratio2=np.zeros(len(stellarmassratio))
cusp_stellarmassratio1=stellarmassratio
cusp_stellarmassratio2=stellarmassratio
core_stellarmassratio1=stellarmassratio
core_stellarmassratio2=stellarmassratio


low=1.e-10
high=1.
for i in range(0,len(stellarmassratio)):
    cusp_massratio1[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_cusp_mstar1,beta_cusp_mstar1),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
    cusp_massratio2[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_cusp_mstar2,beta_cusp_mstar2),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
    core_massratio1[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_core_mstar1,beta_core_mstar1),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)
    core_massratio2[i]=optimize.brentq(findmassratio,low,high,args=(stellarmassratio[i],alpha_core_mstar2,beta_core_mstar2),xtol=1.e-12,rtol=1.e-6,maxiter=100,full_output=False,disp=True)

###uncomment these lines to examine change in HALO mass.  otherwise, if commented, examine change in STELLAR mass
cusp_massratio1=stellarmassratio#
cusp_massratio2=stellarmassratio#
core_massratio1=stellarmassratio#
core_massratio2=stellarmassratio#
cusp_stellarmassratio1=(2.**alpha_cusp_mstar1)*(cusp_massratio1**beta_cusp_mstar1)/(1.+cusp_massratio1)**alpha_cusp_mstar1#
cusp_stellarmassratio2=(2.**alpha_cusp_mstar2)*(cusp_massratio2**beta_cusp_mstar2)/(1.+cusp_massratio2)**alpha_cusp_mstar2#
core_stellarmassratio1=(2.**alpha_core_mstar1)*(core_massratio1**beta_core_mstar1)/(1.+core_massratio1)**alpha_core_mstar1#
core_stellarmassratio2=(2.**alpha_core_mstar2)*(core_massratio2**beta_core_mstar2)/(1.+core_massratio2)**alpha_core_mstar2#
#####

cusp_rhalfratio1=(2.**alpha_cusp_rhalf1)*(cusp_massratio1**beta_cusp_rhalf1)/(1.+cusp_massratio1)**alpha_cusp_rhalf1
cusp_sigmaratio1=(2.**alpha_cusp_sigma1)*(cusp_massratio1**beta_cusp_sigma1)/(1.+cusp_massratio1)**alpha_cusp_sigma1
cusp_gbarratio1=cusp_stellarmassratio1/cusp_rhalfratio1**2
cusp_gobsratio1=cusp_massratio1/cusp_rhalfratio1**2
cusp_rhalfratio2=(2.**alpha_cusp_rhalf2)*(cusp_massratio2**beta_cusp_rhalf2)/(1.+cusp_massratio2)**alpha_cusp_rhalf2
cusp_sigmaratio2=(2.**alpha_cusp_sigma2)*(cusp_massratio2**beta_cusp_sigma2)/(1.+cusp_massratio2)**alpha_cusp_sigma2
cusp_gbarratio2=cusp_stellarmassratio2/cusp_rhalfratio2**2
cusp_gobsratio2=cusp_massratio2/cusp_rhalfratio2**2
core_rhalfratio1=(2.**alpha_core_rhalf1)*(core_massratio1**beta_core_rhalf1)/(1.+core_massratio1)**alpha_core_rhalf1
core_sigmaratio1=(2.**alpha_core_sigma1)*(core_massratio1**beta_core_sigma1)/(1.+core_massratio1)**alpha_core_sigma1
core_gbarratio1=core_stellarmassratio1/core_rhalfratio1**2
core_gobsratio1=core_massratio1/core_rhalfratio1**2
core_rhalfratio2=(2.**alpha_core_rhalf2)*(core_massratio2**beta_core_rhalf2)/(1.+core_massratio2)**alpha_core_rhalf2
core_sigmaratio2=(2.**alpha_core_sigma2)*(core_massratio2**beta_core_sigma2)/(1.+core_massratio2)**alpha_core_sigma2
core_gbarratio2=core_stellarmassratio2/core_rhalfratio2**2
core_gobsratio2=core_massratio2/core_rhalfratio2**2

#initial conditions for progenitor
cusp1_gbar0=np.median(cra2_gbar)/cusp_gbarratio1
cusp1_gobs0=np.median(cra2_gobs)/cusp_gobsratio1
cusp2_gbar0=np.median(cra2_gbar)/cusp_gbarratio2
cusp2_gobs0=np.median(cra2_gobs)/cusp_gobsratio2
core1_gbar0=np.median(cra2_gbar)/core_gbarratio1
core1_gobs0=np.median(cra2_gobs)/core_gobsratio1
core2_gbar0=np.median(cra2_gbar)/core_gbarratio2
core2_gobs0=np.median(cra2_gobs)/core_gobsratio2

cusp1_stellarmass0=np.median(cra2_luminosity*upsilonstar)/cusp_stellarmassratio1
cusp1_rhalf0=np.median(cra2_rhalf)/cusp_rhalfratio1
cusp2_stellarmass0=np.median(cra2_luminosity*upsilonstar)/cusp_stellarmassratio2
cusp2_rhalf0=np.median(cra2_rhalf)/cusp_rhalfratio2
core1_stellarmass0=np.median(cra2_luminosity*upsilonstar)/core_stellarmassratio1
core1_rhalf0=np.median(cra2_rhalf)/core_rhalfratio1
core2_stellarmass0=np.median(cra2_luminosity*upsilonstar)/core_stellarmassratio2
core2_rhalf0=np.median(cra2_rhalf)/core_rhalfratio2
cusp1_sigma0=np.median(cra2_vdisp)/cusp_sigmaratio1
cusp2_sigma0=np.median(cra2_vdisp)/cusp_sigmaratio2
core1_sigma0=np.median(cra2_vdisp)/core_sigmaratio1
core2_sigma0=np.median(cra2_vdisp)/core_sigmaratio2

#cusp1_gbar0=gbar[dsph=='sgr']/cusp_gbarratio1
#cusp1_gobs0=gobs[dsph=='sgr']/cusp_gobsratio1
#cusp2_gbar0=gbar[dsph=='sgr']/cusp_gbarratio2
#cusp2_gobs0=gobs[dsph=='sgr']/cusp_gobsratio2
#core1_gbar0=gbar[dsph=='sgr']/core_gbarratio1
#core1_gobs0=gobs[dsph=='sgr']/core_gobsratio1
#core2_gbar0=gbar[dsph=='sgr']/core_gbarratio2
#core2_gobs0=gobs[dsph=='sgr']/core_gobsratio2

for i in range(0,len(cusp1_gbar0)):
    x=np.linspace(1.,cusp_massratio1[i],100)
    cusp_rhalf1=2.**alpha_cusp_rhalf1*x**beta_cusp_rhalf1/(1.+x)**alpha_cusp_rhalf1
    cusp_mstar1=2.**alpha_cusp_mstar1*x**beta_cusp_mstar1/(1.+x)**alpha_cusp_mstar1
    cusp_sigma1=2.**alpha_cusp_sigma1*x**beta_cusp_sigma1/(1.+x)**alpha_cusp_sigma1
    cusp_gbar1=cusp1_gbar0[i]*cusp_mstar1/cusp_rhalf1**2
    cusp_gobs1=cusp1_gobs0[i]*x/cusp_rhalf1**2
#    axgobsgbar.plot(np.log10(cusp_gbar1),np.log10(cusp_gobs1),color='b',lw=0.5)
for i in range(0,len(cusp2_gbar0)):
    x=np.linspace(1.,cusp_massratio2[i],100)
    cusp_rhalf2=2.**alpha_cusp_rhalf2*x**beta_cusp_rhalf2/(1.+x)**alpha_cusp_rhalf2
    cusp_mstar2=2.**alpha_cusp_mstar2*x**beta_cusp_mstar2/(1.+x)**alpha_cusp_mstar2
    cusp_sigma2=2.**alpha_cusp_sigma2*x**beta_cusp_sigma2/(1.+x)**alpha_cusp_sigma2
    cusp_gbar2=cusp2_gbar0[i]*cusp_mstar2/cusp_rhalf2**2
    cusp_gobs2=cusp2_gobs0[i]*x/cusp_rhalf2**2
for i in range(0,len(core1_gbar0)):
    x=np.linspace(1.,core_massratio1[i],100)
    core_rhalf1=2.**alpha_core_rhalf1*x**beta_core_rhalf1/(1.+x)**alpha_core_rhalf1
    core_mstar1=2.**alpha_core_mstar1*x**beta_core_mstar1/(1.+x)**alpha_core_mstar1
    core_sigma1=2.**alpha_core_sigma1*x**beta_core_sigma1/(1.+x)**alpha_core_sigma1
    core_gbar1=core1_gbar0[i]*core_mstar1/core_rhalf1**2
    core_gobs1=core1_gobs0[i]*x/core_rhalf1**2
for i in range(0,len(core2_gbar0)):
    x=np.linspace(1.,core_massratio2[i],100)
    core_rhalf2=2.**alpha_core_rhalf2*x**beta_core_rhalf2/(1.+x)**alpha_core_rhalf2
    core_mstar2=2.**alpha_core_mstar2*x**beta_core_mstar2/(1.+x)**alpha_core_mstar2
    core_sigma2=2.**alpha_core_sigma2*x**beta_core_sigma2/(1.+x)**alpha_core_sigma2
    core_gbar2=core2_gbar0[i]*core_mstar2/core_rhalf2**2
    core_gobs2=core2_gobs0[i]*x/core_rhalf2**2

df44_rhalf=4600.
df44_mhalf=0.71e+10
df44_mstar=1.5e+8
df44_gbar=g*df44_mstar/df44_rhalf**2*(1000.**2)/3.09e+16
df44_gobs=g*df44_mhalf/df44_rhalf**2*(1000.**2)/3.09e+16
#axgobsgbar.scatter([np.log10(df44_gbar)],[np.log10(df44_gobs)],marker='s',s=10,color='k')
#axgobsgbar.legend(loc=4,fontsize=7,handlelength=1,numpoints=1,scatterpoints=1,shadow=False,borderaxespad=0)

a_cusp=np.zeros(len(m200))
logr=np.linspace(-3.,6.,1000)
a_halo=np.zeros(len(m200))
r=10.**logr
x=1.e-2
#a_halo[0]=g*mscale[0]/(rs[0]**2)/x**2*(np.log(1.+x)-x/(1.+x))/(np.log(2.)-0.5)*(1000.**2)/3.09e+16
#a_halo[1]=g*mscale[1]/(rs[1]**2)/x**2*(np.log(1.+x)-x/(1.+x))/(np.log(2.)-0.5)*(1000.**2)/3.09e+16
v200=np.sqrt(g*m200/r200)
#a_cusp[0]=(c200[0]**2/(np.log(1.+c200[0])-c200[0]/(1.+c200[0]))*v200[0]**2/r200[0]/2.)*(1000.**2)/3.09e+16
#a_cusp[1]=(c200[1]**2/(np.log(1.+c200[1])-c200[1]/(1.+c200[1]))*v200[1]**2/r200[1]/2.)*(1000.**2)/3.09e+16
#axgobsgbar.fill_between([-17,-7],[np.log10(a_halo[0]),np.log10(a_halo[0])],[np.log10(a_halo[1]),np.log10(a_halo[1])],facecolor='0.75',rasterized=False,edgecolor='None')
#navarro_mbar0=(10.**behroozi_logmstar[0])*(1.-np.exp(-r/navarro_rd[0])*(1.+r/navarro_rd[0]))
#navarro_mbar1=(10.**behroozi_logmstar[1])*(1.-np.exp(-r/navarro_rd[1])*(1.+r/navarro_rd[1]))
navarro_mbar=10.**garrisonkimmel_logmstar
#navarro_gbar0=g*navarro_mbar0/(r**2)*(1000.**2)/3.09e+16
#navarro_gbar1=g*navarro_mbar1/(r**2)*(1000.**2)/3.09e+16
navarro_gbar=g*navarro_mbar/2.**1.5/(navarro_rh**2)*(1000.**2)/3.09e+16
#navarro_ghalo0=g*mscale[0]/(rs[0]**2)/(r/rs[0])**2*(np.log(1.+r/rs[0])-r/rs[0]/(1.+r/rs[0]))/(np.log(2.)-0.5)*(1000.**2)/3.09e+16
#navarro_ghalo1=g*mscale[1]/(rs[1]**2)/(r/rs[1])**2*(np.log(1.+r/rs[1])-r/rs[1]/(1.+r/rs[1]))/(np.log(2.)-0.5)*(1000.**2)/3.09e+16
navarro_ghalo=g*mscale/(rs**2)/(navarro_rh/rs)**2*(np.log(1.+navarro_rh/rs)-navarro_rh/rs/(1.+navarro_rh/rs))/(np.log(2.)-0.5)*(1000.**2)/3.09e+16
#navarro_gobs0=navarro_gbar0+navarro_ghalo0
#navarro_gobs1=navarro_gbar1+navarro_ghalo1
navarro_gobs=navarro_gbar+navarro_ghalo
navarro_nu0=navarro_mbar*3./4./np.pi/(navarro_rh**3)#Msun/pc^3
navarro_alpha=navarro_nu0-navarro_nu0+1.
navarro_beta=navarro_nu0-navarro_nu0+3.
navarro_gamma=navarro_nu0-navarro_nu0+1.
navarro_rs=rs
navarro_mscale=mscale
navarro_c200=c200
navarro_n=navarro_mbar
navarro_vdisp=navarro_mscale-navarro_mscale
navarro_lum=navarro_mbar/upsilonstar

dicintio_mbar=10.**garrisonkimmel_logmstar
x=np.log10(dicintio_mbar/m200)
y=np.log10(dicintio_mbar/m200)+4.5
dicintio_c200=c200*(1.0+0.00003*np.exp(3.4*y))
dicintio_alpha=2.94-np.log10((10.**(x+2.33))**(-1.08)+(10.**(x+2.33))**2.29)
dicintio_beta=4.23+1.34*x+0.26*x**2
dicintio_gamma=-0.06+np.log10((10.**(x+2.56))**(-0.68)+(10.**(x+2.56)))
for i in range(0,len(logm200_0)):
    for j in range(0,realizations):
        if(dicintio_alpha[i,j]<0.5):
            dicintio_alpha[i,j]=0.5
        if(dicintio_gamma[i,j]>1.5):
            dicintio_gamma[i,j]=1.5

dicintio_rs=r200/dicintio_c200/((2.-dicintio_gamma)/(dicintio_beta-2.))**(1./dicintio_alpha)
dicintio_r2=r200/dicintio_c200
dicintio_rh=np.zeros((len(logm200_0),realizations))
rh_dev=np.zeros((len(logm200_0),realizations))
for i in range(0,len(logm200_0)):
    rh_dev[i,:]=np.random.normal(loc=0.,scale=rh_scatter,size=realizations)
    rh_dev[i,0]=0.
    dicintio_rh[i,:]=dicintio_r2[i,:]*(10.**(-0.7+rh_dev[i,:]))
#    for j in range(0,realizations):
#        if(dicintio_rh[i,j]>dicintio_rs[i,j]):
#               dicintio_rh[i,j]=dicintio_rs[i,j]
dicintio_rd=dicintio_rh/1.678
#for i in range(0,len(dicintio_rs)):
#    if(dicintio_gamma[i]<0.5):
#        dicintio_rh[i]=dicintio_rs[i]*((2.-dicintio_gamma[i])/(dicintio_beta[i]-2.))**(1./dicintio_alpha[i])
a=(3.-dicintio_gamma)/dicintio_alpha
b=(dicintio_beta-dicintio_gamma)/dicintio_alpha
c=(3.-dicintio_gamma+dicintio_alpha)/dicintio_alpha
z1=-1.*(r200/dicintio_rs)**dicintio_alpha
z2=-1.
dicintio_m200mrs=(r200/dicintio_rs)**(3.-dicintio_gamma)*special.hyp2f1(a,b,c,z1)/special.hyp2f1(a,b,c,z2)
dicintio_mscale=m200/dicintio_m200mrs
dicintio_rhos=(3.-dicintio_gamma)*dicintio_mscale/4./np.pi/(dicintio_rs**3)/special.hyp2f1(a,b,c,z2)
dicintio_gbar=g*dicintio_mbar/2.**1.5/(dicintio_rh**2)*(1000.**2)/3.09e+16
z1=-1.*(dicintio_rh/dicintio_rs)**dicintio_alpha
dicintio_ghalo=g*dicintio_mscale/(rs**2)/(dicintio_rh/rs)**2*(dicintio_rh/dicintio_rs)**(3.-dicintio_gamma)*special.hyp2f1(a,b,c,z1)/special.hyp2f1(a,b,c,z2)*(1000.**2)/3.09e+16
dicintio_gobs=dicintio_gbar+dicintio_ghalo
dicintio_nu0=dicintio_mbar*3./4./np.pi/(dicintio_rh**3)#Msun/pc^3
dicintio_n=dicintio_mbar
dicintio_vdisp=dicintio_mscale-dicintio_mscale
dicintio_lum=dicintio_mbar/upsilonstar


justin_mbar=10.**garrisonkimmel_logmstar
justin_c200=c200
justin_rs=rs
justin_r2=justin_rs
justin_rh=np.zeros((len(logm200_0),realizations))
rh_dev=np.zeros((len(logm200_0),realizations))
for i in range(0,len(logm200_0)):
    rh_dev[i,:]=np.random.normal(loc=0.,scale=rh_scatter,size=realizations)
    rh_dev[i,0]=0.
    justin_rh[i,:]=justin_r2[i,:]*(10.**(-0.7+rh_dev[i,:]))
    for j in range(0,realizations):
        if(justin_rh[i,j]>justin_rs[i,j]):
               justin_rh[i,j]=justin_rs[i,j]

justin_rcore=1.75*justin_rh
justin_rhos=m200/4./np.pi/(justin_rs**3)/(np.log(1.+c200)-c200/(1.+c200))/np.tanh(justin_c200*justin_rs/justin_rcore)
justin_mscale=4.*np.pi*justin_rhos*(justin_rs**3)*(np.log(2.)-0.5)*np.tanh(justin_rs/justin_rcore)
justin_gbar=g*justin_mbar/2.**1.5/(justin_rh**2)*(1000.**2)/3.09e+16
justin_ghalo=g*justin_mscale/(rs**2)/(justin_rh/rs)**2*(np.log(1.+justin_rh/justin_rs)-justin_rh/justin_rs/(1.+justin_rh/justin_rs))*np.tanh(justin_rh/justin_rcore)*(1000.**2)/3.09e+16
justin_gobs=justin_gbar+justin_ghalo
justin_nu0=justin_mbar*3./4./np.pi/(justin_rh**3)#Msun/pc^3
justin_n=justin_mbar
justin_vdisp=justin_mscale-justin_mscale
justin_lum=justin_mbar/upsilonstar

#for i in range(0,len(logm200_0)):
#    for j in range(0,len(logm200[i,:])):
#        params=np.zeros(100)
#        params[1]=np.pi
#        params[2]=g
#        params[11]=2.
#        params[12]=5.
#        params[13]=0.
#        params[14]=navarro_rh[i,j]
#        params[15]=navarro_nu0[i,j]
##        params[16]=navarr_nscale[i,j]
#        params[17]=navarro_mbar[i,j]/2.**1.5
#        params[31]=navarro_alpha[i,j]
#        params[32]=navarro_beta[i,j]
#        params[33]=navarro_gamma[i,j]
#        params[34]=navarro_rs[i,j]
#        params[35]=navarro_mscale[i,j]
#        params[36]=rhomin
#        params[43]=upsilonstar
#        params[51]=navarro_c200[i,j]
#        
#        min0=0.
#        max0=1.
#        val0=integrate.quad(alphabetagamma_lweightedvdisp,min0,max0,args=(params))
#        min0=1.
#        max0=navarro_c200[i,j]
#        val2=integrate.quad(alphabetagamma_lweightedvdisp,min0,max0,args=(params))
#        navarro_vdisp[i,j]=np.sqrt((val0[0]+val2[0])*2.*np.pi*navarro_nu0[i,j]*(navarro_rh[i,j]**2)/navarro_n[i,j])
#        print 'navarro: ',i,j,navarro_vdisp[i,j],navarro_rh[i,j],navarro_rs[i,j],navarro_c200[i,j]
#
for i in range(0,len(logm200_0)):
    for j in range(0,len(logm200[i,:])):
        params=np.zeros(100)
        params[1]=np.pi
        params[2]=g
        params[11]=2.
        params[12]=5.
        params[13]=0.
        params[14]=dicintio_rh[i,j]
        params[15]=dicintio_nu0[i,j]
#        params[16]=navarr_nscale[i,j]
        params[17]=dicintio_mbar[i,j]/2.**1.5
        params[31]=dicintio_alpha[i,j]
        params[32]=dicintio_beta[i,j]
        params[33]=dicintio_gamma[i,j]
        params[34]=dicintio_rs[i,j]
        params[35]=dicintio_mscale[i,j]
        params[36]=rhomin
        params[43]=upsilonstar
        params[51]=dicintio_c200[i,j]
        
        min0=0.
        max0=1.
        val0=integrate.quad(alphabetagamma_lweightedvdisp,min0,max0,args=(params))
        min0=1.
        max0=dicintio_c200[i,j]
        val2=integrate.quad(alphabetagamma_lweightedvdisp,min0,max0,args=(params))
        dicintio_vdisp[i,j]=np.sqrt((val0[0]+val2[0])*2.*np.pi*dicintio_nu0[i,j]*(dicintio_rh[i,j]**2)/dicintio_n[i,j])
#        print 'DiCintio: ',i,j,dicintio_vdisp[i,j],dicintio_rh[i,j],dicintio_r2[i,j],dicintio_c200[i,j]

#for i in range(0,len(logm200_0)):
#    for j in range(0,len(logm200[i,:])):
#        params=np.zeros(100)
#        params[1]=np.pi
#        params[2]=g
#        params[11]=2.
#        params[12]=5.
#        params[13]=0.
#        params[14]=justin_rh[i,j]
#        params[15]=justin_nu0[i,j]
##        params[16]=navarr_nscale[i,j]
#        params[17]=justin_mbar[i,j]/2.**1.5
##        params[31]=justin_alpha[i,j]
##        params[32]=justin_beta[i,j]
##        params[33]=justin_gamma[i,j]
#        params[34]=justin_rs[i,j]
#        params[35]=justin_mscale[i,j]
#        params[36]=rhomin
#        params[43]=upsilonstar
#        params[51]=justin_c200[i,j]
#        params[99]=justin_rcore[i,j]
#
#        min0=0.
#        max0=1.
#        val0=integrate.quad(justin_lweightedvdisp,min0,max0,args=(params))
#        min0=1.
#        max0=justin_c200[i,j]
#        val2=integrate.quad(justin_lweightedvdisp,min0,max0,args=(params))
#        justin_vdisp[i,j]=np.sqrt((val0[0]+val2[0])*2.*np.pi*justin_nu0[i,j]*(justin_rh[i,j]**2)/justin_n[i,j])
#        print 'Justin: ',i,j,justin_vdisp[i,j],justin_rh[i,j],justin_r2[i,j],justin_c200[i,j]
#
navarro_gbar0=[]
navarro_gobslo=[]
navarro_gobshi=[]
dicintio_gbar0=[]
dicintio_gobslo=[]
dicintio_gobshi=[]
justin_gbar0=[]
justin_gobslo=[]
justin_gobshi=[]
for i in range(0,len(logm200_0)):
    navarro_gbar0.append(np.log10(np.percentile(navarro_gbar[i,:],50)))
    navarro_gobslo.append(np.log10(np.percentile(navarro_gobs[i,:],0.5)))
    navarro_gobshi.append(np.log10(np.percentile(navarro_gobs[i,:],99.5)))
    dicintio_gbar0.append(np.log10(np.percentile(dicintio_gbar[i,:],50)))
    dicintio_gobslo.append(np.log10(np.percentile(dicintio_gobs[i,:],0.5)))
    dicintio_gobshi.append(np.log10(np.percentile(dicintio_gobs[i,:],99.5)))
    justin_gbar0.append(np.log10(np.percentile(justin_gbar[i,:],50)))
    justin_gobslo.append(np.log10(np.percentile(justin_gobs[i,:],0.5)))
    justin_gobshi.append(np.log10(np.percentile(justin_gobs[i,:],99.5)))
navarro_gbar0=np.array(navarro_gbar0)
navarro_gobslo=np.array(navarro_gobslo)
navarro_gobshi=np.array(navarro_gobshi)
dicintio_gbar0=np.array(dicintio_gbar0)
dicintio_gobslo=np.array(dicintio_gobslo)
dicintio_gobshi=np.array(dicintio_gobshi)
justin_gbar0=np.array(justin_gbar0)
justin_gobslo=np.array(justin_gobslo)
justin_gobshi=np.array(justin_gobshi)


navarro_rh0=[]
navarro_mbarlo=[]
navarro_mbarhi=[]
navarro_vdisplo=[]
navarro_vdisphi=[]
dicintio_rh0=[]
dicintio_mbarlo=[]
dicintio_mbarhi=[]
dicintio_vdisplo=[]
dicintio_vdisphi=[]
justin_rh0=[]
justin_mbarlo=[]
justin_mbarhi=[]
justin_vdisplo=[]
justin_vdisphi=[]
for i in range(0,len(logm200_0)):
    navarro_rh0.append(np.log10(np.percentile(navarro_rh[i,:],50)))
    navarro_mbarlo.append(np.log10(np.percentile(navarro_mbar[i,:],0.5)))
    navarro_mbarhi.append(np.log10(np.percentile(navarro_mbar[i,:],99.5)))
    navarro_vdisplo.append(np.log10(np.percentile(navarro_vdisp[i,:],0.5)))
    navarro_vdisphi.append(np.log10(np.percentile(navarro_vdisp[i,:],99.5)))
    dicintio_rh0.append(np.log10(np.percentile(dicintio_rh[i,:],50)))
    dicintio_mbarlo.append(np.log10(np.percentile(dicintio_mbar[i,:],0.5)))
    dicintio_mbarhi.append(np.log10(np.percentile(dicintio_mbar[i,:],99.5)))
    dicintio_vdisplo.append(np.log10(np.percentile(dicintio_vdisp[i,:],0.5)))
    dicintio_vdisphi.append(np.log10(np.percentile(dicintio_vdisp[i,:],99.5)))
    justin_rh0.append(np.log10(np.percentile(justin_rh[i,:],50)))
    justin_mbarlo.append(np.log10(np.percentile(justin_mbar[i,:],0.5)))
    justin_mbarhi.append(np.log10(np.percentile(justin_mbar[i,:],99.5)))
    justin_vdisplo.append(np.log10(np.percentile(justin_vdisp[i,:],0.5)))
    justin_vdisphi.append(np.log10(np.percentile(justin_vdisp[i,:],99.5)))
navarro_rh0=np.array(navarro_rh0)
navarro_mbarlo=np.array(navarro_mbarlo)
navarro_mbarhi=np.array(navarro_mbarhi)
dicintio_rh0=np.array(dicintio_rh0)
dicintio_mbarlo=np.array(dicintio_mbarlo)
dicintio_mbarhi=np.array(dicintio_mbarhi)
justin_rh0=np.array(justin_rh0)
justin_mbarlo=np.array(justin_mbarlo)
justin_mbarhi=np.array(justin_mbarhi)


for i in range(0,len(m200)):
    for j in range(0,realizations):
        string=str(round(smhm_scatter,5))+' '+str(round(np.log10(m200[i,j]),5))+' '+str(round(np.log10(dicintio_rh[i,j]),5))+' '+str(round(np.log10(dicintio_lum[i,j]),5))+' '+str(round(np.log10(dicintio_vdisp[i,j]),5))+' '+str(round(np.log10(dicintio_gbar[i,j]),5))+' '+str(round(np.log10(dicintio_gobs[i,j]),5))+' \n'
        
        g1.write(str(round(smhm_scatter,5))+' '+str(round(np.log10(m200[i,j]),5))+' '+str(round(np.log10(dicintio_rh[i,j]),5))+' '+str(round(np.log10(dicintio_lum[i,j]),5))+' '+str(round(np.log10(dicintio_vdisp[i,j]),5))+' '+str(round(np.log10(dicintio_gbar[i,j]),5))+' '+str(round(np.log10(dicintio_gobs[i,j]),5))+' \n')
g1.close()

#plotfilename='cra2_gobsgbar_tracks2.pdf'
#plt.savefig(plotfilename,dpi=400)
#plt.show()
#plt.close()
