#!/usr/bin/python
import numpy as np
import matplotlib
from astropy import units as u
from astropy.coordinates import SkyCoord,Distance,ICRS
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

#racenter=177.310
#deccenter=-18.413

racenter=(5.+27.6/60.)*15.*np.pi/180.
deccenter=(-69.87)*np.pi/180.

coords=SkyCoord(racenter,deccenter,unit=['rad','rad'])
lcenter=coords.galactic.l.radian
bcenter=coords.galactic.b.radian

alpha0=np.linspace(racenter-0.000001,racenter+0.000001,1000)
dalpha0=alpha0[1]-alpha0[0]
coords=SkyCoord(alpha0,np.zeros(len(alpha0))+deccenter,unit=['rad','rad'])
l0=coords.galactic.l.radian
b0=coords.galactic.b.radian
dldalpha=(np.gradient(l0,dalpha0))[499]
dbdalpha=(np.gradient(b0,dalpha0))[499]

delta0=np.linspace(deccenter-0.000001,deccenter+0.000001,1000)
ddelta=delta0[1]-delta0[0]
coords=SkyCoord(np.zeros(len(delta0))+racenter,delta0,unit=['rad','rad'])
l0=coords.galactic.l.radian
b0=coords.galactic.b.radian
dlddelta=(np.gradient(l0,ddelta))[499]
dbddelta=(np.gradient(b0,ddelta))[499]

u1=np.array([np.cos(bcenter)*np.cos(lcenter),np.cos(bcenter)*np.sin(lcenter),np.sin(bcenter)])
u2=np.array([-np.sin(bcenter)*np.cos(lcenter)*dbdalpha-np.cos(bcenter)*np.sin(lcenter)*dldalpha,-np.sin(bcenter)*np.sin(lcenter)*dbdalpha+np.cos(bcenter)*np.cos(lcenter)*dldalpha,np.cos(bcenter)*dbdalpha])
u2=-u2/np.cos(deccenter)#-cos(dec) correction
u3=np.array([-np.sin(bcenter)*np.cos(lcenter)*dbddelta-np.cos(bcenter)*np.sin(lcenter)*dlddelta,-np.sin(bcenter)*np.sin(lcenter)*dbddelta+np.cos(bcenter)*np.cos(lcenter)*dlddelta,np.cos(bcenter)*dbddelta])

#mualpha=#mas/yr
#mudelta=#mas/yr
distance=50.1#kpc
muwest=-1.68#-mualpha*np.cos(deccenter*np.pi/180.) (mas/yr)
munorth=0.34#mudelta (mas/yr)
vsys=262.2#HRF LOS velocity in km/s
vx=distance*muwest*3.09e+16/1000./3600./180.*np.pi/365./24./3600.#km/s
vy=distance*munorth*3.09e+16/1000./3600./180.*np.pi/365./24./3600.#km/s
r0=8.5#kpc
rsolar=np.array([-r0,0,0],dtype=float)
vsolar=np.array([10.,5.2+220.,7.2])
rlmc=rsolar+distance*u1
vlmc=vsolar+vsys*u1+vx*u2+vy*u3
rlmc_mag=np.sqrt(rlmc[0]**2+rlmc[1]**2+rlmc[2]**2)
vlmc_mag=np.sqrt(vlmc[0]**2+vlmc[1]**2+vlmc[2]**2)
vlmc_rad=np.dot(vlmc,rlmc/rlmc_mag)
vlmc_tan=np.sqrt(vlmc_mag**2-vlmc_rad**2)
print 'u1=',u1
print 'u2=',u2
print 'u3=',u3
print 'vx=',vx
print 'vy=',vy
print 'v=',vlmc
print '|r|=',rlmc_mag
print '|v|=',vlmc_mag
print 'v_rad=',vlmc_rad
print 'v_tan=',vlmc_tan

