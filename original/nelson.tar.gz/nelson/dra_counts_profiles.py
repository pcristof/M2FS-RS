import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='True')
plt.rc('legend',framealpha=0.5)
plt.rc('legend',borderpad=1)
plt.rc('legend',borderaxespad=1)
plt.rc('legend',scatterpoints=1)
plt.rc('legend',numpoints=1)
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('xtick.minor',size=2)
plt.rc('ytick.minor',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick.minor',width=0.5)
plt.rc('ytick.minor',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='6')
plt.rc('ytick',labelsize='6')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

g=0.0043# grav constant in galaxy units        
    
with open('/physics2/mgwalker/chains/dra_counts.profiles') as f: # read data file
    data=f.readlines()
dracounts_rad=[]
dracounts_radpc=[]
dracounts_mstacy=[]
dracounts_mstacylo1=[]
dracounts_mstacylo2=[]
dracounts_mstacyhi1=[]
dracounts_mstacyhi2=[]
dracounts_rhostacy=[]
dracounts_rhostacylo1=[]
dracounts_rhostacylo2=[]
dracounts_rhostacyhi1=[]
dracounts_rhostacyhi2=[]
dracounts_slopestacy=[]
dracounts_slopestacylo1=[]
dracounts_slopestacylo2=[]
dracounts_slopestacyhi1=[]
dracounts_slopestacyhi2=[]
dracounts_slopestellarmass=[]
dracounts_slopestellarmasslo1=[]
dracounts_slopestellarmasslo2=[]
dracounts_slopestellarmasshi1=[]
dracounts_slopestellarmasshi2=[]

for line in data: # fill arrays
    p=line.split()
    dracounts_rad.append(float(p[0]))
    dracounts_radpc.append(float(p[1]))
    dracounts_mstacy.append(float(p[27]))
    dracounts_mstacylo1.append(float(p[28]))
    dracounts_mstacylo2.append(float(p[30]))
    dracounts_mstacyhi1.append(float(p[29]))
    dracounts_mstacyhi2.append(float(p[31]))
    dracounts_rhostacy.append(float(p[32]))
    dracounts_rhostacylo1.append(float(p[33]))
    dracounts_rhostacylo2.append(float(p[35]))
    dracounts_rhostacyhi1.append(float(p[34]))
    dracounts_rhostacyhi2.append(float(p[36]))
    dracounts_slopestacy.append(float(p[37]))
    dracounts_slopestacylo1.append(float(p[38]))
    dracounts_slopestacylo2.append(float(p[40]))
    dracounts_slopestacyhi1.append(float(p[39]))
    dracounts_slopestacyhi2.append(float(p[41]))
    dracounts_slopestellarmass.append(float(p[42]))
    dracounts_slopestellarmasslo1.append(float(p[43]))
    dracounts_slopestellarmasslo2.append(float(p[45]))
    dracounts_slopestellarmasshi1.append(float(p[44]))
    dracounts_slopestellarmasshi2.append(float(p[46]))

dracounts_rad=np.array(dracounts_rad)
dracounts_radpc=np.array(dracounts_radpc)
dracounts_mstacy=np.array(dracounts_mstacy)
dracounts_mstacylo1=np.array(dracounts_mstacylo1)
dracounts_mstacylo2=np.array(dracounts_mstacylo2)
dracounts_mstacyhi1=np.array(dracounts_mstacyhi1)
dracounts_mstacyhi2=np.array(dracounts_mstacyhi2)
dracounts_rhostacy=np.array(dracounts_rhostacy)
dracounts_rhostacylo1=np.array(dracounts_rhostacylo1)
dracounts_rhostacylo2=np.array(dracounts_rhostacylo2)
dracounts_rhostacyhi1=np.array(dracounts_rhostacyhi1)
dracounts_rhostacyhi2=np.array(dracounts_rhostacyhi2)
dracounts_slopestacy=np.array(dracounts_slopestacy)
dracounts_slopestacylo1=np.array(dracounts_slopestacylo1)
dracounts_slopestacylo2=np.array(dracounts_slopestacylo2)
dracounts_slopestacyhi1=np.array(dracounts_slopestacyhi1)
dracounts_slopestacyhi2=np.array(dracounts_slopestacyhi2)
dracounts_slopestellarmass=np.array(dracounts_slopestellarmass)
dracounts_slopestellarmasslo1=np.array(dracounts_slopestellarmasslo1)
dracounts_slopestellarmasslo2=np.array(dracounts_slopestellarmasslo2)
dracounts_slopestellarmasshi1=np.array(dracounts_slopestellarmasshi1)
dracounts_slopestellarmasshi2=np.array(dracounts_slopestellarmasshi2)

gs=plt.GridSpec(20,20) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size

ax3_0=fig.add_subplot(gs[0:5,0:8])
ax1_0=fig.add_subplot(gs[5:10,0:8])
ax2_0=fig.add_subplot(gs[10:15,0:8])
#ax0_0=fig.add_subplot(gs[10:15,0:8])
ax0_1=fig.add_subplot(gs[15:20,12:20])
#ax3=fig.add_subplot(gs[15:20,4:10])

#ax0_1.xaxis.set_major_formatter(plt.NullFormatter())
ax0_1.set_ylabel(r'$\sigma_{v_{los}}$ [km/s]',fontsize=10,rotation=90)
ax0_1.set_xlabel(r'$R$ [arcmin]',fontsize=10,rotation=0,labelpad=5)
ax0_1.set_xlim([1,500])
ax0_1.set_ylim([0,9])
ax0_1.set_xscale(u'log')
ax0_1.set_yscale(u'linear')
#ax0_1.set_yticks([1,10,100])
#ax0_1.set_yticklabels([1,10,100],fontsize=10)
#ax0_1.scatter(np.median(cra2_rhalf0),np.median(cra2_vdisp0),s=10,lw=0,edgecolor='none',alpha=0.69,marker='s',color='b',rasterized=True,label='Cra 2')
#ax0_1.fill_between(cra2rho_rad,cra2rho_vdisplo2,cra2rho_vdisphi2,facecolor=(0.5,0.0,1.0),alpha=0.6,rasterized=False,edgecolor='None')
ax0_1.fill_between(cra2rho_rad,cra2rho_vdisplo2,cra2rho_vdisphi2,facecolor='indigo',alpha=0.85,rasterized=False,edgecolor='None')
ax0_1.fill_between(cra2rholight_rad,cra2rholight_vdisplo2,cra2rholight_vdisphi2,facecolor='darkred',alpha=0.6,rasterized=False,edgecolor='None')
ax0_1.errorbar(r,vdisp,xerr=sigr,yerr=sigvdisp,elinewidth=0.75,fmt='o',capsize=0,alpha=1,color='k',rasterized=False)
#ax0_1.errorbar(light_r,light_vdisp,xerr=light_sigr,yerr=light_sigvdisp,elinewidth=0.25,fmt='o',capsize=0,alpha=1,color='r',rasterized=True)
ax0_1.text(1.5,7.5,'Crater 2',fontsize=7,color='k')
#ax0_1.fill_between(cra2rho_rad,cra2rho_vdisplo2,cra2rho_vdisphi2,facecolor='0.6',alpha=0.5,rasterized=False,edgecolor='None')
#ax0_1.plot(cra2rho_rad,cra2rho_vdisp,lw=0.5,color='k')
ax0_1.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='indigo',label='DM+stars',alpha=0.7)
ax0_1.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars only')
ax0_1.legend(loc=1,fontsize=6,handlelength=1,numpoints=1,scatterpoints=1,shadow=False)
axtop=ax0_1.twiny()
shite=ax0_1.get_xlim()
distance=117000.
shite2=[]
shite2.append(shite[0])
shite2.append(shite[1])
shite2=np.array(shite2)
shite3=distance*np.tan(shite2/60.*np.pi/180.)
axtop.set_xlim(shite3)
axtop.set_xscale(u'log')
axtop.set_xlabel(r'$R$ [pc]',fontsize=10,rotation=0,labelpad=7)
#ax1_0.xaxis.set_major_formatter(plt.NullFormatter())

ax3_0.xaxis.set_major_formatter(plt.NullFormatter())
ax3_0.set_ylabel(r'd$\log M_{\rm enclosed}$/d$\log r$',fontsize=10,rotation=90)
#ax2_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
#ax3_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
ax3_0.set_xlim([10,10000])
ax3_0.set_ylim([0.01,3])
ax3_0.set_xscale(u'log')
ax3_0.set_yscale(u'linear')
#ax3_0.set_yticks([1,10,100])
#ax3_0.set_yticklabels([1,10,100],fontsize=10)
#ax3_0.scatter(np.median(cra2_rhalf0),np.median(cra2_vdisp0),s=10,lw=0,edgecolor='none',alpha=0.69,marker='s',color='b',rasterized=True,label='Cra 2')
ax3_0.fill_between(cra2rho_radpc,cra2rho_slopedmlo2,cra2rho_slopedmhi2,facecolor='navy',alpha=0.6,rasterized=False,edgecolor='None')
ax3_0.fill_between(cra2counts_radpc,cra2counts_slopestellarmasslo2,cra2counts_slopestellarmasshi2,facecolor='darkred',alpha=0.6,rasterized=False,edgecolor='None')
ax3_0.fill_between(cra2counts_radpc,cra2counts_slopestacylo2,cra2counts_slopestacyhi2,facecolor='g',alpha=0.6,rasterized=False,edgecolor='None')
#ax3_0.text(1000,2.7,'Crater 2',fontsize=7,color='k')
#ax3_0.plot(cra2rho_radpc,cra2rho_rho,lw=0.5,color='k')
ax3_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='navy',label='dark matter')
ax3_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars')
ax3_0.xaxis.set_major_formatter(plt.NullFormatter())

ax1_0.xaxis.set_major_formatter(plt.NullFormatter())
ax1_0.set_ylabel(r'$\rho$ [M$_{\odot}$/pc$^3$]',fontsize=10,rotation=90)
#ax2_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
#ax1_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
ax1_0.set_xlim([10,10000])
ax1_0.set_ylim([0.00000005,0.099])
ax1_0.set_xscale(u'log')
ax1_0.set_yscale(u'log')
#ax1_0.set_yticks([1,10,100])
#ax1_0.set_yticklabels([1,10,100],fontsize=10)
#ax1_0.scatter(np.median(cra2_rhalf0),np.median(cra2_vdisp0),s=10,lw=0,edgecolor='none',alpha=0.69,marker='s',color='b',rasterized=True,label='Cra 2')
ax1_0.fill_between(cra2rho_radpc,cra2rho_rholo2,cra2rho_rhohi2,facecolor='navy',alpha=0.6,rasterized=False,edgecolor='None',label='dark matter')
ax1_0.fill_between(cra2rho_radpc,cra2rho_rhostarlo2,cra2rho_rhostarhi2,facecolor='darkred',alpha=0.6,rasterized=False,edgecolor='None',label='stars')
ax1_0.fill_between(cra2counts_radpc,cra2counts_rhostacylo2,cra2counts_rhostacyhi2,facecolor='g',alpha=0.6,rasterized=False,edgecolor='None')
#ax1_0.plot(cra2counts_radpc,cra2counts_rhostacy,color='g',lw=2)
ax1_0.text(1000,0.01,'Crater 2',fontsize=7,color='k')
#ax1_0.plot(cra2rho_radpc,cra2rho_rho,lw=0.5,color='k')
ax1_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='navy',label='dark matter')
ax1_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars')
ax1_0.xaxis.set_major_formatter(plt.NullFormatter())

#ax2_0.xaxis.set_major_formatter(plt.NullFormatter())
ax2_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
ax2_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
ax2_0.set_xlim([10,10000])
ax2_0.set_ylim([100,7000000000])
ax2_0.set_xscale(u'log')
ax2_0.set_yscale(u'log')
#ax2_0.fill_between(cra2rho_radpc,cra2rho_masslo2,cra2rho_masshi2,facecolor='0.1',alpha=0.60,rasterized=False,edgecolor='None')
ax2_0.fill_between(cra2rho_radpc,cra2rho_masslo2,cra2rho_masshi2,facecolor='navy',alpha=0.6,rasterized=False,edgecolor='None')
ax2_0.fill_between(cra2rho_radpc,cra2rho_stellarmasslo2,cra2rho_stellarmasshi2,facecolor='darkred',alpha=0.6,rasterized=False,edgecolor='None')
#ax2_0.fill_between(cra2rho_radpc,cra2rho_mstacylo2,cra2rho_mstacyhi2,facecolor='y',alpha=0.6,rasterized=False,edgecolor='None')
ax2_0.fill_between(cra2counts_radpc,cra2counts_mstacylo2,cra2counts_mstacyhi2,facecolor='g',alpha=0.6,rasterized=False,edgecolor='None')
#ax2_0.plot(cra2counts_radpc,cra2counts_mstacy,color='g',lw=2)
ax2_0.errorbar([cra2_rhalf0],[cra2_mrhalf0],xerr=[cra2_sigrhalf0],yerr=[cra2_sigmrhalf0],elinewidth=0.5,fmt='.',capsize=0,alpha=1,color='white',rasterized=False)
ax2_0.errorbar([cra2_rwolf],[cra2_mwolf],xerr=[cra2_sigrwolf],yerr=[cra2_sigmwolf],elinewidth=0.5,fmt='.',capsize=0,alpha=1,color='white',rasterized=False)
#ax2_0.fill_between(cra2rho_radpc,cra2rho_mtotlo2,cra2rho_mtothi2,facecolor='k',alpha=0.60,rasterized=False,edgecolor='None')
#ax2_0.plot(cra2rho_radpc,cra2rho_mtot,lw=0.5,color='k')
#ax2_0.xaxis.set_major_formatter(plt.NullFormatter())
ax2_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='navy',label='dark matter')
ax2_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='darkred',label='stars')
ax2_0.plot([1,10],[1.e-25,1.e-25],lw=0.5,color='g',label='gobs(gbar)')
ax2_0.legend(loc=2,fontsize=6,handlelength=1,numpoints=1,scatterpoints=1,shadow=False)

#ax0_0.set_ylabel(r'$M_{\rm enclosed}$ [M$_{\odot}$]',fontsize=10,rotation=90)
#ax0_0.set_xlabel(r'$r$ [pc]',fontsize=10,rotation=0,labelpad=5)
#ax0_0.set_xlim([10,10000])
#ax0_0.set_ylim([100,9000000000])
#ax0_0.set_xscale(u'log')
#ax0_0.set_yscale(u'log')
##ax0_0.fill_between(cra2rho_radpc,cra2rho_masslo2,cra2rho_masshi2,facecolor='0.1',alpha=0.60,rasterized=False,edgecolor='None')
#ax0_0.fill_between(cra2rho_radpc,cra2rho_masslo2,cra2rho_masshi2,facecolor='b',alpha=0.60,rasterized=False,edgecolor='None')
#ax0_0.fill_between(cra2rho_radpc,cra2rho_stellarmasslo2,cra2rho_stellarmasshi2,facecolor='r',alpha=0.60,rasterized=False,edgecolor='None')
##ax0_0.fill_between(cra2rho_radpc,cra2rho_mtotlo2,cra2rho_mtothi2,facecolor='k',alpha=0.60,rasterized=False,edgecolor='None')
#ax0_0.plot(cra2rho_radpc,cra2rho_stellarmass,lw=0.25,color='r')
##ax0_0.plot(cra2rho_radpc,cra2rho_mtot,lw=0.5,color='k')
#ax0_0.plot(cra2rho_rad,cra2rho_vdisp,lw=0.25,color='k')

plotfilename='dra_counts_profiles.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
