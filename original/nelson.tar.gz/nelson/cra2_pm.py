import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.io import fits 
from scipy import stats
import random
import mycode2
from astropy.coordinates import SkyCoord,Distance,ICRS
from galpy.potential import MWPotential2014
from galpy.orbit import Orbit
from galpy.potential import vesc
from astropy import units
np.set_printoptions(threshold='nan')

#plt.rc('grid',alpha=0.7) # modify rcparams
#plt.rc('grid',color='white')
#plt.rc('grid',linestyle='-')
plt.rc('legend',frameon='False')
plt.rc('xtick.major',size=2)
plt.rc('ytick.major',size=2)
plt.rc('axes',axisbelow='True')
plt.rc('axes',grid='False')
plt.rc('axes',facecolor='white')
plt.rc('axes',linewidth=0.5)
plt.rc('xtick.major',width=0.5)
plt.rc('ytick.major',width=0.5)
plt.rc('xtick',direction='in')
plt.rc('ytick',direction='in')
plt.rc('xtick',labelsize='5')
plt.rc('ytick',labelsize='5')
plt.rc('text',usetex='True')
plt.rc('font',family='serif')
plt.rc('font',style='normal')
plt.rc('font',serif='Century')
plt.rc('savefig',format='eps')
plt.rc('lines',markeredgewidth=0)
plt.rc('lines',markersize=2)

##use van der marel 2002 formalism to calculate velocities in GRF, XYZ system
mw=MWPotential2014
r0=8.29#kpc mcmillan 2011
usun=11.1#schonrich 2010
vsun=12.24#schonrich 2010
wsun=7.25#schonrich 2010
vlsr=239.#mcmillan 2011
rsolar=np.array([-r0,0,0],dtype=float)
vsolar=np.array([usun,vsun+vlsr,wsun])

cra2_radegcenter=177.310#deg
cra2_decdegcenter=-18.413
cra2_racenter=cra2_radegcenter*np.pi/180.#rad
cra2_deccenter=cra2_decdegcenter*np.pi/180.#rad
cra2_distance=117.5#kpc
cra2_coords=SkyCoord(cra2_racenter,cra2_deccenter,unit=['rad','rad'])
cra2_lcenter=cra2_coords.galactic.l.radian
cra2_bcenter=cra2_coords.galactic.b.radian

alpha0=np.linspace(cra2_racenter-0.000001,cra2_racenter+0.000001,1000)
dalpha0=alpha0[1]-alpha0[0]
coords=SkyCoord(alpha0,np.zeros(len(alpha0))+cra2_deccenter,unit=['rad','rad'])
l0=coords.galactic.l.radian
b0=coords.galactic.b.radian
dldalpha=(np.gradient(l0,dalpha0))[499]
dbdalpha=(np.gradient(b0,dalpha0))[499]

delta0=np.linspace(cra2_deccenter-0.000001,cra2_deccenter+0.000001,1000)
ddelta=delta0[1]-delta0[0]
coords=SkyCoord(np.zeros(len(delta0))+cra2_racenter,delta0,unit=['rad','rad'])
l0=coords.galactic.l.radian
b0=coords.galactic.b.radian
dlddelta=(np.gradient(l0,ddelta))[499]
dbddelta=(np.gradient(b0,ddelta))[499]

u1=np.array([np.cos(cra2_bcenter)*np.cos(cra2_lcenter),np.cos(cra2_bcenter)*np.sin(cra2_lcenter),np.sin(cra2_bcenter)])
u2=np.array([-np.sin(cra2_bcenter)*np.cos(cra2_lcenter)*dbdalpha-np.cos(cra2_bcenter)*np.sin(cra2_lcenter)*dldalpha,-np.sin(cra2_bcenter)*np.sin(cra2_lcenter)*dbdalpha+np.cos(cra2_bcenter)*np.cos(cra2_lcenter)*dldalpha,np.cos(cra2_bcenter)*dbdalpha])
u2=-u2/np.cos(cra2_deccenter)#correction for -cos(dec)
u3=np.array([-np.sin(cra2_bcenter)*np.cos(cra2_lcenter)*dbddelta-np.cos(cra2_bcenter)*np.sin(cra2_lcenter)*dlddelta,-np.sin(cra2_bcenter)*np.sin(cra2_lcenter)*dbddelta+np.cos(cra2_bcenter)*np.cos(cra2_lcenter)*dlddelta,np.cos(cra2_bcenter)*dbddelta])

cra2_r=rsolar+cra2_distance*u1
cra2_rmod=np.sqrt(cra2_r[0]**2+cra2_r[1]**2+cra2_r[2]**2)
####
    
cra2_data1='/physics2/mgwalker/chains/cra2pmpost_equal_weights.dat'

out1='cra2pm_commands.tex'
out2='cra2pm_table.tex'
g1=open(out1,'w')
g2=open(out2,'w')

with open(cra2_data1) as f: # read data file
    data=f.readlines()

cra2_bigsigma0=[]
cra2_logrs=[]
cra2_bigsigmab=[]
cra2_bigsigmagrad=[]
cra2_gradtheta=[]
cra2_vmean=[]
cra2_vvar=[]
cra2_mualpha=[]
cra2_mudelta=[]
cra2_fehmean=[]
cra2_zvar=[]
cra2_fehgrad=[]
cra2_like=[]

for line in data: # fill arrays
    p=line.split()
    cra2_vmean.append(float(p[4]))
    cra2_vvar.append(float(p[2]))
    cra2_mualpha.append(float(p[6]))
    cra2_mudelta.append(float(p[7]))
    cra2_fehmean.append(float(p[5]))
    cra2_zvar.append(float(p[3]))
    cra2_fehgrad.append(float(p[11]))
    cra2_like.append(float(p[12]))
    cra2_bigsigma0.append(float(p[0]))
    cra2_logrs.append(float(p[1]))
    cra2_bigsigmab.append(float(p[8]))
    cra2_bigsigmagrad.append(float(p[9]))
    cra2_gradtheta.append(float(p[10]))

cra2_vmean=np.array(cra2_vmean)
cra2_vvar=np.array(cra2_vvar)
cra2_mualpha=np.array(cra2_mualpha)
cra2_mudelta=np.array(cra2_mudelta)
cra2_fehmean=np.array(cra2_fehmean)
cra2_zvar=np.array(cra2_zvar)
cra2_fehgrad=np.array(cra2_fehgrad)
cra2_like=np.array(cra2_like)
cra2_bigsigma0=np.array(cra2_bigsigma0)
cra2_logrs=np.array(cra2_logrs)
cra2_bigsigmab=np.array(cra2_bigsigmab)
cra2_bigsigmagrad=np.array(cra2_bigsigmagrad)
cra2_gradtheta=np.array(cra2_gradtheta)

cra2_rs=10.**cra2_logrs
cra2_vdisp=np.sqrt(10.**cra2_vvar)
cra2_fehdisp=np.sqrt(10.**cra2_zvar)
cra2_gradtheta=cra2_gradtheta*180./np.pi

cra2_muwest=-cra2_mualpha/100.*np.cos(cra2_deccenter)#mas/yr
cra2_munorth=cra2_mudelta/100.#mas/yr
cra2_vsys=cra2_vmean#HRF LOS velocity in km/s
cra2_vx=cra2_distance*cra2_muwest*3.09e+16/1000./3600./180.*np.pi/365./24./3600.#km/s
cra2_vy=cra2_distance*cra2_munorth*3.09e+16/1000./3600./180.*np.pi/365./24./3600.#km/s
cra2_v=[]
cra2_vrad=[]
cra2_vtan=[]
cra2_apo=[]
cra2_peri=[]
cra2_ecc=[]
cra2_vesc=[]
for i in range(0,len(cra2_vsys)):
    vec=vsolar+cra2_vsys[i]*u1+cra2_vx[i]*u2+cra2_vy[i]*u3
    mag=np.sqrt(vec[0]**2+vec[1]**2+vec[2]**2)
    rad=np.dot(vec,cra2_r/np.sqrt(cra2_r[0]**2+cra2_r[1]**2+cra2_r[2]**2))
    tan=np.sqrt(mag**2-rad**2)
    cra2_v.append(vec)
    cra2_vrad.append(rad)
    cra2_vtan.append(tan)
    o=Orbit(vxvv=[cra2_rmod,rad,tan],ro=r0,vo=vlsr)
    o1=Orbit(vxvv=[cra2_radegcenter,cra2_decdegcenter,cra2_distance,cra2_mualpha[i]/100.*np.cos(cra2_deccenter),cra2_mudelta[i]/100.,cra2_vmean[i]],radec=True,solarmotion='schoenrich',ro=r0,vo=vlsr)
    ts=np.linspace(0,-10.,10000)*units.Gyr
#    o.integrate(ts,mw)
    o1.integrate(ts,mw)
    cra2_apo.append(o1.rap())
    cra2_peri.append(o1.rperi())
    cra2_ecc.append(o1.e())
    vescape=vesc(MWPotential2014,cra2_rmod*units.kpc)*vlsr
    cra2_vesc.append(mag/vescape)
    print i,o1.rap(),o1.rperi(),o1.e(),mag,rad,tan,mag/vescape
#    print i,o1.vx(),o1.vy(),o1.vz(),vec[0],vec[1],vec[2]
cra2_v=np.array(cra2_v)
cra2_vrad=np.array(cra2_vrad)
cra2_vtan=np.array(cra2_vtan)
cra2_apo=np.array(cra2_apo)
cra2_peri=np.array(cra2_peri)
cra2_ecc=np.array(cra2_ecc)
cra2_vesc=np.array(cra2_vesc)
bound=np.where(cra2_vesc<=1.)
disrupt=np.where(cra2_peri<10.)

gs=plt.GridSpec(7,7) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
#fig.set_

cra2_statsvmean=np.percentile(cra2_vmean,[2.5,16.,50.,84.,97.5])
cra2_statsvvar=np.percentile(cra2_vvar,[2.5,16.,50.,84.,97.5])
cra2_statsvdisp=np.percentile(cra2_vdisp,[2.5,16.,50.,84.,97.5])
cra2_statsmualpha=np.percentile(cra2_mualpha,[2.5,16.,50.,84.,97.5])
cra2_statsmudelta=np.percentile(cra2_mudelta,[2.5,16.,50.,84.,97.5])
cra2_statszvar=np.percentile(cra2_zvar,[2.5,16.,50.,84.,97.5])
cra2_statsfehdisp=np.percentile(cra2_fehdisp,[2.5,16.,50.,84.,97.5])
cra2_statsfehmean=np.percentile(cra2_fehmean,[2.5,16.,50.,84.,97.5])
cra2_statsfehgrad=np.percentile(cra2_fehgrad,[2.5,16.,50.,84.,97.5])
cra2_statsbigsigma0=np.percentile(cra2_bigsigma0,[2.5,16.,50.,84.,97.5])
cra2_statslogrs=np.percentile(cra2_logrs,[2.5,16.,50.,84.,97.5])
cra2_statsrs=np.percentile(cra2_rs,[2.5,16.,50.,84.,97.5])
cra2_statsbigsigmab=np.percentile(cra2_bigsigmab,[2.5,16.,50.,84.,97.5])
cra2_statsbigsigmagrad=np.percentile(cra2_bigsigmagrad,[2.5,16.,50.,84.,97.5])
cra2_statsgradtheta=np.percentile(cra2_gradtheta,[2.5,16.,50.,84.,97.5])

ax6_0=fig.add_subplot(gs[6,0])
ax5_0=fig.add_subplot(gs[5,0])
ax4_0=fig.add_subplot(gs[4,0])
ax3_0=fig.add_subplot(gs[3,0])
ax2_0=fig.add_subplot(gs[2,0])
ax1_0=fig.add_subplot(gs[1,0])

ax5_1=fig.add_subplot(gs[5,1])
ax4_1=fig.add_subplot(gs[4,1])
ax3_1=fig.add_subplot(gs[3,1])
ax2_1=fig.add_subplot(gs[2,1])
ax1_1=fig.add_subplot(gs[1,1])

ax4_2=fig.add_subplot(gs[4,2])
ax3_2=fig.add_subplot(gs[3,2])
ax2_2=fig.add_subplot(gs[2,2])
ax1_2=fig.add_subplot(gs[1,2])

ax3_3=fig.add_subplot(gs[3,3])
ax2_3=fig.add_subplot(gs[2,3])
ax1_3=fig.add_subplot(gs[1,3])

ax2_4=fig.add_subplot(gs[2,4])
ax1_4=fig.add_subplot(gs[1,4])

ax1_5=fig.add_subplot(gs[1,5])

axorbit=fig.add_subplot(gs[5:7,5:7])

#ax1_4=fig.add_subplot(gs[1,4])

ax1_6=fig.add_subplot(gs[1,6])
ax0_5=fig.add_subplot(gs[0,5])
ax0_4=fig.add_subplot(gs[0,4])
ax0_3=fig.add_subplot(gs[0,3])
ax0_2=fig.add_subplot(gs[0,2])
ax0_1=fig.add_subplot(gs[0,1])
ax0_0=fig.add_subplot(gs[0,0])

#    ax0_12=fig.add_subplot(gs[0,12])
vmeanlim=[80,95]
vdisplim=[0,12]
mualphalim=[-499,499]
mudeltalim=[-499,499]
fehmeanlim=[-4.99,0.99] 
fehdisplim=[0.01,0.59]
fehgradlim=[-0.2,0.2]  

vmeanticks=[80,85,90,95]
vdispticks=[2,4,6,8,10]
mualphaticks=[-250,0,250]
mudeltaticks=[-250,0,250]
fehmeanticks=[-4,-3,-2,-1,0]
fehdispticks=[0.15,0.3,0.45]
fehgradticks=[-0.1,0,0.1]

vmeanlabel=[r'$\langle v_{\rm los}\rangle$ [km/s]']
vdisplabel=[r'$\sigma_v$ [km/s]']
mualphalabel=[r'$\mu_{\alpha}$ [mas/cent.]']
mudeltalabel=[r'$\mu_{\delta}$ [mas/cent.]']
fehmeanlabel=[r'$\langle [\mathrm{Fe/H}]\rangle $ [dex]']
fehdisplabel=[r'$\sigma_{[\mathrm{Fe/H}]}$ [dex]']
fehgradlabel=[r'$k_Z $ $\bigl [ \frac{\rm dex}{\prime}\bigr ]$']

axorbit.set_xlabel(r'$r_{\rm peri}$ [kpc]',fontsize=7)
axorbit.set_ylabel(r'$r_{\rm apo}$ [kpc]',fontsize=7)
axorbit.set_xlim([0,150])
axorbit.set_ylim([100,400])
axorbit.set_xscale(u'linear')
axorbit.set_yscale(u'linear')
axorbit.scatter(cra2_peri[bound],cra2_apo[bound],s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

ax6_0.set_xlabel(vmeanlabel[0],fontsize=7,rotation=0)
ax6_0.set_ylabel(vdisplabel[0],fontsize=7,rotation=90,labelpad=1)
ax6_0.set_xlim(vmeanlim)
ax6_0.set_ylim(vdisplim)
ax6_0.set_xscale(u'linear')
ax6_0.set_yscale(u'linear')
ax6_0.set_xticks(vmeanticks)
ax6_0.set_xticklabels(vmeanticks,rotation=0)
ax6_0.set_yticks(vdispticks)
ax6_0.set_yticklabels(vdispticks,rotation=0)
#ax6_0.scatter(vmean2,vdisp2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax6_0.scatter(cra2_vmean,cra2_vdisp,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax6_0.set_xlabel(vmeanlabel[0],fontsize=7,rotation=0)
ax5_0.set_ylabel(mualphalabel[0],fontsize=7,rotation=90,labelpad=15)
ax5_0.set_xlim(vmeanlim)
ax5_0.set_ylim(mualphalim)
ax5_0.set_xscale(u'linear')
ax5_0.set_yscale(u'linear')
ax5_0.set_xticks(vmeanticks)
#ax6_0.set_xticklabels(vmeanticks,rotation=0)
ax5_0.set_yticks(mualphaticks)
ax5_0.set_yticklabels(mualphaticks,rotation=0)
ax5_0.xaxis.set_major_formatter(plt.NullFormatter())
#ax5_0.scatter(vmean2,mualpha2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax5_0.scatter(cra2_vmean,cra2_mualpha,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax5_0.set_xlabel(vmeanlabel[0],fontsize=7,rotation=0)
ax4_0.set_ylabel(mudeltalabel[0],fontsize=7,rotation=90,labelpad=1)
ax4_0.set_xlim(vmeanlim)
ax4_0.set_ylim(mudeltalim)
ax4_0.set_xscale(u'linear')
ax4_0.set_yscale(u'linear')
ax5_0.set_xticks(vmeanticks)
#ax5_0.set_xticklabels(vmeanticks,rotation=0)
ax4_0.set_yticks(mudeltaticks)
ax4_0.set_yticklabels(mudeltaticks,rotation=0)
ax4_0.xaxis.set_major_formatter(plt.NullFormatter())
#ax4_0.scatter(vmean2,mudelta2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax4_0.scatter(cra2_vmean,cra2_mudelta,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax4_0.set_xlabel(vmeanlabel[0],fontsize=7,rotation=0)
ax3_0.set_ylabel(fehmeanlabel[0],fontsize=7,rotation=90,labelpad=15)
ax3_0.set_xlim(vmeanlim)
ax3_0.set_ylim(fehmeanlim)
ax3_0.set_xscale(u'linear')
ax3_0.set_yscale(u'linear')
ax3_0.set_xticks(vmeanticks)
#ax4_0.set_xticklabels(vmeanticks,rotation=0)
ax3_0.set_yticks(fehmeanticks)
ax3_0.set_yticklabels(fehmeanticks,rotation=0)
ax3_0.xaxis.set_major_formatter(plt.NullFormatter())
#ax3_0.scatter(vmean2,fehmean2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax3_0.scatter(cra2_vmean,cra2_fehmean,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax3_0.set_xlabel(vmeanlabel[0],fontsize=7,rotation=0)
ax2_0.set_ylabel(fehdisplabel[0],fontsize=7,rotation=90,labelpad=1)
ax2_0.set_xlim(vmeanlim)
ax2_0.set_ylim(fehdisplim)
ax2_0.set_xscale(u'linear')
ax2_0.set_yscale(u'linear')
ax2_0.set_xticks(vmeanticks)
#ax3_0.set_xticklabels(vmeanticks,rotation=0)
ax2_0.set_yticks(fehdispticks)
ax2_0.set_yticklabels(fehdispticks,rotation=0)
ax2_0.xaxis.set_major_formatter(plt.NullFormatter())
#ax2_0.scatter(vmean2,fehdisp2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax2_0.scatter(cra2_vmean,cra2_fehdisp,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax2_0.set_xlabel(vmeanlabel[0],fontsize=7,rotation=0)
ax1_0.set_ylabel(fehgradlabel[0],fontsize=7,rotation=90,labelpad=15)
ax1_0.set_xlim(vmeanlim)
ax1_0.set_ylim(fehgradlim)
ax1_0.set_xscale(u'linear')
ax1_0.set_yscale(u'linear')
ax1_0.set_xticks(vmeanticks)
#ax2_0.set_xticklabels(vmeanticks,rotation=0)
ax1_0.set_yticks(fehgradticks)
ax1_0.set_yticklabels(fehgradticks,rotation=0)
ax1_0.xaxis.set_major_formatter(plt.NullFormatter())
#ax1_0.scatter(vmean2,fehgrad2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax1_0.scatter(cra2_vmean,cra2_fehgrad,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

ax0_0.set_ylabel('probability',fontsize=7,rotation=90,labelpad=1)
ax0_0.xaxis.set_major_formatter(plt.NullFormatter())
ax0_0.set_xticks(vmeanticks)
ax0_0.yaxis.set_major_formatter(plt.NullFormatter())
#ax0_0.hist(vmean2,bins=50,range=vmeanlim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='b',linewidth=0.5)
ax0_0.hist(cra2_vmean,bins=50,range=vmeanlim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='k',linewidth=0.5,label='Cra 2')
#ax0_0.legend(loc=2,fontsize=7,handlelength=0.5,numpoints=1,scatterpoints=1,shadow=False)



ax5_1.set_xlabel(vdisplabel[0],fontsize=7,rotation=0)
#ax5_1.set_ylabel(mualphalabel[0],fontsize=7,rotation=90,labelpad=5)
ax5_1.set_xlim(vdisplim)
ax5_1.set_ylim(mualphalim)
ax5_1.set_xscale(u'linear')
ax5_1.set_yscale(u'linear')
ax5_1.set_xticks(vdispticks)
ax5_1.set_xticklabels(vdispticks,rotation=0)
ax5_1.set_yticks(mualphaticks)
ax5_1.set_yticklabels(mualphaticks,rotation=0)
ax5_1.yaxis.set_major_formatter(plt.NullFormatter())
#ax5_1.scatter(vdisp2,mualpha2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax5_1.scatter(cra2_vdisp,cra2_mualpha,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax5_1.set_xlabel(vdisplabel[0],fontsize=7,rotation=0)
#ax4_1.set_ylabel(mudeltalabel[0],fontsize=7,rotation=90,labelpad=5)
ax4_1.set_xlim(vdisplim)
ax4_1.set_ylim(mudeltalim)
ax4_1.set_xscale(u'linear')
ax4_1.set_yscale(u'linear')
ax4_1.set_xticks(vdispticks)
#ax4_1.set_xticklabels(vdispticks,rotation=0)
ax4_1.set_yticks(mudeltaticks)
#ax4_1.set_yticklabels(mudeltaticks,rotation=0)
ax4_1.xaxis.set_major_formatter(plt.NullFormatter())
ax4_1.yaxis.set_major_formatter(plt.NullFormatter())
#ax4_1.scatter(vdisp2,mudelta2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax4_1.scatter(cra2_vdisp,cra2_mudelta,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax3_1.set_xlabel(vdisplabel[0],fontsize=7,rotation=0)
#ax3_1.set_ylabel(fehmeanlabel[0],fontsize=7,rotation=90,labelpad=5)
ax3_1.set_xlim(vdisplim)
ax3_1.set_ylim(fehmeanlim)
ax3_1.set_xscale(u'linear')
ax3_1.set_yscale(u'linear')
ax3_1.set_xticks(vdispticks)
#ax3_1.set_xticklabels(vdispticks,rotation=0)
ax3_1.set_yticks(fehmeanticks)
#ax3_1.set_yticklabels(fehmeanticks,rotation=0)
ax3_1.yaxis.set_major_formatter(plt.NullFormatter())
ax3_1.xaxis.set_major_formatter(plt.NullFormatter())
#ax3_1.scatter(vdisp2,fehmean2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax3_1.scatter(cra2_vdisp,cra2_fehmean,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax2_1.set_xlabel(vdisplabel[0],fontsize=7,rotation=0)
#ax2_1.set_ylabel(fehdisplabel[0],fontsize=7,rotation=90,labelpad=5)
ax2_1.set_xlim(vdisplim)
ax2_1.set_ylim(fehdisplim)
ax2_1.set_xscale(u'linear')
ax2_1.set_yscale(u'linear')
ax2_1.set_xticks(vdispticks)
#ax2_1.set_xticklabels(vdispticks,rotation=0)
ax2_1.set_yticks(fehdispticks)
#ax2_1.set_yticklabels(fehdispticks,rotation=0)
ax2_1.yaxis.set_major_formatter(plt.NullFormatter())
ax2_1.xaxis.set_major_formatter(plt.NullFormatter())
#ax2_1.scatter(vdisp2,fehdisp2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax2_1.scatter(cra2_vdisp,cra2_fehdisp,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax1_1.set_xlabel(vdisplabel[0],fontsize=7,rotation=0)
#ax1_1.set_ylabel(fehgradlabel[0],fontsize=7,rotation=90,labelpad=5)
ax1_1.set_xlim(vdisplim)
ax1_1.set_ylim(fehgradlim)
ax1_1.set_xscale(u'linear')
ax1_1.set_yscale(u'linear')
ax1_1.set_xticks(vdispticks)
#ax1_1.set_xticklabels(vdispticks,rotation=0)
ax1_1.set_yticks(fehgradticks)
#ax1_1.set_yticklabels(fehgradticks,rotation=0)
ax1_1.yaxis.set_major_formatter(plt.NullFormatter())
ax1_1.xaxis.set_major_formatter(plt.NullFormatter())
#ax1_1.scatter(vdisp2,fehgrad2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax1_1.scatter(cra2_vdisp,cra2_fehgrad,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax0_1.set_ylabel('probability',fontsize=7,rotation=90,labelpad=5)
ax0_1.xaxis.set_major_formatter(plt.NullFormatter())
ax0_1.set_xticks(vdispticks)
ax0_1.yaxis.set_major_formatter(plt.NullFormatter())
#ax0_1.hist(vdisp2,bins=50,range=vdisplim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='b',linewidth=0.5)
ax0_1.hist(cra2_vdisp,bins=50,range=vdisplim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='k',linewidth=0.5)



ax4_2.set_xlabel(mualphalabel[0],fontsize=7,rotation=0)
#ax4_2.set_ylabel(mudeltalabel[0],fontsize=7,rotation=90,labelpad=5)
ax4_2.set_xlim(mualphalim)
ax4_2.set_ylim(mudeltalim)
ax4_2.set_xscale(u'linear')
ax4_2.set_yscale(u'linear')
ax4_2.set_xticks(mualphaticks)
#ax4_2.set_xticklabels(mualphaticks,rotation=0)
ax4_2.set_yticks(mudeltaticks)
#ax4_2.set_yticklabels(mudeltaticks,rotation=0)
ax4_2.yaxis.set_major_formatter(plt.NullFormatter())
#ax4_2.scatter(mualpha2,mudelta2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax4_2.scatter(cra2_mualpha,cra2_mudelta,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)
ax4_2.scatter(cra2_mualpha[disrupt],cra2_mudelta[disrupt],s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='r',rasterized=True)

#ax3_2.set_xlabel(mualphalabel[0],fontsize=7,rotation=0)
#ax3_2.set_ylabel(fehmeanlabel[0],fontsize=7,rotation=90,labelpad=5)
ax3_2.set_xlim(mualphalim)
ax3_2.set_ylim(fehmeanlim)
ax3_2.set_xscale(u'linear')
ax3_2.set_yscale(u'linear')
ax3_2.set_xticks(mualphaticks)
#ax3_2.set_xticklabels(mualphaticks,rotation=0)
ax3_2.set_yticks(fehmeanticks)
#ax3_2.set_yticklabels(fehmeanticks,rotation=0)
ax3_2.yaxis.set_major_formatter(plt.NullFormatter())
ax3_2.xaxis.set_major_formatter(plt.NullFormatter())
#ax3_2.scatter(mualpha2,fehmean2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax3_2.scatter(cra2_mualpha,cra2_fehmean,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax2_2.set_xlabel(mualphalabel[0],fontsize=7,rotation=0)
#ax2_2.set_ylabel(fehdisplabel[0],fontsize=7,rotation=90,labelpad=5)
ax2_2.set_xlim(mualphalim)
ax2_2.set_ylim(fehdisplim)
ax2_2.set_xscale(u'linear')
ax2_2.set_yscale(u'linear')
ax2_2.set_xticks(mualphaticks)
#ax2_2.set_xticklabels(mualphaticks,rotation=0)
ax2_2.set_yticks(fehdispticks)
#ax2_2.set_yticklabels(fehdispticks,rotation=0)
ax2_2.yaxis.set_major_formatter(plt.NullFormatter())
ax2_2.xaxis.set_major_formatter(plt.NullFormatter())
#ax2_2.scatter(mualpha2,fehdisp2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax2_2.scatter(cra2_mualpha,cra2_fehdisp,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax1_2.set_xlabel(mualphalabel[0],fontsize=7,rotation=0)
#ax1_2.set_ylabel(fehgradlabel[0],fontsize=7,rotation=90,labelpad=5)
ax1_2.set_xlim(mualphalim)
ax1_2.set_ylim(fehgradlim)
ax1_2.set_xscale(u'linear')
ax1_2.set_yscale(u'linear')
ax1_2.set_xticks(mualphaticks)
#ax1_2.set_xticklabels(mualphaticks,rotation=0)
ax1_2.set_yticks(fehgradticks)
#ax1_2.set_yticklabels(fehgradticks,rotation=0)
ax1_2.yaxis.set_major_formatter(plt.NullFormatter())
ax1_2.xaxis.set_major_formatter(plt.NullFormatter())
#ax1_2.scatter(mualpha2,fehgrad2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax1_2.scatter(cra2_mualpha,cra2_fehgrad,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax0_2.set_ylabel('probability',fontsize=7,rotation=90,labelpad=5)
ax0_2.xaxis.set_major_formatter(plt.NullFormatter())
ax0_2.set_xticks(mualphaticks)
ax0_2.yaxis.set_major_formatter(plt.NullFormatter())
#ax0_2.hist(mualpha2,bins=50,range=mualphalim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='b',linewidth=0.5)
ax0_2.hist(cra2_mualpha,bins=50,range=mualphalim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='k',linewidth=0.5)

ax3_3.set_xlabel(mudeltalabel[0],fontsize=7,rotation=0)
#ax3_3.set_ylabel(fehmeanlabel[0],fontsize=7,rotation=90,labelpad=5)
ax3_3.set_xlim(mudeltalim)
ax3_3.set_ylim(fehmeanlim)
ax3_3.set_xscale(u'linear')
ax3_3.set_yscale(u'linear')
ax3_3.set_xticks(mudeltaticks)
#ax3_3.set_xticklabels(mudeltaticks,rotation=0)
ax3_3.set_yticks(fehmeanticks)
#ax3_3.set_yticklabels(fehmeanticks,rotation=0)
ax3_3.yaxis.set_major_formatter(plt.NullFormatter())
#ax3_3.scatter(mudelta2,fehmean2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax3_3.scatter(cra2_mudelta,cra2_fehmean,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax2_3.set_xlabel(mudeltalabel[0],fontsize=7,rotation=0)
#ax2_3.set_ylabel(fehdisplabel[0],fontsize=7,rotation=90,labelpad=5)
ax2_3.set_xlim(mudeltalim)
ax2_3.set_ylim(fehdisplim)
ax2_3.set_xscale(u'linear')
ax2_3.set_yscale(u'linear')
ax2_3.set_xticks(mudeltaticks)
#ax2_3.set_xticklabels(mudeltaticks,rotation=0)
ax2_3.set_yticks(fehdispticks)
#ax2_3.set_yticklabels(fehdispticks,rotation=0)
ax2_3.yaxis.set_major_formatter(plt.NullFormatter())
ax2_3.xaxis.set_major_formatter(plt.NullFormatter())
#ax2_3.scatter(mudelta2,fehdisp2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax2_3.scatter(cra2_mudelta,cra2_fehdisp,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax1_3.set_xlabel(mudeltalabel[0],fontsize=7,rotation=0)
#ax1_3.set_ylabel(fehgradlabel[0],fontsize=7,rotation=90,labelpad=5)
ax1_3.set_xlim(mudeltalim)
ax1_3.set_ylim(fehgradlim)
ax1_3.set_xscale(u'linear')
ax1_3.set_yscale(u'linear')
ax1_3.set_xticks(mudeltaticks)
#ax1_3.set_xticklabels(mudeltaticks,rotation=0)
ax1_3.set_yticks(fehgradticks)
#ax1_3.set_yticklabels(fehgradticks,rotation=0)
ax1_3.yaxis.set_major_formatter(plt.NullFormatter())
ax1_3.xaxis.set_major_formatter(plt.NullFormatter())
#ax1_3.scatter(mudelta2,fehgrad2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax1_3.scatter(cra2_mudelta,cra2_fehgrad,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax0_3.set_ylabel('probability',fontsize=7,rotation=90,labelpad=5)
ax0_3.xaxis.set_major_formatter(plt.NullFormatter())
ax0_3.set_xticks(mudeltaticks)
ax0_3.yaxis.set_major_formatter(plt.NullFormatter())
#ax0_3.hist(mudelta2,bins=50,range=mudeltalim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='b',linewidth=0.5)
ax0_3.hist(cra2_mudelta,bins=50,range=mudeltalim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='k',linewidth=0.5)


ax2_4.set_xlabel(fehmeanlabel[0],fontsize=7,rotation=0)
#ax2_4.set_ylabel(fehdisplabel[0],fontsize=7,rotation=90,labelpad=5)
ax2_4.set_xlim(fehmeanlim)
ax2_4.set_ylim(fehdisplim)
ax2_4.set_xscale(u'linear')
ax2_4.set_yscale(u'linear')
ax2_4.set_xticks(fehmeanticks)
#ax2_4.set_xticklabels(fehmeanticks,rotation=0)
ax2_4.set_yticks(fehdispticks)
#ax2_4.set_yticklabels(fehdispticks,rotation=0)
ax2_4.yaxis.set_major_formatter(plt.NullFormatter())
#ax2_4.scatter(fehmean2,fehdisp2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax2_4.scatter(cra2_fehmean,cra2_fehdisp,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax1_4.set_xlabel(fehmeanlabel[0],fontsize=7,rotation=0)
#ax1_4.set_ylabel(fehgradlabel[0],fontsize=7,rotation=90,labelpad=5)
ax1_4.set_xlim(fehmeanlim)
ax1_4.set_ylim(fehgradlim)
ax1_4.set_xscale(u'linear')
ax1_4.set_yscale(u'linear')
ax1_4.set_xticks(fehmeanticks)
#ax1_4.set_xticklabels(fehmeanticks,rotation=0)
ax1_4.set_yticks(fehgradticks)
#ax1_4.set_yticklabels(fehgradticks,rotation=0)
ax1_4.yaxis.set_major_formatter(plt.NullFormatter())
ax1_4.xaxis.set_major_formatter(plt.NullFormatter())
#ax1_4.scatter(fehmean2,fehgrad2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax1_4.scatter(cra2_fehmean,cra2_fehgrad,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax0_4.set_ylabel('probability',fontsize=7,rotation=90,labelpad=5)
ax0_4.xaxis.set_major_formatter(plt.NullFormatter())
ax0_4.set_xticks(fehmeanticks)
ax0_4.yaxis.set_major_formatter(plt.NullFormatter())
#ax0_4.hist(fehmean2,bins=50,range=fehmeanlim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='b',linewidth=0.5)
ax0_4.hist(cra2_fehmean,bins=50,range=fehmeanlim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='k',linewidth=0.5)


ax1_5.set_xlabel(fehdisplabel[0],fontsize=7,rotation=0)
#ax1_5.set_ylabel(fehgradlabel[0],fontsize=7,rotation=90,labelpad=5)
ax1_5.set_xlim(fehdisplim)
ax1_5.set_ylim(fehgradlim)
ax1_5.set_xscale(u'linear')
ax1_5.set_yscale(u'linear')
ax1_5.set_xticks(fehdispticks)
#ax1_5.set_xticklabels(fehdispticks,rotation=0)
ax1_5.set_yticks(fehgradticks)
#ax1_5.set_yticklabels(fehgradticks,rotation=0)
ax1_5.yaxis.set_major_formatter(plt.NullFormatter())
#ax1_5.scatter(fehdisp2,fehgrad2,s=1,lw=0,edgecolor='none',alpha=0.75,marker='.',color='b',rasterized=True)
ax1_5.scatter(cra2_fehdisp,cra2_fehgrad,s=1,lw=0,edgecolor='none',alpha=0.35,marker='.',color='k',rasterized=True)

#ax0_5.set_ylabel('probability',fontsize=7,rotation=90,labelpad=5)
ax0_5.xaxis.set_major_formatter(plt.NullFormatter())
ax0_5.set_xticks(fehdispticks)
ax0_5.yaxis.set_major_formatter(plt.NullFormatter())
#ax0_5.hist(fehdisp2,bins=50,range=fehdisplim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='b',linewidth=0.5)

ax0_5.hist(cra2_fehdisp,bins=50,range=fehdisplim,normed=True,histtype='step',align='mid',rwidth=0,orientation='vertical',color='k',linewidth=0.5)

ax1_6.set_xlabel('probability',fontsize=7,rotation=0,labelpad=5)
ax1_6.yaxis.set_major_formatter(plt.NullFormatter())
ax1_6.xaxis.set_major_formatter(plt.NullFormatter())
ax1_6.set_yticks(fehgradticks)
#ax1_6.hist(fehgrad2,bins=50,range=fehgradlim,normed=True,histtype='step',align='mid',rwidth=0,orientation='horizontal',color='b',linewidth=0.5)
ax1_6.hist(cra2_fehgrad,bins=50,range=fehgradlim,normed=True,histtype='step',align='mid',rwidth=0,orientation='horizontal',color='k',linewidth=0.5)

g1.write(r'\newcommand{\pmvmean}{$'+str(round(cra2_statsvmean[2],1))+r'_{'+str(round(cra2_statsvmean[1]-cra2_statsvmean[2],1))+r'}'+r'^{+'+str(round(cra2_statsvmean[3]-cra2_statsvmean[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmvvar}{$'+str(round(cra2_statsvvar[2],1))+r'_{'+str(round(cra2_statsvvar[1]-cra2_statsvvar[2],1))+r'}'+r'^{+'+str(round(cra2_statsvvar[3]-cra2_statsvvar[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmvdisp}{$'+str(round(cra2_statsvdisp[2],1))+r'_{'+str(round(cra2_statsvdisp[1]-cra2_statsvdisp[2],1))+r'}'+r'^{+'+str(round(cra2_statsvdisp[3]-cra2_statsvdisp[2],1))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmmualpha}{$'+str(round(cra2_statsmualpha[2],0))+r'_{'+str(round(cra2_statsmualpha[1]-cra2_statsmualpha[2],0))+r'}'+r'^{+'+str(round(cra2_statsmualpha[3]-cra2_statsmualpha[2],0))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmmudelta}{$'+str(round(cra2_statsmudelta[2],0))+r'_{'+str(round(cra2_statsmudelta[1]-cra2_statsmudelta[2],0))+r'}'+r'^{+'+str(round(cra2_statsmudelta[3]-cra2_statsmudelta[2],0))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmfehmean}{$'+str(round(cra2_statsfehmean[2],2))+r'_{'+str(round(cra2_statsfehmean[1]-cra2_statsfehmean[2],2))+r'}'+r'^{+'+str(round(cra2_statsfehmean[3]-cra2_statsfehmean[2],2))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmzvar}{$'+str(round(cra2_statszvar[2],2))+r'_{'+str(round(cra2_statszvar[1]-cra2_statszvar[2],2))+r'}'+r'^{+'+str(round(cra2_statszvar[3]-cra2_statszvar[2],2))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmfehdisp}{$'+str(round(cra2_statsfehdisp[2],2))+r'_{'+str(round(cra2_statsfehdisp[1]-cra2_statsfehdisp[2],2))+r'}'+r'^{+'+str(round(cra2_statsfehdisp[3]-cra2_statsfehdisp[2],2))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmfehgrad}{$'+str(round(cra2_statsfehgrad[2],3))+r'_{'+str(round(cra2_statsfehgrad[1]-cra2_statsfehgrad[2],3))+r'}'+r'^{+'+str(round(cra2_statsfehgrad[3]-cra2_statsfehgrad[2],3))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmbigsigma}{$'+str(round(cra2_statsbigsigma0[2],2))+r'_{'+str(round(cra2_statsbigsigma0[1]-cra2_statsbigsigma0[2],2))+r'}'+r'^{+'+str(round(cra2_statsbigsigma0[3]-cra2_statsbigsigma0[2],2))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmrs}{$'+str(round(cra2_statsrs[2],2))+r'_{'+str(round(cra2_statsrs[1]-cra2_statsrs[2],2))+r'}'+r'^{+'+str(round(cra2_statsrs[3]-cra2_statsrs[2],2))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmlogrs}{$'+str(round(cra2_statslogrs[2],2))+r'_{'+str(round(cra2_statslogrs[1]-cra2_statslogrs[2],2))+r'}'+r'^{+'+str(round(cra2_statslogrs[3]-cra2_statslogrs[2],2))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmbigsigmab}{$'+str(round(cra2_statsbigsigmab[2],2))+r'_{'+str(round(cra2_statsbigsigmab[1]-cra2_statsbigsigmab[2],2))+r'}'+r'^{+'+str(round(cra2_statsbigsigmab[3]-cra2_statsbigsigmab[2],2))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmbigsigmagrad}{$'+str(round(cra2_statsbigsigmagrad[2],4))+r'_{'+str(round(cra2_statsbigsigmagrad[1]-cra2_statsbigsigmagrad[2],4))+r'}'+r'^{+'+str(round(cra2_statsbigsigmagrad[3]-cra2_statsbigsigmagrad[2],4))+r'}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmgradtheta}{$'+str(round(cra2_statsgradtheta[2],2))+r'_{'+str(round(cra2_statsgradtheta[1]-cra2_statsgradtheta[2],2))+r'}'+r'^{+'+str(round(cra2_statsgradtheta[3]-cra2_statsgradtheta[2],2))+r'}$'+r'}'+'\n')

g1.write(r'\newcommand{\pmvmeanexpanded}{$'+str(round(cra2_statsvmean[2],1))+r'_{'+str(round(cra2_statsvmean[1]-cra2_statsvmean[2],1))+r'('+str(round(cra2_statsvmean[0]-cra2_statsvmean[2],1))+r')}'+r'^{+'+str(round(cra2_statsvmean[3]-cra2_statsvmean[2],1))+r'(+'+str(round(cra2_statsvmean[4]-cra2_statsvmean[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmvvarexpanded}{$'+str(round(cra2_statsvvar[2],1))+r'_{'+str(round(cra2_statsvvar[1]-cra2_statsvvar[2],1))+r'('+str(round(cra2_statsvvar[0]-cra2_statsvvar[2],1))+r')}'+r'^{+'+str(round(cra2_statsvvar[3]-cra2_statsvvar[2],1))+r'(+'+str(round(cra2_statsvvar[4]-cra2_statsvvar[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmvdispexpanded}{$'+str(round(cra2_statsvdisp[2],1))+r'_{'+str(round(cra2_statsvdisp[1]-cra2_statsvdisp[2],1))+r'('+str(round(cra2_statsvdisp[0]-cra2_statsvdisp[2],1))+r')}'+r'^{+'+str(round(cra2_statsvdisp[3]-cra2_statsvdisp[2],1))+r'(+'+str(round(cra2_statsvdisp[4]-cra2_statsvdisp[2],1))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmmualphaexpanded}{$'+str(round(cra2_statsmualpha[2],0))+r'_{'+str(round(cra2_statsmualpha[1]-cra2_statsmualpha[2],0))+r'('+str(round(cra2_statsmualpha[0]-cra2_statsmualpha[2],0))+r')}'+r'^{+'+str(round(cra2_statsmualpha[3]-cra2_statsmualpha[2],0))+r'(+'+str(round(cra2_statsmualpha[4]-cra2_statsmualpha[2],0))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmmudeltaexpanded}{$'+str(round(cra2_statsmudelta[2],0))+r'_{'+str(round(cra2_statsmudelta[1]-cra2_statsmudelta[2],0))+r'('+str(round(cra2_statsmudelta[0]-cra2_statsmudelta[2],0))+r')}'+r'^{+'+str(round(cra2_statsmudelta[3]-cra2_statsmudelta[2],0))+r'(+'+str(round(cra2_statsmudelta[4]-cra2_statsmudelta[2],0))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmfehmeanexpanded}{$'+str(round(cra2_statsfehmean[2],2))+r'_{'+str(round(cra2_statsfehmean[1]-cra2_statsfehmean[2],2))+r'('+str(round(cra2_statsfehmean[0]-cra2_statsfehmean[2],2))+r')}'+r'^{+'+str(round(cra2_statsfehmean[3]-cra2_statsfehmean[2],2))+r'(+'+str(round(cra2_statsfehmean[4]-cra2_statsfehmean[2],2))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmzvarexpanded}{$'+str(round(cra2_statszvar[2],2))+r'_{'+str(round(cra2_statszvar[1]-cra2_statszvar[2],2))+r'('+str(round(cra2_statszvar[0]-cra2_statszvar[2],2))+r')}'+r'^{+'+str(round(cra2_statszvar[3]-cra2_statszvar[2],2))+r'(+'+str(round(cra2_statszvar[4]-cra2_statszvar[2],2))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmfehdispexpanded}{$'+str(round(cra2_statsfehdisp[2],2))+r'_{'+str(round(cra2_statsfehdisp[1]-cra2_statsfehdisp[2],2))+r'('+str(round(cra2_statsfehdisp[0]-cra2_statsfehdisp[2],2))+r')}'+r'^{+'+str(round(cra2_statsfehdisp[3]-cra2_statsfehdisp[2],2))+r'(+'+str(round(cra2_statsfehdisp[4]-cra2_statsfehdisp[2],2))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmfehgradexpanded}{$'+str(round(cra2_statsfehgrad[2],3))+r'_{'+str(round(cra2_statsfehgrad[1]-cra2_statsfehgrad[2],3))+r'('+str(round(cra2_statsfehgrad[0]-cra2_statsfehgrad[2],3))+r')}'+r'^{+'+str(round(cra2_statsfehgrad[3]-cra2_statsfehgrad[2],3))+r'(+'+str(round(cra2_statsfehgrad[4]-cra2_statsfehgrad[2],3))+r')}$'+r'}'+'\n')

g1.write(r'\newcommand{\pmbigsigmaexpanded}{$'+str(round(cra2_statsbigsigma0[2],2))+r'_{'+str(round(cra2_statsbigsigma0[1]-cra2_statsbigsigma0[2],2))+r'('+str(round(cra2_statsbigsigma0[0]-cra2_statsbigsigma0[2],2))+r')}'+r'^{+'+str(round(cra2_statsbigsigma0[3]-cra2_statsbigsigma0[2],2))+r'(+'+str(round(cra2_statsbigsigma0[4]-cra2_statsbigsigma0[2],2))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmlogrsexpanded}{$'+str(round(cra2_statslogrs[2],2))+r'_{'+str(round(cra2_statslogrs[1]-cra2_statslogrs[2],2))+r'('+str(round(cra2_statslogrs[0]-cra2_statslogrs[2],2))+r')}'+r'^{+'+str(round(cra2_statslogrs[3]-cra2_statslogrs[2],2))+r'(+'+str(round(cra2_statslogrs[4]-cra2_statslogrs[2],2))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmrsexpanded}{$'+str(round(cra2_statsrs[2],2))+r'_{'+str(round(cra2_statsrs[1]-cra2_statsrs[2],2))+r'('+str(round(cra2_statsrs[0]-cra2_statsrs[2],2))+r')}'+r'^{+'+str(round(cra2_statsrs[3]-cra2_statsrs[2],2))+r'(+'+str(round(cra2_statsrs[4]-cra2_statsrs[2],2))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmbigsigmabexpanded}{$'+str(round(cra2_statsbigsigmab[2],2))+r'_{'+str(round(cra2_statsbigsigmab[1]-cra2_statsbigsigmab[2],2))+r'('+str(round(cra2_statsbigsigmab[0]-cra2_statsbigsigmab[2],2))+r')}'+r'^{+'+str(round(cra2_statsbigsigmab[3]-cra2_statsbigsigmab[2],2))+r'(+'+str(round(cra2_statsbigsigmab[4]-cra2_statsbigsigmab[2],2))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmbigsigmagradexpanded}{$'+str(round(cra2_statsbigsigmagrad[2],4))+r'_{'+str(round(cra2_statsbigsigmagrad[1]-cra2_statsbigsigmagrad[2],4))+r'('+str(round(cra2_statsbigsigmagrad[0]-cra2_statsbigsigmagrad[2],4))+r')}'+r'^{+'+str(round(cra2_statsbigsigmagrad[3]-cra2_statsbigsigmagrad[2],4))+r'(+'+str(round(cra2_statsbigsigmagrad[4]-cra2_statsbigsigmagrad[2],4))+r')}$'+r'}'+'\n')
g1.write(r'\newcommand{\pmgradthetaexpanded}{$'+str(round(cra2_statsgradtheta[2],2))+r'_{'+str(round(cra2_statsgradtheta[1]-cra2_statsgradtheta[2],2))+r'('+str(round(cra2_statsgradtheta[0]-cra2_statsgradtheta[2],2))+r')}'+r'^{+'+str(round(cra2_statsgradtheta[3]-cra2_statsgradtheta[2],2))+r'(+'+str(round(cra2_statsgradtheta[4]-cra2_statsgradtheta[2],2))+r')}$'+r'}'+'\n')

g1.write(r'\newcommand{\pmvdispupperlim}{$'+str(round(np.percentile(cra2_vdisp,84),1))+r'$}'+'\n')
g1.write(r'\newcommand{\pmfehdispupperlim}{$'+str(round(np.percentile(cra2_fehdisp,84),1))+r'$}'+'\n')
g1.write(r'\newcommand{\pmfehgradlowerlim}{$'+str(round(np.percentile(cra2_fehgrad,16),1))+r'$}'+'\n')

g2.write(r'\begin{table*}'+'\n')
g2.write(r'\scriptsize'+'\n')
g2.write(r'\centering'+'\n')
g2.write(r'\caption{\scriptsize Summary of probability distribution functions for chemodynamical parameters---constant velocity dispersion model}'+'\n')
g2.write(r'\begin{tabular}{@{}lllllllllll@{}}'+'\n')
g2.write(r'\hline'+'\n')
g2.write(r'parameter & prior & posterior & description\\'+'\n')
#g2.write(r'&  & (red sample) & (blue sample) &\\'+'\n')
#g2.write(r'&  & (red sample) &\\'+'\n')
g2.write(r'\hline'+'\n')
g2.write(r'\smallskip'+'\n')
#g2.write(r'$\langle v_{\rm los}\rangle$ [km s$^{-1}$] & uniform between -500 and +500 & \vmeanexpanded & \vmeantwoexpanded '+r'& mean velocity at center' +r'\\'+'\n')
g2.write(r'$\langle v_{\rm los}\rangle$ [km s$^{-1}$] & uniform between -500 and +500 & \pmvmeanexpanded '+r'& mean velocity at center (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
#g2.write(r'$\sigma_{v_{\rm los}}$ [km s$^{-1}$] & uniform between 0 and +500 & \vdispexpanded & \vdisptwoexpanded '+r'& velocity dispersion' +r'\\'+'\n')
g2.write(r'$\log_{10}[\sigma^2_{v_{\rm los}} /(\mathrm{km^2 s^{-2}})]$ & uniform between -5 and +5 & \pmvvarexpanded '+r'& velocity dispersion (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
#g2.write(r'$k_{v_{\rm los}}$ [km s$^{-1}$ arcmin$^{-1}$] & uniform between 0 and +10 & \mualphaexpanded & \mualphatwoexpanded '+r'& magnitude of maximum velocity pm' +r'\\'+'\n')
g2.write(r'$k_{v_{\rm los}}$ [km s$^{-1}$ arcmin$^{-1}$] & uniform between -1000 and +1000 & \pmmualphaexpanded '+r'& magnitude of maximum velocity pm (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
#g2.write(r'$\theta_{v_{\rm los}}$ [$\degr$] & uniform between -180 and +180 & \mudeltaexpanded & \mudeltatwoexpanded '+r'& direction of maximum velocity pm' +r'\\'+'\n')
g2.write(r'$\theta_{v_{\rm los}}$ [deg.] & uniform between -1000 and +1000 & \pmmudeltaexpanded '+r'& direction of maximum velocity pm (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
#g2.write(r'$\langle \feh\rangle $ & uniform between -5 and +1 & \fehmeanexpanded & \fehmeantwoexpanded '+r'& mean metallicity at center' +r'\\'+'\n')
g2.write(r'$\langle \feh\rangle $ [dex] & uniform between -5 and +1 & \pmfehmeanexpanded '+r'& mean metallicity at center (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
#g2.write(r'$\sigma_{\feh}$ & uniform between 0 and +2 & \fehdispexpanded & \fehdisptwoexpanded '+r'& metallicity dispersion' +r'\\'+'\n')
g2.write(r'$\log_{10}[\sigma^2_{\feh}]$ & uniform between -5 and +2 & \pmzvarexpanded '+r'& metallicity dispersion (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
#g2.write(r'$k_{\feh}$ [dex arcmin$^{-1}$] & uniform between -1 and +1 & \fehgradexpanded & \fehgradtwoexpanded '+r'& magnitude of metallicity pm' +r'\\'+'\n')
g2.write(r'$k_Z$ [dex arcmin$^{-1}$] & uniform between -1 and +1 & \pmfehgradexpanded '+r'& magnitude of metallicity pm (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\log_{10}[\Sigma_{0,1}/(\mathrm{arcmin}^{-2})]$ & uniform between -10 and +10 & \pmbigsigmaexpanded '+r'& 2D stellar density scale (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\log_{10}[R_{\rm h}/(\mathrm{arcmin})]$ & uniform between -1 and +3.5 & \pmlogrsexpanded '+r'& 2D halflight radius (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\log_{10}[\Sigma_{0,2}/(\mathrm{arcmin}^{-2})]$ & uniform between -10 and +10 & \pmbigsigmabexpanded '+r'& 2D stellar density (foreground)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$k_2 [\mathrm{arcmin}^{-1}]$ & uniform between 0 and +0.1 & \pmbigsigmagradexpanded '+r'& pm in 2D stellar density (foreground)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\theta_2$ [deg.] & uniform between -180 and +180 & \pmgradthetaexpanded '+r'& direction of pm in 2D stellar density (foreground)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\sigma_{v_{\rm los}}$ [km s$^{-1}$] && \pmvdispexpanded '+r'& velocity dispersion (Cra2)' +r'\\'+'\n')
g2.write(r'\smallskip'+'\n')
g2.write(r'$\sigma_{\feh}$ [dex] && \pmfehdispexpanded '+r'& metallicity dispersion (Cra2)' +r'\\'+'\n')
g2.write(r'$R_{\rm h}$ [arcmin] && \pmrsexpanded '+r'& 2D halflight radius (Cra2)' +r'\\'+'\n')

g2.write(r'\hline'+'\n')
g2.write(r'\end{tabular}'+'\n')
g2.write(r'\\'+'\n')
g2.write(r'\label{tab:cra2_pm}'+'\n')
g2.write(r'\end{table*}'+'\n')



g1.close()
g2.close()
plotfilename='cra2pm.pdf'
plt.savefig(plotfilename,dpi=400)
plt.show()
plt.close()
