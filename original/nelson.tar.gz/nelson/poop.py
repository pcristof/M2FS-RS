gs=plt.GridSpec(10,10) # define multi-panel plot
gs.update(wspace=0,hspace=0) # specify inter-panel spacing
fig=plt.figure(figsize=(6,6)) # define plot size
ax1=fig.add_subplot(gs[0:5,0:5])
ax2=fig.add_subplot(gs[0:5,5:10])

rtide=160.2/60.
ellipticity=0.29
width=rtide
height=rtide*(1.-ellipticity)
angle=56.7

ax1.scatter(x[keepnogaia],y[keepnogaia],s=3,color='k',alpha=0.3,label='foreground')
ax1.scatter(x[keepnogaiamem],y[keepnogaiamem],s=3,color='r',alpha=0.6,label='member')
ax1.set_xlim([1.9,-1.9])
ax1.set_ylim([-1.9,1.9])
ax1.set_ylabel(r'$\Delta$ Dec. [deg]')
ax1.set_xlabel(r'$\Delta$ R.A. [deg]')
ax1.text(2.,2.1,'Sextans')
ax1.text(-0.8,1.65,'pre-Gaia')
ellipse1=matplotlib.patches.Ellipse((0,0),width,height,angle,fill=False)
ax1.add_artist(ellipse1)
ax1.legend(loc=3,fontsize=8)

ax2.scatter(x[keepgaia],y[keepgaia],s=3,color='k',alpha=0.3)
ax2.scatter(x[keepgaiamem],y[keepgaiamem],s=3,color='r',alpha=0.6)
ax2.set_xlim([1.9,-1.9])
ax2.set_ylim([-1.9,1.9])
ax2.set_xlabel(r'$\Delta$ R.A. [deg]')
ax2.text(-0.7,1.65,'post-Gaia')
ellipse2=matplotlib.patches.Ellipse((0,0),width,height,angle,fill=False)
ax2.add_artist(ellipse2)
ax2.yaxis.set_major_formatter(plt.NullFormatter())

plt.savefig('nelson_sextans.pdf',dpi=200)
plt.show()
plt.close()
