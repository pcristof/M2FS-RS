import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import scipy
import mycode
matplotlib.use('TkAgg')
#matplotlib.use('pdf')

with open('/verafs/scratch/phy200028p/mgwalker/mycode/jeans.profile') as f:
    data=f.readlines()
rad=[]
bigs=[]
bigsigma=[]
rho=[]
mass=[]
ani=[]
sigmalos=[]
sigmarad=[]
sigmatan=[]
for line in data:
    p=line.split()
    rad.append(float(p[0]))
    bigs.append(float(p[1]))
    bigsigma.append(float(p[2]))
    rho.append(float(p[3]))
    mass.append(float(p[4]))
    ani.append(float(p[5]))
    sigmalos.append(float(p[6]))
    sigmarad.append(float(p[7]))
    sigmatan.append(float(p[8]))
rad=np.array(rad)
bigs=np.array(bigs)
bigsigma=np.array(bigsigma)
rho=np.array(rho)
mass=np.array(mass)
ani=np.array(ani)
sigmalos=np.array(sigmalos)
sigmarad=np.array(sigmarad)
sigmatan=np.array(sigmatan)

plt.plot(bigs,sigmatan)
#plt.xlim([0.1,1.e5])
#plt.ylim([])
plt.xscale('log')
plt.yscale('log')

plt.show()
plt.close()
